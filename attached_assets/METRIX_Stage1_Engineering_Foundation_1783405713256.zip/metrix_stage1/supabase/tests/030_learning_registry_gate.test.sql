-- supabase/tests/030_learning_registry_gate.test.sql
--
-- The "learning registry write requires approval" rule is enforced across
-- TWO layers, not one, and this test only covers the RLS layer:
--   1. RLS (this file): no authenticated-role insert policy exists on
--      learning_registry at all (004_review_approval_learning_policies.sql)
--      — an authenticated user cannot write here under any circumstances.
--   2. Application guard (packages/db/src/__tests__/db.test.ts): the
--      service-role client itself refuses to write unless
--      validateLearningRegistryApproval (packages/metrix-core) confirms a
--      real approval_events row with approved_for = 'learning_registry'.
--
-- KNOWN GAP, flagged rather than silently fixed: migration 0007 does not
-- have a NOT NULL / CHECK constraint forcing approval_event_id to reference
-- a row with approved_for = 'learning_registry' at the database level, so a
-- service-role write that skipped the application guard would not be
-- stopped by Postgres alone. Closing this gap means either a NOT NULL
-- constraint (already present) plus a trigger validating approved_for, or
-- accepting the two-layer model as sufficient — that's a decision for Alex,
-- not something to retroactively bolt onto an already-shipped migration
-- without sign-off.
begin;
select plan(2);

insert into organizations (id, name) values ('00000000-0000-0000-0000-00000000000c', 'Test Org 3');
insert into clients (id, org_id, name, client_code)
  values ('00000000-0000-0000-0000-0000000000c1', '00000000-0000-0000-0000-00000000000c', 'Client D', 'CLID');
insert into client_memberships (client_id, user_id, org_id, role)
  values ('00000000-0000-0000-0000-0000000000c1', '00000000-0000-0000-0000-000000000003', '00000000-0000-0000-0000-00000000000c', 'owner');

set local role authenticated;
set local request.jwt.claim.sub = '00000000-0000-0000-0000-000000000003';

select throws_ok(
  $$ insert into learning_registry (client_id, source_object_type, source_object_id, learning_summary, contract_version, schema_version)
     values ('00000000-0000-0000-0000-0000000000c1', 'intelligence_card', gen_random_uuid(), 'test', 'v1', 'v1') $$,
  '42501',
  null,
  'authenticated role has no insert policy on learning_registry — RLS blocks it outright'
);

reset role;

select is(
  (select count(*)::int from pg_policies where tablename = 'learning_registry' and cmd = 'INSERT'),
  0,
  'no INSERT policy exists on learning_registry for any role — confirms the "service-role + application guard only" design'
);

select * from finish();
rollback;
