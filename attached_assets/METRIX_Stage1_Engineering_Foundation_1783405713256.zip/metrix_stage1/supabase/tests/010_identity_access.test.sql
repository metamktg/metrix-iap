-- supabase/tests/010_identity_access.test.sql
-- Exercises 001_identity_access_policies.sql directly: a user with a
-- client_memberships row for Client A can read Client A but never Client B,
-- and vice versa. Uses the standard Supabase pgTAP pattern of impersonating
-- a JWT via request.jwt.claim.sub + `set local role authenticated`.
begin;
select plan(4);

insert into organizations (id, name) values ('00000000-0000-0000-0000-00000000000a', 'Test Org');

insert into clients (id, org_id, name, client_code) values
  ('00000000-0000-0000-0000-0000000000a1', '00000000-0000-0000-0000-00000000000a', 'Client A', 'CLIA'),
  ('00000000-0000-0000-0000-0000000000a2', '00000000-0000-0000-0000-00000000000a', 'Client B', 'CLIB');

insert into client_memberships (client_id, user_id, org_id, role) values
  ('00000000-0000-0000-0000-0000000000a1', '00000000-0000-0000-0000-000000000001', '00000000-0000-0000-0000-00000000000a', 'owner'),
  ('00000000-0000-0000-0000-0000000000a2', '00000000-0000-0000-0000-000000000002', '00000000-0000-0000-0000-00000000000a', 'owner');

-- Impersonate user 1 (Client A member only).
set local role authenticated;
set local request.jwt.claim.sub = '00000000-0000-0000-0000-000000000001';

select is(
  (select count(*)::int from clients where id = '00000000-0000-0000-0000-0000000000a1'),
  1,
  'user 1 CAN read their own assigned client (Client A)'
);

select is(
  (select count(*)::int from clients where id = '00000000-0000-0000-0000-0000000000a2'),
  0,
  'user 1 CANNOT read Client B — no client_memberships row for them there'
);

reset role;

-- Impersonate user 2 (Client B member only) — the reverse case.
set local role authenticated;
set local request.jwt.claim.sub = '00000000-0000-0000-0000-000000000002';

select is(
  (select count(*)::int from clients where id = '00000000-0000-0000-0000-0000000000a2'),
  1,
  'user 2 CAN read their own assigned client (Client B)'
);

select is(
  (select count(*)::int from clients where id = '00000000-0000-0000-0000-0000000000a1'),
  0,
  'user 2 CANNOT read Client A — org_members alone would have granted this incorrectly; client_memberships is the only gate'
);

reset role;
select * from finish();
rollback;
