-- supabase/tests/000_schema_smoke.test.sql
-- Run via `supabase test db`. Confirms migrations + policies apply cleanly
-- and that RLS is actually enabled where it must be — this is the automated
-- form of the Stage 1 "fresh migration applies cleanly" success criterion.
begin;
select plan(6);

select has_table('public', 'clients', 'clients table exists after migrations');
select has_table('public', 'global_variable_registry', 'global_variable_registry table exists (migration 0009)');
select has_table('public', 'learning_registry', 'learning_registry table exists');

select row_security_is_enabled('public', 'clients', 'RLS is enabled on clients');
select row_security_is_enabled('public', 'bsil_suggestions', 'RLS is enabled on bsil_suggestions');
select row_security_is_enabled('public', 'learning_registry', 'RLS is enabled on learning_registry');

select * from finish();
rollback;
