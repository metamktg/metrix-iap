-- supabase/tests/020_alert_bsil_constraints.test.sql
-- Exercises the two hard schema-level constraints from migration 0006:
-- no ROAS-based v1 alert trigger, and BSIL suggestions scoped only to
-- campaign/ad_set. These run as postgres (bypassing RLS) specifically to
-- prove the CHECK constraints themselves reject bad data regardless of who's
-- asking — this is the layer beneath RLS and beneath the metrix-core
-- application guard, so it needs its own direct test.
begin;
select plan(4);

insert into organizations (id, name) values ('00000000-0000-0000-0000-00000000000b', 'Test Org 2');
insert into clients (id, org_id, name, client_code)
  values ('00000000-0000-0000-0000-0000000000b1', '00000000-0000-0000-0000-00000000000b', 'Client C', 'CLIC');

select throws_ok(
  $$ insert into alert_rules (client_id, metric) values ('00000000-0000-0000-0000-0000000000b1', 'roas') $$,
  '23514',
  null,
  'alert_rules rejects metric = ''roas'' at the schema level'
);

select lives_ok(
  $$ insert into alert_rules (client_id, metric) values ('00000000-0000-0000-0000-0000000000b1', 'cost_per_purchase') $$,
  'alert_rules accepts a non-roas metric'
);

select throws_ok(
  $$ insert into bsil_suggestions (client_id, budget_scope_object, entity_id, scope_key, suggestion_type, confidence_grade, contract_version, schema_version)
     values ('00000000-0000-0000-0000-0000000000b1', 'creative', gen_random_uuid(), 'scope-1', 'scale', 'HIGH', 'v1', 'v1') $$,
  '23514',
  null,
  'bsil_suggestions rejects budget_scope_object = ''creative'' at the schema level'
);

select lives_ok(
  $$ insert into bsil_suggestions (client_id, budget_scope_object, entity_id, scope_key, suggestion_type, confidence_grade, contract_version, schema_version)
     values ('00000000-0000-0000-0000-0000000000b1', 'campaign', gen_random_uuid(), 'scope-1', 'scale', 'HIGH', 'v1', 'v1') $$,
  'bsil_suggestions accepts budget_scope_object = ''campaign'''
);

select * from finish();
rollback;
