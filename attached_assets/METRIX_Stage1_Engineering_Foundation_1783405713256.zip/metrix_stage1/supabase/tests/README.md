# Supabase database/security tests (pgTAP)

Run via `supabase test db` (see `.github/workflows/ci.yml` — this is the
`supabase-migrations` job's final step, gating on migrations applying
cleanly first).

| File | Covers |
|---|---|
| `000_schema_smoke.test.sql` | Fresh migration applies cleanly; RLS is actually enabled on key tables. |
| `010_identity_access.test.sql` | Cross-client read rejection / assigned-client read success — the `client_memberships`-only rule. |
| `020_alert_bsil_constraints.test.sql` | No-ROAS-v1-alert-trigger constraint; BSIL budget-scope constraint (`campaign`/`ad_set` only). |
| `030_learning_registry_gate.test.sql` | No client-facing insert path exists on `learning_registry` at all. |

## Two layers, tested in two places

The "learning registry write requires approval" and "BSIL suggestions can't
target creative" rules are each enforced at more than one layer:

- **RLS + schema constraints** — tested here, in this directory.
- **Application-layer guards** (`packages/metrix-core`'s
  `rejectCreativeLevelBudgetSuggestion` and
  `validateLearningRegistryApproval`, called from `packages/db`) — tested in
  `packages/db/src/__tests__/db.test.ts` and
  `packages/metrix-core/src/__tests__/metrix-core.test.ts`.

Both layers need their own tests; one passing doesn't imply the other does.

## Known gap

`030_learning_registry_gate.test.sql` documents a real gap: migration 0007
has no database-level constraint tying `approval_event_id` to a row with
`approved_for = 'learning_registry'`. Today that rule is enforced only by
(a) RLS blocking all authenticated-role inserts and (b) the application
guard in `packages/db`. Closing it fully would mean a trigger or additional
constraint on an already-shipped migration — flagged for Alex's sign-off,
not fixed unilaterally here.

## Not yet built

`tests/integration/` and `tests/e2e/` remain placeholders — out of Stage 1
scope per the briefing (Stage 1 requires "basic security tests exist," not
full integration/e2e coverage).
