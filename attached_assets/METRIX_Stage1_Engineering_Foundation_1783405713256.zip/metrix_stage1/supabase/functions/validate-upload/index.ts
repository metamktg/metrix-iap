// supabase/functions/validate-upload/index.ts
//
// Entry point for manual CSV/pivot-export uploads (packages/connectors'
// manualUploadConnector). Runs the full tenancy guard, then hands off to
// IAP_DATA_BUNDLE_PREP intake-quality checks. The actual bundle-prep logic is
// Stage 2 — this stub proves the guard sequence and the request/response
// contract only.
import { GuardError, runFullGuard } from "../_shared/authGuard.ts";

interface ValidateUploadRequest {
  client_id: string;
  cohort_key: string;
  source_file: string;
}

Deno.serve(async (req: Request) => {
  try {
    const body: ValidateUploadRequest = await req.json();
    if (!body.client_id || !body.cohort_key || !body.source_file) {
      return new Response(
        JSON.stringify({ error: "client_id, cohort_key, and source_file are required." }),
        { status: 400 },
      );
    }

    const { serviceClient: _serviceClient } = await runFullGuard({
      req,
      clientId: body.client_id,
    });

    // TODO (Stage 2): run packages/connectors' manualUploadConnector against
    // the uploaded rows, then packages/metrix-core's creative-resolution
    // pipeline, then persist an analysis_run_inputs row via
    // packages/db/analysisRunsRepo using _serviceClient.
    return new Response(
      JSON.stringify({
        status: "stub",
        message: "Guard passed. Upload validation logic is Stage 2 work.",
      }),
      { status: 200, headers: { "Content-Type": "application/json" } },
    );
  } catch (err) {
    if (err instanceof GuardError) {
      return new Response(JSON.stringify({ error: err.message }), { status: err.status });
    }
    return new Response(JSON.stringify({ error: "Unexpected error." }), { status: 500 });
  }
});
