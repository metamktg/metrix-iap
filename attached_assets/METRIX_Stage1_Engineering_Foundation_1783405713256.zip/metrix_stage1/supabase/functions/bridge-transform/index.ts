// supabase/functions/bridge-transform/index.ts
//
// Transforms a validated data bundle (IAPDataBundleOutput) between pipeline
// stages when a shape mismatch needs reconciling — e.g. adapting an older
// stored analysis_run's stage output to the current prompt version's
// expected input shape, using promptVersions.isCurrentPromptVersion
// (packages/iap-engine) to detect the mismatch. Guard-first, same pattern.
import { GuardError, runFullGuard } from "../_shared/authGuard.ts";

interface BridgeTransformRequest {
  client_id: string;
  analysis_run_id: string;
  from_stage: string;
  to_stage: string;
}

Deno.serve(async (req: Request) => {
  try {
    const body: BridgeTransformRequest = await req.json();
    if (!body.client_id || !body.analysis_run_id || !body.from_stage || !body.to_stage) {
      return new Response(
        JSON.stringify({ error: "client_id, analysis_run_id, from_stage, and to_stage are required." }),
        { status: 400 },
      );
    }

    const { serviceClient: _serviceClient } = await runFullGuard({
      req,
      clientId: body.client_id,
      objectCheck: { table: "analysis_runs", objectId: body.analysis_run_id },
    });

    // TODO (Stage 2): load the from_stage output via analysisRunStagesRepo,
    // check prompt-version compatibility (packages/iap-engine/promptVersions),
    // and re-shape as needed before handing to to_stage.
    return new Response(
      JSON.stringify({
        status: "stub",
        message: "Guard passed. Bridge-transform logic is Stage 2 work.",
      }),
      { status: 200, headers: { "Content-Type": "application/json" } },
    );
  } catch (err) {
    if (err instanceof GuardError) {
      return new Response(JSON.stringify({ error: err.message }), { status: err.status });
    }
    return new Response(JSON.stringify({ error: "Unexpected error." }), { status: 500 });
  }
});
