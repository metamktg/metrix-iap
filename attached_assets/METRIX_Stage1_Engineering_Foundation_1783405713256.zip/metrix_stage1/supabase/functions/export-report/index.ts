// supabase/functions/export-report/index.ts
//
// Generates a client-facing or executive-summary report (reports table) from
// approved intelligence_cards for a given analysis_run. Guard-first — the
// object check here verifies the analysis_run belongs to the client before
// anything is exported.
import { GuardError, runFullGuard } from "../_shared/authGuard.ts";

interface ExportReportRequest {
  client_id: string;
  analysis_run_id: string;
  report_type: "internal" | "client_facing" | "executive_summary";
}

Deno.serve(async (req: Request) => {
  try {
    const body: ExportReportRequest = await req.json();
    if (!body.client_id || !body.analysis_run_id || !body.report_type) {
      return new Response(
        JSON.stringify({ error: "client_id, analysis_run_id, and report_type are required." }),
        { status: 400 },
      );
    }

    const { serviceClient: _serviceClient } = await runFullGuard({
      req,
      clientId: body.client_id,
      objectCheck: { table: "analysis_runs", objectId: body.analysis_run_id },
    });

    // TODO (Stage 2): run IAP_REPORT_SUMMARY (packages/iap-engine) over this
    // run's approved intelligence_cards, validate against reportSchema
    // (packages/schemas), and insert via packages/db/reportsRepo.
    return new Response(
      JSON.stringify({
        status: "stub",
        message: "Guard passed. Report export logic is Stage 2 work.",
      }),
      { status: 200, headers: { "Content-Type": "application/json" } },
    );
  } catch (err) {
    if (err instanceof GuardError) {
      return new Response(JSON.stringify({ error: err.message }), { status: err.status });
    }
    return new Response(JSON.stringify({ error: "Unexpected error." }), { status: 500 });
  }
});
