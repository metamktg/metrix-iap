// supabase/functions/resolve-creatives/index.ts
//
// Runs packages/metrix-core's resolveCreativeIdentity over a batch of
// NormalizedRecords for a client's analysis run. Naming-convention parse is
// primary, ad_id is fallback — never invents a creative_id. Guard-first.
import { GuardError, runFullGuard } from "../_shared/authGuard.ts";

interface ResolveCreativesRequest {
  client_id: string;
  analysis_run_id: string;
}

Deno.serve(async (req: Request) => {
  try {
    const body: ResolveCreativesRequest = await req.json();
    if (!body.client_id || !body.analysis_run_id) {
      return new Response(
        JSON.stringify({ error: "client_id and analysis_run_id are required." }),
        { status: 400 },
      );
    }

    const { serviceClient: _serviceClient } = await runFullGuard({
      req,
      clientId: body.client_id,
      objectCheck: { table: "analysis_runs", objectId: body.analysis_run_id },
    });

    // TODO (Stage 2): fetch this run's analysis_run_inputs, run each
    // NormalizedRecord through packages/metrix-core's
    // resolveCreativeIdentity, and persist resolution results back onto the
    // run's working data (exact destination table is a Stage 2 design
    // decision — flagged here rather than invented).
    return new Response(
      JSON.stringify({
        status: "stub",
        message: "Guard passed. Creative resolution logic is Stage 2 work.",
      }),
      { status: 200, headers: { "Content-Type": "application/json" } },
    );
  } catch (err) {
    if (err instanceof GuardError) {
      return new Response(JSON.stringify({ error: err.message }), { status: err.status });
    }
    return new Response(JSON.stringify({ error: "Unexpected error." }), { status: 500 });
  }
});
