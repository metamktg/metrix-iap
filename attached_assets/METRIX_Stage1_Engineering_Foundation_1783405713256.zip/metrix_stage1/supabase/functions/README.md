# Supabase Edge Functions

Six functions, all guard-first per the Stage 1 briefing's required pattern:

```
verify caller identity
verify org membership
verify client access
verify requested object belongs to client/org
only then write with service role
```

`_shared/authGuard.ts` implements this sequence once (`runFullGuard`) — every
function below calls it rather than re-implementing the check.

| Function | Purpose | Stage |
|---|---|---|
| `validate-upload` | Entry point for manual CSV/pivot uploads → `IAP_DATA_BUNDLE_PREP` intake checks | guard done, logic Stage 2 |
| `run-pipeline` | Triggers a full `runIAPChain` execution for a client + cohort | guard done, logic Stage 2 |
| `bridge-transform` | Reconciles a stage output shape against a newer prompt version | guard done, logic Stage 2 |
| `resolve-creatives` | Runs `resolveCreativeIdentity` over a run's normalized records | guard done, logic Stage 2 |
| `export-report` | Generates a `reports` row from approved `intelligence_cards` | guard done, logic Stage 2 |
| `severity-scheduler` | Scheduled (cron), not user-triggered — evaluates `alert_rules` | guard N/A (see below), logic Stage 2 |

## `severity-scheduler` is different

It's invoked by `pg_cron` / a Supabase scheduled trigger, not by a user
request — there's no caller JWT, so the four-step guard doesn't apply. It
runs as the service role across all clients, which means:

- Every real query it makes must explicitly scope by `client_id` in code —
  there's no RLS backstop when using the service-role client.
- The no-ROAS-v1-alert-trigger rule is re-asserted in code
  (`.neq("metric", "roas")`) as a second layer on top of the migration 0006
  check constraint, since an unattended scheduled job has no other backstop
  if a bug ever bypassed the constraint.

## What's stubbed vs. real

The guard sequence, request validation, and error handling in every function
are real, working code. The actual business logic after the guard (the
`TODO (Stage 2)` comments) is intentionally not implemented yet — Stage 1's
job was the tenancy-guard structure and request/response contracts, not the
pipeline logic itself.
