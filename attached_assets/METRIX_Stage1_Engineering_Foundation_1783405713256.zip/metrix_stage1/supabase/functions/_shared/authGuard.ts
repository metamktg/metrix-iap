// supabase/functions/_shared/authGuard.ts
//
// Every Edge Function in this repo runs the SAME four-step guard before
// touching the service-role client, per the Stage 1 briefing:
//   1. verify caller identity
//   2. verify org membership
//   3. verify client access
//   4. verify the requested object belongs to that client/org
// Only after all four pass does a function construct a service-role client
// and write. This file is the one place that sequence is implemented — no
// function should hand-roll its own version of it.
import { createClient, type SupabaseClient } from "npm:@supabase/supabase-js@2";

export interface GuardEnv {
  SUPABASE_URL: string;
  SUPABASE_ANON_KEY: string;
  SUPABASE_SERVICE_ROLE_KEY: string;
}

export interface GuardResult {
  userId: string;
  /** A client scoped to the caller's own JWT — respects RLS, use for reads that should be tenant-bounded. */
  userClient: SupabaseClient;
  /** Bypasses RLS. Only touch this AFTER step 4 (object-belongs-to-client) has been verified for this specific request. */
  serviceClient: SupabaseClient;
}

export class GuardError extends Error {
  status: number;
  constructor(message: string, status = 403) {
    super(message);
    this.status = status;
  }
}

function getEnv(): GuardEnv {
  const SUPABASE_URL = Deno.env.get("SUPABASE_URL");
  const SUPABASE_ANON_KEY = Deno.env.get("SUPABASE_ANON_KEY");
  const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  if (!SUPABASE_URL || !SUPABASE_ANON_KEY || !SUPABASE_SERVICE_ROLE_KEY) {
    throw new GuardError("Missing required Supabase env vars for this function.", 500);
  }
  return { SUPABASE_URL, SUPABASE_ANON_KEY, SUPABASE_SERVICE_ROLE_KEY };
}

/** Step 1 + 2: verify caller identity and return a user-scoped client (org membership is enforced by RLS on the tables that client queries). */
export async function verifyCallerIdentity(req: Request): Promise<{ userId: string; userClient: SupabaseClient }> {
  const env = getEnv();
  const authHeader = req.headers.get("Authorization");
  if (!authHeader) {
    throw new GuardError("Missing Authorization header.", 401);
  }

  const userClient = createClient(env.SUPABASE_URL, env.SUPABASE_ANON_KEY, {
    global: { headers: { Authorization: authHeader } },
  });

  const { data, error } = await userClient.auth.getUser();
  if (error || !data.user) {
    throw new GuardError("Could not verify caller identity from the provided token.", 401);
  }

  return { userId: data.user.id, userClient };
}

/** Step 3: verify the caller has client_memberships access to this specific client. RLS on client_memberships enforces this at the query level; this is the explicit application-layer check the briefing requires before any service-role write. */
export async function verifyClientAccess(userClient: SupabaseClient, clientId: string): Promise<void> {
  const { data, error } = await userClient
    .from("client_memberships")
    .select("id")
    .eq("client_id", clientId)
    .maybeSingle();

  if (error) throw new GuardError(`Client access check failed: ${error.message}`, 500);
  if (!data) throw new GuardError(`Caller does not have access to client ${clientId}.`, 403);
}

/** Step 4: verify a specific object (by table + id) actually belongs to the client being acted on, before any service-role write touches it. */
export async function verifyObjectBelongsToClient(
  userClient: SupabaseClient,
  table: string,
  objectId: string,
  clientId: string,
): Promise<void> {
  const { data, error } = await userClient
    .from(table)
    .select("id")
    .eq("id", objectId)
    .eq("client_id", clientId)
    .maybeSingle();

  if (error) throw new GuardError(`Object ownership check failed: ${error.message}`, 500);
  if (!data) throw new GuardError(`Object ${objectId} in ${table} does not belong to client ${clientId}.`, 403);
}

/** Runs the full four-step guard and only then returns a service-role client, ready for the function's actual write. */
export async function runFullGuard(args: {
  req: Request;
  clientId: string;
  objectCheck?: { table: string; objectId: string };
}): Promise<GuardResult> {
  const env = getEnv();
  const { userId, userClient } = await verifyCallerIdentity(args.req);
  await verifyClientAccess(userClient, args.clientId);
  if (args.objectCheck) {
    await verifyObjectBelongsToClient(userClient, args.objectCheck.table, args.objectCheck.objectId, args.clientId);
  }

  const serviceClient = createClient(env.SUPABASE_URL, env.SUPABASE_SERVICE_ROLE_KEY, {
    auth: { persistSession: false },
  });

  return { userId, userClient, serviceClient };
}
