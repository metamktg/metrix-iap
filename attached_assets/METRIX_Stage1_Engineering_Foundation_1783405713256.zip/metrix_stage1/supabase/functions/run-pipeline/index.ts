// supabase/functions/run-pipeline/index.ts
//
// Triggers a full IAP chain run (packages/iap-engine's runIAPChain) for a
// client + cohort. Guard-first, same as every function in this directory.
// The actual chain execution (calling out to the Anthropic API per stage) is
// Stage 2 work — this stub proves the request contract and guard sequence.
import { GuardError, runFullGuard } from "../_shared/authGuard.ts";

interface RunPipelineRequest {
  client_id: string;
  cohort_key: string;
  analysis_run_id?: string;
}

Deno.serve(async (req: Request) => {
  try {
    const body: RunPipelineRequest = await req.json();
    if (!body.client_id || !body.cohort_key) {
      return new Response(
        JSON.stringify({ error: "client_id and cohort_key are required." }),
        { status: 400 },
      );
    }

    const objectCheck = body.analysis_run_id
      ? { table: "analysis_runs", objectId: body.analysis_run_id }
      : undefined;

    const { serviceClient: _serviceClient } = await runFullGuard({
      req,
      clientId: body.client_id,
      objectCheck,
    });

    // TODO (Stage 2): resolveActiveCohorts + createRunCohortSnapshot
    // (packages/metrix-core), createRunWithCohortSnapshot
    // (packages/db/analysisRunsRepo), then packages/iap-engine's
    // runIAPChain with a real Anthropic API executor, persisting stage
    // records via analysisRunStagesRepo as they complete.
    return new Response(
      JSON.stringify({
        status: "stub",
        message: "Guard passed. Pipeline execution logic is Stage 2 work.",
      }),
      { status: 200, headers: { "Content-Type": "application/json" } },
    );
  } catch (err) {
    if (err instanceof GuardError) {
      return new Response(JSON.stringify({ error: err.message }), { status: err.status });
    }
    return new Response(JSON.stringify({ error: "Unexpected error." }), { status: 500 });
  }
});
