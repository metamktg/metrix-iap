// supabase/functions/severity-scheduler/index.ts
//
// Unlike the other five functions, this one is invoked on a schedule
// (pg_cron / Supabase scheduled function), not by an authenticated user
// request — there's no caller JWT to run the four-step guard against. It
// necessarily runs as the service role across all clients' alert_rules, so
// the tenancy discipline here is different: every query in the eventual
// implementation MUST explicitly scope by client_id in application code
// (there's no RLS backstop when using the service-role client), and the
// no-ROAS-v1-alert-trigger rule must be enforced in code here too, not just
// relied on via the migration 0006 check constraint, since a bug that
// bypasses the constraint (e.g. a raw SQL function) would otherwise have no
// second layer of defense in an unattended scheduled job.
import { createClient } from "npm:@supabase/supabase-js@2";

Deno.serve(async (_req: Request) => {
  const SUPABASE_URL = Deno.env.get("SUPABASE_URL");
  const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
    return new Response(JSON.stringify({ error: "Missing Supabase env vars." }), { status: 500 });
  }

  const serviceClient = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, {
    auth: { persistSession: false },
  });

  // Defense-in-depth: even though migration 0006 already has
  // check (metric <> 'roas'), a scheduled service-role job re-asserts it in
  // code before acting on any rule, since there's no RLS backstop here.
  const { data: rules, error } = await serviceClient
    .from("alert_rules")
    .select("*")
    .neq("metric", "roas");

  if (error) {
    return new Response(JSON.stringify({ error: error.message }), { status: 500 });
  }

  // TODO (Stage 2): for each client-scoped rule, evaluate threshold_config
  // against fresh metrics and write intelligence_cards (severity field) for
  // any breach. Explicitly loop per client_id — never a cross-client batch
  // query — since there is no RLS boundary protecting this service-role path.
  return new Response(
    JSON.stringify({
      status: "stub",
      rules_considered: rules?.length ?? 0,
      message: "Severity evaluation logic is Stage 2 work.",
    }),
    { status: 200, headers: { "Content-Type": "application/json" } },
  );
});
