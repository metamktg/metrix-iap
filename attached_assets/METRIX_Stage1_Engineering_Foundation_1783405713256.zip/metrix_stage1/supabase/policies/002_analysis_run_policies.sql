-- METRIX IAP — Policy 002: Analysis run policies (Blueprint v2.0 §11.2)
--
-- All four tables here (analysis_runs, analysis_run_cohorts,
-- analysis_run_inputs, analysis_run_stages) are scoped through
-- has_client_access(). The three child tables have no client_id column of
-- their own — they join through analysis_run_id to inherit the same
-- boundary, so a client's run history can never leak into another client's
-- view via a child table even if the parent policy were somehow bypassed.

alter table analysis_runs enable row level security;
alter table analysis_run_cohorts enable row level security;
alter table analysis_run_inputs enable row level security;
alter table analysis_run_stages enable row level security;

create policy analysis_runs_select on analysis_runs
  for select using (has_client_access(client_id));

-- Runs are triggered by owner/operator roles (client_viewer is read-only
-- throughout this policy set).
create policy analysis_runs_insert on analysis_runs
  for insert with check (
    has_client_access(client_id) and client_role(client_id) in ('owner', 'operator')
  );

create policy analysis_runs_update on analysis_runs
  for update using (
    has_client_access(client_id) and client_role(client_id) in ('owner', 'operator')
  ) with check (
    has_client_access(client_id) and client_role(client_id) in ('owner', 'operator')
  );

create policy analysis_run_cohorts_select on analysis_run_cohorts
  for select using (
    exists (
      select 1 from analysis_runs
      where analysis_runs.id = analysis_run_cohorts.analysis_run_id
        and has_client_access(analysis_runs.client_id)
    )
  );

-- Cohort snapshots are written once, at run creation, by the pipeline —
-- never edited by client-facing roles afterward (mutating a historical
-- snapshot would defeat its entire purpose).
create policy analysis_run_cohorts_insert on analysis_run_cohorts
  for insert with check (
    exists (
      select 1 from analysis_runs
      where analysis_runs.id = analysis_run_cohorts.analysis_run_id
        and has_client_access(analysis_runs.client_id)
        and client_role(analysis_runs.client_id) in ('owner', 'operator')
    )
  );

create policy analysis_run_inputs_select on analysis_run_inputs
  for select using (
    exists (
      select 1 from analysis_runs
      where analysis_runs.id = analysis_run_inputs.analysis_run_id
        and has_client_access(analysis_runs.client_id)
    )
  );

create policy analysis_run_inputs_insert on analysis_run_inputs
  for insert with check (
    exists (
      select 1 from analysis_runs
      where analysis_runs.id = analysis_run_inputs.analysis_run_id
        and has_client_access(analysis_runs.client_id)
        and client_role(analysis_runs.client_id) in ('owner', 'operator')
    )
  );

create policy analysis_run_stages_select on analysis_run_stages
  for select using (
    exists (
      select 1 from analysis_runs
      where analysis_runs.id = analysis_run_stages.analysis_run_id
        and has_client_access(analysis_runs.client_id)
    )
  );

-- Stage rows are written exclusively by the pipeline (apps/worker via the
-- service-role client), never by an authenticated client-facing role. No
-- insert/update policy is granted here on purpose — service_role bypasses
-- RLS entirely, so this table is effectively write-only-by-backend.
