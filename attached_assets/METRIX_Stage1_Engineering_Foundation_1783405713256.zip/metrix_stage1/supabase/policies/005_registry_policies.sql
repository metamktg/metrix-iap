-- METRIX IAP — Policy 005: Registry policies (Blueprint v2.0 §6.2, §11.2/§16)
--
-- Two different trust levels in this file:
--   - cohort_definitions and global_variable_registry are GLOBAL config-as-data
--     (a new cohort or variable is a new row, never a schema change per the
--     additive-only principle). Every authenticated user may read them;
--     nobody writes them through the client-facing anon/JWT path — only the
--     service role, via a controlled registry-maintenance function.
--   - client_enabled_cohorts is per-client config the Settings checklist
--     (Plane 4) reads AND WRITES directly, so owner/operator get real INSERT/
--     UPDATE here, unlike the two global tables.

alter table cohort_definitions enable row level security;
alter table client_enabled_cohorts enable row level security;
alter table global_variable_registry enable row level security;

-- Global, read-only registries: any authenticated user may read.
create policy cohort_definitions_select on cohort_definitions
  for select using (auth.role() = 'authenticated');
-- No insert/update/delete policy: registry additions are config-as-data
-- changes shipped as migrations/seed, or via a guarded service-role
-- maintenance function — never directly from a client session.

create policy global_variable_registry_select on global_variable_registry
  for select using (auth.role() = 'authenticated');
-- Same rule: deprecation and new-code rows are service-role/migration only.

-- client_enabled_cohorts: this IS client-facing config, unlike the two global
-- registries above. owner/operator read and write directly; client_viewer is
-- read-only, matching the role split used everywhere else in this policy set.
create policy client_enabled_cohorts_select on client_enabled_cohorts
  for select using (has_client_access(client_id));

create policy client_enabled_cohorts_manage on client_enabled_cohorts
  for all using (
    has_client_access(client_id) and client_role(client_id) in ('owner', 'operator')
  ) with check (
    has_client_access(client_id) and client_role(client_id) in ('owner', 'operator')
    -- cohort_key must reference an existing cohort_definitions row — already
    -- enforced by the migration 0002 foreign key; not re-litigated here.
  );
