-- METRIX IAP — Policy 001: Identity and access (Blueprint v2.0 §11.1)
--
-- Non-negotiable rule from migration 0001: org_members governs ORG-level
-- membership/admin actions only. client_memberships is the SINGLE source of
-- truth for CLIENT-level data visibility. Never both — a query must never
-- grant client data access via org_members alone.
--
-- This file defines the two helper functions every later policy file calls,
-- plus RLS for the identity tables themselves (organizations, org_members,
-- clients, client_memberships).

alter table organizations enable row level security;
alter table org_members enable row level security;
alter table clients enable row level security;
alter table client_memberships enable row level security;

-- Is the current user an org_members admin of this org? Used only for
-- org-level actions (e.g. creating a client record), never for reading a
-- client's data.
create or replace function is_org_admin(check_org_id uuid)
returns boolean
language sql
security definer
stable
as $$
  select exists (
    select 1 from org_members
    where org_id = check_org_id
      and user_id = auth.uid()
      and role = 'admin'
  );
$$;

-- The one and only gate for "can this user see this client's data".
create or replace function has_client_access(check_client_id uuid)
returns boolean
language sql
security definer
stable
as $$
  select exists (
    select 1 from client_memberships
    where client_id = check_client_id
      and user_id = auth.uid()
  );
$$;

-- Role within a client, for policies that differentiate owner/operator from
-- client_viewer (e.g. who may approve, who may only read).
create or replace function client_role(check_client_id uuid)
returns text
language sql
security definer
stable
as $$
  select role from client_memberships
  where client_id = check_client_id
    and user_id = auth.uid()
  limit 1;
$$;

-- organizations: visible to members of that org only.
create policy organizations_select on organizations
  for select using (
    exists (select 1 from org_members where org_id = organizations.id and user_id = auth.uid())
  );

-- org_members: a user can see their own membership rows; org admins can see
-- and manage all membership rows for their org.
create policy org_members_select_self on org_members
  for select using (user_id = auth.uid() or is_org_admin(org_id));

create policy org_members_manage_admin on org_members
  for all using (is_org_admin(org_id))
  with check (is_org_admin(org_id));

-- clients: visibility is via client_memberships ONLY (per the non-negotiable
-- rule above) — org_members membership alone does not grant this.
create policy clients_select_via_membership on clients
  for select using (has_client_access(id));

-- Creating a client is an org-level action (org admins provision new
-- clients); this does NOT itself grant data access — a client_memberships
-- row must be created separately (service-role function
-- validate-upload / an onboarding function) for anyone, including the
-- creator, to subsequently read the client's data.
create policy clients_insert_org_admin on clients
  for insert with check (is_org_admin(org_id));

create policy clients_update_org_admin on clients
  for update using (is_org_admin(org_id)) with check (is_org_admin(org_id));

-- client_memberships: users see their own rows; org admins manage all
-- membership rows for clients within their org.
create policy client_memberships_select_self on client_memberships
  for select using (user_id = auth.uid() or is_org_admin(org_id));

create policy client_memberships_manage_admin on client_memberships
  for all using (is_org_admin(org_id))
  with check (is_org_admin(org_id));
