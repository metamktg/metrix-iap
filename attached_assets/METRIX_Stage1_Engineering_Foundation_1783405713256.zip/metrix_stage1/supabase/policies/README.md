# Supabase RLS policies

Real Row Level Security policies (Blueprint v2.0 §12), applied in filename
order after migrations and seed.

| File | Covers |
|---|---|
| `001_identity_access_policies.sql` | `organizations`, `org_members`, `clients`, `client_memberships`. Defines `has_client_access()`, `is_org_admin()`, `client_role()` — every later file calls these. |
| `002_analysis_run_policies.sql` | `analysis_runs`, `analysis_run_cohorts`, `analysis_run_inputs`, `analysis_run_stages`. |
| `003_output_policies.sql` | `intelligence_cards`, `creative_briefs`, `reports`, `onboarding_creative_intake`, `creative_alignment_checks`, `alert_rules`, `bsil_suggestions`. |
| `004_review_approval_learning_policies.sql` | `review_events`, `human_edits`, `approval_events`, `learning_registry`. |
| `005_registry_policies.sql` | `cohort_definitions`, `client_enabled_cohorts`, `global_variable_registry`. |

## The one rule every file follows

**`client_memberships` is the single source of truth for client-level data
visibility.** `org_members` governs org-level admin actions (provisioning a
client, managing memberships) only. No policy in this directory grants
access to a client's data on the basis of `org_members` alone — every
client-scoped `select`/`insert`/`update` policy calls `has_client_access()`,
which reads `client_memberships` exclusively.

## Deliberately absent policies (the important part)

A few tables have **no INSERT policy for any authenticated role** — this is
not an oversight:

- `bsil_suggestions` — pipeline output only. `packages/db`'s
  `rejectCreativeLevelBudgetSuggestion` guard runs before the service-role
  client ever attempts the write.
- `analysis_run_stages` — pipeline output only, written by `apps/worker` via
  the service-role client.
- `learning_registry` — written only after `packages/db`'s
  `validateLearningRegistryApproval` guard confirms a real `approval_events`
  row with `approved_for = 'learning_registry'`.
- `cohort_definitions`, `global_variable_registry` — global config-as-data;
  new rows ship as migrations/seed or through a guarded maintenance function,
  never from a client session.

If a future change adds a client-facing insert path to any of these tables,
that's a deliberate architecture decision requiring Alex's sign-off — not a
policy gap to "fix" by adding an insert policy.

## Testing

`supabase/tests/` exercises these policies directly (fresh-migration apply,
cross-client read rejection, no-ROAS-alert rejection, budget-scope rejection,
learning-registry-without-approval rejection).
