-- METRIX IAP — Policy 004: Review, approval, learning policies (Blueprint v2.0 §11.4)
--
-- Hard rule enforced here: learning_registry has NO client-facing INSERT
-- policy at all. A row can only be written by the service-role client,
-- which itself only proceeds after packages/db's
-- validateLearningRegistryApproval guard confirms a real approval_events row
-- exists with approved_for = 'learning_registry'. RLS is the second layer;
-- the application guard is the first.
--
-- review_events, human_edits, and approval_events all reference
-- analysis_run_id with no direct client_id column — scope is inherited via
-- analysis_runs, same pattern as policy 002.

alter table review_events enable row level security;
alter table human_edits enable row level security;
alter table approval_events enable row level security;
alter table learning_registry enable row level security;

create policy review_events_select on review_events
  for select using (
    exists (
      select 1 from analysis_runs
      where analysis_runs.id = review_events.analysis_run_id
        and has_client_access(analysis_runs.client_id)
    )
  );

-- A review is a real human action — reviewer_id must be the caller, and the
-- caller must have owner/operator standing on the underlying client.
create policy review_events_insert on review_events
  for insert with check (
    reviewer_id = auth.uid()
    and exists (
      select 1 from analysis_runs
      where analysis_runs.id = review_events.analysis_run_id
        and has_client_access(analysis_runs.client_id)
        and client_role(analysis_runs.client_id) in ('owner', 'operator')
    )
  );

create policy human_edits_select on human_edits
  for select using (
    exists (
      select 1 from analysis_runs
      where analysis_runs.id = human_edits.analysis_run_id
        and has_client_access(analysis_runs.client_id)
    )
  );

create policy human_edits_insert on human_edits
  for insert with check (
    editor_id = auth.uid()
    and exists (
      select 1 from analysis_runs
      where analysis_runs.id = human_edits.analysis_run_id
        and has_client_access(analysis_runs.client_id)
        and client_role(analysis_runs.client_id) in ('owner', 'operator')
    )
  );

create policy approval_events_select on approval_events
  for select using (
    exists (
      select 1 from analysis_runs
      where analysis_runs.id = approval_events.analysis_run_id
        and has_client_access(analysis_runs.client_id)
    )
  );

-- Approval must be attributable to a real person — approver_id = auth.uid()
-- is required, not just permitted. This is what makes a later
-- learning_registry write auditable back to a specific human decision.
create policy approval_events_insert on approval_events
  for insert with check (
    approver_id = auth.uid()
    and exists (
      select 1 from analysis_runs
      where analysis_runs.id = approval_events.analysis_run_id
        and has_client_access(analysis_runs.client_id)
        and client_role(analysis_runs.client_id) in ('owner', 'operator')
    )
  );

create policy learning_registry_select on learning_registry
  for select using (has_client_access(client_id));

-- Deliberately no learning_registry_insert policy for any authenticated
-- role. Writes happen only through the service-role client from
-- supabase/functions, after the approval-purpose guard has already run.
