-- METRIX IAP — Policy 003: Output policies (Blueprint v2.0 §11.3, §8, §10)
--
-- Covers every table a client-facing role reads finished intelligence from:
-- intelligence_cards, creative_briefs, reports (migration 0004),
-- onboarding_creative_intake, creative_alignment_checks (migration 0005),
-- alert_rules, bsil_suggestions (migration 0006).
--
-- Hard constraint enforced here in addition to the DB check constraint and
-- the metrix-core application guard: nothing in this file grants INSERT on
-- bsil_suggestions to any client-facing role — suggestions are pipeline
-- output only, written via the service-role client after
-- rejectCreativeLevelBudgetSuggestion has already run in packages/db.

alter table intelligence_cards enable row level security;
alter table creative_briefs enable row level security;
alter table reports enable row level security;
alter table onboarding_creative_intake enable row level security;
alter table creative_alignment_checks enable row level security;
alter table alert_rules enable row level security;
alter table bsil_suggestions enable row level security;

-- intelligence_cards: read for any client member; status transitions
-- (draft -> reviewed/approved/dismissed/archived) require owner/operator.
create policy intelligence_cards_select on intelligence_cards
  for select using (has_client_access(client_id));

create policy intelligence_cards_update on intelligence_cards
  for update using (
    has_client_access(client_id) and client_role(client_id) in ('owner', 'operator')
  ) with check (
    has_client_access(client_id) and client_role(client_id) in ('owner', 'operator')
  );
-- No client-facing INSERT policy: cards are pipeline output, written by the
-- service-role client.

create policy creative_briefs_select on creative_briefs
  for select using (has_client_access(client_id));

create policy creative_briefs_update on creative_briefs
  for update using (
    has_client_access(client_id) and client_role(client_id) in ('owner', 'operator')
  ) with check (
    has_client_access(client_id) and client_role(client_id) in ('owner', 'operator')
  );

create policy reports_select on reports
  for select using (has_client_access(client_id));
-- Reports are generated and status-managed by owner/operator via
-- export-report; no direct client-facing INSERT here either.
create policy reports_update on reports
  for update using (
    has_client_access(client_id) and client_role(client_id) in ('owner', 'operator')
  ) with check (
    has_client_access(client_id) and client_role(client_id) in ('owner', 'operator')
  );

create policy onboarding_creative_intake_select on onboarding_creative_intake
  for select using (has_client_access(client_id));

create policy onboarding_creative_intake_insert on onboarding_creative_intake
  for insert with check (
    has_client_access(client_id) and client_role(client_id) in ('owner', 'operator')
  );

create policy creative_alignment_checks_select on creative_alignment_checks
  for select using (has_client_access(client_id));

create policy creative_alignment_checks_update on creative_alignment_checks
  for update using (
    has_client_access(client_id) and client_role(client_id) in ('owner', 'operator')
  ) with check (
    has_client_access(client_id) and client_role(client_id) in ('owner', 'operator')
  );

-- alert_rules.client_id is nullable in the schema (a platform-wide default
-- rule has client_id null). Client-scoped rows follow the normal boundary;
-- null-client rows are never selectable by a client-facing role — those are
-- service-role/platform-admin concerns only.
create policy alert_rules_select on alert_rules
  for select using (client_id is not null and has_client_access(client_id));

create policy alert_rules_manage on alert_rules
  for all using (
    client_id is not null and has_client_access(client_id) and client_role(client_id) in ('owner', 'operator')
  ) with check (
    client_id is not null and has_client_access(client_id) and client_role(client_id) in ('owner', 'operator')
    -- The no-ROAS-v1-alert-trigger rule is enforced at the schema level
    -- (migration 0006 check (metric <> 'roas')) and is not re-litigated here.
  );

-- bsil_suggestions: read-only for client-facing roles. Status transitions
-- (approve/reject/executed_manually) are a human decision, so owner/operator
-- may update status — but INSERT is intentionally absent from this policy
-- set. Suggestions only ever come from the pipeline via the service-role
-- client, after packages/db's application-layer budget-scope guard runs.
create policy bsil_suggestions_select on bsil_suggestions
  for select using (has_client_access(client_id));

create policy bsil_suggestions_update_status on bsil_suggestions
  for update using (
    has_client_access(client_id) and client_role(client_id) in ('owner', 'operator')
  ) with check (
    has_client_access(client_id) and client_role(client_id) in ('owner', 'operator')
    -- budget_scope_object is immutable via this policy path (not included in
    -- the check's writable columns at the application layer) — only status
    -- should change here.
  );
