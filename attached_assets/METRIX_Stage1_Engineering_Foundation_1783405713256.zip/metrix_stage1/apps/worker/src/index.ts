// The worker eventually owns heavy processing: upload normalization, metric
// validation, creative resolution, prompt chain execution, bridge transform,
// report export, learning writeback (per the Stage 1 briefing). None of that
// is wired up yet — this is a placeholder loop proving the process boots and
// can import every upstream package cleanly.
import { listActivePromptsInChainOrder } from "@metrix/iap-engine";

function selfCheck() {
  const chain = listActivePromptsInChainOrder();
  console.log(
    `@metrix/worker booted. ${chain.length} active prompts registered: ${chain
      .map((p) => p.name)
      .join(" -> ")}`,
  );
}

selfCheck();

// TODO (Stage 2): replace this with a real queue consumer (e.g. BullMQ) that
// picks up validate-upload / run-pipeline / export-report jobs and executes
// the actual pipeline via packages/iap-engine + packages/connectors +
// packages/db, using createServiceRoleClient after the same guard sequence
// used in supabase/functions.
