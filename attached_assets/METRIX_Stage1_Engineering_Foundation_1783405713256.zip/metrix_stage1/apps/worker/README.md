# @metrix/worker (apps/worker)

Placeholder process. Boots and self-checks that the prompt registry
(`@metrix/iap-engine`) loads correctly and every upstream package
(`schemas`, `metrix-core`, `iap-engine`, `db`, `connectors`) imports cleanly.

## Where the real work goes eventually

Per the Stage 1 briefing, this app is meant to own:

```
upload normalization
metric validation
creative resolution
prompt chain execution
bridge transform
report export
learning writeback
```

None of that is implemented yet — Stage 1's job was proving every package
this worker depends on actually compiles and links together. A real queue
consumer (e.g. BullMQ) picking up jobs from `supabase/functions/run-pipeline`
etc. is Stage 2 work.
