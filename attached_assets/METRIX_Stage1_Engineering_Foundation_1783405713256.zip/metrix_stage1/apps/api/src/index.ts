// Minimal Node HTTP server. Deliberately framework-light at Stage 1 — real
// routes (validate-upload proxy, run-pipeline trigger, etc.) are Stage 2
// work once the actual request/response contracts are settled through the
// Supabase Edge Functions in supabase/functions/. For now this proves the
// app boots and has one real, working endpoint.
import { createServer } from "node:http";

const PORT = process.env.PORT ? Number(process.env.PORT) : 3001;

const server = createServer((req, res) => {
  if (req.url === "/health") {
    res.writeHead(200, { "Content-Type": "application/json" });
    res.end(JSON.stringify({ status: "ok", app: "api" }));
    return;
  }

  res.writeHead(404, { "Content-Type": "application/json" });
  res.end(JSON.stringify({ error: "Not found" }));
});

server.listen(PORT, () => {
  console.log(`@metrix/api listening on :${PORT}`);
});
