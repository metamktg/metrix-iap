# @metrix/api (apps/api)

Minimal Node HTTP server skeleton with one working route: `GET /health`.

## Stage 1 scope

Framework-light on purpose. Real routes should mirror the request/response
contracts already established in `supabase/functions/*` (which run the
four-step tenancy guard) rather than reinventing auth handling here — this
app is a thin layer, not a second guard implementation.

## Env vars

`SUPABASE_URL`, `SUPABASE_ANON_KEY`, `SUPABASE_SERVICE_ROLE_KEY` — see
`.env.example` at the repo root. This app is server-side only; it's the one
place `createServiceRoleClient` (from `@metrix/db`) is safe to use, but only
after the same identity/access/object-ownership checks used in
`supabase/functions/_shared/authGuard.ts`.
