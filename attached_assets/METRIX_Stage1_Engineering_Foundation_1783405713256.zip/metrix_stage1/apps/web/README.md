# @metrix/web (apps/web)

Next.js frontend skeleton. Deliberately minimal at Stage 1 — a placeholder
home page and a working `/health` route, nothing more.

## Design rule

This app is not the dumping ground for pipeline logic. Anything beyond
presentation belongs in `packages/metrix-core`, `packages/iap-engine`, or
`packages/db` — imported here, not reimplemented here.

## Env vars

See `.env.example` at the repo root: `NEXT_PUBLIC_SUPABASE_URL`,
`NEXT_PUBLIC_SUPABASE_ANON_KEY`. Never import `@metrix/db`'s
`createServiceRoleClient` into this app — it bypasses RLS and must never run
in browser-reachable code.
