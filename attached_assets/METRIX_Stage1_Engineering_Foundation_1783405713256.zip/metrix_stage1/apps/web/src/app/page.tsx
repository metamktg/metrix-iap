// Placeholder only — Stage 1 explicitly defers full UI work. This page
// exists so `pnpm dev` in apps/web has something real to render, not a
// dumping ground for pipeline logic (that belongs in packages/metrix-core
// and packages/iap-engine).
export default function HomePage() {
  return (
    <main>
      <h1>Metrix IAP</h1>
      <p>Stage 1 engineering foundation. Real UI is Stage 2+ work.</p>
    </main>
  );
}
