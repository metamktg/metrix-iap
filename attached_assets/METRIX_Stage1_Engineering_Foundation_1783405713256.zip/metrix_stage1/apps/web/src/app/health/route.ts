// Placeholder health route so the app skeleton has a real, working
// endpoint per the Stage 1 success criteria.
import { NextResponse } from "next/server";

export async function GET(): Promise<NextResponse> {
  return NextResponse.json({ status: "ok", app: "web" });
}
