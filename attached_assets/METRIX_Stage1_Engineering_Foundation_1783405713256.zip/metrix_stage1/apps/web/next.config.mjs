/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  // Env vars come from .env.example at the repo root — see README for the
  // three required at runtime (NEXT_PUBLIC_SUPABASE_URL, etc).
};

export default nextConfig;
