# METRIX IAP — Official Repository

Metrix Intelligent Ads Protocol (IAP): an 11-prompt creative-intelligence engine for Meta Ads, with a Supabase backend. This repo is the canonical home for the platform's schema, seeds, prompt documentation, and now its Stage 1 engineering foundation (Blueprint v2.0 §11.5).

## What this repo is right now

**Stage 0 repo shell: complete. Stage 1 engineering foundation: built.**

Root monorepo tooling exists and is meaningful (`pnpm install && pnpm lint && pnpm typecheck && pnpm test` all have real scripts to run), every package under `packages/*` has real source code — not just `.gitkeep` — and `supabase/policies/`, `supabase/functions/`, and `supabase/tests/` are no longer pending: real RLS policies, guarded Edge Function stubs, and pgTAP tests exist.

**Not yet true, and don't claim otherwise:** this is not build-ready, deploy-ready, security-ready, production-ready, or a finished SaaS repo. `apps/web`, `apps/api`, and `apps/worker` are skeletons with one working route/self-check each, not real applications. The actual pipeline logic behind every guarded Edge Function stub is Stage 2 work, flagged inline as `TODO (Stage 2)`.

## Repo map

```
supabase/
  migrations/   Runnable schema DDL, filename order (22 tables incl. global_variable_registry)
  seed/         Seed data: cohort_definitions (4 cohorts), global_variable_registry (51 codes)
  policies/     5 real RLS policy files — see supabase/policies/README.md
  functions/    6 Edge Function stubs, all guard-first — see supabase/functions/README.md
  tests/        pgTAP tests: schema smoke, cross-client access, alert/BSIL constraints, learning-registry gate
docs/
  architecture/ Master Blueprint v2.0
  data-model/   Cohort Architecture, Listen Layer 125-metric contract, migrations README
  prompts/      The 7 cohort-aware v2.0 IAP prompt documents, registered in packages/iap-engine
  iap/ product/ security/ resources/  as before (scope TBD / non-canonical reference)
apps/
  web/          Next.js skeleton — placeholder page + /health route
  api/          Minimal Node HTTP server — /health route
  worker/       Boots, self-checks the prompt registry loads; real queue consumer is Stage 2
packages/
  schemas/      Zod schemas for every table row and prompt-chain output — see packages/schemas/README.md
  metrix-core/  Deterministic cohort/resolver/confidence/MST/BSIL/approval logic, no I/O
  iap-engine/   Prompt registry + loader + chain runner over docs/prompts/
  db/           Supabase repo helpers, tenant-scoped, with application-layer guards
  connectors/   Connector interface + manual-upload connector (column mapping is Stage 2)
  ui/           One shared component (ConfidenceBadge) — full library is Stage 2+
tests/          integration / e2e / security — still placeholders, out of Stage 1 scope
```

## Hard constraints baked into the schema and now enforced in code (do not relax)
- BSIL is suggestion-only; `bsil_suggestions.budget_scope_object` is check-constrained to campaign/ad_set — and rejected a second time by `packages/metrix-core`'s `rejectCreativeLevelBudgetSuggestion` before any write.
- `alert_rules.metric <> 'roas'` (no ROAS alerts in v1; ROAS stays a reporting metric) — re-asserted in code in `supabase/functions/severity-scheduler`.
- `learning_registry` writes require an `approval_events` row with `approved_for = 'learning_registry'` — RLS blocks all authenticated-role inserts outright, and `packages/db`'s `validateLearningRegistryApproval` guards the service-role path.
- Manual creative intake requires >= 5 assets (schema-enforced, migration 0005).
- Creative identity: naming-convention (`concept_code`) is primary; `ad_id` is the fallback join key. No `creative_id` field exists. The parser in `packages/metrix-core/creative-resolution` is grounded directly in the live "Meta Ads Naming Convention System" Drive doc (`[CONCEPT_VAR]_[TYPE]_[LANDING_PAGE]_[TEST_ID]`, e.g. `C1A_STC_PDP_T1`).
- Cohorts are first-class, per-run snapshotted, never blended. `lead_gen` and `service` are distinct cohorts sharing `required_metric_block: service_18`.
- `client_memberships` is the single source of truth for client-level data visibility — `org_members` never grants it alone (see `supabase/policies/001_identity_access_policies.sql`).

## Known gaps, flagged not invented
- Column → Listen Layer metric mapping in `packages/connectors`' manual-upload connector is stubbed (`metrics: {}`).
- `packages/iap-engine`'s output-schema registry only covers `IAP_DATA_BUNDLE_PREP`, `IAP_ANALYSIS_CORE`, and `MST_TEST_ENGINE` — the other four prompts resolve into shared table shapes and don't have a bespoke stage-output schema yet.
- No database-level constraint ties `learning_registry.approval_event_id` to a row with the right `approved_for` value — only RLS + the application guard enforce it today. See `supabase/tests/030_learning_registry_gate.test.sql`.

## Scope notes
- The 7 prompts in `docs/prompts/` are the cohort-aware v2.0 repairs, and the only ones registered in `packages/iap-engine`. The remaining IAP prompts (MST_CREATIVE_SCAN, MST_METHOD_REFERENCE, VARIABLES_REGISTRY-as-doc, system context) are pending a scope/inclusion decision.
- Session/handoff working documents are intentionally excluded from this repo.
