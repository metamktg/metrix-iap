// Root ESLint flat config for the Metrix monorepo.
// Package-level configs may extend this; keep this file dependency-light
// so `pnpm lint` works even before every package has its own overrides.
import tseslint from "typescript-eslint";

export default tseslint.config(
  {
    ignores: [
      "**/dist/**",
      "**/.turbo/**",
      "**/node_modules/**",
      "**/coverage/**",
      "supabase/.branches/**",
      "supabase/.temp/**",
    ],
  },
  ...tseslint.configs.recommended,
  {
    rules: {
      // Metrix-specific discipline: no bare `creative_id` identifiers anywhere
      // in engineering code. concept_code / naming-convention parse is primary,
      // ad_id is the only sanctioned fallback (Blueprint v2.0 §7).
      "@typescript-eslint/no-explicit-any": "warn",
      "@typescript-eslint/no-unused-vars": [
        "warn",
        { argsIgnorePattern: "^_", varsIgnorePattern: "^_" },
      ],
    },
  },
);
