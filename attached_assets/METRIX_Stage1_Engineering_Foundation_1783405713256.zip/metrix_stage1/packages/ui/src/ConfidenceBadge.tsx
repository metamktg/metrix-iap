// A single, small shared component to establish the package's shape. Deliberately
// not building out a full component library yet — Stage 1 explicitly defers
// "full UI" work. This exists so apps/web has at least one real thing to import.
import type { ConfidenceGrade } from "@metrix/schemas";

const LABEL_BY_GRADE: Record<ConfidenceGrade, string> = {
  HIGH: "High confidence",
  MODERATE: "Moderate confidence",
  LOW: "Low confidence",
  INSUFFICIENT: "Insufficient data",
};

export interface ConfidenceBadgeProps {
  grade: ConfidenceGrade;
}

export function ConfidenceBadge({ grade }: ConfidenceBadgeProps) {
  return (
    <span data-metrix-confidence-grade={grade}>{LABEL_BY_GRADE[grade]}</span>
  );
}
