# @metrix/ui

Shared React components for `apps/web`. Deliberately minimal at Stage 1 — the
web app should not exist as UI-heavy work yet, so this package holds only what
is needed to prove the shape (`ConfidenceBadge`, rendering an
`intelligence_cards.confidence_grade` value).

Full component library work is a Stage 2+ concern.
