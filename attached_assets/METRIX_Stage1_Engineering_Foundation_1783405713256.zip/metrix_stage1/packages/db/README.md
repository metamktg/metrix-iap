# @metrix/db

Supabase query helpers. Every repo function requires the relevant `client_id`
(or is explicitly global, like `globalVariableRegistryRepo`) — there is no
"fetch everything" helper for any tenant-scoped table.

## Two client constructors, not interchangeable

- `createUserScopedClient(env, accessToken)` — respects RLS via the caller's
  JWT. Use this in `apps/api` and `apps/worker` for anything driven by a real
  user request.
- `createServiceRoleClient(env)` — bypasses RLS entirely. Only for
  `supabase/functions/*` code that has already run its own tenancy guard.
  Throws if constructed without a service role key. **Never** import this into
  `apps/web` or anything reachable from the browser.

## Application-layer guards, on top of RLS and DB constraints

Two repos call into `@metrix/metrix-core` guards before writing, on purpose:

- `bsilSuggestionsRepo.insertBsilSuggestion` calls
  `rejectCreativeLevelBudgetSuggestion` before the insert. A creative-scoped
  BSIL suggestion never reaches Postgres — see `src/__tests__/db.test.ts`,
  which proves this with a client that throws if it's ever actually called.
- `learningRegistryRepo.insertLearningRegistryEntry` requires the full
  `ApprovalEvent` object (not just an id) and validates
  `approved_for === 'learning_registry'` plus id match before writing.

This is deliberate belt-and-suspenders: RLS and the migration check
constraints are the real enforcement boundary, but a clear application-layer
error here is far more actionable than a raw Postgres constraint violation
surfacing three layers up in `apps/worker`.

## Repos

`clientsRepo` · `cohortsRepo` · `analysisRunsRepo` · `analysisRunStagesRepo` ·
`intelligenceCardsRepo` · `creativeBriefsRepo` · `reportsRepo` ·
`bsilSuggestionsRepo` · `learningRegistryRepo` · `globalVariableRegistryRepo`
