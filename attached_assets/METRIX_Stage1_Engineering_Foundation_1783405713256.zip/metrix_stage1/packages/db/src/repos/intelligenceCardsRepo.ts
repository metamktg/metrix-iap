// Wraps intelligence_cards (migration 0004). Every list function requires
// client_id — there is deliberately no "list all cards across clients"
// helper here, matching the tenant-safety brief.
import type { SupabaseClient } from "@supabase/supabase-js";
import type { IntelligenceCard } from "@metrix/schemas";

export async function insertIntelligenceCard(
  supabase: SupabaseClient,
  card: IntelligenceCard,
): Promise<IntelligenceCard> {
  const { data, error } = await supabase.from("intelligence_cards").insert(card).select().single();
  if (error) throw error;
  return data as IntelligenceCard;
}

export async function listIntelligenceCardsForClient(
  supabase: SupabaseClient,
  clientId: string,
  filters: { status?: IntelligenceCard["status"]; cohortKey?: string } = {},
): Promise<IntelligenceCard[]> {
  let query = supabase.from("intelligence_cards").select("*").eq("client_id", clientId);
  if (filters.status) query = query.eq("status", filters.status);
  if (filters.cohortKey) query = query.eq("cohort_key", filters.cohortKey);

  const { data, error } = await query.order("created_at", { ascending: false });
  if (error) throw error;
  return (data ?? []) as IntelligenceCard[];
}

export async function updateIntelligenceCardStatus(
  supabase: SupabaseClient,
  clientId: string,
  cardId: string,
  status: IntelligenceCard["status"],
): Promise<void> {
  const { error } = await supabase
    .from("intelligence_cards")
    .update({ status })
    .eq("client_id", clientId)
    .eq("id", cardId);
  if (error) throw error;
}
