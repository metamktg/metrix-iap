// Wraps global_variable_registry (migration 0009). This is global config
// data, not client-scoped — every function here is intentionally
// client-agnostic, unlike the other repos in this package.
import type { SupabaseClient } from "@supabase/supabase-js";
import type { GlobalVariableRegistryEntry, VariableFamily } from "@metrix/schemas";

export async function listGlobalVariables(
  supabase: SupabaseClient,
  filters: { family?: VariableFamily; status?: "active" | "deprecated" } = {},
): Promise<GlobalVariableRegistryEntry[]> {
  let query = supabase.from("global_variable_registry").select("*");
  if (filters.family) query = query.eq("variable_family", filters.family);
  if (filters.status) query = query.eq("status", filters.status);

  const { data, error } = await query;
  if (error) throw error;
  return (data ?? []) as GlobalVariableRegistryEntry[];
}

export async function getGlobalVariable(
  supabase: SupabaseClient,
  variableCode: string,
): Promise<GlobalVariableRegistryEntry | null> {
  const { data, error } = await supabase
    .from("global_variable_registry")
    .select("*")
    .eq("variable_code", variableCode)
    .maybeSingle();
  if (error) throw error;
  return data as GlobalVariableRegistryEntry | null;
}

/**
 * Resolves a possibly-deprecated variable code to its currently active
 * replacement, following superseded_by chains. Returns the input code
 * unchanged if it's already active or not found (a missing code is a data
 * gap to flag elsewhere, not something this function should paper over).
 */
export async function resolveActiveVariableCode(
  supabase: SupabaseClient,
  variableCode: string,
): Promise<string> {
  let current = await getGlobalVariable(supabase, variableCode);
  let resolvedCode = variableCode;
  const seen = new Set<string>();

  while (current && current.status === "deprecated" && current.superseded_by) {
    if (seen.has(current.variable_code)) {
      throw new Error(`Cycle detected in superseded_by chain starting at "${variableCode}".`);
    }
    seen.add(current.variable_code);
    resolvedCode = current.superseded_by;
    current = await getGlobalVariable(supabase, current.superseded_by);
  }

  return resolvedCode;
}
