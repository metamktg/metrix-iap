// Wraps creative_briefs (migration 0004). Uses concept_code, never
// creative_id, matching the locked identity model.
import type { SupabaseClient } from "@supabase/supabase-js";
import type { CreativeBrief } from "@metrix/schemas";

export async function insertCreativeBrief(
  supabase: SupabaseClient,
  brief: CreativeBrief,
): Promise<CreativeBrief> {
  const { data, error } = await supabase.from("creative_briefs").insert(brief).select().single();
  if (error) throw error;
  return data as CreativeBrief;
}

export async function listCreativeBriefsForClient(
  supabase: SupabaseClient,
  clientId: string,
  status?: CreativeBrief["status"],
): Promise<CreativeBrief[]> {
  let query = supabase.from("creative_briefs").select("*").eq("client_id", clientId);
  if (status) query = query.eq("status", status);

  const { data, error } = await query.order("created_at", { ascending: false });
  if (error) throw error;
  return (data ?? []) as CreativeBrief[];
}

export async function updateCreativeBriefStatus(
  supabase: SupabaseClient,
  clientId: string,
  briefId: string,
  status: CreativeBrief["status"],
): Promise<void> {
  const { error } = await supabase
    .from("creative_briefs")
    .update({ status })
    .eq("client_id", clientId)
    .eq("id", briefId);
  if (error) throw error;
}
