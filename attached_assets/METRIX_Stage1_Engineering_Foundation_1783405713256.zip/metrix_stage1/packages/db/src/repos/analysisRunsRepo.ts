// Wraps analysis_runs and analysis_run_cohorts (migration 0003). Creating a
// run and its cohort snapshot happen together here, because a run without a
// cohort snapshot is an invalid, unauditable state — see
// createRunWithCohortSnapshot below rather than composing the two inserts at
// the call site.
import type { SupabaseClient } from "@supabase/supabase-js";
import type { AnalysisRun, AnalysisRunCohortSnapshot } from "@metrix/schemas";

export async function getAnalysisRun(
  supabase: SupabaseClient,
  clientId: string,
  runId: string,
): Promise<AnalysisRun | null> {
  const { data, error } = await supabase
    .from("analysis_runs")
    .select("*")
    .eq("client_id", clientId)
    .eq("id", runId)
    .maybeSingle();
  if (error) throw error;
  return data as AnalysisRun | null;
}

export async function listAnalysisRunsForClient(
  supabase: SupabaseClient,
  clientId: string,
): Promise<AnalysisRun[]> {
  const { data, error } = await supabase
    .from("analysis_runs")
    .select("*")
    .eq("client_id", clientId)
    .order("created_at", { ascending: false });
  if (error) throw error;
  return (data ?? []) as AnalysisRun[];
}

export async function createRunWithCohortSnapshot(
  supabase: SupabaseClient,
  run: AnalysisRun,
  cohortSnapshot: AnalysisRunCohortSnapshot[],
): Promise<AnalysisRun> {
  const { data: createdRun, error: runError } = await supabase
    .from("analysis_runs")
    .insert(run)
    .select()
    .single();
  if (runError) throw runError;

  const snapshotRows = cohortSnapshot.map((row) => ({ ...row, analysis_run_id: createdRun.id }));
  if (snapshotRows.length > 0) {
    const { error: snapshotError } = await supabase
      .from("analysis_run_cohorts")
      .insert(snapshotRows);
    if (snapshotError) throw snapshotError;
  }

  return createdRun as AnalysisRun;
}

export async function updateAnalysisRunStatus(
  supabase: SupabaseClient,
  runId: string,
  status: AnalysisRun["status"],
  completedAt?: string,
): Promise<void> {
  const { error } = await supabase
    .from("analysis_runs")
    .update({ status, completed_at: completedAt ?? null })
    .eq("id", runId);
  if (error) throw error;
}
