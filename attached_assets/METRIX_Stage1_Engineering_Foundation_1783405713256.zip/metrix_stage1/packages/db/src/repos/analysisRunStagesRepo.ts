// Wraps analysis_run_stages. Rows here typically come straight from
// packages/iap-engine's runPromptStage / runIAPChain results.
import type { SupabaseClient } from "@supabase/supabase-js";
import type { AnalysisRunStage } from "@metrix/schemas";

export async function insertRunStage(
  supabase: SupabaseClient,
  stage: AnalysisRunStage,
): Promise<AnalysisRunStage> {
  const { data, error } = await supabase.from("analysis_run_stages").insert(stage).select().single();
  if (error) throw error;
  return data as AnalysisRunStage;
}

export async function insertRunStages(
  supabase: SupabaseClient,
  stages: AnalysisRunStage[],
): Promise<AnalysisRunStage[]> {
  if (stages.length === 0) return [];
  const { data, error } = await supabase.from("analysis_run_stages").insert(stages).select();
  if (error) throw error;
  return (data ?? []) as AnalysisRunStage[];
}

export async function listStagesForRun(
  supabase: SupabaseClient,
  analysisRunId: string,
): Promise<AnalysisRunStage[]> {
  const { data, error } = await supabase
    .from("analysis_run_stages")
    .select("*")
    .eq("analysis_run_id", analysisRunId)
    .order("started_at", { ascending: true });
  if (error) throw error;
  return (data ?? []) as AnalysisRunStage[];
}
