// Wraps the `clients` table (migration 0001). Every read here is
// scoped by org_id at the call site as a defense-in-depth convention —
// the actual tenant boundary is enforced by RLS (supabase/policies/), this
// is a second layer so an application bug can't accidentally request
// cross-org data even if a policy were ever misconfigured.
import type { SupabaseClient } from "@supabase/supabase-js";

export interface ClientRow {
  id: string;
  org_id: string;
  name: string;
  client_code: string;
  status: "active" | "paused" | "archived";
  created_at?: string;
  updated_at?: string;
}

export async function getClientById(
  supabase: SupabaseClient,
  orgId: string,
  clientId: string,
): Promise<ClientRow | null> {
  const { data, error } = await supabase
    .from("clients")
    .select("*")
    .eq("org_id", orgId)
    .eq("id", clientId)
    .maybeSingle();

  if (error) throw error;
  return data as ClientRow | null;
}

export async function listClientsForOrg(
  supabase: SupabaseClient,
  orgId: string,
  status?: ClientRow["status"],
): Promise<ClientRow[]> {
  let query = supabase.from("clients").select("*").eq("org_id", orgId);
  if (status) query = query.eq("status", status);

  const { data, error } = await query;
  if (error) throw error;
  return (data ?? []) as ClientRow[];
}

export async function createClientRecord(
  supabase: SupabaseClient,
  row: Omit<ClientRow, "id" | "created_at" | "updated_at">,
): Promise<ClientRow> {
  const { data, error } = await supabase.from("clients").insert(row).select().single();
  if (error) throw error;
  return data as ClientRow;
}
