// Wraps learning_registry and approval_events (migration 0007).
// insertLearningRegistryEntry requires the caller to pass the actual
// approval_events row (not just an id) so the approval-purpose guard from
// metrix-core can validate it before the write — passing only an id would
// let a wrongly-scoped approval slip through undetected until the DB
// check constraint (if any) or RLS policy caught it later.
import type { SupabaseClient } from "@supabase/supabase-js";
import type { ApprovalEvent, LearningRegistryEntry } from "@metrix/schemas";
import { validateLearningRegistryApproval } from "@metrix/metrix-core";

export async function insertApprovalEvent(
  supabase: SupabaseClient,
  event: ApprovalEvent,
): Promise<ApprovalEvent> {
  const { data, error } = await supabase.from("approval_events").insert(event).select().single();
  if (error) throw error;
  return data as ApprovalEvent;
}

export async function insertLearningRegistryEntry(
  supabase: SupabaseClient,
  entry: LearningRegistryEntry,
  approvalEvent: ApprovalEvent,
): Promise<LearningRegistryEntry> {
  validateLearningRegistryApproval(approvalEvent);

  if (approvalEvent.id !== entry.approval_event_id) {
    throw new Error(
      "learning_registry write rejected: entry.approval_event_id does not match the provided approvalEvent.id.",
    );
  }

  const { data, error } = await supabase
    .from("learning_registry")
    .insert(entry)
    .select()
    .single();
  if (error) throw error;
  return data as LearningRegistryEntry;
}

export async function listLearningRegistryForClient(
  supabase: SupabaseClient,
  clientId: string,
  cohortKey?: string,
): Promise<LearningRegistryEntry[]> {
  let query = supabase.from("learning_registry").select("*").eq("client_id", clientId);
  if (cohortKey) query = query.eq("cohort_key", cohortKey);

  const { data, error } = await query.order("created_at", { ascending: false });
  if (error) throw error;
  return (data ?? []) as LearningRegistryEntry[];
}
