// Wraps cohort_definitions (global, config-as-data) and
// client_enabled_cohorts (per-client, per migration 0002). Pair with
// packages/metrix-core's resolveActiveCohorts / createRunCohortSnapshot for
// the deterministic logic on top of these rows — this file only fetches and
// writes, it doesn't decide anything.
import type { SupabaseClient } from "@supabase/supabase-js";
import type { ClientEnabledCohort, CohortDefinition } from "@metrix/schemas";

export async function listCohortDefinitions(supabase: SupabaseClient): Promise<CohortDefinition[]> {
  const { data, error } = await supabase.from("cohort_definitions").select("*");
  if (error) throw error;
  return (data ?? []) as CohortDefinition[];
}

export async function getCohortDefinition(
  supabase: SupabaseClient,
  cohortKey: string,
): Promise<CohortDefinition | null> {
  const { data, error } = await supabase
    .from("cohort_definitions")
    .select("*")
    .eq("cohort_key", cohortKey)
    .maybeSingle();
  if (error) throw error;
  return data as CohortDefinition | null;
}

export async function listEnabledCohortsForClient(
  supabase: SupabaseClient,
  clientId: string,
): Promise<ClientEnabledCohort[]> {
  const { data, error } = await supabase
    .from("client_enabled_cohorts")
    .select("*")
    .eq("client_id", clientId);
  if (error) throw error;
  return (data ?? []) as ClientEnabledCohort[];
}

export async function upsertClientEnabledCohort(
  supabase: SupabaseClient,
  row: ClientEnabledCohort,
): Promise<ClientEnabledCohort> {
  const { data, error } = await supabase
    .from("client_enabled_cohorts")
    .upsert(row, { onConflict: "client_id,cohort_key" })
    .select()
    .single();
  if (error) throw error;
  return data as ClientEnabledCohort;
}
