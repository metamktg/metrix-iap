// Wraps reports (migration 0004).
import type { SupabaseClient } from "@supabase/supabase-js";
import type { Report } from "@metrix/schemas";

export async function insertReport(supabase: SupabaseClient, report: Report): Promise<Report> {
  const { data, error } = await supabase.from("reports").insert(report).select().single();
  if (error) throw error;
  return data as Report;
}

export async function listReportsForClient(
  supabase: SupabaseClient,
  clientId: string,
  reportType?: Report["report_type"],
): Promise<Report[]> {
  let query = supabase.from("reports").select("*").eq("client_id", clientId);
  if (reportType) query = query.eq("report_type", reportType);

  const { data, error } = await query.order("created_at", { ascending: false });
  if (error) throw error;
  return (data ?? []) as Report[];
}
