// Wraps bsil_suggestions (migration 0006). insertBsilSuggestion calls
// metrix-core's rejectCreativeLevelBudgetSuggestion BEFORE the insert — this
// is deliberate belt-and-suspenders on top of the DB check constraint: a
// clear application-layer error is more actionable than a raw Postgres
// constraint violation surfacing in apps/worker.
import type { SupabaseClient } from "@supabase/supabase-js";
import type { BSILSuggestion } from "@metrix/schemas";
import { rejectCreativeLevelBudgetSuggestion } from "@metrix/metrix-core";

export async function insertBsilSuggestion(
  supabase: SupabaseClient,
  suggestion: BSILSuggestion,
): Promise<BSILSuggestion> {
  rejectCreativeLevelBudgetSuggestion(suggestion.budget_scope_object);

  const { data, error } = await supabase.from("bsil_suggestions").insert(suggestion).select().single();
  if (error) throw error;
  return data as BSILSuggestion;
}

export async function listBsilSuggestionsForClient(
  supabase: SupabaseClient,
  clientId: string,
  status?: BSILSuggestion["status"],
): Promise<BSILSuggestion[]> {
  let query = supabase.from("bsil_suggestions").select("*").eq("client_id", clientId);
  if (status) query = query.eq("status", status);

  const { data, error } = await query.order("created_at", { ascending: false });
  if (error) throw error;
  return (data ?? []) as BSILSuggestion[];
}

export async function updateBsilSuggestionStatus(
  supabase: SupabaseClient,
  clientId: string,
  suggestionId: string,
  status: BSILSuggestion["status"],
): Promise<void> {
  const { error } = await supabase
    .from("bsil_suggestions")
    .update({ status })
    .eq("client_id", clientId)
    .eq("id", suggestionId);
  if (error) throw error;
}
