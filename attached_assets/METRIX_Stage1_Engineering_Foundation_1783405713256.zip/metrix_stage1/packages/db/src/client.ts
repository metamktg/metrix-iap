// Two distinct client constructors, deliberately not interchangeable:
//   - createServiceRoleClient: bypasses RLS. Only for supabase/functions/*
//     server-side code that has already run its own tenancy guard. Never
//     import this into apps/web or anything reachable from the browser.
//   - createUserScopedClient: respects RLS via the caller's JWT. This is what
//     apps/api and apps/worker should use for anything driven by a real user
//     request.
import { createClient, type SupabaseClient } from "@supabase/supabase-js";

export interface MetrixSupabaseEnv {
  url: string;
  anonKey: string;
  serviceRoleKey?: string;
}

export function createUserScopedClient(env: MetrixSupabaseEnv, accessToken: string): SupabaseClient {
  return createClient(env.url, env.anonKey, {
    global: { headers: { Authorization: `Bearer ${accessToken}` } },
    auth: { persistSession: false },
  });
}

export function createServiceRoleClient(env: MetrixSupabaseEnv): SupabaseClient {
  if (!env.serviceRoleKey) {
    throw new Error(
      "createServiceRoleClient called without a serviceRoleKey. This client bypasses RLS — " +
        "it must never be constructed with the anon key, and must never run in browser code.",
    );
  }
  return createClient(env.url, env.serviceRoleKey, {
    auth: { persistSession: false },
  });
}
