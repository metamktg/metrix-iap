import { describe, expect, it } from "vitest";
import type { SupabaseClient } from "@supabase/supabase-js";
import { insertBsilSuggestion } from "../repos/bsilSuggestionsRepo.js";
import { insertLearningRegistryEntry } from "../repos/learningRegistryRepo.js";
import { createServiceRoleClient } from "../client.js";

// A client that throws if any Supabase call is actually attempted — proves
// the application-layer guards short-circuit BEFORE hitting the network,
// not just that they eventually surface a DB error.
const explodingClient = {
  from() {
    throw new Error("Supabase should never be called when the guard rejects first.");
  },
} as unknown as SupabaseClient;

describe("bsilSuggestionsRepo guard", () => {
  it("rejects a creative-scoped suggestion before touching the client", async () => {
    await expect(
      insertBsilSuggestion(explodingClient, {
        client_id: "11111111-1111-1111-1111-111111111111",
        budget_scope_object: "creative" as never,
        entity_id: "22222222-2222-2222-2222-222222222222",
        scope_key: "scope-1",
        suggestion_type: "scale",
        confidence_grade: "HIGH",
        contract_version: "v1",
        schema_version: "v1",
        status: "pending",
        suggested_change: {},
        rationale_json: {},
      }),
    ).rejects.toThrow(/budget-scope violation/);
  });
});

describe("learningRegistryRepo guard", () => {
  it("rejects an entry whose approval_event_id doesn't match the provided approval event", async () => {
    await expect(
      insertLearningRegistryEntry(
        explodingClient,
        {
          client_id: "11111111-1111-1111-1111-111111111111",
          source_object_type: "intelligence_card",
          source_object_id: "22222222-2222-2222-2222-222222222222",
          learning_summary: "test",
          variable_weight_deltas: {},
          approval_event_id: "33333333-3333-3333-3333-333333333333",
          contract_version: "v1",
          schema_version: "v1",
        },
        {
          id: "44444444-4444-4444-4444-444444444444",
          object_type: "intelligence_card",
          object_id: "22222222-2222-2222-2222-222222222222",
          approved_for: "learning_registry",
        },
      ),
    ).rejects.toThrow(/does not match/);
  });
});

describe("createServiceRoleClient", () => {
  it("refuses to construct without a service role key", () => {
    expect(() => createServiceRoleClient({ url: "https://x.supabase.co", anonKey: "anon" })).toThrow();
  });
});
