# @metrix/schemas

Zod validation schemas for every object that crosses a boundary in Metrix IAP:
prompt-chain payloads, Supabase table rows, and the pipeline-internal shapes
that connect them.

## Why this package exists

Every prompt output must validate against a schema **before** it is written to
Supabase (Stage 1 rule, non-negotiable). This package is the single place
those schemas live, so `packages/iap-engine`, `packages/db`, and `apps/api`
all import the same definitions instead of re-deriving them.

## Contents

| Schema | Backing table / doc |
|---|---|
| `cohortDefinitionSchema` | `cohort_definitions` |
| `clientEnabledCohortSchema` | `client_enabled_cohorts` |
| `analysisRunCohortSnapshotSchema` | `analysis_run_cohorts` |
| `analysisRunSchema` | `analysis_runs` |
| `analysisRunInputSchema` | `analysis_run_inputs` |
| `analysisRunStageSchema` | `analysis_run_stages` |
| `normalizedRecordSchema` | pipeline-internal, pre-resolution |
| `creativeIdentityResolutionSchema` | pipeline-internal, resolver output |
| `intelligenceCardSchema` | `intelligence_cards` |
| `creativeBriefSchema` | `creative_briefs` |
| `reportSchema` | `reports` |
| `bsilSuggestionSchema` | `bsil_suggestions` |
| `learningRegistryEntrySchema` | `learning_registry` |
| `approvalEventSchema` | `approval_events` |
| `globalVariableRegistryEntrySchema` | `global_variable_registry` |
| `mstTestEngineOutputSchema` | `docs/prompts/MST_TEST_ENGINE_v2.0.md` |
| `iapDataBundleOutputSchema` | `docs/prompts/IAP_DATA_BUNDLE_PREP_v2.0.md` |
| `iapAnalysisCoreOutputSchema` | `docs/prompts/IAP_ANALYSIS_CORE_v2.0.md` |

## Non-negotiable rules encoded here

- No `creative_id` field anywhere. `concept_code` is the naming-convention
  primary identifier; `ad_id` is the fallback join key only.
- MST `verdict` is restricted to the canonical four values. Finer descriptors
  live in `performance_band` and are never a fifth verdict.
- `bsil_suggestions.budget_scope_object` is restricted to `campaign` / `ad_set`
  — creative, copy, angle, and landing_page are structurally impossible here.
- `learning_registry` rows require an `approval_event_id`; pair with
  `packages/metrix-core`'s approval guard before writing.

## Updating a schema

If a migration in `supabase/migrations/` changes a `check (... in (...))`
constraint or a column, update the matching enum/schema in this package in the
**same commit**. Drift between the database and this package is the exact
failure mode this package exists to prevent.
