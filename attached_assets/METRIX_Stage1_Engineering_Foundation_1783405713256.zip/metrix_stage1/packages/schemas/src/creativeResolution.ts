// Creative identity model (Blueprint v2.0 §7, locked): naming-convention
// (concept_code) is the PRIMARY identifier. ad_id is the fallback join key
// only. There is no creative_id field or concept anywhere in Metrix IAP.
// Sprint/batch context is a database association (which analysis_run an ad_id
// appears in), never parsed from the ad name — there is no sprint-version slot.
import { z } from "zod";

// A single row of ingested Meta Ads data after CSV/API normalization, prior to
// creative resolution. Shape is intentionally permissive on metric fields
// (jsonb-like) since the active metric block is cohort-dependent
// (docs/data-model/METRIX_Listen_Layer_125_Metric_Contract_v1.md); identity and
// provenance fields are strict.
export const normalizedRecordSchema = z.object({
  ad_id: z.string().min(1),
  ad_name: z.string().min(1),
  campaign_id: z.string().min(1).nullable().optional(),
  campaign_name: z.string().nullable().optional(),
  ad_set_id: z.string().min(1).nullable().optional(),
  ad_set_name: z.string().nullable().optional(),
  cohort_key: z.string().min(1),
  source_file: z.string().min(1),
  source_row_index: z.number().int().nonnegative(),
  metrics: z.record(z.string(), z.number().nullable()).default({}),
  raw: z.record(z.string(), z.unknown()).default({}),
});
export type NormalizedRecord = z.infer<typeof normalizedRecordSchema>;

// Output of the creative-resolution step (packages/metrix-core/creative-resolution).
// resolution_method records how identity was established, never invents a
// creative_id. unresolved_reason is populated only when method === "unresolved".
export const creativeIdentityResolutionSchema = z.object({
  ad_id: z.string().min(1),
  concept_code: z.string().min(1).nullable(),
  variation_id: z.string().nullable().optional(),
  format_type: z.enum(["static", "video", "carousel"]).nullable().optional(),
  hook_type: z.string().nullable().optional(),
  custom_tags: z.array(z.string()).default([]),
  resolution_method: z.enum(["naming_convention", "ad_id_fallback", "unresolved"]),
  unresolved_reason: z.string().nullable().optional(),
  confidence: z.enum(["exact", "partial", "fallback"]),
});
export type CreativeIdentityResolution = z.infer<typeof creativeIdentityResolutionSchema>;
