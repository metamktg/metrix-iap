// Shared enums. These must stay byte-for-byte in sync with the `check (... in (...))`
// constraints in supabase/migrations/*.sql. If a migration changes a constraint,
// this file changes in the same PR — schemas drifting from the database is the
// exact failure mode packages/schemas exists to prevent.
import { z } from "zod";

export const confidenceGradeSchema = z.enum(["HIGH", "MODERATE", "LOW", "INSUFFICIENT"]);
export type ConfidenceGrade = z.infer<typeof confidenceGradeSchema>;

export const terminalMetricDirectionSchema = z.enum(["lower_is_better", "higher_is_better"]);
export type TerminalMetricDirection = z.infer<typeof terminalMetricDirectionSchema>;

export const analysisRunStatusSchema = z.enum(["pending", "running", "complete", "failed"]);
export type AnalysisRunStatus = z.infer<typeof analysisRunStatusSchema>;

export const analysisRunInputTypeSchema = z.enum([
  "upload",
  "client_context",
  "creative_asset",
  "landing_page",
  "strategy_note",
  "prior_report",
  "api_snapshot",
]);
export type AnalysisRunInputType = z.infer<typeof analysisRunInputTypeSchema>;

export const entityScopeSchema = z.enum([
  "account",
  "campaign",
  "ad_set",
  "ad",
  "creative",
  "landing_page",
  "cohort",
]);
export type EntityScope = z.infer<typeof entityScopeSchema>;

export const severitySchema = z.enum(["info", "watch", "warning", "critical"]);
export type Severity = z.infer<typeof severitySchema>;

export const intelligenceCardStatusSchema = z.enum([
  "draft",
  "reviewed",
  "approved",
  "dismissed",
  "archived",
]);
export type IntelligenceCardStatus = z.infer<typeof intelligenceCardStatusSchema>;

export const creativeBriefStatusSchema = z.enum([
  "draft",
  "approved",
  "in_production",
  "launched",
  "archived",
]);
export type CreativeBriefStatus = z.infer<typeof creativeBriefStatusSchema>;

export const briefTypeSchema = z.enum(["matrix", "general"]);
export const briefVoiceSchema = z.enum(["ugc", "brand", "ai_ugc"]);
export const briefAssetTypeSchema = z.enum(["static", "video", "carousel", "ai_video"]);

export const reportTypeSchema = z.enum(["internal", "client_facing", "executive_summary"]);
export const reportStatusSchema = z.enum(["draft", "reviewed", "approved", "delivered"]);

// Budget-scope hard constraint (Blueprint §10.1): BSIL suggestions bind ONLY to
// campaign or ad_set. Never creative, copy, angle, variable, or landing_page.
export const budgetScopeObjectSchema = z.enum(["campaign", "ad_set"]);
export type BudgetScopeObject = z.infer<typeof budgetScopeObjectSchema>;

export const bsilSuggestionTypeSchema = z.enum([
  "scale",
  "reduce",
  "pause",
  "hold",
  "reallocate",
]);
export const bsilStatusSchema = z.enum(["pending", "approved", "rejected", "executed_manually"]);

export const approvedForSchema = z.enum([
  "internal_use",
  "client_report",
  "creative_brief",
  "strategy_export",
  "learning_registry",
]);
export type ApprovedFor = z.infer<typeof approvedForSchema>;

// Canonical MST verdicts — exactly four values, never a fifth. Finer descriptors
// (moderate, solid, strong...) belong in performance_band, never here.
export const mstVerdictSchema = z.enum([
  "universal_winner",
  "avatar_dependent",
  "underperformer",
  "insufficient_data",
]);
export type MSTVerdict = z.infer<typeof mstVerdictSchema>;

export const mstCombinationStatusSchema = z.enum(["winning_combination", "avoid_combination"]);
export const mstFormulaStatusSchema = z.enum(["golden_formula"]);

export const variableFamilySchema = z.enum([
  "CN",
  "FW",
  "TN",
  "ST",
  "AW",
  "HP",
  "PR",
  "HK",
  "CTA",
]);
export type VariableFamily = z.infer<typeof variableFamilySchema>;
