// Mirrors docs/prompts/MST_TEST_ENGINE_v2.0.md output shape.
// mst_cell_code is the matrix-cell identifier — never creative_id (§7).
// verdict is restricted to the canonical four; performance_band carries any
// finer descriptor (moderate, solid, strong...) and is never a fifth verdict.
import { z } from "zod";
import { mstCombinationStatusSchema, mstFormulaStatusSchema, mstVerdictSchema } from "./enums.js";

const matrixPositionSchema = z.object({
  concept: z.string().min(1),
  angle: z.string().min(1),
  row_color: z.string().nullable().optional(),
});

const variableStackSchema = z.object({
  concept_vars: z.array(z.string()).default([]),
  angle_vars: z.array(z.string()).default([]),
});

export const mstCreativePerformanceSchema = z.object({
  mst_cell_code: z.string().min(1),
  cohort_key: z.string().min(1),
  matrix_position: matrixPositionSchema,
  variable_stack: variableStackSchema,
  metrics: z.record(z.string(), z.number().nullable()).default({}),
  secondary_metrics: z.record(z.string(), z.number().nullable()).default({}),
  verdict: mstVerdictSchema,
  performance_band: z.string().nullable().optional(),
});
export type MSTCreativePerformance = z.infer<typeof mstCreativePerformanceSchema>;

const variableVerdictSchema = z.object({
  variable_code: z.string().min(1),
  verdict: mstVerdictSchema,
  performance_band: z.string().nullable().optional(),
});

const combinationSchema = z.object({
  variable_codes: z.array(z.string()).default([]),
  combination_status: mstCombinationStatusSchema,
});

const goldenFormulaSchema = z.object({
  variable_codes: z.array(z.string()).default([]),
  formula_status: mstFormulaStatusSchema,
  supporting_cell_codes: z.array(z.string()).default([]),
});

export const mstTestEngineOutputSchema = z.object({
  analysis_run_id: z.string().uuid(),
  cohort_key: z.string().min(1),
  creative_performance: z.array(mstCreativePerformanceSchema).default([]),
  variable_verdicts: z.array(variableVerdictSchema).default([]),
  combinations: z.array(combinationSchema).default([]),
  golden_formulas: z.array(goldenFormulaSchema).default([]),
  contract_version: z.string().min(1),
  schema_version: z.string().min(1),
});
export type MSTTestEngineOutput = z.infer<typeof mstTestEngineOutputSchema>;
