import { describe, expect, it } from "vitest";
import {
  bsilSuggestionSchema,
  budgetScopeObjectSchema,
  globalVariableRegistryEntrySchema,
  intelligenceCardSchema,
  mstVerdictSchema,
} from "../index.js";

describe("budget scope hard constraint", () => {
  it("rejects a creative-scoped BSIL suggestion", () => {
    const attempt = bsilSuggestionSchema.safeParse({
      client_id: "11111111-1111-1111-1111-111111111111",
      budget_scope_object: "creative",
      entity_id: "22222222-2222-2222-2222-222222222222",
      scope_key: "scope-1",
      suggestion_type: "scale",
      confidence_grade: "HIGH",
      contract_version: "v1",
      schema_version: "v1",
    });
    expect(attempt.success).toBe(false);
  });

  it("accepts campaign and ad_set", () => {
    expect(budgetScopeObjectSchema.safeParse("campaign").success).toBe(true);
    expect(budgetScopeObjectSchema.safeParse("ad_set").success).toBe(true);
  });
});

describe("MST canonical verdict taxonomy", () => {
  it("rejects a fifth verdict value", () => {
    expect(mstVerdictSchema.safeParse("strong_performer").success).toBe(false);
  });

  it("accepts only the four canonical values", () => {
    for (const v of ["universal_winner", "avatar_dependent", "underperformer", "insufficient_data"]) {
      expect(mstVerdictSchema.safeParse(v).success).toBe(true);
    }
  });
});

describe("intelligence card cohort discipline", () => {
  it("requires a cohort_key (cross-cohort blending is never valid)", () => {
    const attempt = intelligenceCardSchema.safeParse({
      client_id: "11111111-1111-1111-1111-111111111111",
      card_type: "creative_dna",
      title: "Test",
      summary: "Test",
      confidence_grade: "MODERATE",
      contract_version: "v1",
      schema_version: "v1",
    });
    expect(attempt.success).toBe(false);
  });
});

describe("global variable registry", () => {
  it("rejects a variable_code that doesn't match its family prefix", () => {
    const attempt = globalVariableRegistryEntrySchema.safeParse({
      variable_code: "CN_Comparison",
      variable_family: "FW",
      label: "Comparison",
      definition: "test",
    });
    expect(attempt.success).toBe(false);
  });

  it("rejects a deprecated row without superseded_by", () => {
    const attempt = globalVariableRegistryEntrySchema.safeParse({
      variable_code: "PR_SocialProof",
      variable_family: "PR",
      label: "Social Proof",
      definition: "test",
      status: "deprecated",
    });
    expect(attempt.success).toBe(false);
  });

  it("accepts the real PR_SocialProof -> PR_MassProof deprecation", () => {
    const attempt = globalVariableRegistryEntrySchema.safeParse({
      variable_code: "PR_SocialProof",
      variable_family: "PR",
      label: "Social Proof",
      definition: "test",
      status: "deprecated",
      superseded_by: "PR_MassProof",
    });
    expect(attempt.success).toBe(true);
  });
});
