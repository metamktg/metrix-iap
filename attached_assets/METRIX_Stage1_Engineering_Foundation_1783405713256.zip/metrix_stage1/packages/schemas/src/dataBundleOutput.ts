// Mirrors docs/prompts/IAP_DATA_BUNDLE_PREP_v2.0.md output shape.
// This is the normalization + intake-quality-check output stage that feeds
// IAP_ANALYSIS_CORE. active_cohorts must match the analysis_run_cohorts
// snapshot for the run, not the live client_enabled_cohorts state.
import { z } from "zod";

const intakeSummarySchema = z.object({
  total_rows_imported: z.number().int().nonnegative().default(0),
  files_processed: z.array(z.string()).default([]),
  unique_campaigns: z.number().int().nonnegative().default(0),
  unique_ad_sets: z.number().int().nonnegative().default(0),
  unique_ads: z.number().int().nonnegative().default(0),
  unique_demographics: z.number().int().nonnegative().default(0),
  unique_placements: z.number().int().nonnegative().default(0),
  active_cohorts: z.array(z.string()).default([]),
  data_points_analyzed: z.number().int().nonnegative().optional(),
});

const perCohortTotalsSchema = z.object({
  cohort_key: z.string().min(1),
  terminal_metric: z.string().min(1),
  terminal_stage_events: z.number().int().nonnegative().default(0),
  overall_terminal_metric_value: z.number().default(0),
  overall_ctr: z.number().default(0),
  overall_terminal_rate: z.number().default(0),
});

const campaignTotalsSchema = z.object({
  total_spend: z.number().default(0),
  total_impressions: z.number().int().nonnegative().default(0),
  total_clicks: z.number().int().nonnegative().default(0),
  per_cohort: z.array(perCohortTotalsSchema).default([]),
});

export const iapDataBundleOutputSchema = z.object({
  analysis_run_id: z.string().uuid(),
  intake_summary: intakeSummarySchema,
  campaign_totals: campaignTotalsSchema,
  // confidence_level here is bundle-level intake confidence, distinct from the
  // per-card confidence_grade used downstream in intelligence_cards.
  confidence_level: z.enum(["high", "medium", "validation_required", "insufficient"]),
  anomalies: z
    .array(
      z.object({
        anomaly_type: z.string().min(1),
        description: z.string().min(1),
        affected_scope: z.string().nullable().optional(),
      }),
    )
    .default([]),
  contract_version: z.string().min(1),
  schema_version: z.string().min(1),
});
export type IAPDataBundleOutput = z.infer<typeof iapDataBundleOutputSchema>;
