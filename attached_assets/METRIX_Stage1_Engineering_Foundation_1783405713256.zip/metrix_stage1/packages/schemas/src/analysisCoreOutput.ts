// Mirrors docs/prompts/IAP_ANALYSIS_CORE_v2.0.md output shape. This is the
// intelligence-extraction stage that reads an IAPDataBundleOutput and produces
// the signal groups that intelligence_cards get built from downstream.
import { z } from "zod";

const funnelPerformanceSchema = z.object({
  cohort_key: z.string().min(1),
  stage_rates: z.record(z.string(), z.number()).default({}),
  terminal_rate: z.number().default(0),
  terminal_metric_value: z.number().default(0),
  buying_intent_score: z.number().nullable().optional(),
  funnel_drop_stage: z.string().nullable().optional(),
});

const trafficQualitySignalSchema = z.object({
  pattern_type: z.string().min(1),
  copy_ids: z.array(z.string()).default([]),
  insight: z.string().min(1),
  strategic_implication: z.string().min(1),
});

const psychologyPatternSchema = z.object({
  indicator_type: z.string().min(1),
  affected_segments: z.array(z.string()).default([]),
  pattern_description: z.string().min(1),
  audience_insight: z.string().min(1),
  application: z.string().min(1),
});

const creativeDnaSignalSchema = z.object({
  signal_type: z.enum(["concept", "angle", "hook", "format", "copy_length", "tone"]),
  winning_variants: z.array(z.string()).default([]),
  performance_delta: z.number().nullable().optional(),
  consistency_score: z.string().nullable().optional(),
  isolation_confidence: z.enum(["high", "medium", "requires_validation"]),
});

const themePerformanceSchema = z.object({
  theme: z.string().min(1),
  copy_count: z.number().int().nonnegative().default(0),
  aggregated_metrics: z.record(z.string(), z.number()).default({}),
  top_performer: z.record(z.string(), z.unknown()).default({}),
});

export const iapAnalysisCoreOutputSchema = z.object({
  analysis_run_id: z.string().uuid(),
  funnel_performance: z.array(funnelPerformanceSchema).default([]),
  traffic_quality_signals: z.array(trafficQualitySignalSchema).default([]),
  psychology_patterns: z.array(psychologyPatternSchema).default([]),
  creative_dna_signals: z.array(creativeDnaSignalSchema).default([]),
  theme_performance: z.array(themePerformanceSchema).default([]),
  contract_version: z.string().min(1),
  schema_version: z.string().min(1),
});
export type IAPAnalysisCoreOutput = z.infer<typeof iapAnalysisCoreOutputSchema>;
