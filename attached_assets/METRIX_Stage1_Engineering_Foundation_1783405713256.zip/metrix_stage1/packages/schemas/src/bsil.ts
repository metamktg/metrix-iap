// Mirrors supabase/migrations/20260706000600_alerts_bsil.sql.
// Hard constraint: budget_scope_object in ('campaign','ad_set') only.
// Metrix is suggestion-only — nothing here executes against a live account.
import { z } from "zod";
import { budgetScopeObjectSchema, bsilStatusSchema, bsilSuggestionTypeSchema, confidenceGradeSchema } from "./enums.js";

export const bsilSuggestionSchema = z.object({
  id: z.string().uuid().optional(),
  analysis_run_id: z.string().uuid().nullable().optional(),
  client_id: z.string().uuid(),
  budget_scope_object: budgetScopeObjectSchema,
  entity_id: z.string().uuid(),
  scope_key: z.string().min(1),
  suggestion_type: bsilSuggestionTypeSchema,
  suggested_change: z.record(z.string(), z.unknown()).default({}),
  confidence_grade: confidenceGradeSchema,
  rationale_json: z.record(z.string(), z.unknown()).default({}),
  cohort_key: z.string().min(1).nullable().optional(),
  contract_version: z.string().min(1),
  schema_version: z.string().min(1),
  status: bsilStatusSchema.default("pending"),
  created_at: z.string().datetime().optional(),
});
export type BSILSuggestion = z.infer<typeof bsilSuggestionSchema>;
