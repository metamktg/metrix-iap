// Mirrors supabase/migrations/20260706000300_analysis_runs.sql.
import { z } from "zod";
import { analysisRunInputTypeSchema, analysisRunStatusSchema } from "./enums.js";

export const analysisRunSchema = z.object({
  id: z.string().uuid().optional(),
  client_id: z.string().uuid(),
  triggered_by: z.string().uuid().nullable().optional(),
  status: analysisRunStatusSchema.default("pending"),
  engine_version: z.string().min(1),
  created_at: z.string().datetime().optional(),
  completed_at: z.string().datetime().nullable().optional(),
});
export type AnalysisRun = z.infer<typeof analysisRunSchema>;

export const analysisRunInputSchema = z.object({
  id: z.string().uuid().optional(),
  analysis_run_id: z.string().uuid(),
  input_type: analysisRunInputTypeSchema,
  source_table: z.string().nullable().optional(),
  source_id: z.string().uuid().nullable().optional(),
  payload: z.record(z.string(), z.unknown()).default({}),
  created_at: z.string().datetime().optional(),
});
export type AnalysisRunInput = z.infer<typeof analysisRunInputSchema>;

// One row per prompt/skill stage executed within a run. prompt_name should
// resolve against the iap-engine prompt registry (docs/prompts/*_v2.0.md).
export const analysisRunStageSchema = z.object({
  id: z.string().uuid().optional(),
  analysis_run_id: z.string().uuid(),
  prompt_name: z.string().min(1),
  prompt_version: z.string().min(1),
  skill_name: z.string().nullable().optional(),
  skill_version: z.string().nullable().optional(),
  engine_version: z.string().min(1),
  input_schema_version: z.string().min(1),
  output_schema_version: z.string().min(1),
  started_at: z.string().datetime().optional(),
  completed_at: z.string().datetime().nullable().optional(),
  status: analysisRunStatusSchema.default("pending"),
});
export type AnalysisRunStage = z.infer<typeof analysisRunStageSchema>;
