// Mirrors supabase/migrations/20260706000400_outputs.sql.
import { z } from "zod";
import {
  briefAssetTypeSchema,
  briefTypeSchema,
  briefVoiceSchema,
  confidenceGradeSchema,
  creativeBriefStatusSchema,
  entityScopeSchema,
  intelligenceCardStatusSchema,
  reportStatusSchema,
  reportTypeSchema,
  severitySchema,
} from "./enums.js";

// entity_scope enforces the BSIL budget-scope constraint surface (§10.1) at the
// reporting layer. Each card carries a single cohort_key — cross-cohort scores
// are never blended (§6.5), so cohort_key is required, not optional.
export const intelligenceCardSchema = z.object({
  id: z.string().uuid().optional(),
  analysis_run_id: z.string().uuid().nullable().optional(),
  client_id: z.string().uuid(),
  card_type: z.string().min(1),
  card_subtype: z.string().nullable().optional(),
  title: z.string().min(1),
  summary: z.string().min(1),
  evidence_json: z.record(z.string(), z.unknown()).default({}),
  implication_json: z.record(z.string(), z.unknown()).default({}),
  recommendation_json: z.record(z.string(), z.unknown()).default({}),
  named_factors: z.array(z.string()).default([]),
  confidence_grade: confidenceGradeSchema,
  confidence_score: z.number().nullable().optional(),
  severity: severitySchema.nullable().optional(),
  priority: z.number().int().default(100),
  cohort_key: z.string().min(1),
  entity_scope: entityScopeSchema.nullable().optional(),
  entity_id: z.string().uuid().nullable().optional(),
  budget_scope_object: z.enum(["campaign", "ad_set"]).nullable().optional(),
  payload: z.record(z.string(), z.unknown()).default({}),
  contract_version: z.string().min(1),
  schema_version: z.string().min(1),
  status: intelligenceCardStatusSchema.default("draft"),
  created_at: z.string().datetime().optional(),
});
export type IntelligenceCard = z.infer<typeof intelligenceCardSchema>;

export const creativeBriefSchema = z.object({
  id: z.string().uuid().optional(),
  client_id: z.string().uuid(),
  analysis_run_id: z.string().uuid().nullable().optional(),
  brief_type: briefTypeSchema,
  voice: briefVoiceSchema.nullable().optional(),
  asset_type: briefAssetTypeSchema.nullable().optional(),
  // concept_code, not creative_id — matches the locked identity model (§7).
  concept_code: z.string().nullable().optional(),
  angle_stack: z.array(z.string()).default([]),
  target_icp: z.record(z.string(), z.unknown()).default({}),
  message_pillar: z.string().nullable().optional(),
  brief_payload: z.record(z.string(), z.unknown()).default({}),
  contract_version: z.string().min(1),
  schema_version: z.string().min(1),
  status: creativeBriefStatusSchema.default("draft"),
  created_at: z.string().datetime().optional(),
});
export type CreativeBrief = z.infer<typeof creativeBriefSchema>;

export const reportSchema = z.object({
  id: z.string().uuid().optional(),
  client_id: z.string().uuid(),
  analysis_run_id: z.string().uuid().nullable().optional(),
  report_type: reportTypeSchema,
  title: z.string().min(1),
  content_json: z.record(z.string(), z.unknown()).default({}),
  contract_version: z.string().min(1),
  schema_version: z.string().min(1),
  status: reportStatusSchema.default("draft"),
  created_at: z.string().datetime().optional(),
});
export type Report = z.infer<typeof reportSchema>;
