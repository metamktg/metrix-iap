// Mirrors supabase/migrations/20260707000900_global_variable_registry.sql.
// Config-as-data, same pattern as cohort_definitions: a new variable code is a
// new row, never a schema change. Deprecated rows are never deleted — they get
// status: 'deprecated' and a superseded_by pointer so historical creative
// tagged with the old code stays resolvable.
import { z } from "zod";
import { variableFamilySchema } from "./enums.js";

export const globalVariableRegistryEntrySchema = z
  .object({
    variable_code: z.string().min(1),
    variable_family: variableFamilySchema,
    label: z.string().min(1),
    definition: z.string().min(1),
    strategic_role: z.string().nullable().optional(),
    is_required_in_stack: z.boolean().default(false),
    typical_pairings: z.array(z.string()).default([]),
    best_for_concepts: z.array(z.string()).default([]),
    common_elements: z.array(z.string()).default([]),
    typical_formats: z.array(z.string()).default([]),
    best_funnel_stage: z.array(z.string()).default([]),
    performance_indicators: z.array(z.string()).default([]),
    status: z.enum(["active", "deprecated"]).default("active"),
    superseded_by: z.string().nullable().optional(),
    deprecation_note: z.string().nullable().optional(),
    effective_date: z.string().date().optional(),
    schema_version: z.string().default("v1.0"),
    created_at: z.string().datetime().optional(),
    updated_at: z.string().datetime().optional(),
  })
  .refine((row) => row.variable_code.startsWith(`${row.variable_family}_`), {
    message: "variable_code must be prefixed with its variable_family (e.g. CN_...)",
    path: ["variable_code"],
  })
  .refine((row) => row.status === "active" || !!row.superseded_by, {
    message: "deprecated rows must set superseded_by",
    path: ["superseded_by"],
  });
export type GlobalVariableRegistryEntry = z.infer<typeof globalVariableRegistryEntrySchema>;
