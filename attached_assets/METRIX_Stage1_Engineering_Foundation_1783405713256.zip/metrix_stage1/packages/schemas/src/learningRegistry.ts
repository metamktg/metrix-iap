// Mirrors supabase/migrations/20260706000700_review_approval_learning.sql.
// Hard rule: a learning_registry row must reference an approval_events row
// with approved_for = 'learning_registry'. approval_event_id is therefore
// required here, not optional — validate against the DB rule before write,
// see packages/metrix-core/bsil (approval guard lives alongside budget guard).
import { z } from "zod";
import { approvedForSchema } from "./enums.js";

export const learningRegistryEntrySchema = z.object({
  id: z.string().uuid().optional(),
  client_id: z.string().uuid(),
  source_object_type: z.string().min(1),
  source_object_id: z.string().uuid(),
  cohort_key: z.string().min(1).nullable().optional(),
  learning_summary: z.string().min(1),
  variable_weight_deltas: z.record(z.string(), z.number()).default({}),
  approval_event_id: z.string().uuid(),
  contract_version: z.string().min(1),
  schema_version: z.string().min(1),
  created_at: z.string().datetime().optional(),
});
export type LearningRegistryEntry = z.infer<typeof learningRegistryEntrySchema>;

// approval_events row shape, needed to validate the approved_for gate before
// a learning_registry write is attempted.
export const approvalEventSchema = z.object({
  id: z.string().uuid().optional(),
  analysis_run_id: z.string().uuid().nullable().optional(),
  object_type: z.string().min(1),
  object_id: z.string().uuid(),
  approver_id: z.string().uuid().nullable().optional(),
  approved_for: approvedForSchema,
  created_at: z.string().datetime().optional(),
});
export type ApprovalEvent = z.infer<typeof approvalEventSchema>;
