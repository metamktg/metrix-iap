// Cohorts are config-as-data (migration 0002): a new business model is a new row
// in cohort_definitions, never a schema change. Mirrors
// docs/data-model/METRIX_Cohort_Architecture_v1.md.
import { z } from "zod";
import { terminalMetricDirectionSchema } from "./enums.js";

export const cohortDefinitionSchema = z.object({
  cohort_key: z.string().min(1),
  label: z.string().min(1),
  funnel_stages: z.array(z.string().min(1)).default([]),
  intent_score_weights: z.record(z.string(), z.number()).default({}),
  terminal_metric: z.string().min(1),
  terminal_metric_direction: terminalMetricDirectionSchema,
  required_metric_block: z.string().min(1),
  schema_version: z.string().min(1),
  created_at: z.string().datetime().optional(),
  updated_at: z.string().datetime().optional(),
});
export type CohortDefinition = z.infer<typeof cohortDefinitionSchema>;

// client_enabled_cohorts is the table the Settings checklist (Plane 4) reads and
// writes directly. Multiple cohorts may be enabled per client; is_primary marks
// exactly one as the default surface, enforced at the application layer since
// Postgres has no native "exactly one true per client_id" constraint here.
export const clientEnabledCohortSchema = z.object({
  id: z.string().uuid().optional(),
  client_id: z.string().uuid(),
  cohort_key: z.string().min(1),
  enabled: z.boolean().default(true),
  priority: z.number().int().default(100),
  is_primary: z.boolean().default(false),
  cohort_config: z.record(z.string(), z.unknown()).default({}),
  kpi_targets: z.record(z.string(), z.unknown()).default({}),
  created_at: z.string().datetime().optional(),
  updated_at: z.string().datetime().optional(),
});
export type ClientEnabledCohort = z.infer<typeof clientEnabledCohortSchema>;

// analysis_run_cohorts: the per-run snapshot. Because client_enabled_cohorts is
// reconfigurable, every run records which cohorts were active for that run, so
// historical runs stay interpretable after a client's business model changes.
export const analysisRunCohortSnapshotSchema = z.object({
  id: z.string().uuid().optional(),
  analysis_run_id: z.string().uuid(),
  cohort_key: z.string().min(1),
  was_enabled: z.boolean().default(true),
  cohort_config_snapshot: z.record(z.string(), z.unknown()).default({}),
  created_at: z.string().datetime().optional(),
});
export type AnalysisRunCohortSnapshot = z.infer<typeof analysisRunCohortSnapshotSchema>;
