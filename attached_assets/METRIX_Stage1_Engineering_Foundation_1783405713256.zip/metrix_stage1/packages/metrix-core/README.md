# @metrix/metrix-core

Deterministic, non-LLM logic. No prompt execution, no I/O — every function
here is a pure function over data passed in by the caller (`packages/db`,
`apps/worker`, `packages/iap-engine`).

## Modules

- **`cohort/`** — `resolveActiveCohorts`, `createRunCohortSnapshot`. Reads the
  live `client_enabled_cohorts` state vs. the per-run snapshot; never blends
  the two.
- **`creative-resolution/`** — `parseNamingConvention`, `resolveByAdIdFallback`,
  `markUnresolved`, and the `resolveCreativeIdentity` orchestrator that
  implements the locked Resolver contract: naming-convention parse is
  primary, `ad_id` is fallback, identical behavior for CSV and API input.
- **`confidence/`** — `classifySignalConfidence`, `normalizeTerminalMetricDirection`.
- **`mst/`** — `validateMSTVerdict`, `classifyPerformanceBand`,
  `validateMSTCellCode`/`buildMSTCellCode`.
- **`bsil/`** — `validateBudgetScope`, `rejectCreativeLevelBudgetSuggestion`.
- **`approval/`** — `validateLearningRegistryApproval` (added beyond the
  original Stage 1 module list — the learning-registry approval gate is a
  locked hard rule with no other home; additive, not a scope change).

## A note on the naming-convention parser

`parseNamingConvention` is grounded directly in the canonical "Meta Ads Naming
Convention System" doc in Drive (fetched and confirmed 2026-07-07), not a
guess. The AD LEVEL structure is `[CONCEPT_VAR]_[TYPE]_[LANDING_PAGE]_[TEST_ID]`,
e.g. `C1A_STC_PDP_T1`. `CONCEPT_VAR` (e.g. `C1A`, `U5A`, `W1B`) is the
`concept_code` — the same token shape as `mst_cell_code` for Test Matrix
concepts. There is no ad-name hook-type slot in this convention (hook is a
copy-level `HK_` variable, not a naming token), so `hook_type` is always
`null` from this parser and gets populated downstream from copy metadata. If
the live Drive doc changes the convention, update
`creative-resolution/parseNamingConvention.ts` to match — do not let this
silently diverge from the real convention again.

## Design rule

Nothing in this package calls Supabase, the Anthropic API, or any prompt
runner. If a function needs to fetch something, it belongs in `packages/db`
or `packages/iap-engine`, not here.
