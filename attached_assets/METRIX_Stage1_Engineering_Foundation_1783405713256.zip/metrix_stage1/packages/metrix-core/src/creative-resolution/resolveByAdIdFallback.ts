// ad_id is the FALLBACK join key only (Blueprint v2.0 §7) — used when naming
// convention parsing fails to find a concept_code. This never invents a
// concept_code; it simply anchors identity on ad_id so metrics still join
// correctly across the pipeline.
import type { CreativeIdentityResolution } from "@metrix/schemas";

export function resolveByAdIdFallback(adId: string): CreativeIdentityResolution {
  return {
    ad_id: adId,
    concept_code: null,
    variation_id: null,
    format_type: null,
    hook_type: null,
    custom_tags: [],
    resolution_method: "ad_id_fallback",
    unresolved_reason: null,
    confidence: "fallback",
  };
}
