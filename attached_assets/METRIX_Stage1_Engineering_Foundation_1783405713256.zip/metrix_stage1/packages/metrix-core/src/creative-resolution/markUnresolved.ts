// Used when neither naming-convention parsing nor ad_id are usable (e.g. a
// malformed export row missing ad_id entirely). Per the "known gaps should be
// flagged, not invented" principle, this never fabricates an identifier —
// it produces an explicit unresolved record with a reason string so the
// intake-quality-check stage (IAP_DATA_BUNDLE_PREP) can surface it as an
// anomaly rather than silently dropping the row.
import type { CreativeIdentityResolution } from "@metrix/schemas";

export function markUnresolved(
  adId: string | null,
  reason: string,
): CreativeIdentityResolution {
  return {
    ad_id: adId ?? "unknown",
    concept_code: null,
    variation_id: null,
    format_type: null,
    hook_type: null,
    custom_tags: [],
    resolution_method: "unresolved",
    unresolved_reason: reason,
    confidence: "fallback",
  };
}
