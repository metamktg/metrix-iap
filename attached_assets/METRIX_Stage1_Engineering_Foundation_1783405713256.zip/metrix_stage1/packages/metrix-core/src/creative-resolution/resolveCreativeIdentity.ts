// The Resolver (Blueprint v2.0, locked decision): a pure function over a
// normalized record shape. Naming-convention parse is primary, ad_id is
// fallback. Operates identically for CSV and API input because both are
// normalized to NormalizedRecord before this ever runs — this function has
// no knowledge of the original source format.
import type { NormalizedRecord, CreativeIdentityResolution } from "@metrix/schemas";
import { parseNamingConvention, toResolutionFromNamingConvention } from "./parseNamingConvention.js";
import { resolveByAdIdFallback } from "./resolveByAdIdFallback.js";
import { markUnresolved } from "./markUnresolved.js";

export function resolveCreativeIdentity(record: NormalizedRecord): CreativeIdentityResolution {
  if (!record.ad_id) {
    return markUnresolved(null, "record missing ad_id — cannot resolve or fall back");
  }

  const parsed = parseNamingConvention(record.ad_name);
  if (parsed.matched) {
    return toResolutionFromNamingConvention(record.ad_id, parsed);
  }

  return resolveByAdIdFallback(record.ad_id);
}
