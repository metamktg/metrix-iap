// Parses an ad_name into its naming-convention tokens, per the canonical
// "Meta Ads Naming Convention System" doc (Drive, live — confirmed via direct
// fetch on 2026-07-07). concept_code (the CONCEPT_VAR token, e.g. "C1A") is
// the PRIMARY identifier (Blueprint v2.0 §7) — this function never produces
// or reads a creative_id.
//
// AD LEVEL structure (the "core system"): [CONCEPT_VAR]_[TYPE]_[LANDING_PAGE]_[TEST_ID]
// e.g. C1A_STC_PDP_T1 = Concept 1 Variation A, Static, Product Page, Test 1.
//
// CONCEPT_VAR = one category prefix letter + concept number + variation letter:
//   C = Concept (Test Matrix)   U = UGC             P = Client Provided
//   A = Ad Hoc                  W = Winner Iteration O = Organic
// This is the SAME token format as mst_cell_code (e.g. "C1A") for Test Matrix
// concepts specifically — see mst/validateMSTCellCode.ts.
//
// TYPE = UGC | STC | VID | GIF | CAR | COL | SOC | SLI
// LANDING_PAGE = HP | PDP | ADV | QZ | BLG | CLP | CHK | REV | FAQ | CMP | PRE | TRL
// TEST_ID = T<n> (T1-T5 observed; treat T\d+ generically)
//
// The final slot may instead carry a seasonal/geo/platform modifier in place
// of a test_id (documented "Advanced" adaptations, e.g. "_BF" for Black
// Friday, "_CA" for Canada, "_TT" for TikTok) — these are captured as
// custom_tags rather than forced into test_id.
//
// There is no sprint-version token anywhere in this convention (locked
// decision) — sprint/batch context is a database association (which
// analysis_run an ad_id appears in), never parsed from the ad name.
import type { CreativeIdentityResolution } from "@metrix/schemas";

const CONCEPT_VAR_PATTERN = /^[CUPAWO]\d+[A-Z]$/;
const TYPE_CODES = new Set(["UGC", "STC", "VID", "GIF", "CAR", "COL", "SOC", "SLI"]);
const LANDING_PAGE_CODES = new Set([
  "HP",
  "PDP",
  "ADV",
  "QZ",
  "BLG",
  "CLP",
  "CHK",
  "REV",
  "FAQ",
  "CMP",
  "PRE",
  "TRL",
]);
const TEST_ID_PATTERN = /^T\d+$/;

export interface ParseNamingConventionResult {
  concept_code: string | null;
  variation_id: string | null;
  format_type: "static" | "video" | "carousel" | null;
  hook_type: string | null;
  custom_tags: string[];
  /** true only when a CONCEPT_VAR token was found in the expected first slot. */
  matched: boolean;
}

const FORMAT_TYPE_BY_CODE: Record<string, "static" | "video" | "carousel" | undefined> = {
  STC: "static",
  VID: "video",
  CAR: "carousel",
};

/**
 * Parses an ad name against the AD LEVEL structure:
 * [CONCEPT_VAR]_[TYPE]_[LANDING_PAGE]_[TEST_ID or modifier].
 *
 * Note: this convention has no dedicated "hook_type" slot — hook is a
 * copy-level variable (HK_ family in the global variable registry), not an
 * ad-name token. hook_type is retained on the result type for schema
 * compatibility but is always null from this parser; it gets populated
 * downstream from copy metadata, not from the name.
 */
export function parseNamingConvention(adName: string): ParseNamingConventionResult {
  const tokens = adName.split("_").filter(Boolean);
  const [conceptVar, typeCode, landingPageCode, lastSlot] = tokens;

  const matched = conceptVar !== undefined && CONCEPT_VAR_PATTERN.test(conceptVar);
  const variation_id = matched ? conceptVar!.match(/[A-Z]$/)?.[0] ?? null : null;

  const format_type =
    typeCode && TYPE_CODES.has(typeCode) ? FORMAT_TYPE_BY_CODE[typeCode] ?? null : null;

  const custom_tags: string[] = [];
  if (typeCode && !TYPE_CODES.has(typeCode)) custom_tags.push(typeCode);
  if (landingPageCode && !LANDING_PAGE_CODES.has(landingPageCode)) custom_tags.push(landingPageCode);
  if (lastSlot && !TEST_ID_PATTERN.test(lastSlot)) custom_tags.push(lastSlot);
  // Anything past the four core slots (seasonal/geo/platform chains) is a custom tag too.
  custom_tags.push(...tokens.slice(4));

  return {
    concept_code: matched ? conceptVar! : null,
    variation_id,
    format_type,
    hook_type: null,
    custom_tags,
    matched,
  };
}

/** Converts a successful naming-convention parse into a resolution record. */
export function toResolutionFromNamingConvention(
  adId: string,
  parsed: ParseNamingConventionResult,
): CreativeIdentityResolution {
  return {
    ad_id: adId,
    concept_code: parsed.concept_code,
    variation_id: parsed.variation_id,
    format_type: parsed.format_type,
    hook_type: parsed.hook_type,
    custom_tags: parsed.custom_tags,
    resolution_method: "naming_convention",
    unresolved_reason: null,
    confidence: parsed.format_type ? "exact" : "partial",
  };
}
