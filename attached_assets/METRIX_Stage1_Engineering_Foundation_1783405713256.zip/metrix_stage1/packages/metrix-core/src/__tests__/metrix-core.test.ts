import { describe, expect, it } from "vitest";
import {
  parseNamingConvention,
  resolveCreativeIdentity,
  resolveActiveCohorts,
  validateMSTVerdict,
  validateMSTCellCode,
  validateBudgetScope,
  rejectCreativeLevelBudgetSuggestion,
  validateLearningRegistryApproval,
  normalizeTerminalMetricDirection,
} from "../index.js";
import type { ClientEnabledCohort, NormalizedRecord } from "@metrix/schemas";

describe("naming convention parsing", () => {
  it("extracts concept_var, format type, and custom tags from a canonical ad name", () => {
    const result = parseNamingConvention("C1A_STC_PDP_T1");
    expect(result.concept_code).toBe("C1A");
    expect(result.variation_id).toBe("A");
    expect(result.format_type).toBe("static");
    expect(result.matched).toBe(true);
  });

  it("parses a winner-iteration video ad", () => {
    const result = parseNamingConvention("W1B_VID_PDP_T1");
    expect(result.concept_code).toBe("W1B");
    expect(result.format_type).toBe("video");
  });

  it("captures a seasonal modifier in the final slot as a custom tag", () => {
    const result = parseNamingConvention("C1A_STC_PDP_BF");
    expect(result.concept_code).toBe("C1A");
    expect(result.custom_tags).toContain("BF");
  });

  it("reports no match when there's no concept_var token", () => {
    const result = parseNamingConvention("random_ad_name_123");
    expect(result.matched).toBe(false);
    expect(result.concept_code).toBeNull();
  });
});

describe("resolver: naming convention primary, ad_id fallback", () => {
  const baseRecord: NormalizedRecord = {
    ad_id: "ad_123",
    ad_name: "some_name",
    cohort_key: "ecommerce",
    source_file: "export.csv",
    source_row_index: 0,
    metrics: {},
    raw: {},
  };

  it("uses naming convention when a concept_code is present", () => {
    const result = resolveCreativeIdentity({ ...baseRecord, ad_name: "C1A_STC_PDP_T1" });
    expect(result.resolution_method).toBe("naming_convention");
    expect(result.concept_code).toBe("C1A");
  });

  it("falls back to ad_id when no concept_code is parseable", () => {
    const result = resolveCreativeIdentity(baseRecord);
    expect(result.resolution_method).toBe("ad_id_fallback");
    expect(result.concept_code).toBeNull();
  });

  it("marks unresolved when ad_id itself is missing", () => {
    const result = resolveCreativeIdentity({ ...baseRecord, ad_id: "" });
    expect(result.resolution_method).toBe("unresolved");
  });
});

describe("cohort resolution", () => {
  const rows: ClientEnabledCohort[] = [
    {
      client_id: "c1",
      cohort_key: "lead_gen",
      enabled: true,
      priority: 200,
      is_primary: false,
      cohort_config: {},
      kpi_targets: {},
    },
    {
      client_id: "c1",
      cohort_key: "ecommerce",
      enabled: true,
      priority: 100,
      is_primary: true,
      cohort_config: {},
      kpi_targets: {},
    },
    {
      client_id: "c1",
      cohort_key: "service",
      enabled: false,
      priority: 50,
      is_primary: false,
      cohort_config: {},
      kpi_targets: {},
    },
  ];

  it("returns only enabled cohorts, sorted by priority", () => {
    const { active, primary } = resolveActiveCohorts(rows);
    expect(active.map((c) => c.cohort_key)).toEqual(["ecommerce", "lead_gen"]);
    expect(primary?.cohort_key).toBe("ecommerce");
  });

  it("throws if more than one primary cohort is enabled", () => {
    const broken = rows.map((r) => ({ ...r, is_primary: true, enabled: true }));
    expect(() => resolveActiveCohorts(broken)).toThrow();
  });
});

describe("MST guards", () => {
  it("validates canonical verdicts only", () => {
    expect(validateMSTVerdict("universal_winner").valid).toBe(true);
    expect(validateMSTVerdict("strong_performer").valid).toBe(false);
  });

  it("validates mst_cell_code shape", () => {
    expect(validateMSTCellCode("C1A").valid).toBe(true);
    expect(validateMSTCellCode("creative_007").valid).toBe(false);
  });
});

describe("BSIL budget scope guard", () => {
  it("accepts campaign and ad_set", () => {
    expect(validateBudgetScope("campaign").valid).toBe(true);
    expect(validateBudgetScope("ad_set").valid).toBe(true);
  });

  it("rejects creative-level scope and throws via the reject helper", () => {
    expect(validateBudgetScope("creative").valid).toBe(false);
    expect(() => rejectCreativeLevelBudgetSuggestion("creative")).toThrow();
  });
});

describe("learning registry approval guard", () => {
  it("rejects a missing approval event", () => {
    expect(() => validateLearningRegistryApproval(null)).toThrow();
  });

  it("rejects an approval event for the wrong purpose", () => {
    expect(() =>
      validateLearningRegistryApproval({
        object_type: "intelligence_card",
        object_id: "11111111-1111-1111-1111-111111111111",
        approved_for: "client_report",
      }),
    ).toThrow();
  });

  it("accepts a correctly scoped approval event", () => {
    expect(() =>
      validateLearningRegistryApproval({
        object_type: "intelligence_card",
        object_id: "11111111-1111-1111-1111-111111111111",
        approved_for: "learning_registry",
      }),
    ).not.toThrow();
  });
});

describe("terminal metric direction normalization", () => {
  it("treats a decrease as improvement when lower_is_better", () => {
    const result = normalizeTerminalMetricDirection(20, 15, "lower_is_better");
    expect(result.improved).toBe(true);
  });

  it("treats an increase as improvement when higher_is_better", () => {
    const result = normalizeTerminalMetricDirection(0.02, 0.03, "higher_is_better");
    expect(result.improved).toBe(true);
  });
});
