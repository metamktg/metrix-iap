// Structural hard constraint (Blueprint v2.0 §10.1): BSIL suggestions bind
// only to budget-bearing objects — campaign or ad_set — never creative, copy,
// angle, variable, or landing_page. This is enforced at three layers: this
// function (application), the Zod schema (packages/schemas), and the
// database check constraint (migration 0006). Belt and suspenders is
// deliberate given the "mistakes are costly" project constraint.
const VALID_BUDGET_SCOPE_OBJECTS = new Set(["campaign", "ad_set"]);

export function validateBudgetScope(scopeObject: string): { valid: boolean; reason?: string } {
  if (VALID_BUDGET_SCOPE_OBJECTS.has(scopeObject)) {
    return { valid: true };
  }
  return {
    valid: false,
    reason: `"${scopeObject}" is not a budget-bearing object. BSIL suggestions may only target "campaign" or "ad_set".`,
  };
}
