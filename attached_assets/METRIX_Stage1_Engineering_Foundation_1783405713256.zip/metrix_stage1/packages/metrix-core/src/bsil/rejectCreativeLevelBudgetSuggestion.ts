// A dedicated rejection path (rather than just calling validateBudgetScope
// and checking `.valid`) so the iap-engine and worker call sites make the
// intent explicit at the point where a suggestion is about to be persisted:
// this throws, it does not just return a boolean, because a creative-level
// budget suggestion reaching the persistence layer is a bug, not a normal
// validation failure to recover from gracefully.
import { validateBudgetScope } from "./validateBudgetScope.js";

export function rejectCreativeLevelBudgetSuggestion(scopeObject: string): void {
  const result = validateBudgetScope(scopeObject);
  if (!result.valid) {
    throw new Error(
      `BSIL budget-scope violation: ${result.reason} This suggestion must not be written to bsil_suggestions.`,
    );
  }
}
