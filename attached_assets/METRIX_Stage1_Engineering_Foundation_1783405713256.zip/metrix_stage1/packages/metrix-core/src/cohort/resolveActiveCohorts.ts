// Deterministic, no I/O. Callers (packages/db, apps/worker) fetch rows from
// Supabase and pass them in; this module never queries anything itself.
import type { ClientEnabledCohort } from "@metrix/schemas";

export interface ResolvedCohorts {
  /** Enabled cohorts sorted by priority ascending (lower number = higher priority). */
  active: ClientEnabledCohort[];
  /** The single primary cohort, if one is both enabled and marked is_primary. */
  primary: ClientEnabledCohort | null;
}

/**
 * Resolves which cohorts are active for a client right now, from the live
 * client_enabled_cohorts rows. This is the "current state" read — for what
 * was active during a specific past run, use the analysis_run_cohorts
 * snapshot instead, never this function (client_enabled_cohorts is mutable
 * and reconfigurable; a historical run must stay interpretable against its
 * own snapshot, not today's config).
 */
export function resolveActiveCohorts(rows: ClientEnabledCohort[]): ResolvedCohorts {
  const active = rows
    .filter((row) => row.enabled)
    .slice()
    .sort((a, b) => a.priority - b.priority);

  const primaryCandidates = active.filter((row) => row.is_primary);
  if (primaryCandidates.length > 1) {
    throw new Error(
      `resolveActiveCohorts: more than one primary cohort enabled for client (${primaryCandidates
        .map((c) => c.cohort_key)
        .join(", ")}). This must be exactly one — fix client_enabled_cohorts before proceeding.`,
    );
  }

  return {
    active,
    primary: primaryCandidates[0] ?? null,
  };
}
