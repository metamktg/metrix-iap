// Because client_enabled_cohorts is reconfigurable, every analysis_run must
// record which cohorts were active for that run at the moment it ran. This is
// what makes historical runs interpretable after a client's business model
// changes later. Called once, at run creation — never re-derived afterward.
import type { AnalysisRunCohortSnapshot, ClientEnabledCohort } from "@metrix/schemas";

export function createRunCohortSnapshot(
  analysisRunId: string,
  enabledCohorts: ClientEnabledCohort[],
): AnalysisRunCohortSnapshot[] {
  return enabledCohorts.map((cohort) => ({
    analysis_run_id: analysisRunId,
    cohort_key: cohort.cohort_key,
    was_enabled: cohort.enabled,
    cohort_config_snapshot: cohort.cohort_config,
  }));
}
