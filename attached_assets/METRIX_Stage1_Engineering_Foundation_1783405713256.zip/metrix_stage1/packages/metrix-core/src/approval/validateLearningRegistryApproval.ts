// Locked rule: learning_registry writes require an explicit approval_events
// row with approved_for = 'learning_registry'. No analysis output feeds
// IAP_OPTIMIZATION_LOOP without a human approving it first. Mirrors the
// budget-scope guard pattern in bsil/ — deterministic check, throws on
// violation because a bypass reaching persistence is a bug.
import type { ApprovalEvent } from "@metrix/schemas";

export function validateLearningRegistryApproval(event: ApprovalEvent | null | undefined): void {
  if (!event) {
    throw new Error(
      "learning_registry write rejected: no approval_events row provided. An explicit human approval is required before any write to the learning registry.",
    );
  }
  if (event.approved_for !== "learning_registry") {
    throw new Error(
      `learning_registry write rejected: approval_events row has approved_for="${event.approved_for}", not "learning_registry".`,
    );
  }
}
