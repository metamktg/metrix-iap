// performance_band is a descriptive, non-verdict field (see
// docs/prompts/MST_TEST_ENGINE_v2.0.md examples: "moderate", "solid",
// "promising", "strong"). It NEVER becomes a fifth verdict value — this
// function only runs on cells that already carry a canonical verdict and
// simply adds color for reporting.
export type PerformanceBand = "promising" | "moderate" | "solid" | "strong";

/**
 * @param performanceDeltaPct How far above the cohort's median terminal
 *   metric this cell performed, as a percentage (already normalized for
 *   terminal_metric_direction — positive always means "better").
 */
export function classifyPerformanceBand(performanceDeltaPct: number): PerformanceBand {
  if (performanceDeltaPct >= 50) return "strong";
  if (performanceDeltaPct >= 25) return "solid";
  if (performanceDeltaPct >= 10) return "moderate";
  return "promising";
}
