// Guards the canonical-four rule at the code level, in addition to the Zod
// enum in packages/schemas. Use this specifically at points where a verdict
// string arrives as untyped input (e.g. parsed from a raw prompt response)
// before it's been through mstTestEngineOutputSchema.
const CANONICAL_VERDICTS = new Set([
  "universal_winner",
  "avatar_dependent",
  "underperformer",
  "insufficient_data",
]);

export function validateMSTVerdict(value: string): { valid: boolean; reason?: string } {
  if (CANONICAL_VERDICTS.has(value)) {
    return { valid: true };
  }
  return {
    valid: false,
    reason: `"${value}" is not one of the four canonical MST verdicts (universal_winner, avatar_dependent, underperformer, insufficient_data). Finer descriptors belong in performance_band, not verdict.`,
  };
}
