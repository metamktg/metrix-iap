// mst_cell_code is the matrix-cell identifier used in place of creative_id
// (Blueprint v2.0 §7 / Stage 0 repair). Observed shape from
// docs/prompts/MST_TEST_ENGINE_v2.0.md examples: concept number + angle
// letter, e.g. "C1A" = concept C1, angle A.
const CELL_CODE_PATTERN = /^C(\d+)([A-Z])$/;

export function validateMSTCellCode(cellCode: string): { valid: boolean; reason?: string } {
  const match = cellCode.match(CELL_CODE_PATTERN);
  if (!match) {
    return {
      valid: false,
      reason: `"${cellCode}" does not match the expected mst_cell_code shape C<concept_number><angle_letter> (e.g. "C1A").`,
    };
  }
  return { valid: true };
}

/** Builds a canonical cell code from a matrix position, the inverse of parsing. */
export function buildMSTCellCode(concept: string, angle: string): string {
  const conceptNumber = concept.replace(/^C/i, "");
  return `C${conceptNumber}${angle.toUpperCase()}`;
}
