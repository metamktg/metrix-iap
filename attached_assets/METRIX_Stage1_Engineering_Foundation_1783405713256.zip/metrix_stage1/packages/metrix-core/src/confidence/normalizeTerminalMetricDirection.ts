// cohort_definitions.terminal_metric_direction tells you whether lower or
// higher values are "better" for that cohort's terminal metric (e.g.
// cost_per_purchase is lower_is_better, conversion_rate is higher_is_better).
// This normalizes a raw before/after delta into a signed "improvement" value
// so downstream code (MST verdicts, BSIL rationale) can compare deltas
// without re-deriving direction logic in five different places.
import type { TerminalMetricDirection } from "@metrix/schemas";

export interface NormalizedDelta {
  raw_delta: number;
  /** Positive means improvement, negative means regression, regardless of direction. */
  normalized_delta: number;
  improved: boolean;
}

export function normalizeTerminalMetricDirection(
  before: number,
  after: number,
  direction: TerminalMetricDirection,
): NormalizedDelta {
  const rawDelta = after - before;
  const normalizedDelta = direction === "lower_is_better" ? -rawDelta : rawDelta;

  return {
    raw_delta: rawDelta,
    normalized_delta: normalizedDelta,
    improved: normalizedDelta > 0,
  };
}
