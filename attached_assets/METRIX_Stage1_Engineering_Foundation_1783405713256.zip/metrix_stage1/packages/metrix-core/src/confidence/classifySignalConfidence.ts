// Confidence thresholds per docs/prompts/IAP_ANALYSIS_CORE_v2.0.md:
//   high: >100 conversions OR >$1000 spend with a consistent pattern
//   medium: 10-100 conversions OR $100-1000 spend with a directional signal
//   validation_required: <10 conversions OR <$100 spend but promising
//   insufficient: below minimum thresholds
// Maps onto the intelligence_cards.confidence_grade enum
// (HIGH/MODERATE/LOW/INSUFFICIENT) — validation_required maps to LOW since it
// still represents a real (if unvalidated) signal, not an absence of one.
import type { ConfidenceGrade } from "@metrix/schemas";

export interface ClassifySignalConfidenceInput {
  conversions: number;
  spend: number;
  /** Whether the underlying pattern holds consistently across the sample, not just a single spike. */
  isConsistentPattern: boolean;
  /** Whether the signal at least points in one clear direction, even if not yet statistically firm. */
  isDirectional: boolean;
}

export function classifySignalConfidence(input: ClassifySignalConfidenceInput): ConfidenceGrade {
  const { conversions, spend, isConsistentPattern, isDirectional } = input;

  if ((conversions > 100 || spend > 1000) && isConsistentPattern) {
    return "HIGH";
  }

  if ((conversions >= 10 && conversions <= 100) || (spend >= 100 && spend <= 1000)) {
    if (isDirectional) return "MODERATE";
  }

  if (conversions < 10 || spend < 100) {
    return "LOW";
  }

  return "INSUFFICIENT";
}
