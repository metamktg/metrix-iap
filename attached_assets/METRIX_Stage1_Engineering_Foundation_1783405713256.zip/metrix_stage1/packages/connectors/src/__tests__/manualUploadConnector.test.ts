import { describe, expect, it } from "vitest";
import { manualUploadConnector } from "../manualUploadConnector.js";

describe("manualUploadConnector", () => {
  it("normalizes rows and flags missing ad_id as a warning, not a silent drop", async () => {
    const result = await manualUploadConnector.ingest({
      cohortKey: "ecommerce",
      sourceFile: "export.csv",
      rows: [
        { ad_id: "123", ad_name: "C1A_STC_PDP_T1", campaign_id: "camp_1" },
        { ad_name: "no id here" },
      ],
    });

    expect(result.records).toHaveLength(2);
    expect(result.records[0]?.ad_id).toBe("123");
    expect(result.warnings).toHaveLength(1);
    expect(result.warnings[0]).toMatch(/missing ad_id/);
  });

  it("rejects a malformed input shape rather than guessing", async () => {
    await expect(manualUploadConnector.ingest({ notTheRightShape: true })).rejects.toThrow();
  });
});
