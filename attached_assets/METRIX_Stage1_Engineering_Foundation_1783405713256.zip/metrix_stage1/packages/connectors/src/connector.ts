// Every connector (manual upload, future Meta API) implements this same
// interface so packages/iap-engine and apps/worker don't need to know which
// source produced a given batch of NormalizedRecords. v1 scope is read-only
// ingestion only — no connector in this package writes back to Meta.
import type { NormalizedRecord } from "@metrix/schemas";

export interface ConnectorIngestResult {
  records: NormalizedRecord[];
  warnings: string[];
}

export interface Connector {
  name: string;
  /** Ingests raw source data and returns normalized records, ready for creative resolution. */
  ingest(rawInput: unknown): Promise<ConnectorIngestResult>;
}
