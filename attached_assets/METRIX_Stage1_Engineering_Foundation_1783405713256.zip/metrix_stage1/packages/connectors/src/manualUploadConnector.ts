// v1 primary intake path: manual CSV/pivot-export upload. Column mapping is
// deliberately a stub here — the real 125-metric Listen Layer contract
// (docs/data-model/METRIX_Listen_Layer_125_Metric_Contract_v1.md) needs to
// drive the actual column -> metric mapping, which is Stage 2 work, not
// Stage 1. This stub establishes the shape and the seam Stage 2 fills in.
import type { NormalizedRecord } from "@metrix/schemas";
import type { Connector, ConnectorIngestResult } from "./connector.js";

export interface ManualUploadRow {
  [column: string]: string | number | null;
}

export interface ManualUploadInput {
  cohortKey: string;
  sourceFile: string;
  rows: ManualUploadRow[];
}

function isManualUploadInput(value: unknown): value is ManualUploadInput {
  return (
    typeof value === "object" &&
    value !== null &&
    "cohortKey" in value &&
    "sourceFile" in value &&
    Array.isArray((value as ManualUploadInput).rows)
  );
}

export const manualUploadConnector: Connector = {
  name: "manual_upload",
  async ingest(rawInput: unknown): Promise<ConnectorIngestResult> {
    if (!isManualUploadInput(rawInput)) {
      throw new Error("manualUploadConnector.ingest expects a ManualUploadInput shape.");
    }

    const warnings: string[] = [];
    const records: NormalizedRecord[] = rawInput.rows.map((row, index) => {
      const adId = String(row.ad_id ?? row.Ad_Name ?? "");
      if (!adId) {
        warnings.push(`Row ${index}: missing ad_id/Ad_Name, record will need creative resolution to flag it unresolved.`);
      }

      return {
        ad_id: adId,
        ad_name: String(row.ad_name ?? row.Ad_Name ?? ""),
        campaign_id: row.campaign_id ? String(row.campaign_id) : null,
        campaign_name: row.campaign_name ? String(row.campaign_name) : null,
        ad_set_id: row.ad_set_id ? String(row.ad_set_id) : null,
        ad_set_name: row.ad_set_name ? String(row.ad_set_name) : null,
        cohort_key: rawInput.cohortKey,
        source_file: rawInput.sourceFile,
        source_row_index: index,
        // Known Stage 2 gap: mapping every raw column onto the 125-metric
        // Listen Layer contract fields. Flagged here rather than invented.
        metrics: {},
        raw: row,
      };
    });

    return { records, warnings };
  },
};
