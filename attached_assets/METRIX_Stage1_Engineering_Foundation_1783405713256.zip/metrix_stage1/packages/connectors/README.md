# @metrix/connectors

Data intake connectors. v1 scope is **read-only ingestion only** — no
connector in this package writes back to Meta, and there is no autonomous
Meta Ads execution anywhere in Metrix (locked rule).

## Contents

- `Connector` — the shared interface every source implements (`ingest(rawInput) -> { records, warnings }`).
- `manualUploadConnector` — the v1 primary intake path (CSV / pivot-export
  upload). **Known Stage 2 gap:** column -> Listen Layer metric mapping is
  stubbed (`metrics: {}`); wiring it to
  `docs/data-model/METRIX_Listen_Layer_125_Metric_Contract_v1.md` is
  Stage 2 work, flagged here rather than invented.

## Not yet built

A live Meta Marketing API connector. Referenced in the Stage 1 briefing as a
future package responsibility, not required for Stage 1 success criteria.
