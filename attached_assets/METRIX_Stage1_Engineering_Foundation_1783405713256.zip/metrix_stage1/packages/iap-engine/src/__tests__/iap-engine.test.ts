import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";
import { describe, expect, it } from "vitest";
import {
  PROMPT_REGISTRY,
  listActivePromptsInChainOrder,
  validatePromptOutput,
  runPromptStage,
} from "../index.js";

// packages/iap-engine/src/__tests__ -> repo root is four levels up.
const REPO_ROOT = join(dirname(fileURLToPath(import.meta.url)), "../../../../");

describe("prompt registry", () => {
  it("registers exactly the seven repaired v2.0 prompt docs", () => {
    const names = Object.keys(PROMPT_REGISTRY).sort();
    expect(names).toEqual(
      [
        "IAP_ANALYSIS_CORE",
        "IAP_BRIEF_BUILDER",
        "IAP_DATA_BUNDLE_PREP",
        "IAP_OPTIMIZATION_LOOP",
        "IAP_REPORT_SUMMARY",
        "IAP_STRATEGY_MAP",
        "MST_TEST_ENGINE",
      ].sort(),
    );
  });

  it("all seven are version 2.0 and active", () => {
    for (const entry of Object.values(PROMPT_REGISTRY)) {
      expect(entry.version).toBe("2.0");
      expect(entry.status).toBe("active");
    }
  });

  it("orders the chain starting with data bundle prep and ending with report summary", () => {
    const chain = listActivePromptsInChainOrder();
    expect(chain[0]?.name).toBe("IAP_DATA_BUNDLE_PREP");
    expect(chain[chain.length - 1]?.name).toBe("IAP_REPORT_SUMMARY");
  });
});

describe("validatePromptOutput", () => {
  it("flags prompts with no registered output schema as a known gap, not a silent pass", () => {
    const result = validatePromptOutput("IAP_STRATEGY_MAP", { anything: true });
    expect(result.valid).toBe(false);
    expect(result.errors?.[0]).toMatch(/known gap/i);
  });

  it("rejects a MST output missing required fields", () => {
    const result = validatePromptOutput("MST_TEST_ENGINE", { cohort_key: "ecommerce" });
    expect(result.valid).toBe(false);
  });
});

describe("runPromptStage", () => {
  it("marks a stage failed when the executor returns invalid output", async () => {
    const { stage, validation } = await runPromptStage({
      analysisRunId: "11111111-1111-1111-1111-111111111111",
      promptName: "MST_TEST_ENGINE",
      input: {},
      executor: async () => ({ garbage: true }),
      engineVersion: "test",
      loadOptions: { repoRoot: REPO_ROOT },
    });
    expect(validation.valid).toBe(false);
    expect(stage.status).toBe("failed");
  });
});
