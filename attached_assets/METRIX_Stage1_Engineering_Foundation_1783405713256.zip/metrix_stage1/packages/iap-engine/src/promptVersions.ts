// Thin wrapper over PROMPT_REGISTRY for version-comparison concerns, kept
// separate from promptRegistry.ts so version-bump logic doesn't get tangled
// with the registry's identity/lookup responsibilities.
import { getPromptRegistryEntry, type PromptName } from "./promptRegistry.js";

export function getPromptVersion(name: PromptName): string {
  return getPromptRegistryEntry(name).version;
}

/**
 * True when a stored analysis_run_stages.prompt_version matches the
 * currently registered version for that prompt. False means the run was
 * executed against an older prompt revision — useful for flagging stale
 * historical runs without silently re-interpreting them under today's logic.
 */
export function isCurrentPromptVersion(name: PromptName, storedVersion: string): boolean {
  return getPromptVersion(name) === storedVersion;
}
