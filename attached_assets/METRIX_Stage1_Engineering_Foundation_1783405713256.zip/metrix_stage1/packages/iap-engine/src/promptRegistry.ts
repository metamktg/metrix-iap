// The seven repaired v2.0 cohort-aware prompt docs currently in
// docs/prompts/. Per the Stage 1 briefing: "do not add legacy prompts unless
// we explicitly decide they are active." Any additional Metrix skills that
// exist outside docs/prompts (e.g. metrix-client-library, metrix-mst-creative-scan)
// are deliberately NOT registered here — they are a separate execution
// surface (Claude Skills), not part of the docs/prompts chain this engine runs.
export type PromptName =
  | "IAP_DATA_BUNDLE_PREP"
  | "IAP_ANALYSIS_CORE"
  | "IAP_STRATEGY_MAP"
  | "IAP_BRIEF_BUILDER"
  | "MST_TEST_ENGINE"
  | "IAP_OPTIMIZATION_LOOP"
  | "IAP_REPORT_SUMMARY";

export interface PromptRegistryEntry {
  name: PromptName;
  version: string;
  /** Path relative to the repo root. */
  docPath: string;
  /** Where this stage sits in the Listen -> Feed-forward chain, for runIAPChain ordering. */
  chainOrder: number;
  status: "active" | "archived";
}

export const PROMPT_REGISTRY: Record<PromptName, PromptRegistryEntry> = {
  IAP_DATA_BUNDLE_PREP: {
    name: "IAP_DATA_BUNDLE_PREP",
    version: "2.0",
    docPath: "docs/prompts/IAP_DATA_BUNDLE_PREP_v2.0.md",
    chainOrder: 1,
    status: "active",
  },
  IAP_ANALYSIS_CORE: {
    name: "IAP_ANALYSIS_CORE",
    version: "2.0",
    docPath: "docs/prompts/IAP_ANALYSIS_CORE_v2.0.md",
    chainOrder: 2,
    status: "active",
  },
  IAP_STRATEGY_MAP: {
    name: "IAP_STRATEGY_MAP",
    version: "2.0",
    docPath: "docs/prompts/IAP_STRATEGY_MAP_v2.0.md",
    chainOrder: 3,
    status: "active",
  },
  IAP_BRIEF_BUILDER: {
    name: "IAP_BRIEF_BUILDER",
    version: "2.0",
    docPath: "docs/prompts/IAP_BRIEF_BUILDER_v2.0.md",
    chainOrder: 4,
    status: "active",
  },
  MST_TEST_ENGINE: {
    name: "MST_TEST_ENGINE",
    version: "2.0",
    docPath: "docs/prompts/MST_TEST_ENGINE_v2.0.md",
    chainOrder: 5,
    status: "active",
  },
  IAP_OPTIMIZATION_LOOP: {
    name: "IAP_OPTIMIZATION_LOOP",
    version: "2.0",
    docPath: "docs/prompts/IAP_OPTIMIZATION_LOOP_v2.0.md",
    chainOrder: 6,
    status: "active",
  },
  IAP_REPORT_SUMMARY: {
    name: "IAP_REPORT_SUMMARY",
    version: "2.0",
    docPath: "docs/prompts/IAP_REPORT_SUMMARY_v2.0.md",
    chainOrder: 7,
    status: "active",
  },
};

export function getPromptRegistryEntry(name: PromptName): PromptRegistryEntry {
  const entry = PROMPT_REGISTRY[name];
  if (!entry) {
    throw new Error(`No registry entry for prompt "${name}".`);
  }
  return entry;
}

export function listActivePromptsInChainOrder(): PromptRegistryEntry[] {
  return Object.values(PROMPT_REGISTRY)
    .filter((entry) => entry.status === "active")
    .sort((a, b) => a.chainOrder - b.chainOrder);
}
