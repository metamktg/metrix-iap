// Runs the active prompt chain in registry order, threading each stage's
// validated output into the next stage's input. Stops on the first stage
// that fails schema validation rather than continuing on bad data — a
// failed stage record is still returned so the caller can persist it and
// see exactly where the chain broke.
import { listActivePromptsInChainOrder } from "./promptRegistry.js";
import { runPromptStage, type PromptExecutor } from "./runPromptStage.js";
import type { AnalysisRunStage } from "@metrix/schemas";

export interface RunIAPChainArgs {
  analysisRunId: string;
  /** Initial input to the first stage (typically raw normalized records / a data bundle request). */
  initialInput: unknown;
  executor: PromptExecutor;
  engineVersion: string;
}

export interface RunIAPChainResult {
  stages: AnalysisRunStage[];
  outputs: Record<string, unknown>;
  stoppedEarly: boolean;
  failedAt?: string;
}

export async function runIAPChain(args: RunIAPChainArgs): Promise<RunIAPChainResult> {
  const { analysisRunId, initialInput, executor, engineVersion } = args;
  const chain = listActivePromptsInChainOrder();

  const stages: AnalysisRunStage[] = [];
  const outputs: Record<string, unknown> = {};
  let currentInput: unknown = initialInput;

  for (const entry of chain) {
    const result = await runPromptStage({
      analysisRunId,
      promptName: entry.name,
      input: currentInput,
      executor,
      engineVersion,
    });

    stages.push(result.stage);
    outputs[entry.name] = result.output;

    if (!result.validation.valid) {
      return { stages, outputs, stoppedEarly: true, failedAt: entry.name };
    }

    currentInput = result.validation.data ?? result.output;
  }

  return { stages, outputs, stoppedEarly: false };
}
