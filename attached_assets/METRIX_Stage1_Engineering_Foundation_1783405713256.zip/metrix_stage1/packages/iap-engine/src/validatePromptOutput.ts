// Every prompt output must validate against a schema before being written to
// Supabase (non-negotiable Stage 1 rule). This is the single choke point
// runPromptStage and runIAPChain both call through — no output reaches
// packages/db without passing here first.
import {
  iapDataBundleOutputSchema,
  iapAnalysisCoreOutputSchema,
  mstTestEngineOutputSchema,
} from "@metrix/schemas";
import type { z } from "zod";
import type { PromptName } from "./promptRegistry.js";

// Not every one of the seven prompts has a bespoke output schema in
// packages/schemas yet (IAP_STRATEGY_MAP, IAP_BRIEF_BUILDER,
// IAP_OPTIMIZATION_LOOP, IAP_REPORT_SUMMARY largely resolve into the shared
// intelligence_cards / creative_briefs / reports / learning_registry table
// shapes rather than a distinct stage-output shape). Flagging this as a known
// gap rather than inventing schemas for them — add here as they're built.
const OUTPUT_SCHEMAS: Partial<Record<PromptName, z.ZodTypeAny>> = {
  IAP_DATA_BUNDLE_PREP: iapDataBundleOutputSchema,
  IAP_ANALYSIS_CORE: iapAnalysisCoreOutputSchema,
  MST_TEST_ENGINE: mstTestEngineOutputSchema,
};

export interface ValidatePromptOutputResult<T = unknown> {
  valid: boolean;
  data?: T;
  errors?: string[];
}

export function validatePromptOutput<T = unknown>(
  name: PromptName,
  rawOutput: unknown,
): ValidatePromptOutputResult<T> {
  const schema = OUTPUT_SCHEMAS[name];
  if (!schema) {
    return {
      valid: false,
      errors: [
        `No output schema registered for "${name}" yet. This is a known gap — ` +
          `flag it rather than persisting unvalidated output. See OUTPUT_SCHEMAS in validatePromptOutput.ts.`,
      ],
    };
  }

  const result = schema.safeParse(rawOutput);
  if (!result.success) {
    return {
      valid: false,
      errors: result.error.issues.map((issue: z.ZodIssue) => `${issue.path.join(".")}: ${issue.message}`),
    };
  }

  return { valid: true, data: result.data as T };
}
