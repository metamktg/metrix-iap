// Reads the actual markdown doc text for a registered prompt. This is the
// only place in the engine that touches the filesystem for prompt content —
// runPromptStage and runIAPChain both go through this rather than reading
// docs/prompts/*.md directly, so a future swap to a DB-backed prompt store
// only changes this one function.
import { readFile } from "node:fs/promises";
import { join } from "node:path";
import { getPromptRegistryEntry, type PromptName } from "./promptRegistry.js";

export interface LoadPromptOptions {
  /** Absolute path to the repo root (where docs/ lives). Defaults to process.cwd(). */
  repoRoot?: string;
}

export async function loadPrompt(name: PromptName, options: LoadPromptOptions = {}): Promise<string> {
  const entry = getPromptRegistryEntry(name);
  const repoRoot = options.repoRoot ?? process.cwd();
  const fullPath = join(repoRoot, entry.docPath);

  try {
    return await readFile(fullPath, "utf-8");
  } catch (cause) {
    throw new Error(
      `Failed to load prompt doc for "${name}" at ${fullPath}. Is repoRoot set correctly?`,
      { cause },
    );
  }
}
