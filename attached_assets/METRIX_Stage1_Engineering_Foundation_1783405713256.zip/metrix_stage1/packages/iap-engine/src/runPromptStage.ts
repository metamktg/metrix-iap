// Runs exactly one prompt stage: load the doc, hand it (plus input) to an
// injected executor, validate the result, return a stage record shaped like
// analysis_run_stages ready for packages/db to persist.
//
// The executor is injected rather than hardcoded to a specific LLM client —
// this package operationalizes the prompt docs, it doesn't own the model
// integration. apps/worker supplies the real executor (an Anthropic API call);
// tests supply a stub.
import type { AnalysisRunStage } from "@metrix/schemas";
import { getPromptRegistryEntry, type PromptName } from "./promptRegistry.js";
import { loadPrompt, type LoadPromptOptions } from "./loadPrompt.js";
import { validatePromptOutput } from "./validatePromptOutput.js";

export type PromptExecutor = (args: {
  promptDoc: string;
  input: unknown;
}) => Promise<unknown>;

export interface RunPromptStageArgs {
  analysisRunId: string;
  promptName: PromptName;
  input: unknown;
  executor: PromptExecutor;
  engineVersion: string;
  loadOptions?: LoadPromptOptions;
}

export interface RunPromptStageResult {
  stage: AnalysisRunStage;
  output: unknown;
  validation: ReturnType<typeof validatePromptOutput>;
}

export async function runPromptStage(args: RunPromptStageArgs): Promise<RunPromptStageResult> {
  const { analysisRunId, promptName, input, executor, engineVersion, loadOptions } = args;
  const entry = getPromptRegistryEntry(promptName);
  const startedAt = new Date().toISOString();

  const promptDoc = await loadPrompt(promptName, loadOptions);
  const rawOutput = await executor({ promptDoc, input });
  const validation = validatePromptOutput(promptName, rawOutput);

  const stage: AnalysisRunStage = {
    analysis_run_id: analysisRunId,
    prompt_name: entry.name,
    prompt_version: entry.version,
    engine_version: engineVersion,
    input_schema_version: "n/a",
    output_schema_version: entry.version,
    started_at: startedAt,
    completed_at: new Date().toISOString(),
    status: validation.valid ? "complete" : "failed",
  };

  return { stage, output: rawOutput, validation };
}
