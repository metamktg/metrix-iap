# @metrix/iap-engine

Operationalizes the seven repaired v2.0 prompt docs in `docs/prompts/`. This
package invents no new intelligence — it loads the existing prompt docs, runs
them through an injected executor (the actual LLM call, supplied by
`apps/worker`), and validates every output against `packages/schemas` before
it's allowed to reach `packages/db`.

## Modules

- **`promptRegistry.ts`** — the seven active prompts, their doc paths, and
  chain order. `IAP_DATA_BUNDLE_PREP` → `IAP_ANALYSIS_CORE` → `IAP_STRATEGY_MAP`
  → `IAP_BRIEF_BUILDER` → `MST_TEST_ENGINE` → `IAP_OPTIMIZATION_LOOP` →
  `IAP_REPORT_SUMMARY`.
- **`promptVersions.ts`** — version lookup and staleness checks against stored
  `analysis_run_stages.prompt_version`.
- **`loadPrompt.ts`** — reads the actual markdown doc text from disk. The only
  filesystem touchpoint in this package.
- **`validatePromptOutput.ts`** — the schema gate. No output reaches
  persistence without passing through here.
- **`runPromptStage.ts`** — runs one stage end to end and returns an
  `analysis_run_stages`-shaped record.
- **`runIAPChain.ts`** — runs the full active chain in order, threading each
  validated output into the next stage's input, stopping on first failure.

## Known gap

`validatePromptOutput` only has bespoke output schemas for
`IAP_DATA_BUNDLE_PREP`, `IAP_ANALYSIS_CORE`, and `MST_TEST_ENGINE` right now.
`IAP_STRATEGY_MAP`, `IAP_BRIEF_BUILDER`, `IAP_OPTIMIZATION_LOOP`, and
`IAP_REPORT_SUMMARY` largely resolve into the shared `intelligence_cards` /
`creative_briefs` / `reports` / `learning_registry` table shapes rather than a
distinct stage-output shape — flagged in code rather than papered over with an
invented schema. Add to `OUTPUT_SCHEMAS` in `validatePromptOutput.ts` as each
is built out.

## Do not add legacy prompts

Only the seven docs in `docs/prompts/` are registered. If an older,
pre-repair prompt version needs to be referenced, mark it `archived` in the
registry rather than deleting history — but it does not enter
`listActivePromptsInChainOrder()`.
