// ═══════════════════════════════════════════════════════════════════════
// METRIX IAP — Exports Hub + Agent Console mock data
// SAMPLE/DEMO DATA — Bookster-branded, seeded for prototype purposes.
// Figures consistent with ~$8k spend / 486 installs / 78 registrations.
// ═══════════════════════════════════════════════════════════════════════

// ─── Exports ──────────────────────────────────────────────────────────

export type ExportFormat = "PDF" | "CSV" | "Slides";
export type ExportStatus = "Ready" | "Processing" | "Failed";

export interface ExportRecord {
  id: string;
  name: string;
  format: ExportFormat;
  source_report: string;
  source_report_id: string;
  workspace: string;
  created_at: string; // "Jul 6, 2026"
  size: string;       // "2.4 MB"
  status: ExportStatus;
  downloads: number;
}

export const EXPORT_RECORDS: ExportRecord[] = [
  {
    id: "exp_0001",
    name: "Bookster — IAP Full Analysis (May–Jul).pdf",
    format: "PDF",
    source_report: "IAP Full Analysis Report",
    source_report_id: "rpt_0001",
    workspace: "Bookster",
    created_at: "Jul 6, 2026",
    size: "3.2 MB",
    status: "Ready",
    downloads: 4,
  },
  {
    id: "exp_0002",
    name: "Bookster — Creative Deep-Dive.slides",
    format: "Slides",
    source_report: "Creative Sprint Report",
    source_report_id: "rpt_0002",
    workspace: "Bookster",
    created_at: "Jul 5, 2026",
    size: "8.7 MB",
    status: "Ready",
    downloads: 2,
  },
  {
    id: "exp_0003",
    name: "Bookster — Ad-level metrics export.csv",
    format: "CSV",
    source_report: "IAP Full Analysis Report",
    source_report_id: "rpt_0001",
    workspace: "Bookster",
    created_at: "Jul 5, 2026",
    size: "412 KB",
    status: "Ready",
    downloads: 9,
  },
  {
    id: "exp_0004",
    name: "Bookster — Client Monthly (June).pdf",
    format: "PDF",
    source_report: "Monthly Performance Report",
    source_report_id: "rpt_0010",
    workspace: "Bookster",
    created_at: "Jul 1, 2026",
    size: "2.1 MB",
    status: "Ready",
    downloads: 6,
  },
  {
    id: "exp_0005",
    name: "Bookster — Registration funnel breakdown.csv",
    format: "CSV",
    source_report: "Sprint Test Readout",
    source_report_id: "rpt_0002",
    workspace: "Bookster",
    created_at: "Jun 30, 2026",
    size: "188 KB",
    status: "Ready",
    downloads: 3,
  },
  {
    id: "exp_0006",
    name: "Bookster — Executive Summary (Q2).slides",
    format: "Slides",
    source_report: "Executive Summary",
    source_report_id: "rpt_0001",
    workspace: "Bookster",
    created_at: "Jun 28, 2026",
    size: "6.4 MB",
    status: "Processing",
    downloads: 0,
  },
  {
    id: "exp_0007",
    name: "Bookster — CAPI gap audit appendix.pdf",
    format: "PDF",
    source_report: "IAP Full Analysis Report",
    source_report_id: "rpt_0001",
    workspace: "Bookster",
    created_at: "Jun 26, 2026",
    size: "1.4 MB",
    status: "Failed",
    downloads: 0,
  },
  {
    id: "exp_0008",
    name: "Bookster — MST matrix cells.csv",
    format: "CSV",
    source_report: "Creative Sprint Report",
    source_report_id: "rpt_0002",
    workspace: "Bookster",
    created_at: "Jun 24, 2026",
    size: "96 KB",
    status: "Ready",
    downloads: 5,
  },
];

// ─── Export destinations (scheduled deliveries) ───────────────────────

export type ScheduleCadence = "Daily" | "Weekly" | "Bi-weekly" | "Monthly";

export interface ExportDestination {
  id: string;
  label: string;
  recipients: string[];
  cadence: ScheduleCadence;
  format: ExportFormat;
  next_send: string;
  last_sent: string;
  active: boolean;
}

export const EXPORT_DESTINATIONS: ExportDestination[] = [
  {
    id: "dst_0001",
    label: "Client — Monthly performance recap",
    recipients: ["jan@bookster.ai"],
    cadence: "Monthly",
    format: "PDF",
    next_send: "Aug 1, 2026",
    last_sent: "Jul 1, 2026",
    active: true,
  },
  {
    id: "dst_0002",
    label: "Internal — Weekly creative deep-dive",
    recipients: ["sam@metamarketing.agency", "priya@metamarketing.agency"],
    cadence: "Weekly",
    format: "Slides",
    next_send: "Jul 13, 2026",
    last_sent: "Jul 6, 2026",
    active: true,
  },
  {
    id: "dst_0003",
    label: "Media buyer — Ad-level metrics dump",
    recipients: ["media@metamarketing.agency"],
    cadence: "Weekly",
    format: "CSV",
    next_send: "Jul 13, 2026",
    last_sent: "Jul 6, 2026",
    active: true,
  },
  {
    id: "dst_0004",
    label: "Client — IAP loop recap",
    recipients: ["jan@bookster.ai", "alex@metamarketing.agency"],
    cadence: "Bi-weekly",
    format: "PDF",
    next_send: "Jul 18, 2026",
    last_sent: "Jul 4, 2026",
    active: false,
  },
];

// ─── Agent Console ────────────────────────────────────────────────────

export type AgentRole = "user" | "agent";

export interface AgentMessage {
  id: string;
  role: AgentRole;
  text: string;
  time: string;         // "9:41 AM"
  citations?: string[]; // e.g. ["run_0001", "C4E_STC_QF_BOOK2_T1"]
}

export const AGENT_THREAD: AgentMessage[] = [
  {
    id: "msg_0001",
    role: "user",
    text: "How is Bookster tracking against last cycle?",
    time: "9:38 AM",
  },
  {
    id: "msg_0002",
    role: "agent",
    text: "This cycle Bookster spent $8,000.84 and drove 486 mobile app installs, 78 registrations, and 0 confirmed trials. Cost-per-trial is directionally down (~$575 → $258) since the registration step moved pre-paywall — but the pixel/CAPI gap is suppressing iOS conversions by an estimated 30–40%, so the true trial count is likely understated.",
    time: "9:38 AM",
    citations: ["run_0001", "aa_bookster_meta"],
  },
  {
    id: "msg_0003",
    role: "user",
    text: "Which creative is carrying registrations?",
    time: "9:40 AM",
  },
  {
    id: "msg_0004",
    role: "agent",
    text: "C2B (product-demo / time-saving, 1000 Books) is the registration control for cold prospecting at ~$320 CPA, T2 / high confidence. C4E (aspirational authority) remains the checkout-depth control at ~$258 CPT. The BYOC upload-flow angle is a T1 candidate but still validation_required — not enough spend to confirm.",
    time: "9:40 AM",
    citations: ["C2B_STC_QF_BOOK2_T2", "C4E_STC_QF_BOOK2_T1"],
  },
  {
    id: "msg_0005",
    role: "user",
    text: "What should we brief next?",
    time: "9:41 AM",
  },
  {
    id: "msg_0006",
    role: "agent",
    text: "Brief the BYOC upload-flow angle first — highest upside, validation_required. Pair it with an Android-only scale of C4E while the CAPI fix is pending. Hold iOS budget flat until conversion events reconcile. I can draft the sprint brief and route it to the Brief Engine.",
    time: "9:41 AM",
    citations: ["run_0001"],
  },
];

export const SUGGESTED_PROMPTS: string[] = [
  "Summarize this week's Bookster performance",
  "Why is CPT down 55%?",
  "Which ads are at fatigue risk?",
  "Draft next sprint brief for BYOC",
  "Flag any tracking issues",
  "Compare Android vs iOS registrations",
];

// ─── Agent actions / automations rail ─────────────────────────────────

export type AgentActionStatus = "Done" | "Running" | "Queued" | "Failed";
export type AgentActionKind = "automation" | "action";

export interface AgentAction {
  id: string;
  title: string;
  detail: string;
  status: AgentActionStatus;
  kind: AgentActionKind;
  time: string;
}

export const AGENT_ACTIONS: AgentAction[] = [
  {
    id: "act_0001",
    title: "Drafted BYOC sprint brief",
    detail: "3 creative cells · routed to Brief Engine",
    status: "Done",
    kind: "action",
    time: "2m ago",
  },
  {
    id: "act_0002",
    title: "Generated IAP Full Analysis report",
    detail: "May 2 – Jul 7 · rpt_0001",
    status: "Done",
    kind: "action",
    time: "18m ago",
  },
  {
    id: "act_0003",
    title: "Fatigue watch — C4E hook score",
    detail: "Monitoring · alerts below 62",
    status: "Running",
    kind: "automation",
    time: "live",
  },
  {
    id: "act_0004",
    title: "CAPI reconciliation check",
    detail: "iOS event match rate re-scan",
    status: "Running",
    kind: "automation",
    time: "live",
  },
  {
    id: "act_0005",
    title: "Weekly client recap export",
    detail: "PDF → jan@bookster.ai",
    status: "Queued",
    kind: "automation",
    time: "in 6d",
  },
  {
    id: "act_0006",
    title: "Scale C4E on Android (CBO)",
    detail: "Blocked — awaiting CAPI verification",
    status: "Failed",
    kind: "action",
    time: "1h ago",
  },
];

// ─── Canned agent reply generator ─────────────────────────────────────

export function cannedAgentReply(prompt: string): string {
  const p = prompt.toLowerCase();
  if (p.includes("fatigue")) {
    return "C4E's hook score has slipped from 82 to ~68 over the last 14 days — approaching the fatigue window. C2B is still fresh at T2. Recommend briefing a replacement angle for C4E before it drops below 62.";
  }
  if (p.includes("capi") || p.includes("tracking") || p.includes("pixel") || p.includes("ios")) {
    return "The pixel/CAPI gap is still open. iOS conversion events are matching at an estimated 60–70% of pixel volume, suppressing measured trials by 30–40%. Don't scale iOS budget until the dev team verifies the CAPI integration.";
  }
  if (p.includes("android")) {
    return "Android is carrying the registration gains — clean tracking, ~$258 CPT vs $575 pre-restructure. A 40% Android-specific budget lift on C4E has strong supporting evidence.";
  }
  if (p.includes("brief") || p.includes("byoc") || p.includes("sprint")) {
    return "I can draft a BYOC upload-flow sprint brief — 3 creative cells, T1 candidate, validation_required. Pair it with an Android-only C4E scale. Want me to route it to the Brief Engine?";
  }
  if (p.includes("cpt") || p.includes("cost") || p.includes("cpa")) {
    return "Cost-per-trial improved ~55% ($575.86 → $258.34) after the registration step moved pre-paywall. The gain is Android-led; iOS reads are unreliable while the CAPI gap is open.";
  }
  if (p.includes("summar") || p.includes("performance") || p.includes("week")) {
    return "This week: $8,000.84 spend, 486 installs, 78 registrations, 0 confirmed trials. C2B is the registration control, C4E the checkout-depth control. Primary risk remains the unresolved CAPI gap on iOS.";
  }
  return "Based on the latest Bookster IAP run: C4E and C2B are the two controls, CPT is down ~55% on Android, and the CAPI gap is the top unresolved risk. Ask me to summarize performance, flag fatigue, or draft the next sprint brief.";
}
