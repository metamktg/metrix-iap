// ═══════════════════════════════════════════════════════════════════════
// METRIX IAP — Audience Analysis data (age/gender breakdown).
// SAMPLE/DEMO DATA seeded per workspace. Bookster (book-summary app).
// Scale consistent with ~$8k spend / 486 installs / 78 registrations.
// ═══════════════════════════════════════════════════════════════════════

export type FatigueState = "fresh" | "mild_fatigue" | "fatigued" | "burnt";
export type SegAction = "Scale" | "Hold" | "Watch" | "Cut";
export type SegConfidence = "high" | "medium" | "validation_required";

export interface AudienceSegment {
  id: string;
  age: string;                       // "25-34"
  gender: "female" | "male" | "unknown";
  spend: number;
  impressions: number;
  clicks: number;
  installs: number;
  registrations: number;
  frequency: number;                 // avg impressions / reached person
  fatigue: FatigueState;
  trend_pct: number;                 // installs delta vs prior period
}

export interface AudienceOverlap {
  a: string;
  b: string;
  overlap_pct: number;
  note: string;
}

export interface SegmentRecommendation {
  id: string;
  segment: string;
  action: SegAction;
  rationale: string;
  confidence: SegConfidence;
}

export interface AudienceData {
  workspace_id: string;
  account_label: string;
  date_range: string;
  blended_cpa: number;               // account blended install CPA baseline
  segments: AudienceSegment[];
  overlaps: AudienceOverlap[];
  recommendations: SegmentRecommendation[];
}

const BOOKSTER_AUDIENCE: AudienceData = {
  workspace_id: "ws_bookster",
  account_label: "Bookster.ai — Meta",
  date_range: "May 2 – Jul 7, 2026",
  blended_cpa: 16.46,
  segments: [
    { id: "f2534", age: "25-34", gender: "female", spend: 1180, impressions: 432000, clicks: 1040, installs: 86, registrations: 17, frequency: 2.4, fatigue: "fresh", trend_pct: 12 },
    { id: "f3544", age: "35-44", gender: "female", spend: 1420, impressions: 452000, clicks: 1010, installs: 106, registrations: 21, frequency: 2.7, fatigue: "fresh", trend_pct: 18 },
    { id: "f4554", age: "45-54", gender: "female", spend: 980, impressions: 308000, clicks: 640, installs: 71, registrations: 16, frequency: 3.1, fatigue: "mild_fatigue", trend_pct: 6 },
    { id: "f5564", age: "55-64", gender: "female", spend: 460, impressions: 118000, clicks: 250, installs: 28, registrations: 6, frequency: 3.4, fatigue: "mild_fatigue", trend_pct: -3 },
    { id: "f1824", age: "18-24", gender: "female", spend: 540, impressions: 196000, clicks: 470, installs: 30, registrations: 3, frequency: 2.1, fatigue: "fresh", trend_pct: 4 },
    { id: "f65p", age: "65+", gender: "female", spend: 220, impressions: 52000, clicks: 96, installs: 12, registrations: 3, frequency: 3.8, fatigue: "fatigued", trend_pct: -8 },
    { id: "m2534", age: "25-34", gender: "male", spend: 890, impressions: 336000, clicks: 790, installs: 54, registrations: 5, frequency: 2.5, fatigue: "mild_fatigue", trend_pct: 2 },
    { id: "m3544", age: "35-44", gender: "male", spend: 760, impressions: 214000, clicks: 520, installs: 45, registrations: 4, frequency: 2.6, fatigue: "mild_fatigue", trend_pct: -1 },
    { id: "m4554", age: "45-54", gender: "male", spend: 540, impressions: 152000, clicks: 330, installs: 26, registrations: 2, frequency: 2.9, fatigue: "fatigued", trend_pct: -6 },
    { id: "m5564", age: "55-64", gender: "male", spend: 300, impressions: 78000, clicks: 150, installs: 12, registrations: 1, frequency: 3.2, fatigue: "fatigued", trend_pct: -11 },
    { id: "m1824", age: "18-24", gender: "male", spend: 380, impressions: 148000, clicks: 360, installs: 8, registrations: 0, frequency: 2.0, fatigue: "burnt", trend_pct: -22 },
    { id: "m65p", age: "65+", gender: "male", spend: 130, impressions: 32000, clicks: 62, installs: 4, registrations: 0, frequency: 3.6, fatigue: "fatigued", trend_pct: -14 },
    { id: "u", age: "Unknown", gender: "unknown", spend: 200, impressions: 54802, clicks: 130, installs: 4, registrations: 0, frequency: 2.3, fatigue: "mild_fatigue", trend_pct: 0 },
  ],
  overlaps: [
    { a: "F 25-34", b: "F 35-44", overlap_pct: 34, note: "Shared lookalike seed — bidding against itself in prospecting" },
    { a: "F 35-44", b: "F 45-54", overlap_pct: 27, note: "Registration control audiences converge; consolidate adsets" },
    { a: "M 25-34", b: "M 35-44", overlap_pct: 22, note: "Low incremental reach; frequency climbing above 2.5" },
    { a: "F 45-54", b: "F 55-64", overlap_pct: 19, note: "Older female cohorts fatiguing — refresh creative before merge" },
  ],
  recommendations: [
    { id: "ar1", segment: "F 35-44", action: "Scale", rationale: "Lowest CPA ($13.40), 20% of registrations, fresh fatigue. Lift budget +25%.", confidence: "high" },
    { id: "ar2", segment: "F 25-34", action: "Scale", rationale: "CPA $13.72, rising installs (+12%). Duplicate into dedicated adset.", confidence: "high" },
    { id: "ar3", segment: "F 45-54", action: "Hold", rationale: "Strong regs but frequency 3.1 and mild fatigue. Rotate C4E variant.", confidence: "medium" },
    { id: "ar4", segment: "M 18-24", action: "Cut", rationale: "CPA $47.50 (2.9x blended), 0 registrations, burnt. Exclude from prospecting.", confidence: "high" },
    { id: "ar5", segment: "M 45-54 / 55-64", action: "Cut", rationale: "Declining installs, negative trend, no registration depth. Reallocate to F 35-44.", confidence: "medium" },
    { id: "ar6", segment: "F 18-24", action: "Watch", rationale: "Cheap clicks but thin registration signal. Validate before scaling spend.", confidence: "validation_required" },
  ],
};

export function getAudienceData(workspaceId: string): AudienceData {
  return { ...BOOKSTER_AUDIENCE, workspace_id: workspaceId };
}
