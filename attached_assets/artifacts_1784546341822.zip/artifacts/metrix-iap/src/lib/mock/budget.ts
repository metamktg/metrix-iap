// ═══════════════════════════════════════════════════════════════════════
// METRIX IAP — Budget Intelligence data.
// SAMPLE/DEMO DATA seeded per workspace. Bookster (book-summary app).
// Scale consistent with ~$8k spend / 486 installs / 78 registrations.
// ═══════════════════════════════════════════════════════════════════════

export type FrontierBand = "scale" | "hold" | "cut";

export interface SpendPacing {
  plan_total: number;                // planned budget for window
  spent_to_date: number;
  days_elapsed: number;
  days_total: number;
  daily_avg: number;                 // actual avg daily spend
  daily_target: number;             // plan / days_total
  status: "under" | "on_track" | "over";
}

export interface ObjectiveAllocation {
  id: string;
  objective: string;                 // "Mobile app installs", ...
  current_spend: number;
  results: number;                   // conversions of that objective
  result_label: string;             // "installs" | "registrations" | ...
  recommended_spend: number;
  note: string;
}

export interface FrontierEntry {
  id: string;
  name: string;
  code: string;
  spend: number;
  installs: number;
  cpa: number;
  efficiency_index: number;          // 100 = blended baseline, higher = better
  band: FrontierBand;
}

export interface WastedSpendCallout {
  id: string;
  label: string;
  amount: number;
  reason: string;
  severity: "Critical" | "High" | "Medium";
}

export interface BudgetData {
  workspace_id: string;
  account_label: string;
  date_range: string;
  blended_cpa: number;
  pacing: SpendPacing;
  allocations: ObjectiveAllocation[];
  frontier: FrontierEntry[];
  wasted: WastedSpendCallout[];
  reclaimable_total: number;
}

const BOOKSTER_BUDGET: BudgetData = {
  workspace_id: "ws_bookster",
  account_label: "Bookster.ai — Meta",
  date_range: "May 2 – Jul 7, 2026",
  blended_cpa: 16.46,
  pacing: {
    plan_total: 9600,
    spent_to_date: 8000.84,
    days_elapsed: 55,
    days_total: 66,
    daily_avg: 145.47,
    daily_target: 145.45,
    status: "on_track",
  },
  allocations: [
    { id: "al_installs", objective: "Mobile app installs", current_spend: 4766.02, results: 486, result_label: "installs", recommended_spend: 5400, note: "Efficient control — install CPA $9.81 blended. Lift +13%." },
    { id: "al_regs", objective: "Registrations", current_spend: 701.29, results: 78, result_label: "registrations", recommended_spend: 1100, note: "Strongest funnel depth. Shift budget in from checkout push." },
    { id: "al_trials", objective: "Trials", current_spend: 787.09, results: 0, result_label: "trials", recommended_spend: 300, note: "0 trials recorded — trial event mis-fires. Throttle until fixed." },
    { id: "al_checkout", objective: "Checkouts", current_spend: 1746.44, results: 0, result_label: "checkouts", recommended_spend: 1000, note: "0 checkouts on $1.7k — pixel/CAPI gap. Cut until tracking verified." },
  ],
  frontier: [
    { id: "fe1", name: "C4E Aspirational Authority", code: "C4E_STC_QF_BOOK2_T1", spend: 1680, installs: 118, cpa: 14.24, efficiency_index: 156, band: "scale" },
    { id: "fe2", name: "C2B Product Demo", code: "C2B_STC_QF_BOOK2_T2", spend: 1120, installs: 74, cpa: 15.14, efficiency_index: 138, band: "scale" },
    { id: "fe3", name: "BYOC Upload Flow", code: "BYOC_HK_CUR_T1", spend: 940, installs: 58, cpa: 16.21, efficiency_index: 118, band: "hold" },
    { id: "fe4", name: "Lookalike Trial Completers", code: "LAL_C4E_MOF", spend: 720, installs: 42, cpa: 17.14, efficiency_index: 104, band: "hold" },
    { id: "fe5", name: "C3 Behavior Shift (Android)", code: "C3_BS_AND_T2", spend: 860, installs: 48, cpa: 17.92, efficiency_index: 96, band: "hold" },
    { id: "fe6", name: "C4E Story Variant", code: "C4E_STO_T1", spend: 540, installs: 28, cpa: 19.29, efficiency_index: 82, band: "cut" },
    { id: "fe7", name: "C2E Read Less Keep More", code: "C2E_STC_QF_T2", spend: 640, installs: 22, cpa: 29.09, efficiency_index: 51, band: "cut" },
    { id: "fe8", name: "V3 Checkout Push", code: "V3_CHKOUT_BOF", spend: 1746, installs: 0, cpa: 0, efficiency_index: 0, band: "cut" },
  ],
  wasted: [
    { id: "w1", label: "V3 Checkout campaign", amount: 1746, reason: "$1,746 spent, 0 checkouts — pixel/CAPI gap on iOS conversion events.", severity: "Critical" },
    { id: "w2", label: "Trials broad delivery", amount: 787, reason: "$787 spent, 0 trials — trial event never fired. Throttle until instrumented.", severity: "High" },
    { id: "w3", label: "M 18-24 prospecting", amount: 380, reason: "$380 for 8 installs ($47.50 CPA, 2.9x blended), 0 registrations.", severity: "High" },
    { id: "w4", label: "Audience Network placement", amount: 640, reason: "CPA $26.67, 62% above blended, declining. Off-platform low intent.", severity: "Medium" },
  ],
  reclaimable_total: 3553,
};

export function getBudgetData(workspaceId: string): BudgetData {
  return { ...BOOKSTER_BUDGET, workspace_id: workspaceId };
}
