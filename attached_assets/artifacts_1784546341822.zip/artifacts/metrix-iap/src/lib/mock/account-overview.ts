// ═══════════════════════════════════════════════════════════════════════
// METRIX IAP — Account Overview data (mirrors the live app.metrix.ad
// Account Overview blueprint). SAMPLE/DEMO DATA seeded per workspace.
// ═══════════════════════════════════════════════════════════════════════

export type IapLoopStage = "Data" | "Analysis" | "Strategy" | "Briefs" | "Report";

export const IAP_LOOP_STAGES: IapLoopStage[] = [
  "Data", "Analysis", "Strategy", "Briefs", "Report",
];

export interface AccountTotals {
  total_spend: number;
  impressions: number;
  link_clicks: number;
  link_ctr: number; // percent
}

export interface EventResult {
  label: string;
  count: number;
  spend: number;
  clicks: number;
}

export interface CoreControl {
  role: string;          // "Primary control" | "Registration control" | ...
  code: string;          // creative code e.g. C4E_STC_QF_BOOK2_T1
  summary: string;
}

export interface AccountOverview {
  workspace_id: string;
  ad_account_label: string;      // e.g. "Bookster"
  connected: boolean;
  date_range_start: string;
  date_range_end: string;
  loop_stage: IapLoopStage;      // current position in the IAP loop
  loop_cycle: string;            // e.g. "4/5"
  totals: AccountTotals;
  current_sprint: {
    headline: string;
    detail: string;
    cta_label: string;
    cta_href: string;
  };
  next_action: string | null;    // null => "No recommendations yet."
  results_by_event: EventResult[];
  core_controls: CoreControl[];
  data_note: string | null;
}

export const ACCOUNT_OVERVIEWS: AccountOverview[] = [
  {
    workspace_id: "ws_bookster",
    ad_account_label: "Bookster",
    connected: true,
    date_range_start: "2026-05-02",
    date_range_end: "2026-07-07",
    loop_stage: "Briefs",
    loop_cycle: "4/5",
    totals: {
      total_spend: 8000.84,
      impressions: 2572802,
      link_clicks: 5848,
      link_ctr: 0.23,
    },
    current_sprint: {
      headline: "Current sprint",
      detail: "MST active · 16 matrix cells · 6 library concepts",
      cta_label: "Open MST",
      cta_href: "/app/creative-library",
    },
    next_action: null,
    results_by_event: [
      { label: "Mobile app installs", count: 486, spend: 4766.02, clicks: 4402 },
      { label: "Trials", count: 0, spend: 787.09, clicks: 284 },
      { label: "Registrations", count: 78, spend: 701.29, clicks: 485 },
      { label: "Checkouts", count: 0, spend: 1746.44, clicks: 677 },
    ],
    core_controls: [
      {
        role: "Primary control",
        code: "C4E_STC_QF_BOOK2_T1",
        summary: "C4E's aspirational authority/static system is the checkout-depth control",
      },
      {
        role: "Registration control",
        code: "C2B_STC_QF_BOOK2_T2",
        summary: "C2B's product-demo/time-saving creative is the registration control for cold prospecting",
      },
    ],
    data_note:
      "Demographic export is reliable for completed registrations, but V3 checkout results are not populated by age/gender.",
  },
];

export function getAccountOverview(workspaceId: string): AccountOverview | undefined {
  return ACCOUNT_OVERVIEWS.find((o) => o.workspace_id === workspaceId);
}
