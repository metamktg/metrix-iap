// ═══════════════════════════════════════════════════════════════════════
// METRIX IAP — Strategy Map data (funnel-stage strategy coverage).
// SAMPLE/DEMO DATA seeded per workspace. Bookster figures consistent with
// ~$8k spend / 486 installs / 78 registrations scale.
// ═══════════════════════════════════════════════════════════════════════

import type { ConfidenceLabel } from "@/lib/types";

export type FunnelStage = "Cold" | "Warm" | "Hot" | "Retention";
export type StrategyStatus = "Live" | "Testing" | "Planned" | "Paused";

export const FUNNEL_STAGES: FunnelStage[] = ["Cold", "Warm", "Hot", "Retention"];

export const STAGE_META: Record<FunnelStage, { label: string; sub: string }> = {
  Cold: { label: "Cold", sub: "TOF · Acquisition" },
  Warm: { label: "Warm", sub: "MOF · Registration" },
  Hot: { label: "Hot", sub: "BOF · Trial / Checkout" },
  Retention: { label: "Retention", sub: "Re-engagement" },
};

export interface StrategyCard {
  id: string;
  workspace_id: string;
  stage: FunnelStage;
  angle: string;
  audience: string;
  status: StrategyStatus;
  confidence: ConfidenceLabel;
  linked_concepts: string[];
  spend_usd: number;
  primary_metric: string;
  note: string;
}

export interface CoverageGap {
  id: string;
  workspace_id: string;
  stage: FunnelStage;
  audience: string;
  severity: "high" | "medium" | "low";
  reason: string;
}

const BOOKSTER_CARDS: StrategyCard[] = [
  {
    id: "sc_bkstr_01",
    workspace_id: "ws_bookster",
    stage: "Cold",
    angle: "Aspirational authority — 1,000 books, 15 min each",
    audience: "Time-Starved Professional · 25–44 · Android",
    status: "Live",
    confidence: "high",
    linked_concepts: ["C4E", "C2B"],
    spend_usd: 2480,
    primary_metric: "CPI $11.59",
    note: "Primary install driver. Android-only bidding avoids the iOS CAPI gap.",
  },
  {
    id: "sc_bkstr_02",
    workspace_id: "ws_bookster",
    stage: "Cold",
    angle: "Product demo — the whole library in your pocket",
    audience: "Depth-Seeking Female · 45–54",
    status: "Live",
    confidence: "high",
    linked_concepts: ["C2B"],
    spend_usd: 1620,
    primary_metric: "CPI $13.73",
    note: "Highest registration rate of any cold angle. Feed placement only.",
  },
  {
    id: "sc_bkstr_03",
    workspace_id: "ws_bookster",
    stage: "Cold",
    angle: "Curiosity — upload your own book (BYOC)",
    audience: "Broad self-improvers · 18–34",
    status: "Testing",
    confidence: "validation_required",
    linked_concepts: ["BYOC"],
    spend_usd: 780,
    primary_metric: "CPI $15.00",
    note: "Strong hook score, thin conversion volume. Needs 7 more days of spend.",
  },
  {
    id: "sc_bkstr_04",
    workspace_id: "ws_bookster",
    stage: "Cold",
    angle: "No-guilt behavior shift — read less, keep more",
    audience: "Broad readers · iOS",
    status: "Paused",
    confidence: "medium",
    linked_concepts: ["C3"],
    spend_usd: 620,
    primary_metric: "Paused",
    note: "Held while pixel/CAPI gap is unresolved. iOS events unreliable.",
  },
  {
    id: "sc_bkstr_05",
    workspace_id: "ws_bookster",
    stage: "Warm",
    angle: "Registration nudge — free before the paywall",
    audience: "Depth-Seeking Female · 45–54",
    status: "Live",
    confidence: "high",
    linked_concepts: ["C2B"],
    spend_usd: 720,
    primary_metric: "CPR $80.00",
    note: "Registration control after flow moved to last, pre-paywall.",
  },
  {
    id: "sc_bkstr_06",
    workspace_id: "ws_bookster",
    stage: "Warm",
    angle: "Loss-aversion reframe — READ LESS. KEEP MORE.",
    audience: "Broad readers",
    status: "Testing",
    confidence: "medium",
    linked_concepts: ["C2E"],
    spend_usd: 540,
    primary_metric: "CPR $141",
    note: "Reg cost elevated vs C2B. Testing shorter primary text variant.",
  },
  {
    id: "sc_bkstr_07",
    workspace_id: "ws_bookster",
    stage: "Hot",
    angle: "Aspirational proof at checkout",
    audience: "Professional readers · warm",
    status: "Live",
    confidence: "high",
    linked_concepts: ["C4E"],
    spend_usd: 460,
    primary_metric: "0 trials · V3",
    note: "Checkout-depth control. Generated majority of initiate-checkout volume.",
  },
];

const BOOKSTER_GAPS: CoverageGap[] = [
  {
    id: "gap_bkstr_01",
    workspace_id: "ws_bookster",
    stage: "Retention",
    audience: "All installed users",
    severity: "high",
    reason: "No retention or re-engagement creative deployed. 486 installs are not being nurtured post-download.",
  },
  {
    id: "gap_bkstr_02",
    workspace_id: "ws_bookster",
    stage: "Hot",
    audience: "Depth-Seeking Female · 45–54",
    severity: "high",
    reason: "Strong registration volume but checkout depth does not follow in V3. No BOF angle for this avatar.",
  },
  {
    id: "gap_bkstr_03",
    workspace_id: "ws_bookster",
    stage: "Cold",
    audience: "iOS acquisition",
    severity: "medium",
    reason: "C3 paused on the CAPI gap. iOS install audience is currently uncovered by any live angle.",
  },
  {
    id: "gap_bkstr_04",
    workspace_id: "ws_bookster",
    stage: "Warm",
    audience: "Male Professional · 25–44",
    severity: "low",
    reason: "No mid-funnel registration angle tested for the male professional segment.",
  },
];

export const STRATEGY_CARDS: StrategyCard[] = [...BOOKSTER_CARDS];
export const COVERAGE_GAPS: CoverageGap[] = [...BOOKSTER_GAPS];

export function getStrategyCards(workspaceId: string): StrategyCard[] {
  return STRATEGY_CARDS.filter((c) => c.workspace_id === workspaceId);
}

export function getCoverageGaps(workspaceId: string): CoverageGap[] {
  return COVERAGE_GAPS.filter((g) => g.workspace_id === workspaceId);
}
