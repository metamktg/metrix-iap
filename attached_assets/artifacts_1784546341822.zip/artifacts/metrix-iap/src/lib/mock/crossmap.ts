// ═══════════════════════════════════════════════════════════════════════
// METRIX IAP — Crossmap / Cross-Account Pattern data (MST layer)
// SAMPLE/DEMO DATA — Bookster-anchored variable stacks matched against
// benchmark verticals drawn from the agency's other accounts + external
// reference sets. Figures seeded to Bookster scale (~$8k spend / 486
// installs / 78 registrations). Not computed from live data.
// ═══════════════════════════════════════════════════════════════════════

export type MatchStatus = "validated" | "promising" | "divergent";

export interface BenchmarkVertical {
  id: string;
  name: string;
  account_label: string;   // representative reference account
  internal: boolean;       // true = another agency account, false = external ref
  cpr_band_min: number;    // cost per registration band (USD)
  cpr_band_max: number;
  cpi_band_min: number;    // cost per install band (USD)
  cpi_band_max: number;
  reg_rate_band: [number, number]; // % of installs -> registration
  sample_spend_usd: number;
  notes: string;
}

export interface CrossmapStack {
  hook: string;
  framework: string;
  tone: string;
  concept: string;
  cta: string;
}

export interface PatternMatch {
  id: string;
  source_cell: string;     // Bookster cell that produced the stack
  stack: CrossmapStack;
  stack_label: string;
  vertical_id: string;
  transferability: number; // 0-100
  status: MatchStatus;
  bookster_cpr: number;    // cost per registration on Bookster
  vertical_cpr: number;    // benchmark cost per registration for the vertical
  delta_pct: number;       // Bookster vs vertical (negative = cheaper)
  installs: number;
  registrations: number;
  evidence: string;
}

export interface ValidatedStack {
  id: string;
  rank: number;
  stack_label: string;
  codes: string[];
  verticals_confirmed: number;
  transferability: number;
  cpr_usd: number;
  lift_pct: number;         // registration-rate lift vs account baseline
  spend_usd: number;
  registrations: number;
  status: string;
  evidence: string;
}

// ─── Benchmark Verticals ──────────────────────────────────────────────

export const BENCHMARK_VERTICALS: BenchmarkVertical[] = [
  {
    id: "vert_audiobook",
    name: "Audiobook / Media Sub",
    account_label: "External ref set",
    internal: false,
    cpr_band_min: 82,
    cpr_band_max: 128,
    cpi_band_min: 12,
    cpi_band_max: 21,
    reg_rate_band: [14, 22],
    sample_spend_usd: 42_000,
    notes: "Closest structural neighbor. Trial-gated, mobile-first, retention-led.",
  },
  {
    id: "vert_edtech",
    name: "EdTech Subscription",
    account_label: "External ref set",
    internal: false,
    cpr_band_min: 95,
    cpr_band_max: 160,
    cpi_band_min: 15,
    cpi_band_max: 26,
    reg_rate_band: [11, 18],
    sample_spend_usd: 58_000,
    notes: "Authority + proof stacks transfer well. Higher intent, longer consideration.",
  },
  {
    id: "vert_productivity",
    name: "Productivity SaaS",
    account_label: "External ref set",
    internal: false,
    cpr_band_min: 74,
    cpr_band_max: 118,
    cpi_band_min: 10,
    cpi_band_max: 19,
    reg_rate_band: [16, 24],
    sample_spend_usd: 36_500,
    notes: "Benefit-led efficiency hooks dominate. Curiosity hooks underperform.",
  },
  {
    id: "vert_pet",
    name: "DTC Pet Supplements",
    account_label: "SKOV Pet",
    internal: true,
    cpr_band_min: 24,
    cpr_band_max: 52,
    cpi_band_min: 8,
    cpi_band_max: 17,
    reg_rate_band: [22, 34],
    sample_spend_usd: 62_400,
    notes: "Purchase funnel, not trial. Proof-first structure transfers; economics do not.",
  },
  {
    id: "vert_combat",
    name: "Combat Sports Apparel",
    account_label: "King of Violence",
    internal: true,
    cpr_band_min: 31,
    cpr_band_max: 72,
    cpi_band_min: 9,
    cpi_band_max: 20,
    reg_rate_band: [18, 28],
    sample_spend_usd: 38_900,
    notes: "Deadpan tone is account-specific. Authority hook is the shared transferable.",
  },
  {
    id: "vert_agency",
    name: "B2B Agency Lead-Gen",
    account_label: "Meta Marketing Agency",
    internal: true,
    cpr_band_min: 48,
    cpr_band_max: 112,
    cpi_band_min: 14,
    cpi_band_max: 30,
    reg_rate_band: [9, 16],
    sample_spend_usd: 284_500,
    notes: "Proof-first + rational tone is the universal winner across B2B and Bookster.",
  },
];

// ─── Cross-Account Pattern Matches ────────────────────────────────────

export const PATTERN_MATCHES: PatternMatch[] = [
  {
    id: "pm_0001",
    source_cell: "C4E",
    stack: { hook: "HK_Authority", framework: "FW_AIDA", tone: "TN_Aspirational", concept: "CN_SocialProof", cta: "CTA_StartFree" },
    stack_label: "Authority · AIDA · Aspirational · Social Proof · Start Free",
    vertical_id: "vert_audiobook",
    transferability: 91,
    status: "validated",
    bookster_cpr: 98,
    vertical_cpr: 112,
    delta_pct: -12,
    installs: 168,
    registrations: 29,
    evidence: "Bookster control stack. Reads under the audiobook CPR band on 3 of 3 checks.",
  },
  {
    id: "pm_0002",
    source_cell: "C4E",
    stack: { hook: "HK_Authority", framework: "FW_AIDA", tone: "TN_Rational", concept: "CN_SocialProof", cta: "CTA_StartFree" },
    stack_label: "Authority · AIDA · Rational · Social Proof · Start Free",
    vertical_id: "vert_agency",
    transferability: 87,
    status: "validated",
    bookster_cpr: 102,
    vertical_cpr: 88,
    delta_pct: 16,
    installs: 142,
    registrations: 24,
    evidence: "Proof-first + rational is the shared B2B winner. Bookster runs hotter CPR but same shape.",
  },
  {
    id: "pm_0003",
    source_cell: "C2B",
    stack: { hook: "HK_Benefit", framework: "FW_BAB", tone: "TN_Rational", concept: "CN_ProductDemo", cta: "CTA_StartFree" },
    stack_label: "Benefit · BAB · Rational · Product Demo · Start Free",
    vertical_id: "vert_productivity",
    transferability: 84,
    status: "validated",
    bookster_cpr: 106,
    vertical_cpr: 96,
    delta_pct: 10,
    installs: 118,
    registrations: 18,
    evidence: "Efficiency-benefit hook is the productivity-SaaS control. Registration control on Bookster.",
  },
  {
    id: "pm_0004",
    source_cell: "C1A",
    stack: { hook: "HK_Curiosity", framework: "FW_ProblemSolution", tone: "TN_Relatable", concept: "CN_BehaviorShift", cta: "CTA_TryFree" },
    stack_label: "Curiosity · Problem/Solution · Relatable · Behavior Shift · Try Free",
    vertical_id: "vert_audiobook",
    transferability: 68,
    status: "promising",
    bookster_cpr: 118,
    vertical_cpr: 105,
    delta_pct: 12,
    installs: 96,
    registrations: 12,
    evidence: "BYOC upload hook. 88 hook score but registration depth still thin — validate with budget.",
  },
  {
    id: "pm_0005",
    source_cell: "C3",
    stack: { hook: "HK_Problem", framework: "FW_ProblemSolution", tone: "TN_Relatable", concept: "CN_BehaviorShift", cta: "CTA_StartFree" },
    stack_label: "Problem · Problem/Solution · Relatable · Behavior Shift · Start Free",
    vertical_id: "vert_edtech",
    transferability: 72,
    status: "promising",
    bookster_cpr: 121,
    vertical_cpr: 130,
    delta_pct: -7,
    installs: 88,
    registrations: 11,
    evidence: "Guilt / behavior-shift angle. Android-led. Reads under EdTech band but volume-limited.",
  },
  {
    id: "pm_0006",
    source_cell: "C2E",
    stack: { hook: "HK_Problem", framework: "FW_PAS", tone: "TN_Assertive", concept: "CN_BehaviorShift", cta: "CTA_TryFree" },
    stack_label: "Problem · PAS · Assertive · Behavior Shift · Try Free",
    vertical_id: "vert_productivity",
    transferability: 41,
    status: "divergent",
    bookster_cpr: 168,
    vertical_cpr: 96,
    delta_pct: 75,
    installs: 42,
    registrations: 4,
    evidence: "READ LESS KEEP MORE. Assertive PAS consumed spend with no trials in V1 — diverges from vertical.",
  },
  {
    id: "pm_0007",
    source_cell: "C4E",
    stack: { hook: "HK_Authority", framework: "FW_AIDA", tone: "TN_Aspirational", concept: "CN_SocialProof", cta: "CTA_StartFree" },
    stack_label: "Authority · AIDA · Aspirational · Social Proof · Start Free",
    vertical_id: "vert_combat",
    transferability: 58,
    status: "promising",
    bookster_cpr: 98,
    vertical_cpr: 54,
    delta_pct: 81,
    installs: 168,
    registrations: 29,
    evidence: "Authority hook transfers; economics do not — combat is a purchase funnel with lower CPR band.",
  },
  {
    id: "pm_0008",
    source_cell: "C2B",
    stack: { hook: "HK_Benefit", framework: "FW_BAB", tone: "TN_Rational", concept: "CN_ProductDemo", cta: "CTA_StartFree" },
    stack_label: "Benefit · BAB · Rational · Product Demo · Start Free",
    vertical_id: "vert_pet",
    transferability: 44,
    status: "divergent",
    bookster_cpr: 106,
    vertical_cpr: 38,
    delta_pct: 179,
    installs: 118,
    registrations: 18,
    evidence: "Structure holds but pet supplements clear at a fraction of the CPR — not an economic match.",
  },
];

// ─── Validated Winning Stacks ─────────────────────────────────────────

export const VALIDATED_STACKS: ValidatedStack[] = [
  {
    id: "vs_0001",
    rank: 1,
    stack_label: "Authority · AIDA · Aspirational · Social Proof · Start Free",
    codes: ["HK_Authority", "FW_AIDA", "TN_Aspirational", "CN_SocialProof", "CTA_StartFree"],
    verticals_confirmed: 3,
    transferability: 91,
    cpr_usd: 98,
    lift_pct: 34,
    spend_usd: 2_640,
    registrations: 29,
    status: "Scale — cross-account control",
    evidence: "C4E control. Confirmed vs Audiobook, EdTech, and B2B agency benchmark bands.",
  },
  {
    id: "vs_0002",
    rank: 2,
    stack_label: "Benefit · BAB · Rational · Product Demo · Start Free",
    codes: ["HK_Benefit", "FW_BAB", "TN_Rational", "CN_ProductDemo", "CTA_StartFree"],
    verticals_confirmed: 2,
    transferability: 84,
    cpr_usd: 106,
    lift_pct: 21,
    spend_usd: 1_910,
    registrations: 18,
    status: "Scale — registration control",
    evidence: "C2B. Efficiency-benefit stack matched to Productivity SaaS + B2B lead-gen.",
  },
  {
    id: "vs_0003",
    rank: 3,
    stack_label: "Authority · AIDA · Rational · Social Proof · Start Free",
    codes: ["HK_Authority", "FW_AIDA", "TN_Rational", "CN_SocialProof", "CTA_StartFree"],
    verticals_confirmed: 2,
    transferability: 87,
    cpr_usd: 102,
    lift_pct: 19,
    spend_usd: 1_480,
    registrations: 24,
    status: "Extend — tone variant of #1",
    evidence: "Rational-tone sibling of the control. Slightly higher CPR, broader reach.",
  },
  {
    id: "vs_0004",
    rank: 4,
    stack_label: "Curiosity · Problem/Solution · Relatable · Behavior Shift · Try Free",
    codes: ["HK_Curiosity", "FW_ProblemSolution", "TN_Relatable", "CN_BehaviorShift", "CTA_TryFree"],
    verticals_confirmed: 1,
    transferability: 68,
    cpr_usd: 118,
    lift_pct: 8,
    spend_usd: 1_210,
    registrations: 12,
    status: "Validate — needs budget",
    evidence: "BYOC upload angle. High hook score, thin registration depth. Isolate before scale.",
  },
  {
    id: "vs_0005",
    rank: 5,
    stack_label: "Problem · Problem/Solution · Relatable · Behavior Shift · Start Free",
    codes: ["HK_Problem", "FW_ProblemSolution", "TN_Relatable", "CN_BehaviorShift", "CTA_StartFree"],
    verticals_confirmed: 1,
    transferability: 72,
    cpr_usd: 121,
    lift_pct: 6,
    spend_usd: 1_000,
    registrations: 11,
    status: "Validate — Android-led",
    evidence: "Guilt / behavior-shift. Reads under EdTech band on Android. Watch iOS CAPI gap.",
  },
];

export function getVertical(id: string): BenchmarkVertical | undefined {
  return BENCHMARK_VERTICALS.find(v => v.id === id);
}
