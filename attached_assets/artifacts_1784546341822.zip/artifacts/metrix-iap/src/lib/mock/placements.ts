// ═══════════════════════════════════════════════════════════════════════
// METRIX IAP — Placement Performance data.
// SAMPLE/DEMO DATA seeded per workspace. Bookster (book-summary app).
// Scale consistent with ~$8k spend / 486 installs.
// ═══════════════════════════════════════════════════════════════════════

export type PlacementFatigue = "fresh" | "mild_fatigue" | "fatigued" | "burnt";
export type PlacementAction = "Scale" | "Hold" | "Shift" | "Cut";

export interface PlacementRow {
  id: string;
  name: string;                      // "Feed", "Stories", "Reels", ...
  surface: string;                   // short descriptor
  spend: number;
  impressions: number;
  clicks: number;
  installs: number;
  fatigue: PlacementFatigue;
  trend_pct: number;                 // installs delta vs prior period
  ios_pct: number;                   // device split
  android_pct: number;
  fb_pct: number;                    // platform split (0/0 = off-platform)
  ig_pct: number;
}

export interface PlacementRecommendation {
  id: string;
  placement: string;
  action: PlacementAction;
  rationale: string;
  confidence: "high" | "medium" | "validation_required";
}

export interface PlacementData {
  workspace_id: string;
  account_label: string;
  date_range: string;
  blended_cpa: number;
  rows: PlacementRow[];
  recommendations: PlacementRecommendation[];
}

const BOOKSTER_PLACEMENTS: PlacementData = {
  workspace_id: "ws_bookster",
  account_label: "Bookster.ai — Meta",
  date_range: "May 2 – Jul 7, 2026",
  blended_cpa: 16.46,
  rows: [
    { id: "feed", name: "Feed", surface: "FB + IG Feed", spend: 3600, impressions: 980000, clicks: 2600, installs: 248, fatigue: "fresh", trend_pct: 14, ios_pct: 42, android_pct: 58, fb_pct: 55, ig_pct: 45 },
    { id: "reels", name: "Reels", surface: "IG + FB Reels", spend: 2200, impressions: 820000, clicks: 1680, installs: 132, fatigue: "fresh", trend_pct: 21, ios_pct: 38, android_pct: 62, fb_pct: 20, ig_pct: 80 },
    { id: "stories", name: "Stories", surface: "IG + FB Stories", spend: 1300, impressions: 480000, clicks: 980, installs: 74, fatigue: "mild_fatigue", trend_pct: 3, ios_pct: 45, android_pct: 55, fb_pct: 30, ig_pct: 70 },
    { id: "an", name: "Audience Network", surface: "Off-platform inventory", spend: 640, impressions: 240000, clicks: 460, installs: 24, fatigue: "fatigued", trend_pct: -9, ios_pct: 30, android_pct: 70, fb_pct: 0, ig_pct: 0 },
    { id: "msgr", name: "Messenger", surface: "Inbox + Stories", spend: 260, impressions: 52802, clicks: 128, installs: 8, fatigue: "burnt", trend_pct: -18, ios_pct: 48, android_pct: 52, fb_pct: 100, ig_pct: 0 },
  ],
  recommendations: [
    { id: "pr1", placement: "Reels", action: "Scale", rationale: "Fastest-growing installs (+21%), CPA $16.67 near blended, IG-heavy. Lift budget +30%.", confidence: "high" },
    { id: "pr2", placement: "Feed", action: "Hold", rationale: "Efficiency control at $14.52 CPA. Maintain spend, rotate C4E to defend fatigue.", confidence: "high" },
    { id: "pr3", placement: "Stories", action: "Shift", rationale: "Mid-pack CPA $17.57. Push Android + IG split where installs concentrate.", confidence: "medium" },
    { id: "pr4", placement: "Audience Network", action: "Cut", rationale: "CPA $26.67 (62% above blended), declining. Exclude from delivery.", confidence: "high" },
    { id: "pr5", placement: "Messenger", action: "Cut", rationale: "CPA $32.50, burnt, negligible volume. Remove placement.", confidence: "high" },
  ],
};

export function getPlacementData(workspaceId: string): PlacementData {
  return { ...BOOKSTER_PLACEMENTS, workspace_id: workspaceId };
}
