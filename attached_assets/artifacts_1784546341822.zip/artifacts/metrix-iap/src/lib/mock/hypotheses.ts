// ═══════════════════════════════════════════════════════════════════════
// METRIX IAP — Hypothesis Queue data (prioritized creative test backlog).
// SAMPLE/DEMO DATA seeded per workspace. Bookster-branded, consistent with
// the ~$8k spend / 486 installs / 78 registrations account scale.
// ═══════════════════════════════════════════════════════════════════════

import type { ConfidenceLabel, VariableCodeFamily } from "@/lib/types";

export type HypothesisStatus = "Queued" | "Testing" | "Validated" | "Rejected";
export type ImpactMetric = "CPI" | "CPR" | "Reg Rate" | "Hook Rate" | "Install Rate";
export type ImpactDirection = "up" | "down";

export const HYPOTHESIS_STATUSES: HypothesisStatus[] = [
  "Queued", "Testing", "Validated", "Rejected",
];

export interface Hypothesis {
  id: string;
  code: string;              // H-01
  workspace_id: string;
  statement: string;
  variable_family: VariableCodeFamily;
  linked_concept: string;    // concept code, e.g. C4E
  avatar: string;            // target avatar name
  impact_metric: ImpactMetric;
  impact_direction: ImpactDirection;
  expected_impact: string;   // e.g. "−18% CPR"
  confidence: ConfidenceLabel;
  status: HypothesisStatus;
  priority_score: number;    // 0–100
  owner: string;
  evidence: string;
}

const BOOKSTER_HYPOTHESES: Hypothesis[] = [
  {
    id: "hyp_bkstr_01",
    code: "H-01",
    workspace_id: "ws_bookster",
    statement: "Moving registration to last (pre-paywall) lifts registration rate on C2B.",
    variable_family: "FW",
    linked_concept: "C2B",
    avatar: "Depth-Seeking Reader",
    impact_metric: "Reg Rate",
    impact_direction: "up",
    expected_impact: "+6 pts reg rate",
    confidence: "high",
    status: "Validated",
    priority_score: 92,
    owner: "Priya Mehta",
    evidence: "Reg rate rose to 23.7% after flow restructure vs 15.9% prior on comparable spend.",
  },
  {
    id: "hyp_bkstr_02",
    code: "H-02",
    workspace_id: "ws_bookster",
    statement: "Android-only bidding on C4E lowers CPI by isolating from the iOS CAPI gap.",
    variable_family: "CN",
    linked_concept: "C4E",
    avatar: "Time-Starved Professional",
    impact_metric: "CPI",
    impact_direction: "down",
    expected_impact: "−22% CPI",
    confidence: "high",
    status: "Validated",
    priority_score: 88,
    owner: "Taylor Kim",
    evidence: "CPI $11.59 on Android vs $21.60 on iOS-inclusive delivery.",
  },
  {
    id: "hyp_bkstr_03",
    code: "H-03",
    workspace_id: "ws_bookster",
    statement: "An authority hook ('1,000 books, 15 min each') beats curiosity for cold professionals.",
    variable_family: "HK",
    linked_concept: "C4E",
    avatar: "Time-Starved Professional",
    impact_metric: "Hook Rate",
    impact_direction: "up",
    expected_impact: "+9 pts hook rate",
    confidence: "high",
    status: "Testing",
    priority_score: 84,
    owner: "Sam Ortega",
    evidence: "HK_Authority tracking 82 hook score vs 71 for HK_Curiosity in current split.",
  },
  {
    id: "hyp_bkstr_04",
    code: "H-04",
    workspace_id: "ws_bookster",
    statement: "A quiz-gate before registration raises checkout depth for the 45–54 segment.",
    variable_family: "CTA",
    linked_concept: "C2B",
    avatar: "Depth-Seeking Reader",
    impact_metric: "Reg Rate",
    impact_direction: "up",
    expected_impact: "+4 pts checkout",
    confidence: "validation_required",
    status: "Testing",
    priority_score: 79,
    owner: "Priya Mehta",
    evidence: "Early quiz-gate cell shows higher intent signals; volume below high threshold.",
  },
  {
    id: "hyp_bkstr_05",
    code: "H-05",
    workspace_id: "ws_bookster",
    statement: "BYOC ('upload your own book') hook wins the 18–24 discovery audience.",
    variable_family: "HK",
    linked_concept: "BYOC",
    avatar: "Curious Self-Improver",
    impact_metric: "Install Rate",
    impact_direction: "up",
    expected_impact: "+12% install rate",
    confidence: "validation_required",
    status: "Testing",
    priority_score: 74,
    owner: "Sam Ortega",
    evidence: "Strong hook engagement, thin conversion volume — needs 7 more days of spend.",
  },
  {
    id: "hyp_bkstr_06",
    code: "H-06",
    workspace_id: "ws_bookster",
    statement: "Reels-native format lowers CPI for the mobile-first 18–24 avatar.",
    variable_family: "CN",
    linked_concept: "BYOC",
    avatar: "Curious Self-Improver",
    impact_metric: "CPI",
    impact_direction: "down",
    expected_impact: "−15% CPI",
    confidence: "medium",
    status: "Queued",
    priority_score: 71,
    owner: "Taylor Kim",
    evidence: "Feed CPI $15.00; Reels hypothesized cheaper on younger audience placements.",
  },
  {
    id: "hyp_bkstr_07",
    code: "H-07",
    workspace_id: "ws_bookster",
    statement: "A retention re-engagement angle recovers installs that never registered.",
    variable_family: "FW",
    linked_concept: "C4E",
    avatar: "Time-Starved Professional",
    impact_metric: "Reg Rate",
    impact_direction: "up",
    expected_impact: "+8% of 486 installs",
    confidence: "medium",
    status: "Queued",
    priority_score: 81,
    owner: "Priya Mehta",
    evidence: "No retention creative live — 486 installs currently un-nurtured post-download.",
  },
  {
    id: "hyp_bkstr_08",
    code: "H-08",
    workspace_id: "ws_bookster",
    statement: "Shorter primary text on C2E cuts registration cost toward the C2B control.",
    variable_family: "TN",
    linked_concept: "C2E",
    avatar: "Depth-Seeking Reader",
    impact_metric: "CPR",
    impact_direction: "down",
    expected_impact: "−30% CPR",
    confidence: "medium",
    status: "Queued",
    priority_score: 68,
    owner: "Sam Ortega",
    evidence: "C2E CPR $141 vs C2B control $80 — copy length flagged as likely driver.",
  },
  {
    id: "hyp_bkstr_09",
    code: "H-09",
    workspace_id: "ws_bookster",
    statement: "A male-professional mid-funnel angle opens untested registration volume.",
    variable_family: "CN",
    linked_concept: "C2B",
    avatar: "Time-Starved Professional",
    impact_metric: "Reg Rate",
    impact_direction: "up",
    expected_impact: "+ new segment",
    confidence: "insufficient",
    status: "Queued",
    priority_score: 55,
    owner: "Priya Mehta",
    evidence: "No MOF angle tested for male 25–44 — coverage gap, no baseline yet.",
  },
  {
    id: "hyp_bkstr_10",
    code: "H-10",
    workspace_id: "ws_bookster",
    statement: "Proof-first hook overcomes AI-accuracy objection for skeptical iOS users.",
    variable_family: "HK",
    linked_concept: "C3",
    avatar: "Skeptical iOS Skimmer",
    impact_metric: "CPR",
    impact_direction: "down",
    expected_impact: "−20% CPR",
    confidence: "insufficient",
    status: "Rejected",
    priority_score: 34,
    owner: "Taylor Kim",
    evidence: "Blocked by pixel/CAPI gap — iOS conversion events unreliable, cannot read result.",
  },
  {
    id: "hyp_bkstr_11",
    code: "H-11",
    workspace_id: "ws_bookster",
    statement: "Urgency CTA ('Start free today') outperforms 'Learn more' on cold traffic.",
    variable_family: "CTA",
    linked_concept: "C4E",
    avatar: "Time-Starved Professional",
    impact_metric: "Install Rate",
    impact_direction: "up",
    expected_impact: "no lift",
    confidence: "medium",
    status: "Rejected",
    priority_score: 41,
    owner: "Sam Ortega",
    evidence: "CTA_StartFree and CTA_LearnMore landed within noise — no significant install-rate delta.",
  },
];

export const HYPOTHESES: Hypothesis[] = [...BOOKSTER_HYPOTHESES];

export function getHypotheses(workspaceId: string): Hypothesis[] {
  return HYPOTHESES.filter((h) => h.workspace_id === workspaceId);
}
