// ═══════════════════════════════════════════════════════════════════════
// METRIX IAP — Customer Avatars / ICP data.
// SAMPLE/DEMO DATA seeded per workspace. Bookster spend/install/registration
// splits sum to ~$8k spend / 486 installs / 78 registrations.
// ═══════════════════════════════════════════════════════════════════════

import type { ConfidenceLabel } from "@/lib/types";

export type AvatarStatus = "Primary" | "Secondary" | "Emerging" | "Deprioritized";

export interface AvatarStats {
  spend_usd: number;
  installs: number;
  registrations: number;
  cpi_usd: number;      // cost per install
  cpr_usd: number;      // cost per registration
  reg_rate: number;     // 0–1 (registrations / installs)
  share_of_spend: number; // 0–1
}

export interface Avatar {
  id: string;
  workspace_id: string;
  name: string;
  tagline: string;
  demographics: string;
  age_range: string;
  primary_platform: string;
  status: AvatarStatus;
  confidence: ConfidenceLabel;
  pains: string[];
  desires: string[];
  objections: string[];
  matched_hooks: string[];
  matched_angles: string[]; // concept codes
  stats: AvatarStats;
  strategic_note: string;
}

const BOOKSTER_AVATARS: Avatar[] = [
  {
    id: "av_bkstr_01",
    workspace_id: "ws_bookster",
    name: "Time-Starved Professional",
    tagline: "Wants the ideas, not the 300 pages.",
    demographics: "Mixed gender · college-educated · $75K+ HHI",
    age_range: "25–44",
    primary_platform: "Meta · Android · Feed",
    status: "Primary",
    confidence: "high",
    pains: [
      "Abandons books around 30–40% and feels guilty",
      "No time to read at professional pace",
      "Subscription fatigue across too many apps",
    ],
    desires: [
      "Retain key ideas in under 15 minutes",
      "Signal continuous learning to peers",
      "Frictionless start with no card required",
    ],
    objections: [
      "\"Summaries lose the nuance of the full book\"",
      "\"Another subscription I'll forget to use\"",
    ],
    matched_hooks: ["HK_Authority", "HK_Result", "HK_Benefit"],
    matched_angles: ["C4E", "C2B"],
    stats: {
      spend_usd: 3120,
      installs: 214,
      registrations: 34,
      cpi_usd: 14.58,
      cpr_usd: 91.76,
      reg_rate: 0.159,
      share_of_spend: 0.39,
    },
    strategic_note: "Scale C4E on Android-specific bidding. Move registration to last, pre-paywall. Avoid iOS due to CAPI gap.",
  },
  {
    id: "av_bkstr_02",
    workspace_id: "ws_bookster",
    name: "Depth-Seeking Reader",
    tagline: "Reads for knowledge that sticks, not speed.",
    demographics: "Female · professional background · philosophy/history interest",
    age_range: "45–54",
    primary_platform: "Meta · Feed",
    status: "Primary",
    confidence: "high",
    pains: [
      "Fast-summary tools feel shallow",
      "Wants breadth without losing rigor",
      "Skeptical of productivity-signaling apps",
    ],
    desires: [
      "1,000+ titles across serious subjects",
      "Knowledge retention over throughput",
      "Intellectual validation, not hustle framing",
    ],
    objections: [
      "\"Will this cover philosophy and economics?\"",
      "\"Is this just business-book fast food?\"",
    ],
    matched_hooks: ["HK_Benefit", "HK_Curiosity"],
    matched_angles: ["C2B", "C2E"],
    stats: {
      spend_usd: 2240,
      installs: 118,
      registrations: 28,
      cpi_usd: 18.98,
      cpr_usd: 80.0,
      reg_rate: 0.237,
      share_of_spend: 0.28,
    },
    strategic_note: "Registration control segment — highest reg rate. Checkout conversion weaker; quiz-gate variant shows promise.",
  },
  {
    id: "av_bkstr_03",
    workspace_id: "ws_bookster",
    name: "Curious Self-Improver",
    tagline: "Discovery-driven, mobile-native, price-sensitive.",
    demographics: "Mixed gender · students & early-career · mobile-first",
    age_range: "18–24",
    primary_platform: "Meta · Reels · Story",
    status: "Emerging",
    confidence: "validation_required",
    pains: [
      "Overwhelmed by what to read next",
      "Short attention span on long-form",
      "Tight budget for paid apps",
    ],
    desires: [
      "Bite-sized ideas that feel like a feed",
      "Upload-your-own-book novelty (BYOC)",
      "Free tier to try before committing",
    ],
    objections: [
      "\"Why pay when I can search it free?\"",
      "\"Will it work with my own PDFs?\"",
    ],
    matched_hooks: ["HK_Curiosity", "HK_Contrast"],
    matched_angles: ["BYOC", "C3"],
    stats: {
      spend_usd: 1560,
      installs: 104,
      registrations: 11,
      cpi_usd: 15.0,
      cpr_usd: 141.82,
      reg_rate: 0.106,
      share_of_spend: 0.195,
    },
    strategic_note: "BYOC hook lands but reg rate lags. Test Reels-native format and free-tier framing before scaling spend.",
  },
  {
    id: "av_bkstr_04",
    workspace_id: "ws_bookster",
    name: "Skeptical iOS Skimmer",
    tagline: "High intent, unreliable tracking.",
    demographics: "Mixed gender · iOS · privacy-conscious",
    age_range: "30–49",
    primary_platform: "Meta · iOS · Feed",
    status: "Deprioritized",
    confidence: "insufficient",
    pains: [
      "Distrusts AI-generated summaries",
      "Privacy concerns with tracking",
      "Wants proof before committing",
    ],
    desires: [
      "Credible, human-sounding condensations",
      "No-guilt way to keep reading habit alive",
      "Clear evidence of value",
    ],
    objections: [
      "\"Is the AI actually accurate?\"",
      "\"I don't want to be tracked\"",
    ],
    matched_hooks: ["HK_Problem", "HK_ProofFirst"],
    matched_angles: ["C3"],
    stats: {
      spend_usd: 1080,
      installs: 50,
      registrations: 5,
      cpi_usd: 21.6,
      cpr_usd: 216.0,
      reg_rate: 0.1,
      share_of_spend: 0.135,
    },
    strategic_note: "Held pending pixel/CAPI fix — iOS conversion events unreliable. Do not scale until tracking confidence recovers.",
  },
];

export const AVATARS: Avatar[] = [...BOOKSTER_AVATARS];

export function getAvatars(workspaceId: string): Avatar[] {
  return AVATARS.filter((a) => a.workspace_id === workspaceId);
}
