const STORAGE_KEY = "metrix-iap:runs-list-search";

export function rememberRunsListSearch(searchString: string) {
  try {
    if (searchString) {
      sessionStorage.setItem(STORAGE_KEY, searchString);
    } else {
      sessionStorage.removeItem(STORAGE_KEY);
    }
  } catch {
    // sessionStorage unavailable — skip persistence
  }
}

export function getRunsListPath(): string {
  try {
    const qs = sessionStorage.getItem(STORAGE_KEY);
    return qs ? `/app/analysis/library?${qs}` : "/app/analysis/library";
  } catch {
    return "/app/analysis/library";
  }
}
