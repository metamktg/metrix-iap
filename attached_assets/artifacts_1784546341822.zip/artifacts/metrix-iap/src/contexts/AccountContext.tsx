// ═══════════════════════════════════════════════════════════════════════
// METRIX IAP — Account Context
// Mirrors live app.metrix.ad: ONE agency ("Metrix Manager") with a flat
// list of ad accounts. Global routes (/app/...) are scoped by the
// `?account=<slug>` URL param — the URL is the single source of truth.
// No sessionStorage. No workspace tree.
// ═══════════════════════════════════════════════════════════════════════

import React, { createContext, useContext, useEffect, useMemo, useRef } from "react";
import { useLocation, useSearch } from "wouter";
import {
  ACCOUNTS,
  USERS,
  getAccountBySlug,
  getWorkspaceWithData,
} from "../lib/mock-data";
import type { Workspace, WorkspaceWithData, User } from "../lib/types";

interface AccountContextValue {
  /** Flat list of the agency's ad accounts (mirrors live switcher). */
  accounts: Workspace[];
  /** Account resolved from ?account=<slug> — null on agency-level views. */
  currentAccount: WorkspaceWithData | null;
  /** Slug from the URL (even if it didn't resolve), null when absent. */
  currentAccountSlug: string | null;
  currentUser: User;
  /** Append the current ?account= param to an href (keeps account scope on nav). */
  withAccount: (href: string) => string;
  /** Switch account: keep the current path, swap the ?account= param. */
  navigateToAccount: (slug: string) => void;
  /** Clear account scope and go to an agency-level path. */
  navigateToAgency: (href: string) => void;
}

const AccountContext = createContext<AccountContextValue | null>(null);

export function AccountProvider({ children }: { children: React.ReactNode }) {
  const [location, navigate] = useLocation();
  const search = useSearch();

  const currentAccountSlug = useMemo(() => {
    const params = new URLSearchParams(search);
    return params.get("account");
  }, [search]);

  const currentAccount = useMemo(() => {
    const account = getAccountBySlug(currentAccountSlug);
    if (!account) return null;
    return getWorkspaceWithData(account.id) ?? null;
  }, [currentAccountSlug]);

  const currentUser = USERS[0];

  // Sticky account scope: legacy in-page links don't carry ?account=, so
  // re-attach the last-known account when navigating between /app routes.
  // Agency-level routes ("/") intentionally clear the scope.
  const lastSlugRef = useRef<string | null>(null);
  useEffect(() => {
    if (currentAccountSlug) lastSlugRef.current = currentAccountSlug;
  }, [currentAccountSlug]);
  useEffect(() => {
    if (!currentAccountSlug && lastSlugRef.current && location.startsWith("/app")) {
      const params = new URLSearchParams(search);
      params.set("account", lastSlugRef.current);
      navigate(`${location}?${params.toString()}`, { replace: true });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [location, currentAccountSlug]);

  function withAccount(href: string): string {
    if (!currentAccountSlug) return href;
    const [path, query = ""] = href.split("?");
    const params = new URLSearchParams(query);
    params.set("account", currentAccountSlug);
    return `${path}?${params.toString()}`;
  }

  function navigateToAccount(slug: string) {
    const params = new URLSearchParams(search);
    params.set("account", slug);
    navigate(`${location}?${params.toString()}`);
  }

  function navigateToAgency(href: string) {
    navigate(href);
  }

  const value: AccountContextValue = {
    accounts: ACCOUNTS,
    currentAccount,
    currentAccountSlug,
    currentUser,
    withAccount,
    navigateToAccount,
    navigateToAgency,
  };

  return (
    <AccountContext.Provider value={value}>
      {children}
    </AccountContext.Provider>
  );
}

export function useAccount(): AccountContextValue {
  const ctx = useContext(AccountContext);
  if (!ctx) throw new Error("useAccount must be used within AccountProvider");
  return ctx;
}
