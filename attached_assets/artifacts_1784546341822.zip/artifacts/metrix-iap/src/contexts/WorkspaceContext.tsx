// ═══════════════════════════════════════════════════════════════════════
// METRIX IAP — Legacy Workspace shim
// Compatibility layer over AccountContext for pages still calling
// useWorkspace()/useCurrentWorkspace(). The "effective" account is the
// URL-selected account, falling back to Bookster so old pages render.
// New code should use useAccount() from AccountContext instead.
// ═══════════════════════════════════════════════════════════════════════

import type React from "react";
import { getWorkspaceWithData, DEFAULT_ACCOUNT_SLUG, getAccountBySlug } from "../lib/mock-data";
import type { Workspace, WorkspaceWithData, User } from "../lib/types";
import { AccountProvider, useAccount } from "./AccountContext";

interface WorkspaceContextValue {
  workspaces: Workspace[];
  currentWorkspace: WorkspaceWithData;
  currentWorkspaceId: string | null;
  isOnWorkspaceRoute: boolean;
  currentUser: User;
  switchWorkspace: (workspaceId: string) => void;
}

export function WorkspaceProvider({ children }: { children: React.ReactNode }) {
  return <AccountProvider>{children}</AccountProvider>;
}

export function useWorkspace(): WorkspaceContextValue {
  const { accounts, currentAccount, currentUser, navigateToAccount } = useAccount();

  const fallbackId = getAccountBySlug(DEFAULT_ACCOUNT_SLUG)!.id;
  const currentWorkspace = currentAccount ?? getWorkspaceWithData(fallbackId)!;

  return {
    workspaces: accounts,
    currentWorkspace,
    currentWorkspaceId: currentAccount?.id ?? null,
    isOnWorkspaceRoute: currentAccount != null,
    currentUser,
    switchWorkspace: (workspaceId: string) => {
      const account = accounts.find(a => a.id === workspaceId);
      if (account) navigateToAccount(account.slug);
    },
  };
}

export function useCurrentWorkspace(): WorkspaceWithData {
  return useWorkspace().currentWorkspace;
}
