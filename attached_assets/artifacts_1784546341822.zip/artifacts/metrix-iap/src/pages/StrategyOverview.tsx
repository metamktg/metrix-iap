// ═══════════════════════════════════════════════════════════════════════
// METRIX IAP — Strategy › Overview
// Strategy posture for the selected account: ICP coverage, the current
// control read from the latest run, and jump-offs into the strategy tools.
// ═══════════════════════════════════════════════════════════════════════

import { Link } from "wouter";
import { Compass, ArrowUpRight, Users, FlaskConical, FileText, TrendingUp } from "lucide-react";
import { cn } from "@/lib/utils";
import { useCurrentWorkspace } from "@/contexts/WorkspaceContext";
import { ANALYSIS_RUNS, ICP_PROFILES, BRIEFS } from "@/lib/mock-data";

export function StrategyOverview() {
  const ws = useCurrentWorkspace();

  const icps = ICP_PROFILES.filter(p => p.workspace_id === ws.id);
  const runs = ANALYSIS_RUNS
    .filter(r => r.workspace_id === ws.id && r.status === "Completed")
    .sort((a, b) => b.created_at.localeCompare(a.created_at));
  const latest = runs[0];
  const briefs = BRIEFS.filter(b => b.workspace_id === ws.id);
  const activeBriefs = briefs.filter(b => b.status === "Draft" || b.status === "In Review" || b.status === "Approved" || b.status === "In Production");
  const completedBriefs = briefs.filter(b => b.status === "Archived");

  const pipelineStats = [
    { label: "ICP Profiles", value: icps.length, icon: Users, color: "text-primary", href: "/app/strategy/avatars" },
    { label: "Briefs in pipeline", value: activeBriefs.length, icon: FileText, color: "text-[hsl(var(--metrix-gold))]", href: "/app/briefs/builder" },
    { label: "Completed briefs", value: completedBriefs.length, icon: TrendingUp, color: "text-[hsl(var(--metrix-success))]", href: "/app/briefs/history" },
    { label: "Completed runs", value: runs.length, icon: FlaskConical, color: "text-purple-400", href: "/app/analysis/library" },
  ];

  return (
    <div className="flex-1 p-5 space-y-4 max-w-5xl">
      <div className="flex items-end justify-between gap-4">
        <div>
          <h1 className="text-lg font-bold text-foreground tracking-tight">Strategy Overview</h1>
          <p className="text-xs text-muted-foreground mt-0.5">
            {ws.name} · {icps.length} ICP profile{icps.length === 1 ? "" : "s"} · {briefs.length} brief{briefs.length === 1 ? "" : "s"} in pipeline
          </p>
        </div>
        <Link
          href="/app/strategy/map"
          className="px-3 py-1.5 rounded-lg bg-primary text-primary-foreground text-xs font-semibold hover:opacity-90 transition-opacity"
          data-testid="link-strategy-map"
        >
          Open Strategy Map
        </Link>
      </div>

      {/* Pipeline metrics strip */}
      <div className="grid grid-cols-4 gap-2.5">
        {pipelineStats.map(stat => (
          <Link
            key={stat.label}
            href={stat.href}
            className="bg-card/60 border border-border/60 rounded-xl px-4 py-3 hover:border-primary/30 hover:bg-card transition-colors group"
          >
            <div className="flex items-center gap-1.5 mb-1.5">
              <stat.icon className={cn("w-3 h-3", stat.color)} />
              <div className="text-[9px] font-semibold uppercase tracking-[0.18em] text-muted-foreground/70">{stat.label}</div>
            </div>
            <div className={cn("text-2xl font-bold tabular-nums", stat.color)}>{stat.value}</div>
          </Link>
        ))}
      </div>

      {/* Current control */}
      {latest ? (
        <div className="bg-card/60 border border-primary/25 rounded-xl px-4 py-3.5">
          <div className="text-[9px] font-semibold uppercase tracking-[0.18em] text-primary mb-1.5">Current control</div>
          <p className="text-sm text-foreground leading-relaxed">{latest.priority_read}</p>
          <div className="flex items-center gap-3 mt-2.5 pt-2.5 border-t border-border/40">
            <span className="text-[10px] font-mono text-muted-foreground/60 uppercase">source · {latest.id}</span>
            <Link href={`/app/analysis/library/${latest.id}`} className="text-[11px] text-primary hover:text-primary/80 transition-colors ml-auto">
              Evidence
            </Link>
          </div>
        </div>
      ) : (
        <div className="flex items-start gap-2.5 bg-card/60 border border-border/60 rounded-xl px-4 py-3.5">
          <Compass className="w-4 h-4 text-muted-foreground/50 shrink-0 mt-0.5" />
          <p className="text-xs text-muted-foreground">
            No completed run yet — the control read appears after the first IAP analysis.{" "}
            <Link href="/app/analysis/new-run" className="text-primary hover:text-primary/80 transition-colors">Start one</Link>.
          </p>
        </div>
      )}

      {/* ICP grid */}
      <div className="bg-card/60 border border-border/60 rounded-xl px-4 py-3.5">
        <div className="flex items-center justify-between mb-2.5">
          <div className="flex items-center gap-1.5 text-[9px] font-semibold uppercase tracking-[0.18em] text-muted-foreground/70">
            <Users className="w-3 h-3" /> Avatars / ICP profiles
          </div>
          <Link href="/app/strategy/avatars" className="text-[11px] text-primary hover:text-primary/80 transition-colors">
            All profiles
          </Link>
        </div>
        {icps.length === 0 ? (
          <p className="text-xs text-muted-foreground py-4 text-center">No ICP profiles generated yet for this account.</p>
        ) : (
          <div className="grid grid-cols-2 gap-2.5">
            {icps.slice(0, 4).map(icp => (
              <div key={icp.profile_id} className="border border-border/40 rounded-lg px-3 py-2.5" data-testid={`icp-${icp.profile_id}`}>
                <div className="flex items-center justify-between gap-2">
                  <span className="text-xs font-semibold text-foreground truncate">{icp.profile_name}</span>
                  <span className={cn(
                    "shrink-0 text-[10px] font-mono px-1.5 py-0.5 rounded border leading-none",
                    icp.confidence_level === "high"
                      ? "text-[hsl(var(--metrix-success))] border-[hsl(var(--metrix-success)/0.3)]"
                      : "text-yellow-400 border-yellow-400/30"
                  )}>
                    {icp.confidence_level}
                  </span>
                </div>
                <p className="text-[11px] text-muted-foreground mt-1 line-clamp-2 leading-relaxed">{icp.strategic_recommendation}</p>
                <div className="flex items-center gap-3 mt-1.5 text-[10px] font-mono text-muted-foreground/60 tabular-nums">
                  <span>CPA ${icp.performance_data.avg_cpa_usd.toFixed(2)}</span>
                  <span>ROAS {icp.performance_data.avg_roas.toFixed(1)}</span>
                  <span>{icp.performance_data.primary_placement}</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Tool jump-offs */}
      <div className="grid grid-cols-3 gap-2.5">
        {[
          { label: "Strategy Map", desc: "Positioning + funnel structure", href: "/app/strategy/map" },
          { label: "Avatars / ICP", desc: `${icps.length} profile${icps.length === 1 ? "" : "s"} on this account`, href: "/app/strategy/avatars" },
          { label: "Hypothesis Queue", desc: "Testable strategy bets", href: "/app/strategy/hypotheses" },
        ].map(l => (
          <Link
            key={l.href}
            href={l.href}
            className="bg-card/60 border border-border/60 rounded-xl px-4 py-3 hover:border-primary/30 hover:bg-card transition-colors group"
            data-testid={`quicklink-${l.label.toLowerCase().replace(/[ /]+/g, "-")}`}
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-foreground">{l.label}</span>
              <ArrowUpRight className="w-3.5 h-3.5 text-muted-foreground/50 group-hover:text-primary transition-colors" />
            </div>
            <p className="text-[11px] text-muted-foreground mt-0.5">{l.desc}</p>
          </Link>
        ))}
      </div>
    </div>
  );
}
