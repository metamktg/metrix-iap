// ═══════════════════════════════════════════════════════════════════════
// METRIX IAP — Creative execution hub (/app/creative)
// Active briefs pipeline, recent creative additions, "New Brief" CTA.
// ═══════════════════════════════════════════════════════════════════════

import { Link } from "wouter";
import { Palette, ArrowUpRight, PlusCircle, Image } from "lucide-react";
import { cn } from "@/lib/utils";
import { useCurrentWorkspace } from "@/contexts/WorkspaceContext";
import { BRIEFS, ADS } from "@/lib/mock-data";

const STATUS_PILL: Record<string, string> = {
  Draft:         "bg-muted text-muted-foreground border-border/40",
  "In Review":   "bg-yellow-400/10 text-yellow-400 border-yellow-400/20",
  Approved:      "bg-primary/10 text-primary border-primary/20",
  "In Production":"bg-[hsl(var(--metrix-cyan)/0.12)] text-[hsl(var(--metrix-cyan))] border-[hsl(var(--metrix-cyan)/0.3)]",
  Archived:      "bg-muted text-muted-foreground/60 border-border/30",
};

const STATUS_BAR: Record<string, string> = {
  Draft:          "bg-border",
  "In Review":    "bg-yellow-400",
  Approved:       "bg-primary",
  "In Production":"bg-[hsl(var(--metrix-cyan))]",
  Archived:       "bg-muted-foreground/20",
};

export function CreativeHub() {
  const ws = useCurrentWorkspace();

  const briefs = BRIEFS.filter(b => b.workspace_id === ws.id)
    .sort((a, b) => b.created_at.localeCompare(a.created_at));
  const active = briefs.filter(b => b.status !== "Archived");
  const recentAds = ADS.filter(a => a.workspace_id === ws.id).slice(0, 4);

  const statusCounts = ["Draft", "In Review", "Approved", "In Production"].map(s => ({
    status: s,
    count: briefs.filter(b => b.status === s).length,
  }));

  return (
    <div className="flex-1 p-5 space-y-4 max-w-5xl">
      <div className="flex items-end justify-between gap-4">
        <div>
          <div className="text-[9px] font-semibold uppercase tracking-[0.18em] text-muted-foreground/60 mb-1">
            Creative · Production
          </div>
          <h1 className="text-lg font-bold text-foreground tracking-tight">Creative</h1>
          <p className="text-xs text-muted-foreground mt-0.5">
            {ws.name} · {briefs.length} brief{briefs.length !== 1 ? "s" : ""} · {active.length} active
          </p>
        </div>
        <Link
          href="/app/briefs/builder"
          className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-primary text-primary-foreground text-xs font-semibold hover:opacity-90 transition-opacity"
        >
          <PlusCircle className="w-3.5 h-3.5" /> New Brief
        </Link>
      </div>

      {/* Pipeline KPI strip */}
      <div className="grid grid-cols-4 gap-2.5">
        {statusCounts.map(({ status, count }) => (
          <div key={status} className="bg-card/60 border border-border/60 rounded-xl px-4 py-3">
            <div className="text-[9px] font-semibold uppercase tracking-[0.18em] text-muted-foreground/70 mb-1">{status}</div>
            <div className="text-2xl font-bold tabular-nums text-foreground">{count}</div>
          </div>
        ))}
      </div>

      {/* Active briefs */}
      {active.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-16 space-y-3">
          <Palette className="w-8 h-8 text-muted-foreground/40" />
          <p className="text-sm text-muted-foreground">No active briefs — start one from the Brief Builder.</p>
        </div>
      ) : (
        <div className="bg-card/60 border border-border/60 rounded-xl overflow-hidden">
          <div className="px-4 py-2.5 flex items-center justify-between border-b border-border/40">
            <div className="text-[9px] font-semibold uppercase tracking-[0.18em] text-muted-foreground/70">Active pipeline</div>
            <Link href="/app/briefs/builder" className="text-[11px] text-primary hover:text-primary/80 transition-colors flex items-center gap-1">
              All briefs <ArrowUpRight className="w-3 h-3" />
            </Link>
          </div>
          <div className="divide-y divide-border/30">
            {active.slice(0, 6).map(brief => (
              <Link
                key={brief.id}
                href={`/app/briefs/${brief.id}`}
                className="flex items-center gap-3 px-4 py-3 hover:bg-white/[0.02] transition-colors group"
              >
                <div className={cn("w-1 h-8 rounded-full shrink-0", STATUS_BAR[brief.status] ?? "bg-border")} />
                <div className="flex-1 min-w-0 space-y-0.5">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-semibold text-foreground truncate">{brief.title}</span>
                    <span className={cn(
                      "shrink-0 text-[10px] px-1.5 py-0.5 rounded border font-semibold leading-none",
                      STATUS_PILL[brief.status] ?? STATUS_PILL.Draft
                    )}>
                      {brief.status}
                    </span>
                  </div>
                  <p className="text-[11px] text-muted-foreground truncate">{brief.objective}</p>
                </div>
                <ArrowUpRight className="w-3.5 h-3.5 text-muted-foreground/40 group-hover:text-primary transition-colors shrink-0" />
              </Link>
            ))}
          </div>
        </div>
      )}

      {/* Recent creative library additions */}
      {recentAds.length > 0 && (
        <div className="bg-card/60 border border-border/60 rounded-xl overflow-hidden">
          <div className="px-4 py-2.5 flex items-center justify-between border-b border-border/40">
            <div className="text-[9px] font-semibold uppercase tracking-[0.18em] text-muted-foreground/70">Recent creative additions</div>
            <Link href="/app/creative-library" className="text-[11px] text-primary hover:text-primary/80 transition-colors flex items-center gap-1">
              Creative Library <ArrowUpRight className="w-3 h-3" />
            </Link>
          </div>
          <div className="divide-y divide-border/30">
            {recentAds.map(ad => (
              <div key={ad.id} className="flex items-center gap-3 px-4 py-3">
                <div className="w-8 h-8 rounded-lg bg-border/30 border border-border/40 flex items-center justify-center shrink-0">
                  <Image className="w-3.5 h-3.5 text-muted-foreground/50" />
                </div>
                <div className="flex-1 min-w-0 space-y-0.5">
                  <div className="text-xs font-semibold text-foreground truncate">{ad.name}</div>
                  <div className="text-[11px] text-muted-foreground">{ad.format} · P{ad.tier} tier</div>
                </div>
                <div className="text-[10px] text-muted-foreground/60 shrink-0 tabular-nums">
                  {ad.roas ? `ROAS ${ad.roas.toFixed(1)}` : "—"}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Quick links */}
      <div className="grid grid-cols-3 gap-2.5">
        {[
          { label: "Creative Library", desc: "All ads + creative DNA",     href: "/app/creative-library" },
          { label: "Briefs",           desc: "Brief builder + pipeline",   href: "/app/briefs/builder" },
          { label: "Produce",          desc: "AI creative generation",      href: "/app/creative/produce" },
        ].map(l => (
          <Link
            key={l.href}
            href={l.href}
            className="bg-card/60 border border-border/60 rounded-xl px-4 py-3 hover:border-primary/30 hover:bg-card transition-colors group"
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-foreground">{l.label}</span>
              <ArrowUpRight className="w-3.5 h-3.5 text-muted-foreground/50 group-hover:text-primary transition-colors" />
            </div>
            <p className="text-[11px] text-muted-foreground mt-0.5">{l.desc}</p>
          </Link>
        ))}
      </div>
    </div>
  );
}
