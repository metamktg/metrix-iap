// ═══════════════════════════════════════════════════════════════════════
// METRIX IAP — Reports execution hub (/app/reports)
// KPI strip, recent reports list, New Report CTA.
// ═══════════════════════════════════════════════════════════════════════

import { Link } from "wouter";
import { FileText, ArrowUpRight, PlusCircle, Calendar } from "lucide-react";
import { cn } from "@/lib/utils";
import { useCurrentWorkspace } from "@/contexts/WorkspaceContext";
import { REPORTS } from "@/lib/mock-data";

const STATUS_PILL: Record<string, string> = {
  Draft:     "bg-muted text-muted-foreground border-border/40",
  "In Review":"bg-yellow-400/10 text-yellow-400 border-yellow-400/20",
  Final:     "bg-emerald-500/10 text-emerald-400 border-emerald-500/20",
  Sent:      "bg-primary/10 text-primary border-primary/20",
};

const STATUS_BAR: Record<string, string> = {
  Draft:     "bg-border",
  "In Review":"bg-yellow-400",
  Final:     "bg-emerald-500",
  Sent:      "bg-primary",
};

export function ReportsHub() {
  const ws = useCurrentWorkspace();

  const reports = REPORTS
    .filter(r => r.workspace_id === ws.id)
    .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());

  const draftCount    = reports.filter(r => r.status === "Draft").length;
  const reviewCount   = reports.filter(r => r.status === "In Review").length;
  const finalCount    = reports.filter(r => r.status === "Final").length;
  const sentCount     = reports.filter(r => r.status === "Sent").length;
  const clientReady   = reports.filter(r => r.client_ready).length;

  return (
    <div className="flex-1 p-5 space-y-4 max-w-5xl">
      <div className="flex items-end justify-between gap-4">
        <div>
          <div className="text-[9px] font-semibold uppercase tracking-[0.18em] text-muted-foreground/60 mb-1">
            Reports · Execution
          </div>
          <h1 className="text-lg font-bold text-foreground tracking-tight">Reports</h1>
          <p className="text-xs text-muted-foreground mt-0.5">
            {ws.name} · {reports.length} report{reports.length !== 1 ? "s" : ""} · {clientReady} client-ready
          </p>
        </div>
        <Link
          href="/app/reports/new"
          className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-primary text-primary-foreground text-xs font-semibold hover:opacity-90 transition-opacity"
        >
          <PlusCircle className="w-3.5 h-3.5" /> New Report
        </Link>
      </div>

      {/* KPI strip */}
      <div className="grid grid-cols-4 gap-2.5">
        {[
          { label: "Draft",     value: draftCount,  color: "text-muted-foreground" },
          { label: "In Review", value: reviewCount,  color: "text-yellow-400" },
          { label: "Final",     value: finalCount,   color: "text-[hsl(var(--metrix-success))]" },
          { label: "Sent",      value: sentCount,    color: "text-primary" },
        ].map(kpi => (
          <div key={kpi.label} className="bg-card/60 border border-border/60 rounded-xl px-4 py-3">
            <div className="text-[9px] font-semibold uppercase tracking-[0.18em] text-muted-foreground/70 mb-1">{kpi.label}</div>
            <div className={cn("text-2xl font-bold tabular-nums", kpi.color)}>{kpi.value}</div>
          </div>
        ))}
      </div>

      {/* Recent reports */}
      {reports.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-20 space-y-3">
          <FileText className="w-8 h-8 text-muted-foreground/40" />
          <p className="text-sm text-muted-foreground">No reports yet — create the first one.</p>
          <Link href="/app/reports/new" className="px-3.5 py-2 rounded-lg bg-primary text-primary-foreground text-xs font-semibold hover:opacity-90 transition-opacity">
            New Report
          </Link>
        </div>
      ) : (
        <div className="bg-card/60 border border-border/60 rounded-xl overflow-hidden">
          <div className="px-4 py-2.5 flex items-center justify-between border-b border-border/40">
            <div className="text-[9px] font-semibold uppercase tracking-[0.18em] text-muted-foreground/70">Recent reports</div>
            <Link href="/app/reports/history" className="text-[11px] text-primary hover:text-primary/80 transition-colors flex items-center gap-1">
              Full history <ArrowUpRight className="w-3 h-3" />
            </Link>
          </div>
          <div className="divide-y divide-border/30">
            {reports.slice(0, 6).map(report => (
              <div key={report.id} className="flex items-center gap-3 px-4 py-3">
                <div className={cn("w-1 h-8 rounded-full shrink-0", STATUS_BAR[report.status] ?? "bg-border")} />
                <div className="flex-1 min-w-0 space-y-0.5">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-semibold text-foreground truncate">{report.title}</span>
                    <span className={cn(
                      "shrink-0 text-[10px] px-1.5 py-0.5 rounded border font-semibold leading-none",
                      STATUS_PILL[report.status] ?? STATUS_PILL.Draft
                    )}>
                      {report.status}
                    </span>
                    {report.client_ready && (
                      <span className="shrink-0 text-[9px] px-1.5 py-0.5 rounded border border-emerald-500/20 bg-emerald-500/10 text-emerald-400 font-semibold leading-none">
                        Client-ready
                      </span>
                    )}
                  </div>
                  <div className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
                    <Calendar className="w-2.5 h-2.5" />
                    {report.date_range_start} – {report.date_range_end}
                  </div>
                </div>
                <div className="text-[10px] text-muted-foreground/60 shrink-0">{report.created_at}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Quick links */}
      <div className="grid grid-cols-3 gap-2.5">
        {[
          { label: "Reports Overview", desc: "KPI summary + trends",     href: "/app/reports/overview" },
          { label: "Builder",          desc: "Create a new report",       href: "/app/reports/new" },
          { label: "Settings",         desc: "Templates + delivery",      href: "/app/reports/settings" },
        ].map(l => (
          <Link
            key={l.href}
            href={l.href}
            className="bg-card/60 border border-border/60 rounded-xl px-4 py-3 hover:border-primary/30 hover:bg-card transition-colors group"
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-foreground">{l.label}</span>
              <ArrowUpRight className="w-3.5 h-3.5 text-muted-foreground/50 group-hover:text-primary transition-colors" />
            </div>
            <p className="text-[11px] text-muted-foreground mt-0.5">{l.desc}</p>
          </Link>
        ))}
      </div>
    </div>
  );
}
