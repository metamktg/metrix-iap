// ═══════════════════════════════════════════════════════════════════════
// METRIX IAP — Creative › Produce (/app/creative/produce)
// AI-powered creative generation — premium feature.
// ═══════════════════════════════════════════════════════════════════════

import { useState } from "react";
import { Sparkles, Wand2, ArrowRight } from "lucide-react";
import { useCurrentWorkspace } from "@/contexts/WorkspaceContext";
import { useToast } from "@/hooks/use-toast";

const FORMATS = ["Static image", "Video (15s)", "Video (30s)", "Carousel", "Story"] as const;
const HOOKS   = ["Aspirational value", "Problem/agitation", "Social proof", "Curiosity gap", "Direct offer"] as const;

export function Produce() {
  const ws = useCurrentWorkspace();
  const { toast } = useToast();

  const [prompt, setPrompt]   = useState("");
  const [format, setFormat]   = useState<typeof FORMATS[number]>("Static image");
  const [hook, setHook]       = useState<typeof HOOKS[number]>("Aspirational value");
  const [loading, setLoading] = useState(false);

  function handleGenerate() {
    if (!prompt.trim()) return;
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      toast({
        title: "Waitlist registered",
        description: "You're on the list — we'll notify you when AI creative generation is available.",
      });
    }, 1400);
  }

  return (
    <div className="flex-1 p-5 max-w-3xl space-y-5">
      <div>
        <div className="text-[9px] font-semibold uppercase tracking-[0.18em] text-muted-foreground/60 mb-1">
          Creative · AI Generation
        </div>
        <h1 className="text-lg font-bold text-foreground tracking-tight">Produce</h1>
        <p className="text-xs text-muted-foreground mt-0.5">
          {ws.name} · AI-powered creative generation from your IAP variable stack
        </p>
      </div>

      {/* Feature intro */}
      <div className="flex items-start gap-3 bg-[hsl(var(--metrix-gold)/0.06)] border border-[hsl(var(--metrix-gold)/0.2)] rounded-xl px-4 py-3.5">
        <Sparkles className="w-4 h-4 text-[hsl(var(--metrix-gold))] shrink-0 mt-0.5" />
        <div className="min-w-0">
          <div className="text-xs font-semibold text-foreground mb-0.5">AI Creative Generation</div>
          <p className="text-[11px] text-muted-foreground leading-relaxed">
            Generate on-brief creative assets directly from your winning variable stacks. 
            Produce scores each output against your IAP signal before it leaves the platform — 
            so only validated creative enters your pipeline.
          </p>
        </div>
      </div>

      {/* Format selector */}
      <div className="bg-card/60 border border-border/60 rounded-xl px-4 py-3.5 space-y-3">
        <div className="text-[9px] font-semibold uppercase tracking-[0.18em] text-muted-foreground/70">Output format</div>
        <div className="flex flex-wrap gap-1.5">
          {FORMATS.map(f => (
            <button
              key={f}
              onClick={() => setFormat(f)}
              className={`px-2.5 py-1 rounded-md text-[11px] font-medium border transition-colors ${
                format === f
                  ? "bg-primary/15 text-primary border-primary/25"
                  : "text-muted-foreground border-border/40 hover:text-foreground hover:bg-white/5"
              }`}
            >
              {f}
            </button>
          ))}
        </div>
      </div>

      {/* Hook selector */}
      <div className="bg-card/60 border border-border/60 rounded-xl px-4 py-3.5 space-y-3">
        <div className="text-[9px] font-semibold uppercase tracking-[0.18em] text-muted-foreground/70">Hook variable</div>
        <div className="flex flex-wrap gap-1.5">
          {HOOKS.map(h => (
            <button
              key={h}
              onClick={() => setHook(h)}
              className={`px-2.5 py-1 rounded-md text-[11px] font-medium border transition-colors ${
                hook === h
                  ? "bg-primary/15 text-primary border-primary/25"
                  : "text-muted-foreground border-border/40 hover:text-foreground hover:bg-white/5"
              }`}
            >
              {h}
            </button>
          ))}
        </div>
      </div>

      {/* Prompt */}
      <div className="bg-card/60 border border-border/60 rounded-xl px-4 py-3.5 space-y-3">
        <div className="text-[9px] font-semibold uppercase tracking-[0.18em] text-muted-foreground/70">Creative brief prompt</div>
        <textarea
          value={prompt}
          onChange={e => setPrompt(e.target.value)}
          placeholder={`Describe the creative for ${ws.name} — the AI will use your winning variable stack to generate on-brief assets.`}
          rows={4}
          className="w-full bg-background border border-border/60 rounded-lg px-3 py-2 text-xs text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:border-primary/50 resize-none"
        />
        <div className="flex items-center justify-between">
          <p className="text-[11px] text-muted-foreground">
            Powered by your IAP signal · {format} · {hook} hook
          </p>
          <button
            onClick={handleGenerate}
            disabled={!prompt.trim() || loading}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-primary text-primary-foreground text-xs font-semibold hover:opacity-90 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
          >
            {loading ? (
              <><Wand2 className="w-3.5 h-3.5 animate-spin" /> Generating…</>
            ) : (
              <><Sparkles className="w-3.5 h-3.5" /> Generate <ArrowRight className="w-3.5 h-3.5" /></>
            )}
          </button>
        </div>
      </div>

      {/* Capability list */}
      <div className="bg-card/60 border border-border/60 rounded-xl px-4 py-3.5 space-y-2.5">
        <div className="text-[9px] font-semibold uppercase tracking-[0.18em] text-muted-foreground/70">What Produce can do</div>
        <div className="grid grid-cols-2 gap-2">
          {[
            "Generate copy variations from winning hooks",
            "Score outputs against your IAP signal",
            "Export directly to brief pipeline",
            "Match tone variables from your MST matrix",
            "Batch generate across multiple formats",
            "Flag creative that contradicts the control",
          ].map(cap => (
            <div key={cap} className="flex items-start gap-2 text-[11px] text-muted-foreground">
              <Sparkles className="w-3 h-3 text-[hsl(var(--metrix-gold))] shrink-0 mt-0.5" />
              {cap}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
