import { useState } from "react";
import { useLocation } from "wouter";
import { cn } from "@/lib/utils";
import {
  Compass, Snowflake, Thermometer, Flame, Repeat,
  AlertTriangle, Layers, ArrowRight, Zap,
} from "lucide-react";
import { useWorkspace } from "@/contexts/WorkspaceContext";
import type { ConfidenceLabel } from "@/lib/types";
import {
  FUNNEL_STAGES, STAGE_META, getStrategyCards, getCoverageGaps,
  type FunnelStage, type StrategyStatus, type StrategyCard, type CoverageGap,
} from "@/lib/mock/strategy-map";

// ─── Chip helpers ──────────────────────────────────────────────────────

function ConfidenceChip({ c }: { c: ConfidenceLabel }) {
  const map: Record<ConfidenceLabel, string> = {
    high: "bg-emerald-500/10 border-emerald-500/20 text-emerald-400",
    medium: "bg-yellow-400/10 border-yellow-400/20 text-yellow-400",
    validation_required: "bg-orange-400/10 border-orange-400/20 text-orange-400",
    insufficient: "bg-muted/50 border-border/40 text-muted-foreground",
  };
  const labels: Record<ConfidenceLabel, string> = {
    high: "High", medium: "Med", validation_required: "Validate", insufficient: "Insuff.",
  };
  return (
    <span className={cn("text-[9px] px-1.5 py-0.5 rounded border font-semibold leading-none", map[c])}>
      {labels[c]}
    </span>
  );
}

const STATUS_STYLES: Record<StrategyStatus, string> = {
  Live: "text-emerald-400 bg-emerald-500/10 border-emerald-500/20",
  Testing: "text-primary bg-primary/10 border-primary/20",
  Planned: "text-blue-400 bg-blue-500/10 border-blue-500/20",
  Paused: "text-red-400 bg-red-500/10 border-red-500/20",
};

function StatusChip({ s }: { s: StrategyStatus }) {
  return (
    <span className={cn("text-[9px] px-1.5 py-0.5 rounded border font-semibold leading-none", STATUS_STYLES[s])}>
      {s}
    </span>
  );
}

const STAGE_ICONS: Record<FunnelStage, React.ComponentType<{ className?: string }>> = {
  Cold: Snowflake,
  Warm: Thermometer,
  Hot: Flame,
  Retention: Repeat,
};

const STAGE_ACCENT: Record<FunnelStage, string> = {
  Cold: "text-[hsl(var(--metrix-cyan))]",
  Warm: "text-yellow-400",
  Hot: "text-orange-400",
  Retention: "text-primary",
};

const SEVERITY_STYLES: Record<CoverageGap["severity"], string> = {
  high: "border-red-500/30 bg-red-500/5",
  medium: "border-orange-400/30 bg-orange-400/5",
  low: "border-yellow-400/25 bg-yellow-400/5",
};

const SEVERITY_TEXT: Record<CoverageGap["severity"], string> = {
  high: "text-red-400",
  medium: "text-orange-400",
  low: "text-yellow-400",
};

const money = (n: number) => n.toLocaleString("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 });

// ─── Strategy Card ─────────────────────────────────────────────────────

function StrategyCardView({ card }: { card: StrategyCard }) {
  const [, navigate] = useLocation();
  return (
    <button
      onClick={() => navigate("/app/creative-library")}
      className={cn(
        "w-full text-left bg-card border rounded-xl px-3 py-3 space-y-2 transition-all group",
        card.status === "Paused"
          ? "border-red-500/20 hover:border-red-500/40"
          : "border-border/60 hover:border-primary/40 hover:bg-primary/[0.02]"
      )}
    >
      <div className="flex items-start justify-between gap-2">
        <p className="text-[11px] font-semibold text-foreground leading-snug">{card.angle}</p>
        <ArrowRight className="w-3 h-3 text-muted-foreground/30 group-hover:text-primary transition-colors shrink-0 mt-0.5" />
      </div>
      <p className="text-[10px] text-muted-foreground">{card.audience}</p>
      <div className="flex items-center gap-1.5 flex-wrap">
        <StatusChip s={card.status} />
        <ConfidenceChip c={card.confidence} />
      </div>
      <div className="flex items-center gap-1 flex-wrap pt-0.5">
        <Layers className="w-2.5 h-2.5 text-muted-foreground/50" />
        {card.linked_concepts.map((c) => (
          <span key={c} className="text-[9px] font-mono px-1 py-0.5 rounded border border-border/40 bg-muted/30 text-muted-foreground">
            {c}
          </span>
        ))}
      </div>
      <div className="flex items-center justify-between border-t border-border/20 pt-2 text-[10px]">
        <span className="text-muted-foreground/70">{money(card.spend_usd)}</span>
        <span className="font-mono font-semibold text-foreground/80">{card.primary_metric}</span>
      </div>
    </button>
  );
}

// ─── StrategyMap ───────────────────────────────────────────────────────

export function StrategyMap() {
  const { currentWorkspace } = useWorkspace();
  const [statusFilter, setStatusFilter] = useState<"All" | StrategyStatus>("All");

  const wsId = currentWorkspace.id;
  const allCards = getStrategyCards(wsId);
  const gaps = getCoverageGaps(wsId);

  const filteredCards =
    statusFilter === "All" ? allCards : allCards.filter((c) => c.status === statusFilter);

  const liveCount = allCards.filter((c) => c.status === "Live").length;
  const testingCount = allCards.filter((c) => c.status === "Testing").length;
  const pausedCount = allCards.filter((c) => c.status === "Paused").length;

  const STATUS_TABS: ("All" | StrategyStatus)[] = ["All", "Live", "Testing", "Planned", "Paused"];

  return (
    <div className="h-full overflow-y-auto">
      <div className="max-w-6xl mx-auto px-6 py-5 space-y-4">

        {/* Header */}
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-primary/10 border border-primary/20 flex items-center justify-center">
              <Compass className="w-4 h-4 text-primary" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-foreground tracking-tight">Strategy Map</h1>
              <p className="text-xs text-muted-foreground mt-0.5">
                {currentWorkspace.name} — funnel coverage across {allCards.length} angles
              </p>
            </div>
          </div>
          <button
            onClick={() => setStatusFilter("All")}
            className="text-[11px] text-white bg-primary hover:bg-primary/90 px-3 py-1.5 rounded-lg font-medium transition-all flex items-center gap-1.5"
          >
            <Zap className="w-3 h-3" /> Reset view
          </button>
        </div>

        {/* Summary strip */}
        <div className="grid grid-cols-4 gap-3">
          {[
            { label: "Live Angles", value: liveCount, color: "text-emerald-400" },
            { label: "In Testing", value: testingCount, color: "text-primary" },
            { label: "Paused", value: pausedCount, color: "text-red-400" },
            { label: "Coverage Gaps", value: gaps.length, color: "text-orange-400" },
          ].map((m) => (
            <div key={m.label} className="bg-card border border-border/60 rounded-xl px-4 py-3">
              <div className={cn("text-xl font-bold leading-none", m.color)}>{m.value}</div>
              <div className="text-[10px] font-medium text-muted-foreground mt-1.5">{m.label}</div>
            </div>
          ))}
        </div>

        {/* Status filter */}
        <div className="flex items-center gap-2 flex-wrap">
          <span className="text-[10px] text-muted-foreground font-medium">Status:</span>
          {STATUS_TABS.map((s) => (
            <button
              key={s}
              onClick={() => setStatusFilter(s)}
              className={cn(
                "px-3 py-1.5 rounded-full text-[11px] font-medium border transition-all",
                statusFilter === s
                  ? "bg-primary/15 border-primary/40 text-primary"
                  : "bg-transparent border-border/50 text-muted-foreground hover:border-border hover:text-foreground"
              )}
            >
              {s === "All" ? "All Statuses" : s}
            </button>
          ))}
        </div>

        {/* Funnel columns */}
        <div className="grid grid-cols-4 gap-3 items-start">
          {FUNNEL_STAGES.map((stage) => {
            const Icon = STAGE_ICONS[stage];
            const stageCards = filteredCards.filter((c) => c.stage === stage);
            const stageGaps = gaps.filter((g) => g.stage === stage);
            const isEmpty = stageCards.length === 0;
            return (
              <div key={stage} className="space-y-2.5">
                {/* Column header */}
                <div className="bg-card/60 border border-border/60 rounded-xl px-3 py-2.5">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1.5">
                      <Icon className={cn("w-3.5 h-3.5", STAGE_ACCENT[stage])} />
                      <span className="text-xs font-bold text-foreground">{STAGE_META[stage].label}</span>
                    </div>
                    <span className="text-[10px] font-mono text-muted-foreground/70">{stageCards.length}</span>
                  </div>
                  <div className="text-[9px] font-semibold uppercase tracking-[0.16em] text-muted-foreground/60 mt-1">
                    {STAGE_META[stage].sub}
                  </div>
                </div>

                {/* Cards */}
                {stageCards.map((card) => (
                  <StrategyCardView key={card.id} card={card} />
                ))}

                {/* Empty / gap indicator */}
                {isEmpty && (
                  <div className="border border-dashed border-border/50 rounded-xl px-3 py-5 text-center">
                    <p className="text-[10px] text-muted-foreground/60">
                      {statusFilter === "All" ? "No coverage" : "No matching angles"}
                    </p>
                  </div>
                )}

                {/* Inline gap chips for the stage */}
                {stageGaps.map((g) => (
                  <div
                    key={g.id}
                    className={cn("border rounded-xl px-3 py-2 flex items-start gap-1.5", SEVERITY_STYLES[g.severity])}
                  >
                    <AlertTriangle className={cn("w-3 h-3 shrink-0 mt-0.5", SEVERITY_TEXT[g.severity])} />
                    <div>
                      <p className={cn("text-[10px] font-semibold", SEVERITY_TEXT[g.severity])}>
                        Gap · {g.audience}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            );
          })}
        </div>

        {/* Coverage gaps detail */}
        {gaps.length > 0 && (
          <div className="space-y-2">
            <div className="flex items-center gap-1.5">
              <AlertTriangle className="w-3 h-3 text-orange-400" />
              <span className="text-[9px] font-semibold uppercase tracking-[0.18em] text-muted-foreground/70">
                Coverage Gaps
              </span>
            </div>
            <div className="grid grid-cols-2 gap-3">
              {gaps.map((g) => (
                <div
                  key={g.id}
                  className={cn("border rounded-xl px-4 py-3 space-y-1.5", SEVERITY_STYLES[g.severity])}
                >
                  <div className="flex items-center gap-2">
                    <span className={cn("text-[9px] px-1.5 py-0.5 rounded border font-bold leading-none uppercase tracking-wide", SEVERITY_STYLES[g.severity], SEVERITY_TEXT[g.severity])}>
                      {g.severity}
                    </span>
                    <span className="text-[11px] font-semibold text-foreground">{g.stage}</span>
                    <span className="text-muted-foreground/40 text-[10px]">·</span>
                    <span className="text-[11px] text-muted-foreground">{g.audience}</span>
                  </div>
                  <p className="text-[11px] text-muted-foreground leading-relaxed">{g.reason}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {allCards.length === 0 && (
          <div className="flex flex-col items-center justify-center py-20 space-y-3">
            <Compass className="w-8 h-8 text-muted-foreground/40" />
            <p className="text-sm text-muted-foreground">No strategy map for this workspace.</p>
            <p className="text-xs text-muted-foreground/60">Strategy angles are seeded from IAP runs.</p>
          </div>
        )}

      </div>
    </div>
  );
}
