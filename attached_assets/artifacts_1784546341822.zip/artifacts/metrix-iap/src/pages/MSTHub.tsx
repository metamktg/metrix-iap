// ═══════════════════════════════════════════════════════════════════════
// METRIX IAP — MST execution hub (/app/mst)
// Active matrix sessions, recent crossmap results, tool links.
// ═══════════════════════════════════════════════════════════════════════

import { Link } from "wouter";
import { Layers, ArrowUpRight, PlusCircle, Trophy } from "lucide-react";
import { cn } from "@/lib/utils";
import { useCurrentWorkspace } from "@/contexts/WorkspaceContext";
import { CREATIVE_CONCEPTS, MST_MATRICES } from "@/lib/mock-data";

// Mock MST session statuses
const SESSION_STATUS = ["Active", "Complete", "Archived"] as const;
type SessionStatus = typeof SESSION_STATUS[number];

const STATUS_PILL: Record<SessionStatus, string> = {
  Active:   "bg-primary/10 text-primary border-primary/20",
  Complete: "bg-emerald-500/10 text-emerald-400 border-emerald-500/20",
  Archived: "bg-muted text-muted-foreground/60 border-border/30",
};

export function MSTHub() {
  const ws = useCurrentWorkspace();

  const matrices = MST_MATRICES.slice(0, 5);
  const concepts = CREATIVE_CONCEPTS.filter(c => c.workspace_id === ws.id);
  const winners = concepts.filter(c => c.tier === 1).length;
  const atRisk  = concepts.filter(c => c.tier === 4).length;

  // Derive mock sessions
  const sessions = matrices.slice(0, 4).map((m, i) => ({
    id: m.id,
    name: m.name,
    status: (i === 0 ? "Active" : i < 3 ? "Complete" : "Archived") as SessionStatus,
    cells: m.cells.length,
    date: m.created_at.slice(0, 10),
  }));

  return (
    <div className="flex-1 p-5 space-y-4 max-w-5xl">
      <div className="flex items-end justify-between gap-4">
        <div>
          <div className="text-[9px] font-semibold uppercase tracking-[0.18em] text-muted-foreground/60 mb-1">
            MST · Matrix Scaling
          </div>
          <h1 className="text-lg font-bold text-foreground tracking-tight">MST</h1>
          <p className="text-xs text-muted-foreground mt-0.5">
            {ws.name} · {sessions.length} session{sessions.length !== 1 ? "s" : ""} · {concepts.length} concept{concepts.length !== 1 ? "s" : ""}
          </p>
        </div>
        <Link
          href="/app/mst/variable-map"
          className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-primary text-primary-foreground text-xs font-semibold hover:opacity-90 transition-opacity"
        >
          <PlusCircle className="w-3.5 h-3.5" /> New MST Session
        </Link>
      </div>

      {/* KPI strip */}
      <div className="grid grid-cols-4 gap-2.5">
        {[
          { label: "Active sessions", value: sessions.filter(s => s.status === "Active").length, color: "text-primary" },
          { label: "Concepts tested", value: concepts.length, color: "text-foreground" },
          { label: "Winning paths",   value: winners,         color: "text-[hsl(var(--metrix-success))]" },
          { label: "At risk",         value: atRisk,          color: "text-destructive" },
        ].map(kpi => (
          <div key={kpi.label} className="bg-card/60 border border-border/60 rounded-xl px-4 py-3">
            <div className="text-[9px] font-semibold uppercase tracking-[0.18em] text-muted-foreground/70 mb-1">{kpi.label}</div>
            <div className={cn("text-2xl font-bold tabular-nums", kpi.color)}>{kpi.value}</div>
          </div>
        ))}
      </div>

      {/* Sessions list */}
      {sessions.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-20 space-y-3">
          <Layers className="w-8 h-8 text-muted-foreground/40" />
          <p className="text-sm text-muted-foreground">No MST sessions yet — start with the Variable Map.</p>
        </div>
      ) : (
        <div className="bg-card/60 border border-border/60 rounded-xl overflow-hidden">
          <div className="px-4 py-2.5 flex items-center justify-between border-b border-border/40">
            <div className="text-[9px] font-semibold uppercase tracking-[0.18em] text-muted-foreground/70">Matrix sessions</div>
            <Link href="/app/mst/history" className="text-[11px] text-primary hover:text-primary/80 transition-colors flex items-center gap-1">
              Full history <ArrowUpRight className="w-3 h-3" />
            </Link>
          </div>
          <div className="divide-y divide-border/30">
            {sessions.map(s => (
              <div key={s.id} className="flex items-center gap-3 px-4 py-3">
                <div className={cn(
                  "w-1 h-8 rounded-full shrink-0",
                  s.status === "Active" ? "bg-primary" : s.status === "Complete" ? "bg-emerald-500" : "bg-border"
                )} />
                <div className="flex-1 min-w-0 space-y-0.5">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-semibold text-foreground truncate">{s.name}</span>
                    <span className={cn(
                      "shrink-0 text-[10px] px-1.5 py-0.5 rounded border font-semibold leading-none",
                      STATUS_PILL[s.status]
                    )}>
                      {s.status}
                    </span>
                  </div>
                  <div className="text-[11px] text-muted-foreground">{s.cells} cells tested</div>
                </div>
                <div className="text-[10px] text-muted-foreground/60 shrink-0">{s.date}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Winning path callout */}
      {winners > 0 && (
        <div className="flex items-start gap-3 px-4 py-3 rounded-xl bg-[hsl(var(--metrix-gold)/0.06)] border border-[hsl(var(--metrix-gold)/0.2)]">
          <Trophy className="w-3.5 h-3.5 text-[hsl(var(--metrix-gold))] shrink-0 mt-0.5" />
          <p className="text-[11px] text-muted-foreground leading-relaxed">
            <span className="text-foreground font-semibold">{winners} winning path{winners !== 1 ? "s" : ""}</span> identified — view the crossmap to see transferable variable stacks.
          </p>
          <Link href="/app/mst/crossmap" className="text-[11px] text-[hsl(var(--metrix-gold))] hover:opacity-80 transition-opacity whitespace-nowrap">
            View crossmap →
          </Link>
        </div>
      )}

      {/* Tool jump-offs */}
      <div className="grid grid-cols-3 gap-2.5">
        {[
          { label: "Variable Map",  desc: "2D variable lineage grid",   href: "/app/mst/variable-map" },
          { label: "Crossmap",      desc: "Cross-concept performance",  href: "/app/mst/crossmap" },
          { label: "Creative Scan", desc: "Variable pattern analysis",  href: "/app/mst/creative-scan" },
        ].map(l => (
          <Link
            key={l.href}
            href={l.href}
            className="bg-card/60 border border-border/60 rounded-xl px-4 py-3 hover:border-primary/30 hover:bg-card transition-colors group"
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-foreground">{l.label}</span>
              <ArrowUpRight className="w-3.5 h-3.5 text-muted-foreground/50 group-hover:text-primary transition-colors" />
            </div>
            <p className="text-[11px] text-muted-foreground mt-0.5">{l.desc}</p>
          </Link>
        ))}
      </div>
    </div>
  );
}
