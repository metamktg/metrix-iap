// ═══════════════════════════════════════════════════════════════════════
// METRIX IAP — Analysis › Overview
// Executive read of the latest completed run for the selected account:
// diagnosis, constraint, opportunity, next action, and quick links.
// ═══════════════════════════════════════════════════════════════════════

import { Link } from "wouter";
import { BarChart3, ArrowUpRight, Target, TrendingUp, ShieldAlert } from "lucide-react";
import { cn } from "@/lib/utils";
import { useCurrentWorkspace } from "@/contexts/WorkspaceContext";
import { ANALYSIS_RUNS } from "@/lib/mock-data";

export function AnalysisOverview() {
  const ws = useCurrentWorkspace();

  const runs = ANALYSIS_RUNS
    .filter(r => r.workspace_id === ws.id)
    .sort((a, b) => b.created_at.localeCompare(a.created_at));
  const latest = runs.find(r => r.status === "Completed") ?? runs[0];

  if (!latest) {
    return (
      <div className="flex-1 p-5">
        <div className="flex flex-col items-center justify-center py-24 text-center">
          <BarChart3 className="w-8 h-8 text-muted-foreground/40 mb-3" />
          <h2 className="text-base font-semibold text-foreground mb-1">No analysis yet</h2>
          <p className="text-sm text-muted-foreground mb-5 max-w-sm">
            Run your first IAP analysis on {ws.name} to generate the executive read.
          </p>
          <Link
            href="/app/analysis/new-run"
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-primary text-primary-foreground text-xs font-semibold hover:opacity-90 transition-opacity"
            data-testid="link-new-run"
          >
            New IAP Run <ArrowUpRight className="w-3.5 h-3.5" />
          </Link>
        </div>
      </div>
    );
  }

  const openDecisions = latest.decision_feed.filter(d => d.status === "Open").length;
  const openRecs = latest.recommendations.filter(r => r.status === "Open").length;
  const priorityFindings = latest.findings.filter(f => f.is_priority_read);

  return (
    <div className="flex-1 p-5 space-y-4 max-w-5xl">
      <div className="flex items-end justify-between gap-4">
        <div>
          <h1 className="text-lg font-bold text-foreground tracking-tight">Analysis Overview</h1>
          <p className="text-xs text-muted-foreground mt-0.5">
            {ws.name} · latest run {latest.id.toUpperCase()} · {latest.objective} · {latest.depth}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Link
            href={`/app/analysis/library/${latest.id}`}
            className="text-xs text-primary hover:text-primary/80 transition-colors inline-flex items-center gap-1"
            data-testid="link-open-run"
          >
            Full run <ArrowUpRight className="w-3 h-3" />
          </Link>
          <Link
            href="/app/analysis/new-run"
            className="px-3 py-1.5 rounded-lg bg-primary text-primary-foreground text-xs font-semibold hover:opacity-90 transition-opacity"
            data-testid="link-new-run"
          >
            New Run
          </Link>
        </div>
      </div>

      {/* KPI strip */}
      <div className="grid grid-cols-4 gap-2.5">
        {[
          { label: "Confidence", value: `${latest.confidence_score}/100` },
          { label: "Signal quality", value: `${latest.signal_quality.overall}/100` },
          { label: "Open decisions", value: openDecisions },
          { label: "Open recommendations", value: openRecs },
        ].map(kpi => (
          <div key={kpi.label} className="bg-card/60 border border-border/60 rounded-xl px-4 py-3">
            <div className="text-[9px] font-semibold uppercase tracking-[0.18em] text-muted-foreground/70 mb-1">{kpi.label}</div>
            <div className="text-2xl font-bold tabular-nums text-foreground">{kpi.value}</div>
          </div>
        ))}
      </div>

      {/* Priority read */}
      <div className="bg-card/60 border border-primary/25 rounded-xl px-4 py-3.5">
        <div className="text-[9px] font-semibold uppercase tracking-[0.18em] text-primary mb-1.5">Priority read</div>
        <p className="text-sm text-foreground leading-relaxed">{latest.priority_read}</p>
        <p className="text-xs text-muted-foreground mt-2 leading-relaxed">{latest.executive_diagnosis}</p>
      </div>

      {/* Constraint / Opportunity / Next action */}
      <div className="grid grid-cols-3 gap-2.5">
        <div className="bg-card/60 border border-border/60 rounded-xl px-4 py-3.5">
          <div className="flex items-center gap-1.5 text-[9px] font-semibold uppercase tracking-[0.18em] text-destructive mb-1.5">
            <ShieldAlert className="w-3 h-3" /> Primary constraint
          </div>
          <p className="text-xs text-foreground/90 leading-relaxed">{latest.primary_constraint}</p>
        </div>
        <div className="bg-card/60 border border-border/60 rounded-xl px-4 py-3.5">
          <div className="flex items-center gap-1.5 text-[9px] font-semibold uppercase tracking-[0.18em] text-[hsl(var(--metrix-success))] mb-1.5">
            <TrendingUp className="w-3 h-3" /> Primary opportunity
          </div>
          <p className="text-xs text-foreground/90 leading-relaxed">{latest.primary_opportunity}</p>
        </div>
        <div className="bg-card/60 border border-border/60 rounded-xl px-4 py-3.5">
          <div className="flex items-center gap-1.5 text-[9px] font-semibold uppercase tracking-[0.18em] text-[hsl(var(--metrix-gold))] mb-1.5">
            <Target className="w-3 h-3" /> Next action
          </div>
          <p className="text-xs text-foreground/90 leading-relaxed">{latest.recommended_next_action}</p>
        </div>
      </div>

      {/* Priority findings */}
      {priorityFindings.length > 0 && (
        <div className="bg-card/60 border border-border/60 rounded-xl px-4 py-3.5">
          <div className="flex items-center justify-between mb-2.5">
            <div className="text-[9px] font-semibold uppercase tracking-[0.18em] text-muted-foreground/70">Priority findings</div>
            <Link href={`/app/analysis/library/${latest.id}`} className="text-[11px] text-primary hover:text-primary/80 transition-colors">
              All findings
            </Link>
          </div>
          <div className="space-y-2.5">
            {priorityFindings.slice(0, 4).map(f => (
              <div key={f.id} className="flex items-start gap-2.5" data-testid={`finding-${f.id}`}>
                <span className={cn(
                  "shrink-0 mt-0.5 text-[10px] font-mono px-1.5 py-0.5 rounded border leading-none",
                  f.confidence === "high"
                    ? "text-[hsl(var(--metrix-success))] border-[hsl(var(--metrix-success)/0.3)]"
                    : "text-yellow-400 border-yellow-400/30"
                )}>
                  {f.confidence}
                </span>
                <div className="min-w-0">
                  <div className="text-xs font-semibold text-foreground">{f.title}</div>
                  <p className="text-xs text-muted-foreground mt-0.5 leading-relaxed line-clamp-2">{f.body}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Quick links */}
      <div className="grid grid-cols-3 gap-2.5">
        {[
          { label: "IAP Library", desc: `${runs.length} run${runs.length === 1 ? "" : "s"} on this account`, href: "/app/analysis/library" },
          { label: "Benchmarks", desc: "Category benchmark memory", href: "/app/analysis/benchmarks" },
          { label: "Budget Insight", desc: "Spend allocation read", href: "/app/analysis/budget" },
        ].map(l => (
          <Link
            key={l.href}
            href={l.href}
            className="bg-card/60 border border-border/60 rounded-xl px-4 py-3 hover:border-primary/30 hover:bg-card transition-colors group"
            data-testid={`quicklink-${l.label.toLowerCase().replace(/ /g, "-")}`}
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-foreground">{l.label}</span>
              <ArrowUpRight className="w-3.5 h-3.5 text-muted-foreground/50 group-hover:text-primary transition-colors" />
            </div>
            <p className="text-[11px] text-muted-foreground mt-0.5">{l.desc}</p>
          </Link>
        ))}
      </div>
    </div>
  );
}
