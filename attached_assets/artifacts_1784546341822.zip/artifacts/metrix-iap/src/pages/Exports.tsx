import { useState } from "react";
import { useLocation } from "wouter";
import { cn } from "@/lib/utils";
import {
  Download, FileText, Table2, Presentation, Mail, Clock,
  CheckCircle2, Loader2, AlertCircle, Plus, ChevronRight,
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import {
  EXPORT_RECORDS, EXPORT_DESTINATIONS,
  type ExportFormat, type ExportStatus, type ExportRecord, type ExportDestination,
} from "@/lib/mock/agent-exports";

// ─── Format + status helpers ──────────────────────────────────────────

const FORMAT_ICON: Record<ExportFormat, React.ComponentType<{ className?: string }>> = {
  PDF: FileText,
  CSV: Table2,
  Slides: Presentation,
};

const FORMAT_STYLE: Record<ExportFormat, string> = {
  PDF: "text-red-400 bg-red-500/10 border-red-500/20",
  CSV: "text-emerald-400 bg-emerald-500/10 border-emerald-500/20",
  Slides: "text-[hsl(var(--metrix-gold))] bg-[hsl(var(--metrix-gold)/0.1)] border-[hsl(var(--metrix-gold)/0.2)]",
};

function FormatChip({ f }: { f: ExportFormat }) {
  const Icon = FORMAT_ICON[f];
  return (
    <span className={cn("inline-flex items-center gap-1 text-[9px] px-1.5 py-0.5 rounded border font-semibold leading-none", FORMAT_STYLE[f])}>
      <Icon className="w-2.5 h-2.5" /> {f}
    </span>
  );
}

function StatusChip({ s }: { s: ExportStatus }) {
  if (s === "Ready") {
    return (
      <span className="inline-flex items-center gap-1 text-[9px] px-1.5 py-0.5 rounded border font-semibold leading-none text-emerald-400 bg-emerald-500/10 border-emerald-500/20">
        <CheckCircle2 className="w-2.5 h-2.5" /> Ready
      </span>
    );
  }
  if (s === "Processing") {
    return (
      <span className="inline-flex items-center gap-1 text-[9px] px-1.5 py-0.5 rounded border font-semibold leading-none text-primary bg-primary/10 border-primary/20">
        <Loader2 className="w-2.5 h-2.5 animate-spin" /> Processing
      </span>
    );
  }
  return (
    <span className="inline-flex items-center gap-1 text-[9px] px-1.5 py-0.5 rounded border font-semibold leading-none text-red-400 bg-red-500/10 border-red-500/20">
      <AlertCircle className="w-2.5 h-2.5" /> Failed
    </span>
  );
}

// ─── Section label ────────────────────────────────────────────────────

function SectionLabel({ children }: { children: React.ReactNode }) {
  return (
    <span className="text-[9px] font-semibold uppercase tracking-[0.18em] text-muted-foreground/70">
      {children}
    </span>
  );
}

// ─── Destination row ──────────────────────────────────────────────────

function DestinationRow({ dest }: { dest: ExportDestination }) {
  const [active, setActive] = useState(dest.active);
  const { toast } = useToast();
  return (
    <div className="flex items-center gap-3 px-4 py-3 border-t border-border/20 first:border-t-0">
      <div className={cn(
        "w-8 h-8 rounded-lg border flex items-center justify-center shrink-0",
        active ? "border-primary/30 bg-primary/5 text-primary" : "border-border/40 bg-muted/20 text-muted-foreground"
      )}>
        <Mail className="w-3.5 h-3.5" />
      </div>
      <div className="flex-1 min-w-0">
        <div className="text-[11px] font-medium text-foreground truncate">{dest.label}</div>
        <div className="text-[10px] text-muted-foreground truncate">
          {dest.recipients.join(", ")}
        </div>
      </div>
      <div className="flex items-center gap-2 shrink-0">
        <FormatChip f={dest.format} />
        <span className="text-[10px] text-muted-foreground border border-border/40 rounded px-1.5 py-0.5">{dest.cadence}</span>
      </div>
      <div className="w-28 shrink-0 text-right">
        <div className="text-[10px] text-foreground flex items-center justify-end gap-1">
          <Clock className="w-2.5 h-2.5 text-muted-foreground" /> {dest.next_send}
        </div>
        <div className="text-[9px] text-muted-foreground/60">last {dest.last_sent}</div>
      </div>
      <button
        onClick={() => {
          setActive(v => !v);
          toast({
            title: active ? "Schedule paused" : "Schedule resumed",
            description: dest.label,
          });
        }}
        className={cn(
          "relative w-9 h-5 rounded-full transition-colors shrink-0",
          active ? "bg-emerald-500/80" : "bg-border/60"
        )}
      >
        <span className={cn(
          "absolute top-0.5 w-4 h-4 rounded-full bg-white transition-all",
          active ? "left-4" : "left-0.5"
        )} />
      </button>
    </div>
  );
}

// ─── Exports ──────────────────────────────────────────────────────────

export function Exports() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [formatFilter, setFormatFilter] = useState<"All" | ExportFormat>("All");

  const filtered = formatFilter === "All"
    ? EXPORT_RECORDS
    : EXPORT_RECORDS.filter(r => r.format === formatFilter);

  const ready = EXPORT_RECORDS.filter(r => r.status === "Ready").length;
  const totalDownloads = EXPORT_RECORDS.reduce((s, r) => s + r.downloads, 0);

  function reDownload(rec: ExportRecord) {
    if (rec.status !== "Ready") {
      toast({ title: "Not available", description: `${rec.name} is ${rec.status.toLowerCase()}.` });
      return;
    }
    toast({ title: "Download started", description: rec.name });
  }

  const filters: Array<"All" | ExportFormat> = ["All", "PDF", "CSV", "Slides"];

  return (
    <div className="h-full overflow-y-auto">
      <div className="max-w-6xl mx-auto px-6 py-5 space-y-4">

        {/* Header */}
        <div className="flex items-start justify-between">
          <div>
            <div className="text-[9px] font-semibold uppercase tracking-[0.18em] text-muted-foreground/60 mb-1">
              Delivery
            </div>
            <h1 className="text-xl font-bold text-foreground tracking-tight">Exports</h1>
            <p className="text-xs text-muted-foreground mt-0.5">
              {EXPORT_RECORDS.length} exports · {ready} ready · {totalDownloads} downloads
            </p>
          </div>
          <button
            onClick={() => navigate("/app/reports/new")}
            className="flex items-center gap-1.5 text-[11px] text-white bg-primary hover:bg-primary/90 px-3 py-1.5 rounded-lg font-medium transition-all"
          >
            <Plus className="w-3 h-3" /> New export
          </button>
        </div>

        {/* KPI row */}
        <div className="grid grid-cols-4 gap-3">
          {[
            { label: "Total Exports", value: EXPORT_RECORDS.length },
            { label: "Ready", value: ready },
            { label: "Scheduled Sends", value: EXPORT_DESTINATIONS.filter(d => d.active).length },
            { label: "Downloads", value: totalDownloads },
          ].map(k => (
            <div key={k.label} className="bg-card border border-border/60 rounded-xl px-4 py-3">
              <div className="text-xl font-bold text-foreground">{k.value}</div>
              <div className="text-[10px] font-medium text-muted-foreground mt-1">{k.label}</div>
            </div>
          ))}
        </div>

        {/* Format filter */}
        <div className="flex items-center gap-2">
          {filters.map(f => (
            <button
              key={f}
              onClick={() => setFormatFilter(f)}
              className={cn(
                "px-3 py-1.5 rounded-full text-[11px] font-medium border transition-all",
                formatFilter === f
                  ? "bg-primary/15 border-primary/40 text-primary"
                  : "bg-transparent border-border/50 text-muted-foreground hover:border-border hover:text-foreground"
              )}
            >
              {f === "All" ? "All formats" : f}
            </button>
          ))}
          <span className="ml-auto text-[11px] text-muted-foreground">{filtered.length} shown</span>
        </div>

        {/* Past exports table */}
        <div className="bg-card border border-border/60 rounded-xl overflow-hidden">
          {/* Column header */}
          <div className="flex items-center gap-3 px-4 py-2.5 border-b border-border/40 bg-muted/10">
            <span className="flex-1 min-w-0"><SectionLabel>Export</SectionLabel></span>
            <span className="w-20 shrink-0"><SectionLabel>Type</SectionLabel></span>
            <span className="w-40 shrink-0"><SectionLabel>Source Report</SectionLabel></span>
            <span className="w-24 shrink-0"><SectionLabel>Date</SectionLabel></span>
            <span className="w-16 shrink-0 text-right"><SectionLabel>Size</SectionLabel></span>
            <span className="w-24 shrink-0"><SectionLabel>Status</SectionLabel></span>
            <span className="w-9 shrink-0" />
          </div>

          {filtered.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-16 space-y-2">
              <Download className="w-7 h-7 text-muted-foreground/40" />
              <p className="text-sm text-muted-foreground">No exports for this format.</p>
            </div>
          ) : (
            filtered.map(rec => (
              <div key={rec.id} className="flex items-center gap-3 px-4 py-3 border-t border-border/20 hover:bg-white/[0.02] transition-colors">
                <div className="flex-1 min-w-0">
                  <div className="text-[11px] font-medium text-foreground truncate">{rec.name}</div>
                  <div className="text-[10px] text-muted-foreground">{rec.workspace} · {rec.downloads} download{rec.downloads !== 1 ? "s" : ""}</div>
                </div>
                <div className="w-20 shrink-0">
                  <FormatChip f={rec.format} />
                </div>
                <button
                  onClick={() => navigate("/app/reports")}
                  className="w-40 shrink-0 text-left group"
                >
                  <span className="text-[10px] text-muted-foreground group-hover:text-primary transition-colors truncate flex items-center gap-1">
                    {rec.source_report}
                    <ChevronRight className="w-2.5 h-2.5 opacity-0 group-hover:opacity-100 transition-opacity" />
                  </span>
                </button>
                <span className="w-24 shrink-0 text-[10px] text-muted-foreground">{rec.created_at}</span>
                <span className="w-16 shrink-0 text-right text-[10px] font-mono text-muted-foreground">{rec.size}</span>
                <div className="w-24 shrink-0">
                  <StatusChip s={rec.status} />
                </div>
                <button
                  onClick={() => reDownload(rec)}
                  disabled={rec.status !== "Ready"}
                  title="Re-download"
                  className={cn(
                    "w-9 h-7 shrink-0 rounded-lg border flex items-center justify-center transition-all",
                    rec.status === "Ready"
                      ? "border-border/60 text-muted-foreground hover:text-foreground hover:border-border"
                      : "border-border/30 text-muted-foreground/30 cursor-not-allowed"
                  )}
                >
                  <Download className="w-3.5 h-3.5" />
                </button>
              </div>
            ))
          )}
        </div>

        {/* Export destinations */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <SectionLabel>Export Destinations</SectionLabel>
            <button
              onClick={() => toast({ title: "Schedule builder", description: "Add a new delivery destination." })}
              className="flex items-center gap-1 text-[10px] text-muted-foreground hover:text-foreground border border-border/50 rounded px-2 py-1 transition-colors"
            >
              <Plus className="w-2.5 h-2.5" /> Add destination
            </button>
          </div>
          <div className="bg-card border border-border/60 rounded-xl overflow-hidden">
            {EXPORT_DESTINATIONS.map(d => (
              <DestinationRow key={d.id} dest={d} />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
