// ═══════════════════════════════════════════════════════════════════════
// METRIX IAP — Reports › Overview (/app/reports/overview)
// KPI summary, status breakdown, recent reports, quick links.
// ═══════════════════════════════════════════════════════════════════════

import { Link } from "wouter";
import { FileText, ArrowUpRight } from "lucide-react";
import { cn } from "@/lib/utils";
import { useCurrentWorkspace } from "@/contexts/WorkspaceContext";
import { REPORTS } from "@/lib/mock-data";

const STATUS_STYLES: Record<string, string> = {
  Draft:     "bg-muted text-muted-foreground border-border/40",
  "In Review":"bg-yellow-400/10 text-yellow-400 border-yellow-400/20",
  Final:     "bg-emerald-500/10 text-emerald-400 border-emerald-500/20",
  Sent:      "bg-primary/10 text-primary border-primary/20",
};

export function ReportsOverview() {
  const ws = useCurrentWorkspace();

  const all = REPORTS.filter(r => r.workspace_id === ws.id)
    .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());

  const statuses = ["Draft", "In Review", "Final", "Sent"] as const;
  const counts = Object.fromEntries(statuses.map(s => [s, all.filter(r => r.status === s).length]));
  const clientReady = all.filter(r => r.client_ready).length;

  return (
    <div className="flex-1 p-5 space-y-4 max-w-5xl">
      <div className="flex items-end justify-between gap-4">
        <div>
          <h1 className="text-lg font-bold text-foreground tracking-tight">Reports Overview</h1>
          <p className="text-xs text-muted-foreground mt-0.5">
            {ws.name} · {all.length} report{all.length !== 1 ? "s" : ""} · {clientReady} client-ready
          </p>
        </div>
        <Link
          href="/app/reports/new"
          className="px-3 py-1.5 rounded-lg bg-primary text-primary-foreground text-xs font-semibold hover:opacity-90 transition-opacity"
        >
          New Report
        </Link>
      </div>

      {/* KPI strip */}
      <div className="grid grid-cols-4 gap-2.5">
        {statuses.map(s => (
          <div key={s} className="bg-card/60 border border-border/60 rounded-xl px-4 py-3 space-y-2">
            <div className="text-2xl font-bold tabular-nums text-foreground">{counts[s]}</div>
            <div className="text-[10px] font-medium text-foreground">{s}</div>
            <div className={cn(
              "text-[9px] px-1.5 py-0.5 rounded border font-semibold leading-none inline-block",
              STATUS_STYLES[s]
            )}>
              {s}
            </div>
          </div>
        ))}
      </div>

      {/* Trend read */}
      <div className="bg-card/60 border border-primary/25 rounded-xl px-4 py-3.5">
        <div className="text-[9px] font-semibold uppercase tracking-[0.18em] text-primary mb-1.5">Pipeline read</div>
        <p className="text-sm text-foreground leading-relaxed">
          {clientReady > 0
            ? `${clientReady} report${clientReady !== 1 ? "s are" : " is"} client-ready — ready to deliver.`
            : "No client-ready reports yet on this account."}
        </p>
        <p className="text-xs text-muted-foreground mt-1.5 leading-relaxed">
          {counts["In Review"]} in review · {counts.Final} finalised · {counts.Sent} sent this period.
        </p>
      </div>

      {/* Recent list */}
      {all.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-20 space-y-3">
          <FileText className="w-8 h-8 text-muted-foreground/40" />
          <p className="text-sm text-muted-foreground">No reports yet.</p>
        </div>
      ) : (
        <div className="bg-card/60 border border-border/60 rounded-xl overflow-hidden">
          <div className="px-4 py-2.5 flex items-center justify-between border-b border-border/40">
            <div className="text-[9px] font-semibold uppercase tracking-[0.18em] text-muted-foreground/70">Recent reports</div>
            <Link href="/app/reports/history" className="text-[11px] text-primary hover:text-primary/80 transition-colors flex items-center gap-1">
              Full history <ArrowUpRight className="w-3 h-3" />
            </Link>
          </div>
          <div className="divide-y divide-border/30">
            {all.slice(0, 5).map(r => (
              <div key={r.id} className="flex items-center gap-3 px-4 py-3">
                <div className="flex-1 min-w-0 space-y-0.5">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-semibold text-foreground truncate">{r.title}</span>
                    <span className={cn(
                      "shrink-0 text-[10px] px-1.5 py-0.5 rounded border font-semibold leading-none",
                      STATUS_STYLES[r.status] ?? ""
                    )}>
                      {r.status}
                    </span>
                  </div>
                  <div className="text-[11px] text-muted-foreground">
                    {r.date_range_start} – {r.date_range_end}
                  </div>
                </div>
                <div className="text-[10px] text-muted-foreground/60 shrink-0">{r.created_at}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Quick links */}
      <div className="grid grid-cols-3 gap-2.5">
        {[
          { label: "Builder",  desc: "Create a new report",    href: "/app/reports/new" },
          { label: "History",  desc: "All past reports",       href: "/app/reports/history" },
          { label: "Settings", desc: "Template + delivery",    href: "/app/reports/settings" },
        ].map(l => (
          <Link
            key={l.href}
            href={l.href}
            className="bg-card/60 border border-border/60 rounded-xl px-4 py-3 hover:border-primary/30 hover:bg-card transition-colors group"
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-foreground">{l.label}</span>
              <ArrowUpRight className="w-3.5 h-3.5 text-muted-foreground/50 group-hover:text-primary transition-colors" />
            </div>
            <p className="text-[11px] text-muted-foreground mt-0.5">{l.desc}</p>
          </Link>
        ))}
      </div>
    </div>
  );
}
