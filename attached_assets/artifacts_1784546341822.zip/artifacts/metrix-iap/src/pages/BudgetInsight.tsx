import { useState } from "react";
import { useLocation } from "wouter";
import { cn } from "@/lib/utils";
import {
  Wallet, ArrowRight, ArrowUp, ArrowDown, AlertTriangle,
  TrendingUp, Gauge, ChevronDown, ChevronUp,
} from "lucide-react";
import { useWorkspace } from "@/contexts/WorkspaceContext";
import {
  getBudgetData,
  type FrontierBand, type ObjectiveAllocation, type WastedSpendCallout,
} from "@/lib/mock/budget";

// ─── Formatters ────────────────────────────────────────────────────────

const money = (n: number) => `$${n.toLocaleString("en-US", { maximumFractionDigits: 0 })}`;
const money2 = (n: number) => `$${n.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
const num = (n: number) => n.toLocaleString("en-US");

// ─── Band chip ─────────────────────────────────────────────────────────

function BandChip({ b }: { b: FrontierBand }) {
  const s: Record<FrontierBand, { c: string; label: string }> = {
    scale: { c: "text-emerald-400 border-emerald-500/20 bg-emerald-500/10", label: "Scale" },
    hold: { c: "text-primary border-primary/20 bg-primary/10", label: "Hold" },
    cut: { c: "text-red-400 border-red-500/20 bg-red-500/10", label: "Cut" },
  };
  return <span className={cn("text-[9px] px-1.5 py-0.5 rounded border font-bold leading-none", s[b].c)}>{s[b].label}</span>;
}

function severityChip(sev: WastedSpendCallout["severity"]) {
  const m: Record<WastedSpendCallout["severity"], string> = {
    Critical: "text-red-400 border-red-500/20 bg-red-500/10",
    High: "text-orange-400 border-orange-400/20 bg-orange-400/10",
    Medium: "text-yellow-400 border-yellow-400/20 bg-yellow-400/10",
  };
  return m[sev];
}

// ─── Reallocation delta ────────────────────────────────────────────────

function ReallocDelta({ a }: { a: ObjectiveAllocation }) {
  const delta = a.recommended_spend - a.current_spend;
  const pct = (delta / a.current_spend) * 100;
  if (Math.abs(pct) < 1) return <span className="text-[10px] font-mono text-muted-foreground">hold</span>;
  const up = delta > 0;
  return (
    <span className={cn("inline-flex items-center gap-0.5 text-[11px] font-mono font-semibold", up ? "text-emerald-400" : "text-red-400")}>
      {up ? <ArrowUp className="w-2.5 h-2.5" /> : <ArrowDown className="w-2.5 h-2.5" />}
      {up ? "+" : ""}{money(Math.abs(delta))}
    </span>
  );
}

// ─── BudgetInsight ─────────────────────────────────────────────────────

export function BudgetInsight() {
  const { currentWorkspace } = useWorkspace();
  const [, navigate] = useLocation();
  const data = getBudgetData(currentWorkspace.id);

  const [bandFilter, setBandFilter] = useState<"all" | FrontierBand>("all");
  const [expanded, setExpanded] = useState<string | null>(null);

  const { pacing } = data;
  const spentPct = (pacing.spent_to_date / pacing.plan_total) * 100;
  const timePct = (pacing.days_elapsed / pacing.days_total) * 100;
  const expectedToDate = pacing.daily_target * pacing.days_elapsed;
  const paceDelta = pacing.spent_to_date - expectedToDate;

  const totalAllocated = data.allocations.reduce((s, a) => s + a.current_spend, 0);
  const filteredFrontier = data.frontier.filter((f) => bandFilter === "all" || f.band === bandFilter);

  const bandCounts = {
    scale: data.frontier.filter((f) => f.band === "scale").length,
    hold: data.frontier.filter((f) => f.band === "hold").length,
    cut: data.frontier.filter((f) => f.band === "cut").length,
  };

  return (
    <div className="h-full overflow-y-auto">
      <div className="max-w-6xl mx-auto px-6 py-5 space-y-4">

        {/* Header */}
        <div className="flex items-start justify-between">
          <div className="space-y-0.5">
            <div className="flex items-center gap-2">
              <Wallet className="w-4 h-4 text-primary" />
              <h1 className="text-xl font-bold text-foreground tracking-tight">Budget Insight</h1>
            </div>
            <p className="text-xs text-muted-foreground">{data.account_label} · {data.date_range}</p>
          </div>
          <span className="text-[10px] font-mono text-muted-foreground/60 pt-1">
            plan {money(pacing.plan_total)} · spent {money(pacing.spent_to_date)}
          </span>
        </div>

        {/* KPI row */}
        <div className="grid grid-cols-4 gap-3">
          {[
            { label: "Spent to Date", value: money(pacing.spent_to_date), sub: `${spentPct.toFixed(0)}% of plan`, color: "text-primary" },
            { label: "Daily Pace", value: money(pacing.daily_avg), sub: `target ${money(pacing.daily_target)}`, color: "text-foreground" },
            { label: "Blended CPA", value: money2(data.blended_cpa), sub: "install cost", color: "text-foreground" },
            { label: "Reclaimable", value: money(data.reclaimable_total), sub: "wasted spend flagged", color: "text-[hsl(var(--metrix-gold))]" },
          ].map((k) => (
            <div key={k.label} className="bg-card border border-border/60 rounded-xl px-4 py-3">
              <div className={cn("text-2xl font-bold leading-none", k.color)}>{k.value}</div>
              <div className="text-[11px] font-medium text-foreground mt-1.5">{k.label}</div>
              <div className="text-[10px] text-muted-foreground mt-0.5">{k.sub}</div>
            </div>
          ))}
        </div>

        {/* Spend pacing vs plan */}
        <div className="bg-card border border-border/60 rounded-xl px-4 py-3.5 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5">
              <Gauge className="w-3 h-3 text-[hsl(var(--metrix-cyan))]" />
              <span className="text-[9px] font-semibold uppercase tracking-[0.18em] text-muted-foreground/70">Spend Pacing vs Plan</span>
            </div>
            <span className={cn(
              "text-[10px] px-2 py-0.5 rounded border font-semibold leading-none",
              pacing.status === "on_track" ? "text-emerald-400 border-emerald-500/20 bg-emerald-500/10"
                : pacing.status === "over" ? "text-red-400 border-red-500/20 bg-red-500/10"
                : "text-yellow-400 border-yellow-400/20 bg-yellow-400/10"
            )}>
              {pacing.status === "on_track" ? "On track" : pacing.status === "over" ? "Overpacing" : "Underpacing"}
            </span>
          </div>

          {/* dual bar: spend vs time */}
          <div className="space-y-2.5">
            <div className="space-y-1">
              <div className="flex items-center justify-between text-[10px]">
                <span className="text-muted-foreground">Budget consumed</span>
                <span className="font-mono text-foreground">{money(pacing.spent_to_date)} / {money(pacing.plan_total)}</span>
              </div>
              <div className="relative w-full bg-border/30 rounded-full h-2 overflow-hidden">
                <div className="h-full rounded-full bg-primary" style={{ width: `${Math.min(100, spentPct)}%` }} />
                <div className="absolute top-0 h-full w-px bg-foreground/60" style={{ left: `${timePct}%` }} />
              </div>
            </div>
            <div className="space-y-1">
              <div className="flex items-center justify-between text-[10px]">
                <span className="text-muted-foreground">Time elapsed</span>
                <span className="font-mono text-foreground">Day {pacing.days_elapsed} / {pacing.days_total}</span>
              </div>
              <div className="w-full bg-border/30 rounded-full h-2 overflow-hidden">
                <div className="h-full rounded-full bg-[hsl(var(--metrix-cyan))]" style={{ width: `${timePct}%` }} />
              </div>
            </div>
          </div>

          <div className="flex items-center gap-4 pt-1 border-t border-border/30 text-[10px] text-muted-foreground">
            <span>Expected to date <span className="font-mono text-foreground">{money(expectedToDate)}</span></span>
            <span className="text-muted-foreground/30">·</span>
            <span className="flex items-center gap-1">
              Variance
              <span className={cn("font-mono font-semibold", Math.abs(paceDelta) < 200 ? "text-emerald-400" : paceDelta > 0 ? "text-orange-400" : "text-yellow-400")}>
                {paceDelta >= 0 ? "+" : ""}{money(paceDelta)}
              </span>
            </span>
            <span className="text-muted-foreground/30">·</span>
            <span>{money(pacing.plan_total - pacing.spent_to_date)} remaining</span>
          </div>
        </div>

        {/* Budget allocation by objective */}
        <div className="space-y-2">
          <span className="text-[9px] font-semibold uppercase tracking-[0.18em] text-muted-foreground/70">Allocation by Objective · Reallocation</span>
          <div className="bg-card border border-border/60 rounded-xl overflow-hidden">
            <div className="grid grid-cols-[minmax(0,1.4fr)_repeat(4,minmax(0,1fr))] gap-2 px-4 py-2 border-b border-border/40 bg-muted/10 text-[9px] font-semibold uppercase tracking-wide text-muted-foreground">
              <span>Objective</span>
              <span className="text-right">Current</span>
              <span className="text-right">Results</span>
              <span className="text-right">Recommended</span>
              <span className="text-right">Shift</span>
            </div>
            {data.allocations.map((a, i) => {
              const sharePct = (a.current_spend / totalAllocated) * 100;
              const zeroResults = a.results === 0;
              return (
                <div key={a.id} className={cn("px-4 py-2.5", i !== data.allocations.length - 1 && "border-b border-border/20")}>
                  <div className="grid grid-cols-[minmax(0,1.4fr)_repeat(4,minmax(0,1fr))] gap-2 items-center">
                    <div className="min-w-0">
                      <div className="text-[11px] font-medium text-foreground truncate">{a.objective}</div>
                      <div className="flex items-center gap-1.5 mt-1">
                        <div className="w-24 bg-border/30 rounded-full h-1 overflow-hidden">
                          <div className={cn("h-full rounded-full", zeroResults ? "bg-red-400" : "bg-[hsl(var(--metrix-cyan))]")} style={{ width: `${sharePct}%` }} />
                        </div>
                        <span className="text-[9px] font-mono text-muted-foreground">{sharePct.toFixed(0)}%</span>
                      </div>
                    </div>
                    <span className="text-[11px] font-mono text-foreground text-right">{money(a.current_spend)}</span>
                    <span className={cn("text-[11px] font-mono text-right", zeroResults ? "text-red-400" : "text-foreground")}>
                      {num(a.results)} {a.result_label}
                    </span>
                    <span className="text-[11px] font-mono text-foreground text-right">{money(a.recommended_spend)}</span>
                    <span className="text-right"><ReallocDelta a={a} /></span>
                  </div>
                  <p className="text-[10px] text-muted-foreground leading-snug mt-1.5">{a.note}</p>
                </div>
              );
            })}
          </div>
        </div>

        {/* Efficiency frontier */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-[9px] font-semibold uppercase tracking-[0.18em] text-muted-foreground/70">Efficiency Frontier</span>
            <div className="flex items-center gap-1">
              {([
                { id: "all" as const, label: "All", count: data.frontier.length },
                { id: "scale" as const, label: "Scale", count: bandCounts.scale },
                { id: "hold" as const, label: "Hold", count: bandCounts.hold },
                { id: "cut" as const, label: "Cut", count: bandCounts.cut },
              ]).map((b) => (
                <button
                  key={b.id}
                  onClick={() => setBandFilter(b.id)}
                  className={cn(
                    "px-2.5 py-1 rounded-full text-[10px] font-medium border transition-all",
                    bandFilter === b.id
                      ? "bg-primary/15 border-primary/40 text-primary"
                      : "bg-transparent border-border/50 text-muted-foreground hover:text-foreground"
                  )}
                >
                  {b.label} <span className="text-muted-foreground/60">{b.count}</span>
                </button>
              ))}
            </div>
          </div>
          <div className="space-y-2">
            {filteredFrontier.map((f) => {
              const open = expanded === f.id;
              const idxPct = Math.min(100, (f.efficiency_index / 200) * 100);
              const idxColor = f.efficiency_index >= 130 ? "bg-emerald-500" : f.efficiency_index >= 100 ? "bg-primary" : f.efficiency_index >= 70 ? "bg-yellow-400" : "bg-red-400";
              return (
                <div key={f.id} className="bg-card border border-border/60 rounded-xl overflow-hidden">
                  <button
                    onClick={() => setExpanded(open ? null : f.id)}
                    className="w-full flex items-center gap-3 px-4 py-2.5 text-left hover:bg-white/[0.02] transition-colors"
                  >
                    <BandChip b={f.band} />
                    <div className="flex-1 min-w-0">
                      <div className="text-[11px] font-medium text-foreground truncate">{f.name}</div>
                      <div className="text-[9px] font-mono text-muted-foreground/70 mt-0.5">{f.code}</div>
                    </div>
                    <div className="flex items-center gap-1.5 w-40 shrink-0">
                      <div className="flex-1 bg-border/30 rounded-full h-1 overflow-hidden">
                        <div className={cn("h-full rounded-full", idxColor)} style={{ width: `${idxPct}%` }} />
                      </div>
                      <span className={cn(
                        "text-[10px] font-mono font-semibold w-8 text-right",
                        f.efficiency_index >= 130 ? "text-emerald-400" : f.efficiency_index >= 100 ? "text-foreground" : f.efficiency_index >= 70 ? "text-yellow-400" : "text-red-400"
                      )}>{f.efficiency_index}</span>
                    </div>
                    <div className="w-16 text-right shrink-0">
                      <div className={cn("text-[11px] font-mono font-semibold", f.cpa === 0 ? "text-red-400" : f.cpa <= data.blended_cpa ? "text-emerald-400" : "text-orange-400")}>
                        {f.cpa > 0 ? money2(f.cpa) : "—"}
                      </div>
                      <div className="text-[9px] text-muted-foreground">CPA</div>
                    </div>
                    {open ? <ChevronUp className="w-3.5 h-3.5 text-muted-foreground shrink-0" /> : <ChevronDown className="w-3.5 h-3.5 text-muted-foreground shrink-0" />}
                  </button>
                  {open && (
                    <div className="px-4 pb-3 pt-2 border-t border-border/20 grid grid-cols-3 gap-3 bg-muted/[0.03]">
                      <div>
                        <div className="text-[9px] text-muted-foreground uppercase tracking-wide">Spend</div>
                        <div className="text-[11px] font-mono text-foreground mt-0.5">{money(f.spend)}</div>
                      </div>
                      <div>
                        <div className="text-[9px] text-muted-foreground uppercase tracking-wide">Installs</div>
                        <div className="text-[11px] font-mono text-foreground mt-0.5">{num(f.installs)}</div>
                      </div>
                      <div>
                        <div className="text-[9px] text-muted-foreground uppercase tracking-wide">Efficiency Index</div>
                        <div className="text-[11px] font-mono text-foreground mt-0.5">{f.efficiency_index} <span className="text-muted-foreground">/ 100 base</span></div>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Wasted spend callouts */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-[9px] font-semibold uppercase tracking-[0.18em] text-muted-foreground/70">Wasted-Spend Callouts</span>
            <span className="text-[10px] font-mono text-[hsl(var(--metrix-gold))]">{money(data.reclaimable_total)} reclaimable</span>
          </div>
          <div className="grid grid-cols-2 gap-3">
            {data.wasted.map((w) => (
              <div key={w.id} className="bg-card border border-border/60 rounded-xl px-4 py-3 space-y-1.5">
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-1.5 min-w-0">
                    <AlertTriangle className="w-3 h-3 text-[hsl(var(--metrix-gold))] shrink-0" />
                    <span className="text-[11px] font-semibold text-foreground truncate">{w.label}</span>
                  </div>
                  <span className={cn("text-[9px] px-1.5 py-0.5 rounded border font-semibold leading-none shrink-0", severityChip(w.severity))}>
                    {w.severity}
                  </span>
                </div>
                <div className="text-lg font-bold text-red-400 leading-none">{money(w.amount)}</div>
                <p className="text-[10px] text-muted-foreground leading-snug">{w.reason}</p>
              </div>
            ))}
          </div>
          <button
            onClick={() => navigate("/app/iap/new")}
            className="text-[11px] text-primary hover:text-primary/80 transition-colors flex items-center gap-1 pt-1"
          >
            <TrendingUp className="w-3 h-3" /> Model reallocation in next IAP run <ArrowRight className="w-3 h-3" />
          </button>
        </div>

      </div>
    </div>
  );
}
