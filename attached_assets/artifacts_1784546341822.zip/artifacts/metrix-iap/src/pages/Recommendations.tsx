// ═══════════════════════════════════════════════════════════════════════
// METRIX IAP — Listen › Recommendations
// Open recommendations for the selected ad account, aggregated across
// its analysis runs. Status changes are local (prototype).
// ═══════════════════════════════════════════════════════════════════════

import { useMemo, useState } from "react";
import { Link } from "wouter";
import { Lightbulb, ArrowUpRight } from "lucide-react";
import { cn } from "@/lib/utils";
import { useCurrentWorkspace } from "@/contexts/WorkspaceContext";
import { ANALYSIS_RUNS } from "@/lib/mock-data";
import type { Recommendation } from "@/lib/types";

type RecStatus = Recommendation["status"];

const PRIORITY_STYLE: Record<Recommendation["priority"], string> = {
  Critical: "bg-destructive/15 text-destructive border-destructive/25",
  High: "text-[hsl(var(--metrix-gold))] bg-[hsl(var(--metrix-gold)/0.12)] border-[hsl(var(--metrix-gold)/0.25)]",
  Medium: "bg-primary/15 text-primary border-primary/25",
  Low: "bg-muted text-muted-foreground border-border/40",
};

const STATUS_STYLE: Record<RecStatus, string> = {
  Open: "text-[hsl(var(--metrix-gold))]",
  "In Progress": "text-primary",
  Completed: "text-[hsl(var(--metrix-success))]",
  Dismissed: "text-muted-foreground",
};

const NEXT_STATUS: Record<RecStatus, RecStatus> = {
  Open: "In Progress",
  "In Progress": "Completed",
  Completed: "Open",
  Dismissed: "Open",
};

const FILTERS: (RecStatus | "All")[] = ["All", "Open", "In Progress", "Completed", "Dismissed"];

export function Recommendations() {
  const ws = useCurrentWorkspace();

  const initial = useMemo(
    () =>
      ANALYSIS_RUNS
        .filter(r => r.workspace_id === ws.id)
        .flatMap(r => r.recommendations)
        .sort((a, b) => b.created_at.localeCompare(a.created_at)),
    [ws.id]
  );

  const [items, setItems] = useState(initial);
  const [filter, setFilter] = useState<RecStatus | "All">("All");

  // Re-seed when account changes
  if (items !== initial && !items.some(i => initial.some(x => x.id === i.id))) {
    setItems(initial);
  }

  const visible = filter === "All" ? items : items.filter(i => i.status === filter);
  const openCount = items.filter(i => i.status === "Open").length;

  function advance(id: string) {
    setItems(prev => prev.map(i => (i.id === id ? { ...i, status: NEXT_STATUS[i.status] } : i)));
  }

  return (
    <div className="flex-1 p-5 space-y-4 max-w-5xl">
      <div className="flex items-end justify-between gap-4">
        <div>
          <h1 className="text-lg font-bold text-foreground tracking-tight">Recommendations</h1>
          <p className="text-xs text-muted-foreground mt-0.5">
            {openCount} open for {ws.name} — sourced from IAP analysis runs.
          </p>
        </div>
        <Link
          href="/app/analysis/library"
          className="text-xs text-primary hover:text-primary/80 transition-colors inline-flex items-center gap-1"
          data-testid="link-iap-library"
        >
          IAP Library <ArrowUpRight className="w-3 h-3" />
        </Link>
      </div>

      {/* Status filter chips */}
      <div className="flex items-center gap-1.5">
        {FILTERS.map(f => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={cn(
              "px-2.5 py-1 rounded-md text-[11px] font-medium border transition-colors",
              filter === f
                ? "bg-primary/15 text-primary border-primary/25"
                : "text-muted-foreground border-border/40 hover:text-foreground hover:bg-white/5"
            )}
            data-testid={`filter-${f.toLowerCase().replace(" ", "-")}`}
          >
            {f}
          </button>
        ))}
      </div>

      {visible.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-20 text-center">
          <Lightbulb className="w-8 h-8 text-muted-foreground/40 mb-3" />
          <p className="text-sm text-muted-foreground">No recommendations in this state.</p>
        </div>
      ) : (
        <div className="space-y-2">
          {visible.map(rec => (
            <div
              key={rec.id}
              className="bg-card/60 border border-border/60 rounded-xl px-4 py-3.5"
              data-testid={`rec-${rec.id}`}
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className={cn("text-[10px] font-semibold px-1.5 py-0.5 rounded border leading-none uppercase tracking-wide", PRIORITY_STYLE[rec.priority])}>
                    {rec.priority}
                  </span>
                  <span className="text-[10px] font-mono text-muted-foreground/60 uppercase">{rec.confidence} confidence</span>
                </div>
                <button
                  onClick={() => advance(rec.id)}
                  className={cn("text-[11px] font-semibold shrink-0 hover:opacity-80 transition-opacity", STATUS_STYLE[rec.status])}
                  data-testid={`button-status-${rec.id}`}
                  title={`Mark as ${NEXT_STATUS[rec.status]}`}
                >
                  {rec.status} →
                </button>
              </div>
              <h3 className="text-sm font-semibold text-foreground mt-2">{rec.title}</h3>
              <p className="text-xs text-muted-foreground mt-1 leading-relaxed">{rec.rationale}</p>
              <div className="flex items-center justify-between gap-3 mt-2.5 pt-2.5 border-t border-border/40">
                <p className="text-xs text-foreground/90"><span className="text-muted-foreground/70">Action:</span> {rec.action}</p>
                <Link
                  href={`/app/analysis/library/${rec.run_id}`}
                  className="text-[11px] text-primary hover:text-primary/80 transition-colors shrink-0"
                  data-testid={`link-run-${rec.id}`}
                >
                  Source run
                </Link>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
