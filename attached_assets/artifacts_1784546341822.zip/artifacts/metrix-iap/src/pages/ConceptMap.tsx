import { useState } from "react";
import { useLocation } from "wouter";
import { cn } from "@/lib/utils";
import {
  GitBranch, Trophy, ChevronDown, ChevronRight, ArrowRight,
  CircleDot, Sparkles, Target,
} from "lucide-react";
import { useWorkspace } from "@/contexts/WorkspaceContext";
import { CREATIVE_CONCEPTS } from "@/lib/mock-data";
import type { CreativeConcept, PerformanceTier } from "@/lib/types";

// ─── Variable family helpers ──────────────────────────────────────────

const FAMILY_COLORS: Record<string, string> = {
  HK: "text-primary bg-primary/10 border-primary/20",
  FW: "text-purple-400 bg-purple-500/10 border-purple-500/20",
  TN: "text-blue-400 bg-blue-500/10 border-blue-500/20",
  CN: "text-emerald-400 bg-emerald-500/10 border-emerald-500/20",
  CTA: "text-yellow-400 bg-yellow-400/10 border-yellow-400/20",
};

function famOf(code: string): string {
  return code.split("_")[0];
}
function labelOf(code: string): string {
  const i = code.indexOf("_");
  return i === -1 ? code : code.slice(i + 1);
}

function VarChip({ code }: { code: string }) {
  const fam = famOf(code);
  return (
    <span className={cn(
      "text-[10px] px-1.5 py-0.5 rounded border font-medium leading-none whitespace-nowrap",
      FAMILY_COLORS[fam] ?? "text-muted-foreground bg-muted border-border/40"
    )}>
      <span className="font-mono opacity-60">{fam}</span> {labelOf(code)}
    </span>
  );
}

// ─── Heat coloring (performance tier) ─────────────────────────────────

const TIER_HEAT: Record<PerformanceTier, string> = {
  1: "bg-emerald-500/10 border-emerald-500/30",
  2: "bg-yellow-400/[0.07] border-yellow-400/25",
  3: "bg-orange-400/[0.07] border-orange-400/25",
  4: "bg-red-500/[0.07] border-red-500/25",
};
const TIER_DOT: Record<PerformanceTier, string> = {
  1: "bg-emerald-500",
  2: "bg-yellow-400",
  3: "bg-orange-400",
  4: "bg-red-500",
};
const TIER_TEXT: Record<PerformanceTier, string> = {
  1: "text-emerald-400",
  2: "text-yellow-400",
  3: "text-orange-400",
  4: "text-red-400",
};
const TIER_LABEL: Record<PerformanceTier, string> = {
  1: "P1 Winner",
  2: "P2 Strong",
  3: "P3 Developing",
  4: "P4 At Risk",
};

// ─── Angle lineage row ────────────────────────────────────────────────

function LineageRow({ concept, isWinner }: { concept: CreativeConcept; isWinner: boolean }) {
  const stack = [
    concept.hook_variable,
    concept.framework_variable,
    concept.tone_variable,
    concept.concept_variable,
    concept.cta_variable,
  ];
  return (
    <div className={cn(
      "flex items-center gap-2 rounded-lg border px-3 py-2.5 transition-colors",
      TIER_HEAT[concept.tier],
      isWinner && "ring-1 ring-[hsl(var(--metrix-gold)/0.6)] shadow-[0_0_14px_hsl(var(--metrix-gold)/0.1)]"
    )}>
      <div className="flex items-center gap-1.5 w-24 shrink-0">
        <span className={cn("w-1.5 h-1.5 rounded-full shrink-0", TIER_DOT[concept.tier])} />
        <span className="text-[11px] font-mono font-bold text-foreground/80">{concept.cell_id}</span>
        {isWinner && (
          <Trophy className="w-3 h-3 text-[hsl(var(--metrix-gold))] shrink-0" />
        )}
      </div>

      {/* Variable lineage stack */}
      <div className="flex items-center gap-1 flex-1 min-w-0 flex-wrap">
        {stack.map((code, i) => (
          <div key={i} className="flex items-center gap-1">
            {i > 0 && <ChevronRight className="w-2.5 h-2.5 text-muted-foreground/40 shrink-0" />}
            <VarChip code={code} />
          </div>
        ))}
      </div>

      <span className={cn("text-[9px] font-bold leading-none shrink-0 w-20 text-right", TIER_TEXT[concept.tier])}>
        {TIER_LABEL[concept.tier]}
      </span>
    </div>
  );
}

// ─── Concept family card ──────────────────────────────────────────────

interface Family {
  concept_id: string;
  name: string;
  angles: CreativeConcept[];
  bestTier: PerformanceTier;
  winnerId: string | null;
}

function FamilyCard({ family, winningOnly }: { family: Family; winningOnly: boolean }) {
  const [open, setOpen] = useState(true);

  const angles = winningOnly
    ? family.angles.filter(a => a.id === family.winnerId)
    : family.angles;

  const dist = ([1, 2, 3, 4] as PerformanceTier[]).map(t => ({
    tier: t,
    count: family.angles.filter(a => a.tier === t).length,
  }));

  return (
    <div className={cn(
      "bg-card border rounded-xl overflow-hidden transition-all",
      family.bestTier === 1 ? "border-emerald-500/25" : "border-border/60"
    )}>
      {/* Parent node header */}
      <button
        onClick={() => setOpen(o => !o)}
        className="w-full flex items-center gap-3 px-4 py-3 text-left hover:bg-white/[0.02] transition-colors"
      >
        <div className={cn(
          "flex items-center justify-center w-9 h-9 rounded-lg border shrink-0 font-mono text-xs font-bold",
          family.bestTier === 1
            ? "border-emerald-500/40 bg-emerald-500/10 text-emerald-400"
            : "border-primary/30 bg-primary/10 text-primary"
        )}>
          {family.concept_id}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-foreground truncate">{family.name}</span>
          </div>
          <div className="flex items-center gap-2 mt-1 text-[10px] text-muted-foreground">
            <span>{family.angles.length} angle{family.angles.length !== 1 ? "s" : ""}</span>
            <span className="text-muted-foreground/30">·</span>
            <span className="flex items-center gap-1">
              {dist.filter(d => d.count > 0).map(d => (
                <span key={d.tier} className="flex items-center gap-0.5">
                  <span className={cn("w-1.5 h-1.5 rounded-full", TIER_DOT[d.tier])} />
                  {d.count}
                </span>
              ))}
            </span>
          </div>
        </div>
        {/* Tier heat mini-bar */}
        <div className="flex items-center h-1.5 w-24 rounded-full overflow-hidden bg-border/30 shrink-0">
          {dist.map(d => d.count > 0 && (
            <div
              key={d.tier}
              className={cn("h-full", TIER_DOT[d.tier])}
              style={{ width: `${(d.count / family.angles.length) * 100}%` }}
            />
          ))}
        </div>
        <ChevronDown className={cn("w-4 h-4 text-muted-foreground shrink-0 transition-transform", open && "rotate-180")} />
      </button>

      {open && (
        <div className="border-t border-border/30 p-3 space-y-1.5">
          <div className="flex items-center gap-1.5 px-1 pb-1 text-[9px] font-semibold uppercase tracking-[0.14em] text-muted-foreground/60">
            <GitBranch className="w-2.5 h-2.5" /> Variable Lineage · HK → FW → TN → CN → CTA
          </div>
          {angles.map(a => (
            <LineageRow key={a.id} concept={a} isWinner={a.id === family.winnerId} />
          ))}
        </div>
      )}
    </div>
  );
}

// ─── ConceptMap ───────────────────────────────────────────────────────

export function ConceptMap() {
  const { currentWorkspace } = useWorkspace();
  const [, navigate] = useLocation();

  const [familyFilter, setFamilyFilter] = useState<string>("All");
  const [winningOnly, setWinningOnly] = useState(false);

  const wsId = currentWorkspace.id;
  const scoped = CREATIVE_CONCEPTS.filter(c => c.workspace_id === wsId);
  const concepts = scoped.length > 0 ? scoped : CREATIVE_CONCEPTS;

  // Group into families by concept_id
  const map = new Map<string, CreativeConcept[]>();
  for (const c of concepts) {
    const arr = map.get(c.concept_id) ?? [];
    arr.push(c);
    map.set(c.concept_id, arr);
  }
  const families: Family[] = Array.from(map.entries())
    .map(([concept_id, angles]) => {
      const sorted = [...angles].sort((a, b) => a.tier - b.tier || a.cell_id.localeCompare(b.cell_id));
      const bestTier = Math.min(...sorted.map(a => a.tier)) as PerformanceTier;
      const winner = sorted.find(a => a.tier === bestTier) ?? null;
      return {
        concept_id,
        name: sorted[0].name,
        angles: sorted,
        bestTier,
        winnerId: bestTier === 1 && winner ? winner.id : null,
      };
    })
    .sort((a, b) => a.concept_id.localeCompare(b.concept_id));

  const familyCodes = ["All", ...families.map(f => f.concept_id)];
  const visible = familyFilter === "All" ? families : families.filter(f => f.concept_id === familyFilter);

  const totalAngles = families.reduce((s, f) => s + f.angles.length, 0);
  const winningPaths = families.filter(f => f.winnerId).length;
  const atRisk = concepts.filter(c => c.tier === 4).length;

  return (
    <div className="h-full overflow-y-auto">
      <div className="max-w-6xl mx-auto px-6 py-5 space-y-4">

        {/* Header */}
        <div className="flex items-start justify-between">
          <div>
            <div className="text-[9px] font-semibold uppercase tracking-[0.18em] text-muted-foreground/60 mb-1">
              MST · Matrix Scaling
            </div>
            <h1 className="text-xl font-bold text-foreground tracking-tight">Concept Map</h1>
            <p className="text-xs text-muted-foreground mt-0.5">
              {currentWorkspace.name} · variable lineage across {families.length} concept famil{families.length !== 1 ? "ies" : "y"}
            </p>
          </div>
          <button
            onClick={() => navigate("/app/mst/matrix")}
            className="text-[11px] text-white bg-primary hover:bg-primary/90 px-3 py-1.5 rounded-lg font-medium transition-all flex items-center gap-1.5"
          >
            <Target className="w-3 h-3" /> Matrix Builder
          </button>
        </div>

        {/* Summary strip */}
        <div className="grid grid-cols-4 gap-3">
          {[
            { label: "Concept Families", value: families.length, sub: "grouped by parent", color: "text-foreground" },
            { label: "Total Angles", value: totalAngles, sub: "variable combos", color: "text-foreground" },
            { label: "Winning Paths", value: winningPaths, sub: "P1 lineages", color: "text-emerald-400" },
            { label: "At Risk", value: atRisk, sub: "P4 angles", color: "text-red-400" },
          ].map(m => (
            <div key={m.label} className="bg-card border border-border/60 rounded-xl px-4 py-3">
              <div className={cn("text-xl font-bold leading-none", m.color)}>{m.value}</div>
              <div className="text-[10px] font-medium text-foreground mt-1.5">{m.label}</div>
              <div className="text-[10px] text-muted-foreground mt-0.5">{m.sub}</div>
            </div>
          ))}
        </div>

        {/* Controls + legend */}
        <div className="flex items-center justify-between gap-3 flex-wrap">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-[10px] text-muted-foreground font-medium">Family:</span>
            {familyCodes.map(f => (
              <button
                key={f}
                onClick={() => setFamilyFilter(f)}
                className={cn(
                  "px-2.5 py-1 rounded-full text-[11px] font-medium border transition-all font-mono",
                  familyFilter === f
                    ? "bg-primary/15 border-primary/40 text-primary"
                    : "bg-transparent border-border/50 text-muted-foreground hover:border-border hover:text-foreground"
                )}
              >
                {f}
              </button>
            ))}
            <button
              onClick={() => setWinningOnly(w => !w)}
              className={cn(
                "ml-1 px-2.5 py-1 rounded-full text-[11px] font-medium border transition-all flex items-center gap-1",
                winningOnly
                  ? "bg-[hsl(var(--metrix-gold)/0.12)] border-[hsl(var(--metrix-gold)/0.4)] text-[hsl(var(--metrix-gold))]"
                  : "bg-transparent border-border/50 text-muted-foreground hover:border-border hover:text-foreground"
              )}
            >
              <Trophy className="w-3 h-3" /> Winning path only
            </button>
          </div>

          {/* Heat legend */}
          <div className="flex items-center gap-2.5">
            <span className="text-[9px] font-semibold uppercase tracking-[0.14em] text-muted-foreground/60">Heat</span>
            {([1, 2, 3, 4] as PerformanceTier[]).map(t => (
              <span key={t} className="flex items-center gap-1 text-[10px] text-muted-foreground">
                <span className={cn("w-2 h-2 rounded-sm", TIER_DOT[t])} />
                {TIER_LABEL[t]}
              </span>
            ))}
          </div>
        </div>

        {/* Family cards */}
        {visible.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 space-y-3">
            <GitBranch className="w-8 h-8 text-muted-foreground/40" />
            <p className="text-sm text-muted-foreground">No concept families found.</p>
          </div>
        ) : (
          <div className="space-y-3">
            {visible.map(f => (
              <FamilyCard key={f.concept_id} family={f} winningOnly={winningOnly} />
            ))}
          </div>
        )}

        {/* Winning-path callout */}
        {winningPaths > 0 && (
          <div className="flex items-start gap-3 px-4 py-3 rounded-xl bg-[hsl(var(--metrix-gold)/0.06)] border border-[hsl(var(--metrix-gold)/0.2)]">
            <Sparkles className="w-3.5 h-3.5 text-[hsl(var(--metrix-gold))] shrink-0 mt-0.5" />
            <div className="flex-1 min-w-0">
              <p className="text-[11px] text-muted-foreground leading-relaxed">
                <span className="text-foreground font-semibold">{winningPaths} winning path{winningPaths !== 1 ? "s" : ""}</span> isolated — the P1 lineage in each family is the transferable variable stack. Extend these into the matrix before briefing new cells.
              </p>
              <button
                onClick={() => navigate("/app/mst/crossmap")}
                className="mt-1.5 text-[11px] text-[hsl(var(--metrix-gold))] hover:opacity-80 transition-opacity flex items-center gap-1"
              >
                View crossmap results <ArrowRight className="w-3 h-3" />
              </button>
            </div>
            <CircleDot className="w-3 h-3 text-[hsl(var(--metrix-gold))]/40 shrink-0 mt-0.5" />
          </div>
        )}

      </div>
    </div>
  );
}
