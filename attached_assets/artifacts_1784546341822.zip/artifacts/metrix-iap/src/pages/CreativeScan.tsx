import { useMemo, useState } from "react";
import { useLocation } from "wouter";
import { cn } from "@/lib/utils";
import {
  ScanLine, Loader2, CheckCircle2, Clock, AlertTriangle, Eye,
  Play, Film, Image as ImageIcon, ArrowRight,
} from "lucide-react";
import { useWorkspace } from "@/contexts/WorkspaceContext";
import { ADS } from "@/lib/mock-data";
import type { Ad } from "@/lib/types";

// ─── Scan status model ────────────────────────────────────────────────

type ScanStatus = "queued" | "scanning" | "extracted" | "review" | "failed";

const STATUS_META: Record<ScanStatus, { label: string; chip: string; icon: React.ComponentType<{ className?: string }>; dot: string }> = {
  queued: { label: "Queued", chip: "bg-muted/50 border-border/40 text-muted-foreground", icon: Clock, dot: "bg-muted-foreground/50" },
  scanning: { label: "Scanning", chip: "bg-primary/10 border-primary/20 text-primary", icon: Loader2, dot: "bg-primary" },
  extracted: { label: "Extracted", chip: "bg-emerald-500/10 border-emerald-500/20 text-emerald-400", icon: CheckCircle2, dot: "bg-emerald-500" },
  review: { label: "Needs Review", chip: "bg-orange-400/10 border-orange-400/20 text-orange-400", icon: Eye, dot: "bg-orange-400" },
  failed: { label: "Failed", chip: "bg-red-500/10 border-red-500/20 text-red-400", icon: AlertTriangle, dot: "bg-red-500" },
};

const FAMILY_COLORS: Record<string, string> = {
  HK: "text-primary bg-primary/10 border-primary/20",
  FW: "text-purple-400 bg-purple-500/10 border-purple-500/20",
  TN: "text-blue-400 bg-blue-500/10 border-blue-500/20",
  CN: "text-emerald-400 bg-emerald-500/10 border-emerald-500/20",
  CTA: "text-yellow-400 bg-yellow-400/10 border-yellow-400/20",
};

function labelOf(code?: string): string {
  if (!code) return "—";
  const i = code.indexOf("_");
  return i === -1 ? code : code.slice(i + 1);
}

function DnaChip({ fam, code }: { fam: string; code?: string }) {
  return (
    <span className={cn(
      "text-[9px] px-1.5 py-0.5 rounded border font-medium leading-none whitespace-nowrap",
      code ? (FAMILY_COLORS[fam] ?? "text-muted-foreground bg-muted border-border/40") : "text-muted-foreground/40 bg-transparent border-border/30"
    )}>
      <span className="font-mono opacity-60">{fam}</span> {labelOf(code)}
    </span>
  );
}

const FORMAT_ICON: Record<string, React.ComponentType<{ className?: string }>> = {
  Feed: ImageIcon,
  Square: ImageIcon,
  Story: Film,
  Reel: Play,
  Carousel: Film,
  Collection: Film,
};

// ─── Scan item derivation ─────────────────────────────────────────────

interface ScanItem {
  id: string;
  filename: string;
  format: string;
  aspect: string;
  duration: string;
  status: ScanStatus;
  progress: number;
  dna: { HK?: string; FW?: string; TN?: string; CN?: string; CTA?: string };
  confidence: number;
  ad: Ad;
}

const ASPECT_BY_FORMAT: Record<string, string> = {
  Feed: "1:1", Square: "1:1", Story: "9:16", Reel: "9:16", Carousel: "4:5", Collection: "1:1",
};

function shortFile(ad: Ad): string {
  const base = ad.name.split(/[—|(]/)[0].trim().replace(/\s+/g, "_");
  const ext = ad.format === "Story" || ad.format === "Reel" ? "mp4" : "jpg";
  return `${base}_${ad.format ?? "feed"}.${ext}`.toLowerCase();
}

function deriveStatus(i: number, total: number): { status: ScanStatus; progress: number } {
  if (i === 0) return { status: "scanning", progress: 64 };
  if (i === 1) return { status: "scanning", progress: 38 };
  if (i === 2) return { status: "queued", progress: 0 };
  if (i === 3) return { status: "review", progress: 100 };
  if (i === total - 1) return { status: "failed", progress: 22 };
  return { status: "extracted", progress: 100 };
}

// ─── CreativeScan ─────────────────────────────────────────────────────

export function CreativeScan() {
  const { currentWorkspace } = useWorkspace();
  const [, navigate] = useLocation();
  const wsId = currentWorkspace.id;

  const scoped = ADS.filter(a => a.workspace_id === wsId);
  const pool = scoped.length > 0 ? scoped : ADS.slice(0, 10);

  const baseItems: ScanItem[] = useMemo(() => pool.slice(0, 10).map((ad, i) => {
    const codes = ad.variable_codes;
    const find = (p: string) => codes.find(c => c.startsWith(p));
    const { status, progress } = deriveStatus(i, Math.min(pool.length, 10));
    const conf = ad.hook_score ?? (ad.confidence === "high" ? 90 : ad.confidence === "medium" ? 74 : 52);
    return {
      id: ad.id,
      filename: shortFile(ad),
      format: ad.format ?? "Feed",
      aspect: ASPECT_BY_FORMAT[ad.format ?? "Feed"] ?? "1:1",
      duration: ad.format === "Story" || ad.format === "Reel" ? `0:${15 + (i % 3) * 5}` : "static",
      status,
      progress,
      dna: { HK: find("HK_"), FW: find("FW_"), TN: find("TN_"), CN: find("CN_"), CTA: find("CTA_") },
      confidence: status === "failed" ? 0 : conf,
      ad,
    };
  }), [wsId]);

  // Local status overrides (advancing scans)
  const [over, setOver] = useState<Record<string, { status: ScanStatus; progress: number }>>({});
  const [filter, setFilter] = useState<ScanStatus | "all">("all");

  const items = baseItems.map(it => ({ ...it, ...(over[it.id] ?? {}) }));

  const advance = (it: ScanItem) => {
    const cur = over[it.id]?.status ?? it.status;
    if (cur === "queued") setOver(o => ({ ...o, [it.id]: { status: "scanning", progress: 20 } }));
    else if (cur === "scanning") setOver(o => ({ ...o, [it.id]: { status: "extracted", progress: 100 } }));
    else if (cur === "review") setOver(o => ({ ...o, [it.id]: { status: "extracted", progress: 100 } }));
    else if (cur === "failed") setOver(o => ({ ...o, [it.id]: { status: "scanning", progress: 20 } }));
  };

  const runPending = () => {
    const next: Record<string, { status: ScanStatus; progress: number }> = {};
    items.forEach(it => {
      if (it.status === "queued" || it.status === "scanning" || it.status === "failed") {
        next[it.id] = { status: "extracted", progress: 100 };
      }
    });
    setOver(o => ({ ...o, ...next }));
  };

  const counts = items.reduce<Record<string, number>>((acc, it) => {
    acc[it.status] = (acc[it.status] ?? 0) + 1;
    return acc;
  }, {});
  const pending = (counts.queued ?? 0) + (counts.scanning ?? 0) + (counts.failed ?? 0);

  const filtered = filter === "all" ? items : items.filter(it => it.status === filter);

  return (
    <div className="h-full overflow-y-auto">
      <div className="max-w-6xl mx-auto px-6 py-5 space-y-4">

        {/* Header */}
        <div className="flex items-start justify-between">
          <div>
            <div className="text-[9px] font-semibold uppercase tracking-[0.18em] text-muted-foreground/60 mb-1">
              MST · Matrix Scaling
            </div>
            <h1 className="text-xl font-bold text-foreground tracking-tight">Creative Scan</h1>
            <p className="text-xs text-muted-foreground mt-0.5">
              {currentWorkspace.name} · DNA extraction queue · {items.length} creative{items.length !== 1 ? "s" : ""}
            </p>
          </div>
          <button
            onClick={runPending}
            className={cn(
              "text-[11px] px-3 py-1.5 rounded-lg font-medium transition-all flex items-center gap-1.5",
              pending > 0
                ? "text-white bg-primary hover:bg-primary/90"
                : "text-muted-foreground border border-border/60 hover:text-foreground hover:bg-white/5"
            )}
          >
            <ScanLine className="w-3 h-3" /> Run {pending} pending scan{pending !== 1 ? "s" : ""}
          </button>
        </div>

        {/* Status summary / filter chips */}
        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={() => setFilter("all")}
            className={cn(
              "px-3 py-1.5 rounded-full text-[11px] font-medium border transition-all",
              filter === "all"
                ? "bg-primary/15 border-primary/40 text-primary"
                : "bg-transparent border-border/50 text-muted-foreground hover:border-border hover:text-foreground"
            )}
          >
            All {items.length}
          </button>
          {(Object.keys(STATUS_META) as ScanStatus[]).map(s => {
            const meta = STATUS_META[s];
            return (
              <button
                key={s}
                onClick={() => setFilter(s)}
                className={cn(
                  "px-3 py-1.5 rounded-full text-[11px] font-medium border transition-all flex items-center gap-1.5",
                  filter === s
                    ? "bg-primary/15 border-primary/40 text-primary"
                    : "bg-transparent border-border/50 text-muted-foreground hover:border-border hover:text-foreground"
                )}
              >
                <span className={cn("w-1.5 h-1.5 rounded-full", meta.dot)} />
                {meta.label} {counts[s] ?? 0}
              </button>
            );
          })}
        </div>

        {/* Scan queue */}
        <div className="space-y-2">
          {filtered.map(it => {
            const meta = STATUS_META[it.status];
            const StatusIcon = meta.icon;
            const FmtIcon = FORMAT_ICON[it.format] ?? ImageIcon;
            return (
              <div key={it.id} className="bg-card border border-border/60 rounded-xl px-4 py-3">
                <div className="flex items-center gap-3">
                  {/* Format thumb */}
                  <div className="w-10 h-10 rounded-lg bg-muted/40 border border-border/40 flex items-center justify-center shrink-0">
                    <FmtIcon className="w-4 h-4 text-muted-foreground" />
                  </div>

                  {/* File + meta */}
                  <div className="flex-1 min-w-0">
                    <div className="text-[11px] font-mono font-medium text-foreground truncate">{it.filename}</div>
                    <div className="flex items-center gap-2 mt-0.5 text-[10px] text-muted-foreground">
                      <span>{it.format}</span>
                      <span className="text-muted-foreground/30">·</span>
                      <span>{it.aspect}</span>
                      <span className="text-muted-foreground/30">·</span>
                      <span>{it.duration}</span>
                    </div>
                  </div>

                  {/* DNA chips */}
                  <div className="hidden md:flex items-center gap-1 shrink-0">
                    {it.status === "extracted" || it.status === "review" ? (
                      <>
                        <DnaChip fam="HK" code={it.dna.HK} />
                        <DnaChip fam="FW" code={it.dna.FW} />
                        <DnaChip fam="TN" code={it.dna.TN} />
                      </>
                    ) : (
                      <span className="text-[10px] text-muted-foreground/50 italic">DNA pending…</span>
                    )}
                  </div>

                  {/* Confidence */}
                  <div className="w-14 text-right shrink-0">
                    <div className={cn(
                      "text-sm font-bold font-mono leading-none",
                      it.confidence >= 80 ? "text-emerald-400" : it.confidence >= 60 ? "text-yellow-400" : it.confidence > 0 ? "text-orange-400" : "text-muted-foreground/40"
                    )}>
                      {it.confidence > 0 ? it.confidence : "—"}
                    </div>
                    <div className="text-[9px] text-muted-foreground mt-0.5">DNA conf</div>
                  </div>

                  {/* Status chip */}
                  <span className={cn(
                    "text-[9px] px-2 py-1 rounded border font-semibold leading-none flex items-center gap-1 shrink-0 w-[92px] justify-center",
                    meta.chip
                  )}>
                    <StatusIcon className={cn("w-2.5 h-2.5", it.status === "scanning" && "animate-spin")} />
                    {meta.label}
                  </span>

                  {/* Advance action */}
                  {it.status === "extracted" ? (
                    <span className="text-[10px] shrink-0 w-16 text-center text-emerald-400 flex items-center justify-center gap-1">
                      <CheckCircle2 className="w-2.5 h-2.5" /> Done
                    </span>
                  ) : (
                    <button
                      onClick={() => advance(it)}
                      className="text-[10px] px-2 py-1 rounded-lg border border-border/60 text-muted-foreground hover:text-foreground hover:bg-white/5 transition-all shrink-0 w-16 text-center"
                    >
                      {it.status === "queued" ? "Start" : it.status === "scanning" ? "Finish" : it.status === "review" ? "Accept" : "Retry"}
                    </button>
                  )}
                </div>

                {/* Progress bar for in-flight scans */}
                {(it.status === "scanning" || it.status === "failed") && (
                  <div className="mt-2.5 flex items-center gap-2">
                    <div className="flex-1 bg-border/30 rounded-full h-1 overflow-hidden">
                      <div
                        className={cn("h-full rounded-full transition-all", it.status === "failed" ? "bg-red-400" : "bg-primary")}
                        style={{ width: `${it.progress}%` }}
                      />
                    </div>
                    <span className="text-[9px] font-mono text-muted-foreground w-8 text-right">{it.progress}%</span>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Extracted-variables table */}
        <div className="space-y-2">
          <span className="text-[9px] font-semibold uppercase tracking-[0.18em] text-muted-foreground/70">
            Extracted Variables
          </span>
          <div className="bg-card border border-border/60 rounded-xl overflow-hidden">
            <div className="grid grid-cols-[minmax(0,1.6fr)_repeat(5,minmax(0,1fr))_70px] gap-2 px-4 py-2 border-b border-border/40 bg-muted/10">
              {["Creative", "Hook", "Framework", "Tone", "Concept", "CTA", "Format"].map(h => (
                <span key={h} className="text-[9px] font-semibold uppercase tracking-[0.12em] text-muted-foreground/60">{h}</span>
              ))}
            </div>
            {items.filter(it => it.status === "extracted" || it.status === "review").map(it => (
              <div key={it.id} className="grid grid-cols-[minmax(0,1.6fr)_repeat(5,minmax(0,1fr))_70px] gap-2 px-4 py-2.5 border-b border-border/20 last:border-b-0 items-center hover:bg-white/[0.02] transition-colors">
                <span className="text-[10px] font-mono text-foreground truncate">{it.filename}</span>
                <div><DnaChip fam="HK" code={it.dna.HK} /></div>
                <div><DnaChip fam="FW" code={it.dna.FW} /></div>
                <div><DnaChip fam="TN" code={it.dna.TN} /></div>
                <div><DnaChip fam="CN" code={it.dna.CN} /></div>
                <div><DnaChip fam="CTA" code={it.dna.CTA} /></div>
                <span className="text-[10px] text-muted-foreground">{it.format}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Downstream link */}
        <div className="flex items-center gap-2 pt-1">
          <button
            onClick={() => navigate("/app/mst/concept-map")}
            className="text-[11px] text-muted-foreground hover:text-foreground border border-border/60 px-3 py-1.5 rounded-lg hover:bg-white/5 transition-all flex items-center gap-1.5"
          >
            Map to concepts <ArrowRight className="w-3 h-3" />
          </button>
          <button
            onClick={() => navigate("/app/creative-library")}
            className="text-[11px] text-muted-foreground hover:text-foreground border border-border/60 px-3 py-1.5 rounded-lg hover:bg-white/5 transition-all flex items-center gap-1.5"
          >
            Creative Library <ArrowRight className="w-3 h-3" />
          </button>
        </div>

      </div>
    </div>
  );
}
