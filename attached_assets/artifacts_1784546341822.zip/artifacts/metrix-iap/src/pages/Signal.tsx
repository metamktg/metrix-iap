// ═══════════════════════════════════════════════════════════════════════
// METRIX IAP — Listen › Signal
// Signal-quality read for the selected ad account: the 10 IAP signal
// dimensions from the latest completed run, plus event coverage.
// ═══════════════════════════════════════════════════════════════════════

import { Link } from "wouter";
import { Radio, ArrowUpRight, AlertTriangle } from "lucide-react";
import { cn } from "@/lib/utils";
import { useCurrentWorkspace } from "@/contexts/WorkspaceContext";
import { ANALYSIS_RUNS, AD_ACCOUNTS, IMPORTS } from "@/lib/mock-data";
import type { SignalQualityScore } from "@/lib/types";

const SIGNAL_DIMENSIONS: { key: keyof SignalQualityScore; label: string; hint: string }[] = [
  { key: "tracking_confidence", label: "Tracking confidence", hint: "Pixel / CAPI reliability" },
  { key: "conversion_volume_confidence", label: "Conversion volume", hint: "Enough events per decision window" },
  { key: "spend_sufficiency", label: "Spend sufficiency", hint: "Budget cleared learning thresholds" },
  { key: "creative_diversity", label: "Creative diversity", hint: "Distinct concepts in rotation" },
  { key: "learning_stability", label: "Learning stability", hint: "Delivery not resetting mid-flight" },
  { key: "funnel_consistency", label: "Funnel consistency", hint: "Event chain fires in order" },
  { key: "segment_clarity", label: "Segment clarity", hint: "Audiences separable in the data" },
  { key: "data_cleanliness", label: "Data cleanliness", hint: "Naming + UTM hygiene" },
  { key: "date_range_reliability", label: "Date range reliability", hint: "Window free of structural breaks" },
  { key: "breakdown_usefulness", label: "Breakdown usefulness", hint: "Placement / geo splits usable" },
];

function scoreColor(v: number): string {
  if (v >= 80) return "text-[hsl(var(--metrix-success))]";
  if (v >= 60) return "text-yellow-400";
  return "text-destructive";
}

function barColor(v: number): string {
  if (v >= 80) return "bg-[hsl(var(--metrix-success))]";
  if (v >= 60) return "bg-yellow-400";
  return "bg-destructive";
}

export function Signal() {
  const ws = useCurrentWorkspace();

  const runs = ANALYSIS_RUNS
    .filter(r => r.workspace_id === ws.id && r.status === "Completed")
    .sort((a, b) => b.created_at.localeCompare(a.created_at));
  const latest = runs[0];
  const accounts = AD_ACCOUNTS.filter(a => a.workspace_id === ws.id);
  const imports = IMPORTS.filter(i => i.workspace_id === ws.id);
  const lastImport = imports.sort((a, b) => b.created_at.localeCompare(a.created_at))[0];

  if (!latest) {
    return (
      <div className="flex-1 p-5">
        <div className="flex flex-col items-center justify-center py-24 text-center">
          <Radio className="w-8 h-8 text-muted-foreground/40 mb-3" />
          <h2 className="text-base font-semibold text-foreground mb-1">No signal read yet</h2>
          <p className="text-sm text-muted-foreground mb-5 max-w-sm">
            Signal quality is scored during an IAP analysis run. Run one to get a read on this account's data.
          </p>
          <Link
            href="/app/analysis/new-run"
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-primary text-primary-foreground text-xs font-semibold hover:opacity-90 transition-opacity"
            data-testid="link-new-run"
          >
            New IAP Run <ArrowUpRight className="w-3.5 h-3.5" />
          </Link>
        </div>
      </div>
    );
  }

  const sq = latest.signal_quality;
  const weakest = [...SIGNAL_DIMENSIONS].sort((a, b) => (sq[a.key] as number) - (sq[b.key] as number))[0];

  return (
    <div className="flex-1 p-5 space-y-4 max-w-5xl">
      {/* Header */}
      <div className="flex items-end justify-between gap-4">
        <div>
          <h1 className="text-lg font-bold text-foreground tracking-tight">Signal</h1>
          <p className="text-xs text-muted-foreground mt-0.5">
            Data-quality read for {ws.name} — scored on the latest completed run ({latest.id.toUpperCase()}).
          </p>
        </div>
        <Link
          href={`/app/analysis/library/${latest.id}`}
          className="text-xs text-primary hover:text-primary/80 transition-colors inline-flex items-center gap-1"
          data-testid="link-latest-run"
        >
          Open run <ArrowUpRight className="w-3 h-3" />
        </Link>
      </div>

      {/* Overall + context strip */}
      <div className="grid grid-cols-4 gap-2.5">
        <div className="bg-card/60 border border-border/60 rounded-xl px-4 py-3">
          <div className="text-[9px] font-semibold uppercase tracking-[0.18em] text-muted-foreground/70 mb-1">Overall signal</div>
          <div className={cn("text-2xl font-bold tabular-nums", scoreColor(sq.overall))}>{sq.overall}<span className="text-sm text-muted-foreground/60">/100</span></div>
        </div>
        <div className="bg-card/60 border border-border/60 rounded-xl px-4 py-3">
          <div className="text-[9px] font-semibold uppercase tracking-[0.18em] text-muted-foreground/70 mb-1">Run confidence</div>
          <div className="text-2xl font-bold tabular-nums text-foreground">{latest.confidence_score}<span className="text-sm text-muted-foreground/60">/100</span></div>
        </div>
        <div className="bg-card/60 border border-border/60 rounded-xl px-4 py-3">
          <div className="text-[9px] font-semibold uppercase tracking-[0.18em] text-muted-foreground/70 mb-1">Connected accounts</div>
          <div className="text-2xl font-bold tabular-nums text-foreground">{accounts.length}</div>
        </div>
        <div className="bg-card/60 border border-border/60 rounded-xl px-4 py-3">
          <div className="text-[9px] font-semibold uppercase tracking-[0.18em] text-muted-foreground/70 mb-1">Last import</div>
          <div className="text-sm font-semibold text-foreground mt-1">
            {lastImport ? new Date(lastImport.created_at).toLocaleDateString("en-US", { month: "short", day: "numeric" }) : "—"}
          </div>
        </div>
      </div>

      {/* Weakest-dimension callout */}
      <div className="flex items-start gap-2.5 bg-card/60 border border-yellow-400/25 rounded-xl px-4 py-3">
        <AlertTriangle className="w-4 h-4 text-yellow-400 shrink-0 mt-0.5" />
        <div>
          <div className="text-xs font-semibold text-foreground">Weakest dimension: {weakest.label} ({sq[weakest.key] as number}/100)</div>
          <p className="text-xs text-muted-foreground mt-0.5">{weakest.hint}. Improving this raises decision confidence across the whole loop.</p>
        </div>
      </div>

      {/* Dimension bars */}
      <div className="bg-card/60 border border-border/60 rounded-xl px-4 py-3.5">
        <div className="text-[9px] font-semibold uppercase tracking-[0.18em] text-muted-foreground/70 mb-3">Signal dimensions</div>
        <div className="grid grid-cols-2 gap-x-8 gap-y-3">
          {SIGNAL_DIMENSIONS.map(dim => {
            const v = sq[dim.key] as number;
            return (
              <div key={dim.key} data-testid={`signal-dim-${dim.key}`}>
                <div className="flex items-baseline justify-between mb-1">
                  <span className="text-xs text-foreground">{dim.label}</span>
                  <span className={cn("text-xs font-semibold tabular-nums", scoreColor(v))}>{v}</span>
                </div>
                <div className="h-1.5 rounded-full bg-white/5 overflow-hidden">
                  <div className={cn("h-full rounded-full", barColor(v))} style={{ width: `${v}%` }} />
                </div>
                <div className="text-[10px] text-muted-foreground/60 mt-0.5">{dim.hint}</div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Bottom action strip */}
      <div className="bg-card/60 border border-border/60 rounded-xl px-4 py-3.5">
        <div className="text-[9px] font-semibold uppercase tracking-[0.18em] text-muted-foreground/70 mb-2.5">Next step</div>
        <div className="flex items-start justify-between gap-6">
          <div className="flex-1 min-w-0">
            <p className="text-xs font-semibold text-foreground">
              Resolve <span className="text-yellow-400">{weakest.label}</span> ({sq[weakest.key] as number}/100)
            </p>
            <p className="text-[11px] text-muted-foreground mt-1 leading-relaxed">
              {weakest.hint}. Fixing this dimension raises decision confidence across the entire IAP loop — especially for runs with {sq.overall < 70 ? "sub-70 overall signal" : "borderline confidence scores"}.
            </p>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <Link
              href="/app/listen/imports"
              className="px-3 py-1.5 rounded-lg border border-border/60 text-[11px] text-muted-foreground hover:text-foreground hover:border-border transition-colors"
            >
              Review imports
            </Link>
            <Link
              href={`/app/analysis/library/${latest.id}`}
              className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-primary/10 border border-primary/25 text-[11px] text-primary hover:bg-primary/20 transition-colors"
            >
              Open run <ArrowUpRight className="w-3 h-3" />
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
