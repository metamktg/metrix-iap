// ═══════════════════════════════════════════════════════════════════════
// METRIX IAP — Agency Overview ("/")
// Mirrors live app.metrix.ad: Metrix Manager rollup — bottom-line totals,
// results by event, flat ad-account list, and account recommendations.
// ═══════════════════════════════════════════════════════════════════════

import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { ArrowRight, Building2, Briefcase, Plus, Info } from "lucide-react";
import { ACCOUNTS } from "@/lib/mock-data";

// Agency-level rollups (mirrors live account: Mar 1 – Jul 13, 2026)
const AGENCY_TOTALS = [
  { label: "Total Spend", value: "$15,190.04" },
  { label: "Impressions", value: "2,634,777" },
  { label: "Link Clicks", value: "10,529" },
  { label: "Link CTR", value: "0.40%" },
];

const RESULTS_BY_EVENT = [
  { label: "Mobile app installs", count: "486", spend: "$4,766.02", clicks: "4,402" },
  { label: "Trials", count: "0", spend: "$787.09", clicks: "284" },
  { label: "Registrations", count: "78", spend: "$701.29", clicks: "485" },
  { label: "Checkouts", count: "0", spend: "$1,746.44", clicks: "677" },
  { label: "Purchases", count: "26", spend: "$6,862.11", clicks: "3,807" },
  { label: "unknown", count: "0", spend: "$0.00", clicks: "273" },
  { label: "Website checkouts initiated", count: "33", spend: "$327.10", clicks: "304" },
  { label: "Results", count: "0", spend: "$0.00", clicks: "297" },
];

interface AgencyRec {
  accountName: string;
  slug: string;
  category: string;
  impact: string;
  confidence: string;
  text: string;
  source?: string;
}

const IMPACT_STYLE: Record<string, string> = {
  "HIGH IMPACT": "text-[hsl(var(--metrix-gold))] bg-[hsl(var(--metrix-gold)/0.12)] border-[hsl(var(--metrix-gold)/0.25)]",
  "MEDIUM IMPACT": "bg-primary/15 text-primary border-primary/25",
  "SETUP IMPACT": "bg-muted text-muted-foreground border-border/40",
};

export function AgencyOverview() {
  const [, navigate] = useLocation();

  const configured = ACCOUNTS.filter(a => a.configured !== false);
  const unconfigured = ACCOUNTS.filter(a => a.configured === false);

  const recommendations: AgencyRec[] = [
    {
      accountName: "Bookster", slug: "bookster", category: "CREATIVE",
      impact: "HIGH IMPACT", confidence: "Medium",
      text: "Aspirational authority / \u201clearn like people you admire\u201d is the current checkout-depth control.",
      source: "core_reanalysis_read.primary_control",
    },
    {
      accountName: "Bookster", slug: "bookster", category: "FUNNEL",
      impact: "HIGH IMPACT", confidence: "High",
      text: "Time-poor learner product demo / 1,000 books proof unlocks registration but weakens at checkout depth.",
      source: "core_reanalysis_read.registration_control",
    },
    {
      accountName: "Bookster", slug: "bookster", category: "PLACEMENT",
      impact: "MEDIUM IMPACT", confidence: "Directional",
      text: "Facebook Reels shows the strongest checkout CPA signal.",
      source: "v3_placement_signal",
    },
    ...unconfigured.map(a => ({
      accountName: a.name, slug: a.slug, category: "AD_ACCOUNT",
      impact: "SETUP IMPACT", confidence: "system",
      text: `${a.name} is not configured.`,
    })),
  ];

  return (
    <div className="h-full overflow-y-auto">
      <div className="max-w-6xl mx-auto px-6 py-5 space-y-4">

        {/* Header */}
        <div className="flex items-start justify-between">
          <div>
            <div className="text-[9px] font-semibold uppercase tracking-[0.18em] text-muted-foreground/60 mb-1">
              Agency
            </div>
            <h1 className="text-2xl font-bold text-foreground tracking-tight">Metrix Manager</h1>
            <p className="text-xs text-muted-foreground mt-1">
              {configured.length} configured · {unconfigured.length} to set up
            </p>
          </div>
          <span className="text-[10px] font-mono text-muted-foreground pt-1.5">
            Mar 1, 2026 – Jul 13, 2026
          </span>
        </div>

        {/* Bottom-line totals */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-[9px] font-semibold uppercase tracking-[0.18em] text-muted-foreground/70">
              Bottom-Line Totals
            </span>
            <button className="text-[10px] text-muted-foreground hover:text-foreground border border-border/50 rounded px-2 py-1 transition-colors">
              Customize metrics
            </button>
          </div>
          <div className="grid grid-cols-4 gap-3">
            {AGENCY_TOTALS.map(m => (
              <div key={m.label} className="bg-card border border-border/60 rounded-xl px-4 py-3">
                <div className="text-[9px] font-semibold uppercase tracking-[0.16em] text-muted-foreground/70">
                  {m.label}
                </div>
                <div className="text-xl font-bold text-foreground mt-1.5">{m.value}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Results by event */}
        <div className="space-y-2">
          <span className="text-[9px] font-semibold uppercase tracking-[0.18em] text-muted-foreground/70">
            Results by Event
          </span>
          <div className="grid grid-cols-4 gap-3">
            {RESULTS_BY_EVENT.map(ev => (
              <div key={ev.label} className="bg-card border border-border/60 rounded-xl px-4 py-3">
                <div className="text-[10px] font-medium text-muted-foreground">{ev.label}</div>
                <div className={cn(
                  "text-xl font-bold mt-1",
                  ev.count !== "0" ? "text-foreground" : "text-muted-foreground/60"
                )}>
                  {ev.count}
                </div>
                <div className="text-[10px] text-muted-foreground/70 mt-1.5 space-y-0.5">
                  <div>Spend {ev.spend}</div>
                  <div>Clicks {ev.clicks}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Ad accounts */}
        <div className="space-y-2">
          <span className="text-[9px] font-semibold uppercase tracking-[0.18em] text-muted-foreground/70">
            Ad Accounts
          </span>
          <div className="grid grid-cols-2 gap-2">
            {ACCOUNTS.map(account => {
              const isUnconfigured = account.configured === false;
              return (
                <button
                  key={account.id}
                  onClick={() => navigate(`/app/account?account=${account.slug}`)}
                  className="flex items-center gap-2.5 px-3 py-2.5 rounded-xl border border-border/60 bg-card hover:border-primary/30 hover:bg-primary/5 transition-all text-left group"
                  data-testid={`button-open-account-${account.slug}`}
                >
                  <div className={cn(
                    "w-7 h-7 rounded-md border flex items-center justify-center shrink-0",
                    isUnconfigured ? "bg-white/5 border-border/40" : "bg-primary/15 border-primary/20"
                  )}>
                    <Briefcase className={cn("w-3.5 h-3.5", isUnconfigured ? "text-muted-foreground" : "text-primary")} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-xs font-medium text-foreground truncate">{account.name}</div>
                    <div className={cn(
                      "text-[10px] truncate",
                      isUnconfigured ? "text-yellow-400" : "text-muted-foreground"
                    )}>
                      {isUnconfigured ? "Setup Required" : `${account.platform_label ?? "Meta Ads"} · Connected`}
                    </div>
                  </div>
                  <ArrowRight className="w-3 h-3 text-muted-foreground/40 group-hover:text-primary transition-colors shrink-0" />
                </button>
              );
            })}
            <Link
              href="/app/settings/integrations"
              className="flex items-center gap-2.5 px-3 py-2.5 rounded-xl border border-dashed border-border/60 hover:border-primary/30 hover:bg-primary/5 transition-all text-left group"
              data-testid="link-add-account"
            >
              <div className="w-7 h-7 rounded-md border border-dashed border-border/60 flex items-center justify-center shrink-0">
                <Plus className="w-3.5 h-3.5 text-muted-foreground" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-xs font-medium text-foreground">Add or connect an ad account</div>
                <div className="text-[10px] text-muted-foreground">Connect Meta or add a manual import</div>
              </div>
            </Link>
          </div>
        </div>

        {/* Account recommendations */}
        <div className="space-y-2">
          <span className="text-[9px] font-semibold uppercase tracking-[0.18em] text-muted-foreground/70">
            Account Recommendations
          </span>
          <div className="grid grid-cols-2 gap-2.5">
            {recommendations.map((rec, i) => (
              <div key={i} className="bg-card/60 border border-border/60 rounded-xl px-4 py-3.5" data-testid={`agency-rec-${i}`}>
                <div className="flex items-center gap-1.5 flex-wrap">
                  <span className="text-[9px] font-bold uppercase tracking-[0.14em] text-foreground/80">
                    {rec.accountName}
                  </span>
                  <span className="text-[9px] font-mono uppercase text-muted-foreground/60">{rec.category}</span>
                  <span className={cn(
                    "text-[9px] font-semibold px-1.5 py-0.5 rounded border leading-none uppercase tracking-wide",
                    IMPACT_STYLE[rec.impact] ?? IMPACT_STYLE["MEDIUM IMPACT"]
                  )}>
                    {rec.impact}
                  </span>
                  <span className="text-[9px] font-mono text-muted-foreground/60">{rec.confidence}</span>
                </div>
                <p className="text-xs text-foreground/90 mt-2 leading-relaxed">{rec.text}</p>
                <div className="flex items-center justify-between gap-2 mt-2.5 pt-2 border-t border-border/40">
                  {rec.source ? (
                    <span className="text-[9px] font-mono text-muted-foreground/50 truncate">{rec.source}</span>
                  ) : <span />}
                  <button
                    onClick={() => navigate(`/app/account?account=${rec.slug}`)}
                    className="text-[11px] text-primary hover:text-primary/80 transition-colors shrink-0 flex items-center gap-1"
                    data-testid={`button-rec-open-${rec.slug}-${i}`}
                  >
                    Open {rec.accountName} <ArrowRight className="w-3 h-3" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Sample data note */}
        <div className="flex items-center gap-2 px-3 py-2 rounded-lg bg-primary/5 border border-primary/15 text-[11px] text-muted-foreground">
          <Info className="w-3.5 h-3.5 shrink-0 text-primary/60" />
          <span><strong className="text-foreground">Sample data:</strong> Bookster carries the richest dataset. Other accounts are lightly populated.</span>
        </div>

        <div className="flex items-center gap-2 text-[10px] text-muted-foreground/50">
          <Building2 className="w-3 h-3" />
          Agency workspace · Metrix Manager
        </div>

      </div>
    </div>
  );
}
