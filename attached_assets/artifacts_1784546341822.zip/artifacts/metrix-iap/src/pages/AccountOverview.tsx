// ═══════════════════════════════════════════════════════════════════════
// METRIX IAP — Account Overview (/app/account?account=<slug>)
// Mirrors live app.metrix.ad account home: IAP loop, account totals,
// current focus, results by event, and core controls.
// ═══════════════════════════════════════════════════════════════════════

import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import {
  Zap, ArrowRight, Upload, ChevronRight, Database, BarChart3,
  Compass, FileText, ClipboardList, Table2, Sparkles, Info,
  CircleAlert, Radio,
} from "lucide-react";
import { useWorkspace } from "@/contexts/WorkspaceContext";
import { AD_ACCOUNTS, ANALYSIS_RUNS, IMPORTS } from "@/lib/mock-data";
import {
  getAccountOverview, IAP_LOOP_STAGES,
  type AccountOverview as AccountOverviewData, type IapLoopStage,
} from "@/lib/mock/account-overview";
import type { AnalysisRun } from "@/lib/types";

// ─── Helpers ──────────────────────────────────────────────────────────

const money = (n: number) =>
  n.toLocaleString("en-US", { style: "currency", currency: "USD" });

const num = (n: number) => n.toLocaleString("en-US");

function fmtDate(d: string) {
  return new Date(d + "T00:00:00").toLocaleDateString("en-US", {
    month: "short", day: "numeric", year: "numeric",
  });
}

// ─── IAP Loop stepper ─────────────────────────────────────────────────

const STAGE_ICONS: Record<IapLoopStage, React.ComponentType<{ className?: string }>> = {
  Data: Database,
  Analysis: BarChart3,
  Strategy: Compass,
  Briefs: FileText,
  Report: ClipboardList,
};

function IapLoop({ overview }: { overview: AccountOverviewData }) {
  const currentIdx = IAP_LOOP_STAGES.indexOf(overview.loop_stage);
  return (
    <div className="bg-card/60 border border-border/60 rounded-xl px-4 py-3">
      <div className="flex items-center justify-between mb-2.5">
        <span className="text-[9px] font-semibold uppercase tracking-[0.18em] text-muted-foreground/70">
          IAP Loop
        </span>
        <span className="text-[10px] font-mono text-muted-foreground/60">{overview.loop_cycle}</span>
      </div>
      <div className="grid grid-cols-5 gap-2.5">
        {IAP_LOOP_STAGES.map((stage, i) => {
          const Icon = STAGE_ICONS[stage];
          const isCurrent = i === currentIdx;
          const isPast = i < currentIdx;
          return (
            <div
              key={stage}
              className={cn(
                "flex flex-col items-center gap-1.5 rounded-lg border px-2 py-3 transition-colors",
                isCurrent
                  ? "border-[hsl(var(--metrix-gold)/0.5)] bg-[hsl(var(--metrix-gold)/0.06)] shadow-[0_0_14px_hsl(var(--metrix-gold)/0.12)]"
                  : isPast
                  ? "border-[hsl(var(--metrix-cyan)/0.3)] bg-primary/5"
                  : "border-border/40 bg-transparent opacity-50"
              )}
            >
              <Icon className={cn(
                "w-4 h-4",
                isCurrent ? "text-[hsl(var(--metrix-gold))]" : isPast ? "text-[hsl(var(--metrix-cyan))]" : "text-muted-foreground"
              )} />
              <span className={cn(
                "text-[9px] font-bold uppercase tracking-[0.14em]",
                isCurrent ? "text-[hsl(var(--metrix-gold))]" : isPast ? "text-[hsl(var(--metrix-cyan))]" : "text-muted-foreground"
              )}>
                {stage}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ─── Section label ────────────────────────────────────────────────────

function SectionLabel({ children, hint }: { children: React.ReactNode; hint?: boolean }) {
  return (
    <div className="flex items-center gap-1.5">
      <span className="text-[9px] font-semibold uppercase tracking-[0.18em] text-muted-foreground/70">
        {children}
      </span>
      {hint && <Info className="w-2.5 h-2.5 text-muted-foreground/40" />}
    </div>
  );
}

// ─── Blueprint Account Overview (mirrors live app.metrix.ad) ──────────

function AccountOverviewView({ overview }: { overview: AccountOverviewData }) {
  const [, navigate] = useLocation();

  return (
    <div className="h-full overflow-y-auto">
      <div className="max-w-6xl mx-auto px-6 py-5 space-y-4">

        {/* Header */}
        <div className="flex items-start justify-between">
          <div>
            <div className="text-[9px] font-semibold uppercase tracking-[0.18em] text-muted-foreground/60 mb-1">
              Ad Account
            </div>
            <h1 className="text-2xl font-bold text-foreground tracking-tight">
              {overview.ad_account_label}
            </h1>
          </div>
          <div className="flex items-center gap-3 pt-1">
            <span className="text-[10px] font-mono text-muted-foreground">
              {fmtDate(overview.date_range_start)} – {fmtDate(overview.date_range_end)}
            </span>
            {overview.connected && (
              <span className="flex items-center gap-1.5 text-[10px] font-semibold text-emerald-400">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                {overview.ad_account_label} <span className="text-emerald-400/70 font-mono uppercase tracking-wider">Connected</span>
              </span>
            )}
          </div>
        </div>

        {/* IAP Loop */}
        <IapLoop overview={overview} />

        {/* Account totals */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <SectionLabel>Account Totals</SectionLabel>
            <button className="text-[10px] text-muted-foreground hover:text-foreground border border-border/50 rounded px-2 py-1 transition-colors">
              Customize metrics
            </button>
          </div>
          <div className="grid grid-cols-4 gap-3">
            {[
              { label: "Total Spend", value: money(overview.totals.total_spend) },
              { label: "Impressions", value: num(overview.totals.impressions) },
              { label: "Link Clicks", value: num(overview.totals.link_clicks) },
              { label: "Link CTR", value: `${overview.totals.link_ctr.toFixed(2)}%` },
            ].map((m) => (
              <div key={m.label} className="bg-card border border-border/60 rounded-xl px-4 py-3">
                <div className="text-[9px] font-semibold uppercase tracking-[0.16em] text-muted-foreground/70">
                  {m.label}
                </div>
                <div className="text-xl font-bold text-foreground mt-1.5">{m.value}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Current focus */}
        <div className="space-y-2">
          <SectionLabel hint>Current Focus</SectionLabel>
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-card border border-border/60 rounded-xl px-4 py-3.5 space-y-1.5">
              <div className="flex items-center gap-1.5 text-[11px] font-semibold text-foreground">
                <Sparkles className="w-3 h-3 text-primary" />
                {overview.current_sprint.headline}
              </div>
              <p className="text-xs text-muted-foreground">{overview.current_sprint.detail}</p>
              <button
                onClick={() => navigate(overview.current_sprint.cta_href)}
                className="text-[11px] text-primary hover:text-primary/80 transition-colors flex items-center gap-1"
              >
                {overview.current_sprint.cta_label} <ArrowRight className="w-3 h-3" />
              </button>
            </div>
            <div className="bg-card border border-border/60 rounded-xl px-4 py-3.5 space-y-1.5">
              <div className="flex items-center gap-1.5 text-[11px] font-semibold text-foreground">
                <Zap className="w-3 h-3 text-[hsl(var(--metrix-gold))]" />
                Next action
              </div>
              <p className="text-xs text-muted-foreground">
                {overview.next_action ?? "No recommendations yet."}
              </p>
            </div>
          </div>
        </div>

        {/* Results by event */}
        <div className="space-y-2">
          <SectionLabel hint>Results by Event</SectionLabel>
          <div className="grid grid-cols-4 gap-3">
            {overview.results_by_event.map((ev) => (
              <div key={ev.label} className="bg-card border border-border/60 rounded-xl px-4 py-3">
                <div className="text-[10px] font-medium text-muted-foreground">{ev.label}</div>
                <div className={cn(
                  "text-xl font-bold mt-1",
                  ev.count > 0 ? "text-foreground" : "text-muted-foreground/60"
                )}>
                  {num(ev.count)}
                </div>
                <div className="text-[10px] text-muted-foreground/70 mt-1.5 space-y-0.5">
                  <div>Spend {money(ev.spend)}</div>
                  <div>Clicks {num(ev.clicks)}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Core controls */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <SectionLabel hint>Core Controls</SectionLabel>
            <button
              onClick={() => navigate("/app/creative-library")}
              className="text-[10px] text-muted-foreground hover:text-foreground border border-border/50 rounded px-2 py-1 transition-colors flex items-center gap-1"
            >
              <Table2 className="w-2.5 h-2.5" /> 1 table
            </button>
          </div>
          <div className="grid grid-cols-2 gap-3">
            {overview.core_controls.map((c) => (
              <div key={c.code} className="bg-card border border-border/60 rounded-xl px-4 py-3.5 space-y-1.5">
                <div className="flex items-center gap-1.5 text-[10px] font-semibold text-primary">
                  <span className="w-1.5 h-1.5 rounded-full bg-primary" />
                  {c.role}
                </div>
                <div className="text-[11px] font-mono text-foreground">{c.code}</div>
                <p className="text-xs text-muted-foreground leading-relaxed">{c.summary}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Data note */}
        {overview.data_note && (
          <div className="flex items-start gap-2 bg-card/60 border border-border/40 rounded-xl px-4 py-3">
            <CircleAlert className="w-3.5 h-3.5 text-yellow-400/80 shrink-0 mt-0.5" />
            <p className="text-[11px] text-muted-foreground leading-relaxed">{overview.data_note}</p>
          </div>
        )}

        {/* Quick links row */}
        <div className="flex items-center gap-2 pt-1">
          <Link
            href="/app/listen/signal"
            className="text-[11px] text-muted-foreground hover:text-foreground border border-border/60 px-3 py-1.5 rounded-lg hover:bg-white/5 transition-all flex items-center gap-1.5"
          >
            <Radio className="w-3 h-3" /> Signal
          </Link>
          <Link
            href="/app/listen/imports"
            className="text-[11px] text-muted-foreground hover:text-foreground border border-border/60 px-3 py-1.5 rounded-lg hover:bg-white/5 transition-all flex items-center gap-1.5"
          >
            <Upload className="w-3 h-3" /> Imports
          </Link>
          <Link
            href="/app/analysis/new-run"
            className="text-[11px] text-white bg-primary hover:bg-primary/90 px-3 py-1.5 rounded-lg font-medium transition-all flex items-center gap-1.5 ml-auto"
          >
            <Zap className="w-3 h-3" /> New IAP Run
          </Link>
        </div>

      </div>
    </div>
  );
}

// ─── Fallback (accounts without connected overview data) ──────────────

function runDisplayLabel(run: AnalysisRun) {
  return `${run.depth} — ${run.objective}`;
}

function FallbackHome({ wsId }: { wsId: string }) {
  const [, navigate] = useLocation();
  const { currentWorkspace } = useWorkspace();

  const accounts = AD_ACCOUNTS.filter(a => a.workspace_id === wsId);
  const runs = ANALYSIS_RUNS
    .filter(r => r.workspace_id === wsId)
    .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
  const imports = IMPORTS.filter(i => i.workspace_id === wsId);
  const latestRun = runs[0];

  return (
    <div className="h-full overflow-y-auto">
      <div className="max-w-5xl mx-auto px-6 py-5 space-y-5">
        <div className="flex items-start justify-between">
          <div className="space-y-1">
            <h1 className="text-2xl font-bold text-foreground tracking-tight">
              {currentWorkspace.name}
            </h1>
            {currentWorkspace.client_name && (
              <p className="text-sm text-muted-foreground">{currentWorkspace.client_name}</p>
            )}
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => navigate("/app/listen/imports")}
              className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground border border-border/60 px-3 py-1.5 rounded-lg hover:bg-white/5 transition-all"
            >
              <Upload className="w-3 h-3" />
              Imports
            </button>
            <button
              onClick={() => navigate("/app/analysis/new-run")}
              className="flex items-center gap-1.5 text-xs text-white bg-primary hover:bg-primary/90 px-3 py-1.5 rounded-lg font-medium transition-all"
            >
              <Zap className="w-3 h-3" />
              New IAP Run
            </button>
          </div>
        </div>

        {accounts.length === 0 ? (
          <div className="bg-card border border-border/60 rounded-xl p-5 space-y-2">
            <div className="flex items-center gap-2">
              <CircleAlert className="w-3.5 h-3.5 text-yellow-400/80" />
              <span className="text-xs font-semibold text-foreground uppercase tracking-wide">
                No connected ad account
              </span>
            </div>
            <p className="text-xs text-muted-foreground leading-relaxed">
              Connect an ad account or import data to unlock the Account Overview.
            </p>
          </div>
        ) : (
          <div className="bg-card/60 border border-border/40 rounded-xl px-4 py-3 flex items-start gap-2">
            <CircleAlert className="w-3.5 h-3.5 text-yellow-400/80 shrink-0 mt-0.5" />
            <p className="text-[11px] text-muted-foreground leading-relaxed">
              Account Overview metrics are pending for this account — sample data only.
              Run an IAP analysis or import fresh data to populate account totals.
            </p>
          </div>
        )}

        <div className="grid grid-cols-3 gap-3">
          {[
            { label: "Connected Platforms", value: accounts.length },
            { label: "Analysis Runs", value: runs.length },
            { label: "Imports", value: imports.length },
          ].map(item => (
            <div key={item.label} className="bg-card border border-border/60 rounded-xl px-4 py-3">
              <div className="text-2xl font-bold leading-none text-foreground">{item.value}</div>
              <div className="text-[11px] font-medium text-muted-foreground mt-1.5">{item.label}</div>
            </div>
          ))}
        </div>

        {accounts.length > 0 && (
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-[9px] font-semibold uppercase tracking-[0.18em] text-muted-foreground/70">
                Connected Platforms
              </span>
              <button
                onClick={() => navigate("/app/listen/signal")}
                className="text-[11px] text-muted-foreground hover:text-foreground transition-colors flex items-center gap-0.5"
              >
                Signal read <ChevronRight className="w-3 h-3" />
              </button>
            </div>
            <div className="space-y-2">
              {accounts.map(account => (
                <button
                  key={account.id}
                  onClick={() => navigate("/app/listen/signal")}
                  className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl border border-border/60 bg-card hover:border-primary/30 hover:bg-primary/5 transition-all text-left group"
                >
                  <div className={cn(
                    "w-2 h-2 rounded-full shrink-0",
                    account.data_quality_score >= 80 ? "bg-emerald-500" :
                    account.data_quality_score >= 60 ? "bg-yellow-400" : "bg-orange-400"
                  )} />
                  <div className="flex-1 min-w-0">
                    <div className="text-xs font-medium text-foreground truncate">{account.account_name}</div>
                    <div className="text-[10px] text-muted-foreground mt-0.5">
                      {account.platform} · {account.open_recommendations} rec{account.open_recommendations !== 1 ? "s" : ""} · DQ {account.data_quality_score}
                    </div>
                  </div>
                  <ArrowRight className="w-3 h-3 text-muted-foreground/40 group-hover:text-primary transition-colors shrink-0" />
                </button>
              ))}
            </div>
          </div>
        )}

        {latestRun && (
          <button
            onClick={() => navigate(`/app/analysis/library/${latestRun.id}`)}
            className="w-full bg-card border border-border/60 rounded-xl p-4 hover:border-primary/30 hover:bg-primary/5 transition-all text-left group flex items-center justify-between"
          >
            <div>
              <div className="text-xs font-semibold text-foreground">{runDisplayLabel(latestRun)}</div>
              <div className="text-[10px] text-muted-foreground mt-1">
                {latestRun.date_range_start} – {latestRun.date_range_end} · {latestRun.status}
              </div>
            </div>
            <ChevronRight className="w-4 h-4 text-muted-foreground/40 group-hover:text-primary transition-colors" />
          </button>
        )}
      </div>
    </div>
  );
}

// ─── AccountOverview ──────────────────────────────────────────────────

export function AccountOverview() {
  const { currentWorkspace } = useWorkspace();
  const overview = getAccountOverview(currentWorkspace.id);

  if (overview) {
    return <AccountOverviewView overview={overview} />;
  }
  return <FallbackHome wsId={currentWorkspace.id} />;
}
