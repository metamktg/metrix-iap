import { useState } from "react";
import { useLocation } from "wouter";
import { cn } from "@/lib/utils";
import {
  Users, TrendingUp, TrendingDown, Flame, ArrowRight,
  ChevronDown, ChevronUp, Layers, Target, CheckCircle2,
} from "lucide-react";
import { useWorkspace } from "@/contexts/WorkspaceContext";
import {
  getAudienceData,
  type AudienceSegment, type FatigueState, type SegAction, type SegConfidence,
} from "@/lib/mock/audience";

// ─── Formatters ────────────────────────────────────────────────────────

const money = (n: number) => `$${n.toLocaleString("en-US", { maximumFractionDigits: 0 })}`;
const money2 = (n: number) => `$${n.toFixed(2)}`;
const num = (n: number) => n.toLocaleString("en-US");

// ─── Derived metrics ───────────────────────────────────────────────────

function cpm(s: AudienceSegment) { return (s.spend / s.impressions) * 1000; }
function ctr(s: AudienceSegment) { return (s.clicks / s.impressions) * 100; }
function cpa(s: AudienceSegment) { return s.installs > 0 ? s.spend / s.installs : 0; }

// ─── Chips ─────────────────────────────────────────────────────────────

const FATIGUE_STYLES: Record<FatigueState, string> = {
  fresh: "text-emerald-400",
  mild_fatigue: "text-yellow-400",
  fatigued: "text-orange-400",
  burnt: "text-red-400",
};

function ActionChip({ a }: { a: SegAction }) {
  const s: Record<SegAction, string> = {
    Scale: "text-emerald-400 border-emerald-500/20 bg-emerald-500/10",
    Hold: "text-primary border-primary/20 bg-primary/10",
    Watch: "text-orange-400 border-orange-400/20 bg-orange-400/10",
    Cut: "text-red-400 border-red-500/20 bg-red-500/10",
  };
  return (
    <span className={cn("text-[9px] px-1.5 py-0.5 rounded border font-semibold leading-none", s[a])}>{a}</span>
  );
}

function ConfChip({ c }: { c: SegConfidence }) {
  const map: Record<SegConfidence, string> = {
    high: "bg-emerald-500/10 border-emerald-500/20 text-emerald-400",
    medium: "bg-yellow-400/10 border-yellow-400/20 text-yellow-400",
    validation_required: "bg-orange-400/10 border-orange-400/20 text-orange-400",
  };
  const labels: Record<SegConfidence, string> = { high: "High", medium: "Med", validation_required: "Validate" };
  return (
    <span className={cn("text-[9px] px-1.5 py-0.5 rounded border font-semibold leading-none", map[c])}>{labels[c]}</span>
  );
}

function TrendPill({ v }: { v: number }) {
  if (v === 0) return <span className="text-[10px] font-mono text-muted-foreground">0%</span>;
  const up = v > 0;
  return (
    <span className={cn("inline-flex items-center gap-0.5 text-[10px] font-mono font-semibold", up ? "text-emerald-400" : "text-red-400")}>
      {up ? <TrendingUp className="w-2.5 h-2.5" /> : <TrendingDown className="w-2.5 h-2.5" />}
      {up ? "+" : ""}{v}%
    </span>
  );
}

// ─── CPA cell (colored vs blended) ─────────────────────────────────────

function CpaCell({ value, blended }: { value: number; blended: number }) {
  if (value === 0) return <span className="text-[11px] font-mono text-muted-foreground/50">—</span>;
  const ratio = value / blended;
  const color = ratio <= 0.9 ? "text-emerald-400" : ratio <= 1.1 ? "text-foreground" : ratio <= 1.5 ? "text-orange-400" : "text-red-400";
  return <span className={cn("text-[11px] font-mono font-semibold", color)}>{money2(value)}</span>;
}

// ─── Spend share bar ───────────────────────────────────────────────────

function ShareBar({ pct, tone }: { pct: number; tone: "gold" | "cyan" | "primary" }) {
  const color = tone === "gold" ? "bg-[hsl(var(--metrix-gold))]" : tone === "cyan" ? "bg-[hsl(var(--metrix-cyan))]" : "bg-primary";
  return (
    <div className="w-16 bg-border/30 rounded-full h-1 overflow-hidden">
      <div className={cn("h-full rounded-full", color)} style={{ width: `${Math.min(100, pct)}%` }} />
    </div>
  );
}

// ─── Audience ──────────────────────────────────────────────────────────

type GenderFilter = "all" | "female" | "male";
type SortKey = "spend" | "installs" | "cpa" | "registrations";

export function Audience() {
  const { currentWorkspace } = useWorkspace();
  const [, navigate] = useLocation();
  const data = getAudienceData(currentWorkspace.id);

  const [gender, setGender] = useState<GenderFilter>("all");
  const [sortKey, setSortKey] = useState<SortKey>("spend");
  const [expanded, setExpanded] = useState<string | null>(null);

  const totalSpend = data.segments.reduce((s, x) => s + x.spend, 0);
  const totalInstalls = data.segments.reduce((s, x) => s + x.installs, 0);
  const totalRegs = data.segments.reduce((s, x) => s + x.registrations, 0);
  const maxSpend = Math.max(...data.segments.map((s) => s.spend));

  const filtered = data.segments.filter((s) => gender === "all" || s.gender === gender);
  const sorted = [...filtered].sort((a, b) => {
    if (sortKey === "cpa") return cpa(a) - cpa(b);
    return b[sortKey] - a[sortKey];
  });

  const efficient = [...data.segments]
    .filter((s) => s.installs >= 10)
    .sort((a, b) => cpa(a) - cpa(b))
    .slice(0, 3);

  const genderLabel = (g: AudienceSegment["gender"]) => (g === "female" ? "F" : g === "male" ? "M" : "U");

  const SortBtn = ({ col, label }: { col: SortKey; label: string }) => (
    <button
      onClick={() => setSortKey(col)}
      className={cn(
        "inline-flex items-center gap-0.5 transition-colors",
        sortKey === col ? "text-foreground" : "text-muted-foreground hover:text-foreground"
      )}
    >
      {label}
      {sortKey === col && <ChevronDown className="w-2.5 h-2.5" />}
    </button>
  );

  return (
    <div className="h-full overflow-y-auto">
      <div className="max-w-6xl mx-auto px-6 py-5 space-y-4">

        {/* Header */}
        <div className="flex items-start justify-between">
          <div className="space-y-0.5">
            <div className="flex items-center gap-2">
              <Users className="w-4 h-4 text-primary" />
              <h1 className="text-xl font-bold text-foreground tracking-tight">Audience</h1>
            </div>
            <p className="text-xs text-muted-foreground">
              {data.account_label} · {data.date_range}
            </p>
          </div>
          <span className="text-[10px] font-mono text-muted-foreground/60 pt-1">
            {data.segments.length} segments · blended CPA {money2(data.blended_cpa)}
          </span>
        </div>

        {/* KPI row */}
        <div className="grid grid-cols-4 gap-3">
          {[
            { label: "Spend Analyzed", value: money(totalSpend), sub: "across segments", color: "text-primary" },
            { label: "Installs", value: num(totalInstalls), sub: `blended CPA ${money2(totalSpend / totalInstalls)}`, color: "text-foreground" },
            { label: "Registrations", value: num(totalRegs), sub: `${((totalRegs / totalInstalls) * 100).toFixed(0)}% of installs`, color: "text-foreground" },
            { label: "Best Segment", value: efficient[0] ? `${genderLabel(efficient[0].gender)} ${efficient[0].age}` : "—", sub: efficient[0] ? `CPA ${money2(cpa(efficient[0]))}` : "", color: "text-emerald-400" },
          ].map((k) => (
            <div key={k.label} className="bg-card border border-border/60 rounded-xl px-4 py-3">
              <div className={cn("text-2xl font-bold leading-none", k.color)}>{k.value}</div>
              <div className="text-[11px] font-medium text-foreground mt-1.5">{k.label}</div>
              <div className="text-[10px] text-muted-foreground mt-0.5">{k.sub}</div>
            </div>
          ))}
        </div>

        {/* Top segments cards */}
        <div className="space-y-2">
          <span className="text-[9px] font-semibold uppercase tracking-[0.18em] text-muted-foreground/70">Top Segments</span>
          <div className="grid grid-cols-3 gap-3">
            {efficient.map((s, i) => (
              <div key={s.id} className="bg-card border border-emerald-500/25 rounded-xl px-4 py-3 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-semibold text-foreground">
                    {genderLabel(s.gender)} {s.age}
                  </span>
                  <span className="text-[9px] px-1.5 py-0.5 rounded border border-emerald-500/20 bg-emerald-500/10 text-emerald-400 font-bold leading-none">
                    #{i + 1}
                  </span>
                </div>
                <div className="grid grid-cols-3 gap-1.5">
                  <div>
                    <div className="text-[13px] font-bold text-emerald-400">{money2(cpa(s))}</div>
                    <div className="text-[9px] text-muted-foreground">CPA</div>
                  </div>
                  <div>
                    <div className="text-[13px] font-bold text-foreground">{num(s.installs)}</div>
                    <div className="text-[9px] text-muted-foreground">Installs</div>
                  </div>
                  <div>
                    <div className="text-[13px] font-bold text-foreground">{num(s.registrations)}</div>
                    <div className="text-[9px] text-muted-foreground">Regs</div>
                  </div>
                </div>
                <div className="flex items-center justify-between pt-1 border-t border-border/30">
                  <span className={cn("text-[10px] capitalize", FATIGUE_STYLES[s.fatigue])}>{s.fatigue.replace("_", " ")}</span>
                  <TrendPill v={s.trend_pct} />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Breakdown table */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-[9px] font-semibold uppercase tracking-[0.18em] text-muted-foreground/70">Age / Gender Breakdown</span>
            <div className="flex items-center gap-1">
              {(["all", "female", "male"] as const).map((g) => (
                <button
                  key={g}
                  onClick={() => setGender(g)}
                  className={cn(
                    "px-2.5 py-1 rounded-full text-[10px] font-medium border transition-all capitalize",
                    gender === g
                      ? "bg-primary/15 border-primary/40 text-primary"
                      : "bg-transparent border-border/50 text-muted-foreground hover:text-foreground"
                  )}
                >
                  {g}
                </button>
              ))}
            </div>
          </div>

          <div className="bg-card border border-border/60 rounded-xl overflow-hidden">
            {/* header row */}
            <div className="grid grid-cols-[minmax(0,1.4fr)_repeat(6,minmax(0,1fr))_auto] gap-2 px-4 py-2 border-b border-border/40 bg-muted/10 text-[9px] font-semibold uppercase tracking-wide text-muted-foreground">
              <span>Segment</span>
              <span className="text-right"><SortBtn col="spend" label="Spend" /></span>
              <span className="text-right">CPM</span>
              <span className="text-right">CTR</span>
              <span className="text-right"><SortBtn col="installs" label="Installs" /></span>
              <span className="text-right"><SortBtn col="cpa" label="CPA" /></span>
              <span className="text-right"><SortBtn col="registrations" label="Regs" /></span>
              <span className="text-right w-14">Trend</span>
            </div>
            {sorted.map((s, i) => (
              <div
                key={s.id}
                className={cn(
                  "grid grid-cols-[minmax(0,1.4fr)_repeat(6,minmax(0,1fr))_auto] gap-2 px-4 py-2.5 items-center hover:bg-white/[0.02] transition-colors",
                  i !== sorted.length - 1 && "border-b border-border/20"
                )}
              >
                <div className="flex items-center gap-2 min-w-0">
                  <span className="text-[11px] font-medium text-foreground shrink-0">
                    {genderLabel(s.gender)} {s.age}
                  </span>
                  <span className={cn("w-1 h-1 rounded-full shrink-0", FATIGUE_STYLES[s.fatigue].replace("text-", "bg-"))} />
                </div>
                <div className="flex items-center justify-end gap-1.5">
                  <ShareBar pct={(s.spend / maxSpend) * 100} tone="cyan" />
                  <span className="text-[11px] font-mono text-foreground w-10 text-right">{money(s.spend)}</span>
                </div>
                <span className="text-[11px] font-mono text-muted-foreground text-right">{money2(cpm(s))}</span>
                <span className="text-[11px] font-mono text-muted-foreground text-right">{ctr(s).toFixed(2)}%</span>
                <span className="text-[11px] font-mono text-foreground text-right">{num(s.installs)}</span>
                <span className="text-right"><CpaCell value={cpa(s)} blended={data.blended_cpa} /></span>
                <span className="text-[11px] font-mono text-foreground text-right">{num(s.registrations)}</span>
                <span className="text-right w-14"><TrendPill v={s.trend_pct} /></span>
              </div>
            ))}
          </div>
        </div>

        {/* Overlap + fatigue */}
        <div className="grid grid-cols-2 gap-3">
          {/* Overlap */}
          <div className="bg-card border border-border/60 rounded-xl px-4 py-3 space-y-2.5">
            <div className="flex items-center gap-1.5">
              <Layers className="w-3 h-3 text-[hsl(var(--metrix-cyan))]" />
              <span className="text-[9px] font-semibold uppercase tracking-[0.18em] text-muted-foreground/70">Audience Overlap</span>
            </div>
            {data.overlaps.map((o, i) => (
              <div key={i} className="space-y-1">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] text-foreground font-medium">{o.a} <span className="text-muted-foreground/50">×</span> {o.b}</span>
                  <span className={cn(
                    "text-[11px] font-mono font-semibold",
                    o.overlap_pct >= 30 ? "text-red-400" : o.overlap_pct >= 20 ? "text-orange-400" : "text-yellow-400"
                  )}>{o.overlap_pct}%</span>
                </div>
                <div className="w-full bg-border/30 rounded-full h-1 overflow-hidden">
                  <div className={cn(
                    "h-full rounded-full",
                    o.overlap_pct >= 30 ? "bg-red-400" : o.overlap_pct >= 20 ? "bg-orange-400" : "bg-yellow-400"
                  )} style={{ width: `${o.overlap_pct}%` }} />
                </div>
                <p className="text-[10px] text-muted-foreground leading-snug">{o.note}</p>
              </div>
            ))}
          </div>

          {/* Fatigue */}
          <div className="bg-card border border-border/60 rounded-xl px-4 py-3 space-y-2">
            <div className="flex items-center gap-1.5">
              <Flame className="w-3 h-3 text-orange-400" />
              <span className="text-[9px] font-semibold uppercase tracking-[0.18em] text-muted-foreground/70">Fatigue Indicators</span>
            </div>
            {(["fresh", "mild_fatigue", "fatigued", "burnt"] as FatigueState[]).map((f) => {
              const segs = data.segments.filter((s) => s.fatigue === f);
              if (segs.length === 0) return null;
              return (
                <div key={f} className="flex items-start gap-2 py-1 border-b border-border/20 last:border-0">
                  <span className={cn("text-[10px] font-semibold capitalize w-20 shrink-0", FATIGUE_STYLES[f])}>{f.replace("_", " ")}</span>
                  <div className="flex-1 flex flex-wrap gap-1">
                    {segs.map((s) => (
                      <span key={s.id} className="text-[9px] px-1.5 py-0.5 rounded border border-border/40 bg-muted/30 text-muted-foreground font-mono">
                        {genderLabel(s.gender)} {s.age} · {s.frequency.toFixed(1)}×
                      </span>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Segment recommendations */}
        <div className="space-y-2">
          <span className="text-[9px] font-semibold uppercase tracking-[0.18em] text-muted-foreground/70">Segment Recommendations</span>
          <div className="space-y-2">
            {data.recommendations.map((r) => {
              const open = expanded === r.id;
              return (
                <div key={r.id} className="bg-card border border-border/60 rounded-xl overflow-hidden">
                  <button
                    onClick={() => setExpanded(open ? null : r.id)}
                    className="w-full flex items-center gap-3 px-4 py-2.5 text-left hover:bg-white/[0.02] transition-colors"
                  >
                    <ActionChip a={r.action} />
                    <span className="text-[11px] font-semibold text-foreground w-28 shrink-0">{r.segment}</span>
                    <span className="text-[11px] text-muted-foreground flex-1 truncate">{r.rationale}</span>
                    <ConfChip c={r.confidence} />
                    {open ? <ChevronUp className="w-3.5 h-3.5 text-muted-foreground shrink-0" /> : <ChevronDown className="w-3.5 h-3.5 text-muted-foreground shrink-0" />}
                  </button>
                  {open && (
                    <div className="px-4 pb-3 pt-1 border-t border-border/20 space-y-2">
                      <p className="text-[11px] text-muted-foreground leading-relaxed border-l-2 border-primary/30 pl-3">{r.rationale}</p>
                      <button
                        onClick={() => navigate("/app/iap/new")}
                        className="text-[11px] text-primary hover:text-primary/80 transition-colors flex items-center gap-1"
                      >
                        Brief next sprint <ArrowRight className="w-3 h-3" />
                      </button>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Footer stat strip */}
        <div className="flex items-center gap-4 bg-card/60 border border-border/40 rounded-xl px-4 py-2.5">
          <div className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
            <Target className="w-3 h-3 text-[hsl(var(--metrix-gold))]" />
            <span className="text-foreground font-semibold">{data.recommendations.filter((r) => r.action === "Scale").length}</span> scale
          </div>
          <div className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
            <CheckCircle2 className="w-3 h-3 text-emerald-400" />
            <span className="text-foreground font-semibold">{data.recommendations.filter((r) => r.action === "Hold").length}</span> hold
          </div>
          <div className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
            <Flame className="w-3 h-3 text-red-400" />
            <span className="text-foreground font-semibold">{data.recommendations.filter((r) => r.action === "Cut").length}</span> cut
          </div>
        </div>

      </div>
    </div>
  );
}
