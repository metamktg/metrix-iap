// ═══════════════════════════════════════════════════════════════════════
// METRIX IAP — Report Builder › Settings
// Report defaults for the selected account: branding, cadence, sections,
// recipients. All state is local (prototype).
// ═══════════════════════════════════════════════════════════════════════

import { useState } from "react";
import { Check } from "lucide-react";
import { cn } from "@/lib/utils";
import { useCurrentWorkspace } from "@/contexts/WorkspaceContext";
import { useToast } from "@/hooks/use-toast";

const SECTION_DEFAULTS = [
  { id: "exec", label: "Executive summary", on: true },
  { id: "signal", label: "Signal quality read", on: true },
  { id: "decisions", label: "Decision feed", on: true },
  { id: "creative", label: "Creative DNA breakdown", on: true },
  { id: "benchmarks", label: "Benchmark comparison", on: false },
  { id: "appendix", label: "Raw data appendix", on: false },
];

const CADENCES = ["Weekly", "Bi-weekly", "Monthly", "On demand"] as const;

export function ReportSettings() {
  const ws = useCurrentWorkspace();
  const { toast } = useToast();

  const [sections, setSections] = useState(SECTION_DEFAULTS);
  const [cadence, setCadence] = useState<(typeof CADENCES)[number]>("Monthly");
  const [recipients, setRecipients] = useState("team@metamktgagency.com");
  const [clientBranding, setClientBranding] = useState(true);
  const [autoSend, setAutoSend] = useState(false);

  function toggleSection(id: string) {
    setSections(prev => prev.map(s => (s.id === id ? { ...s, on: !s.on } : s)));
  }

  function save() {
    toast({ title: "Report settings saved", description: `Defaults updated for ${ws.name}.` });
  }

  return (
    <div className="flex-1 p-5 space-y-4 max-w-3xl">
      <div>
        <h1 className="text-lg font-bold text-foreground tracking-tight">Report Settings</h1>
        <p className="text-xs text-muted-foreground mt-0.5">Default template and delivery for {ws.name} reports.</p>
      </div>

      {/* Branding */}
      <div className="bg-card/60 border border-border/60 rounded-xl px-4 py-3.5 space-y-3">
        <div className="text-[9px] font-semibold uppercase tracking-[0.18em] text-muted-foreground/70">Branding</div>
        <label className="flex items-center justify-between cursor-pointer">
          <div>
            <div className="text-xs font-medium text-foreground">Use client branding</div>
            <div className="text-[11px] text-muted-foreground">Cover page and headers use the account's logo and palette.</div>
          </div>
          <button
            onClick={() => setClientBranding(v => !v)}
            className={cn(
              "w-9 h-5 rounded-full transition-colors relative shrink-0",
              clientBranding ? "bg-primary" : "bg-white/10"
            )}
            data-testid="toggle-client-branding"
          >
            <span className={cn(
              "absolute top-0.5 w-4 h-4 rounded-full bg-white transition-all",
              clientBranding ? "left-[18px]" : "left-0.5"
            )} />
          </button>
        </label>
      </div>

      {/* Default sections */}
      <div className="bg-card/60 border border-border/60 rounded-xl px-4 py-3.5 space-y-2.5">
        <div className="text-[9px] font-semibold uppercase tracking-[0.18em] text-muted-foreground/70">Default sections</div>
        <div className="grid grid-cols-2 gap-1.5">
          {sections.map(s => (
            <button
              key={s.id}
              onClick={() => toggleSection(s.id)}
              className={cn(
                "flex items-center gap-2 px-2.5 py-2 rounded-lg border text-left transition-colors",
                s.on
                  ? "border-primary/25 bg-primary/10 text-foreground"
                  : "border-border/40 text-muted-foreground hover:text-foreground hover:bg-white/5"
              )}
              data-testid={`toggle-section-${s.id}`}
            >
              <span className={cn(
                "w-3.5 h-3.5 rounded border flex items-center justify-center shrink-0",
                s.on ? "bg-primary border-primary" : "border-border"
              )}>
                {s.on && <Check className="w-2.5 h-2.5 text-primary-foreground" />}
              </span>
              <span className="text-xs">{s.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Delivery */}
      <div className="bg-card/60 border border-border/60 rounded-xl px-4 py-3.5 space-y-3">
        <div className="text-[9px] font-semibold uppercase tracking-[0.18em] text-muted-foreground/70">Delivery</div>
        <div>
          <div className="text-xs font-medium text-foreground mb-1.5">Cadence</div>
          <div className="flex items-center gap-1.5">
            {CADENCES.map(c => (
              <button
                key={c}
                onClick={() => setCadence(c)}
                className={cn(
                  "px-2.5 py-1 rounded-md text-[11px] font-medium border transition-colors",
                  cadence === c
                    ? "bg-primary/15 text-primary border-primary/25"
                    : "text-muted-foreground border-border/40 hover:text-foreground hover:bg-white/5"
                )}
                data-testid={`cadence-${c.toLowerCase().replace(" ", "-")}`}
              >
                {c}
              </button>
            ))}
          </div>
        </div>
        <div>
          <div className="text-xs font-medium text-foreground mb-1.5">Recipients</div>
          <input
            value={recipients}
            onChange={e => setRecipients(e.target.value)}
            className="w-full bg-background border border-border/60 rounded-lg px-3 py-2 text-xs text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:border-primary/50"
            placeholder="comma-separated emails"
            data-testid="input-recipients"
          />
        </div>
        <label className="flex items-center justify-between cursor-pointer">
          <div>
            <div className="text-xs font-medium text-foreground">Auto-send on completion</div>
            <div className="text-[11px] text-muted-foreground">Deliver automatically when a scheduled report finishes.</div>
          </div>
          <button
            onClick={() => setAutoSend(v => !v)}
            className={cn(
              "w-9 h-5 rounded-full transition-colors relative shrink-0",
              autoSend ? "bg-primary" : "bg-white/10"
            )}
            data-testid="toggle-auto-send"
          >
            <span className={cn(
              "absolute top-0.5 w-4 h-4 rounded-full bg-white transition-all",
              autoSend ? "left-[18px]" : "left-0.5"
            )} />
          </button>
        </label>
      </div>

      <div className="flex justify-end">
        <button
          onClick={save}
          className="px-4 py-2 rounded-lg bg-primary text-primary-foreground text-xs font-semibold hover:opacity-90 transition-opacity"
          data-testid="button-save-settings"
        >
          Save defaults
        </button>
      </div>
    </div>
  );
}
