import { useMemo, useState } from "react";
import { useLocation } from "wouter";
import { cn } from "@/lib/utils";
import {
  Network, Trophy, ChevronRight, Building2, Globe, ArrowRight,
  CheckCircle2, Sparkles, TrendingDown, TrendingUp,
} from "lucide-react";
import { useWorkspace } from "@/contexts/WorkspaceContext";
import {
  BENCHMARK_VERTICALS, PATTERN_MATCHES, VALIDATED_STACKS, getVertical,
  type MatchStatus, type PatternMatch,
} from "@/lib/mock/crossmap";

// ─── Helpers ──────────────────────────────────────────────────────────

const FAMILY_COLORS: Record<string, string> = {
  HK: "text-primary bg-primary/10 border-primary/20",
  FW: "text-purple-400 bg-purple-500/10 border-purple-500/20",
  TN: "text-blue-400 bg-blue-500/10 border-blue-500/20",
  CN: "text-emerald-400 bg-emerald-500/10 border-emerald-500/20",
  CTA: "text-yellow-400 bg-yellow-400/10 border-yellow-400/20",
};

function labelOf(code: string): string {
  const i = code.indexOf("_");
  return i === -1 ? code : code.slice(i + 1);
}

function VarChip({ code }: { code: string }) {
  const fam = code.split("_")[0];
  return (
    <span className={cn(
      "text-[9px] px-1.5 py-0.5 rounded border font-medium leading-none whitespace-nowrap",
      FAMILY_COLORS[fam] ?? "text-muted-foreground bg-muted border-border/40"
    )}>
      <span className="font-mono opacity-60">{fam}</span> {labelOf(code)}
    </span>
  );
}

const STATUS_META: Record<MatchStatus, { label: string; chip: string; text: string; dot: string }> = {
  validated: { label: "Validated", chip: "bg-emerald-500/10 border-emerald-500/20 text-emerald-400", text: "text-emerald-400", dot: "bg-emerald-500" },
  promising: { label: "Promising", chip: "bg-yellow-400/10 border-yellow-400/20 text-yellow-400", text: "text-yellow-400", dot: "bg-yellow-400" },
  divergent: { label: "Divergent", chip: "bg-red-500/10 border-red-500/20 text-red-400", text: "text-red-400", dot: "bg-red-500" },
};

function transferColor(t: number): string {
  return t >= 80 ? "bg-emerald-500" : t >= 60 ? "bg-yellow-400" : t >= 45 ? "bg-orange-400" : "bg-red-400";
}
function transferText(t: number): string {
  return t >= 80 ? "text-emerald-400" : t >= 60 ? "text-yellow-400" : t >= 45 ? "text-orange-400" : "text-red-400";
}

const money = (n: number) => `$${n.toLocaleString("en-US")}`;

// ─── Transferability bar ──────────────────────────────────────────────

function TransferBar({ value }: { value: number }) {
  return (
    <div className="flex items-center gap-2">
      <div className="flex-1 bg-border/30 rounded-full h-1.5 overflow-hidden">
        <div className={cn("h-full rounded-full transition-all", transferColor(value))} style={{ width: `${value}%` }} />
      </div>
      <span className={cn("text-[11px] font-mono font-bold w-8 text-right", transferText(value))}>{value}</span>
    </div>
  );
}

// ─── Pattern match card ───────────────────────────────────────────────

function MatchCard({ m }: { m: PatternMatch }) {
  const [open, setOpen] = useState(false);
  const vert = getVertical(m.vertical_id);
  const meta = STATUS_META[m.status];
  const cheaper = m.delta_pct < 0;
  const codes = [m.stack.hook, m.stack.framework, m.stack.tone, m.stack.concept, m.stack.cta];

  return (
    <div className={cn(
      "bg-card border rounded-xl overflow-hidden transition-all",
      m.status === "validated" ? "border-emerald-500/25" : "border-border/60"
    )}>
      <button onClick={() => setOpen(o => !o)} className="w-full px-4 py-3 text-left hover:bg-white/[0.02] transition-colors">
        <div className="flex items-center gap-3">
          <span className="text-[11px] font-mono font-bold text-foreground/70 w-9 shrink-0">{m.source_cell}</span>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-1 flex-wrap">
              {codes.map((c, i) => <VarChip key={i} code={c} />)}
            </div>
          </div>
          <div className="w-40 shrink-0 hidden md:flex items-center gap-2">
            {vert?.internal ? <Building2 className="w-3 h-3 text-muted-foreground shrink-0" /> : <Globe className="w-3 h-3 text-muted-foreground shrink-0" />}
            <span className="text-[10px] text-muted-foreground truncate">{vert?.name}</span>
          </div>
          <div className="w-28 shrink-0"><TransferBar value={m.transferability} /></div>
          <span className={cn("text-[9px] px-2 py-1 rounded border font-semibold leading-none shrink-0 w-[76px] text-center", meta.chip)}>
            {meta.label}
          </span>
          <ChevronRight className={cn("w-4 h-4 text-muted-foreground shrink-0 transition-transform", open && "rotate-90")} />
        </div>
      </button>

      {open && (
        <div className="px-4 pb-4 pt-1 border-t border-border/30 space-y-3 bg-muted/[0.03]">
          <div className="grid grid-cols-3 gap-3 pt-3">
            <div className="bg-card border border-border/50 rounded-lg px-3 py-2">
              <div className="text-[9px] uppercase tracking-wide text-muted-foreground/60">Bookster CPR</div>
              <div className="text-sm font-bold text-foreground mt-0.5 font-mono">{money(m.bookster_cpr)}</div>
            </div>
            <div className="bg-card border border-border/50 rounded-lg px-3 py-2">
              <div className="text-[9px] uppercase tracking-wide text-muted-foreground/60">{vert?.name} band</div>
              <div className="text-sm font-bold text-foreground mt-0.5 font-mono">
                {vert ? `${money(vert.cpr_band_min)}–${money(vert.cpr_band_max)}` : money(m.vertical_cpr)}
              </div>
            </div>
            <div className="bg-card border border-border/50 rounded-lg px-3 py-2">
              <div className="text-[9px] uppercase tracking-wide text-muted-foreground/60">Delta vs benchmark</div>
              <div className={cn("text-sm font-bold mt-0.5 font-mono flex items-center gap-1", cheaper ? "text-emerald-400" : "text-orange-400")}>
                {cheaper ? <TrendingDown className="w-3 h-3" /> : <TrendingUp className="w-3 h-3" />}
                {cheaper ? "" : "+"}{m.delta_pct}%
              </div>
            </div>
          </div>
          <div className="flex items-center gap-4 text-[10px] text-muted-foreground">
            <span><span className="font-mono text-foreground">{m.installs}</span> installs</span>
            <span className="text-muted-foreground/30">·</span>
            <span><span className="font-mono text-foreground">{m.registrations}</span> registrations</span>
            <span className="text-muted-foreground/30">·</span>
            <span>{vert?.internal ? "Internal account" : "External ref set"} — {vert?.account_label}</span>
          </div>
          <p className="text-[11px] text-muted-foreground leading-relaxed border-l-2 border-primary/30 pl-3">{m.evidence}</p>
        </div>
      )}
    </div>
  );
}

// ─── CrossmapResults ──────────────────────────────────────────────────

export function CrossmapResults() {
  const { currentWorkspace } = useWorkspace();
  const [, navigate] = useLocation();

  const [tab, setTab] = useState<"matches" | "stacks" | "verticals">("matches");
  const [statusFilter, setStatusFilter] = useState<MatchStatus | "all">("all");

  const matches = statusFilter === "all" ? PATTERN_MATCHES : PATTERN_MATCHES.filter(m => m.status === statusFilter);

  const avgTransfer = useMemo(
    () => Math.round(PATTERN_MATCHES.reduce((s, m) => s + m.transferability, 0) / PATTERN_MATCHES.length),
    []
  );
  const validatedCount = PATTERN_MATCHES.filter(m => m.status === "validated").length;

  const tabs = [
    { id: "matches" as const, label: "Pattern Matches", count: PATTERN_MATCHES.length },
    { id: "stacks" as const, label: "Validated Stacks", count: VALIDATED_STACKS.length },
    { id: "verticals" as const, label: "Benchmark Verticals", count: BENCHMARK_VERTICALS.length },
  ];

  return (
    <div className="h-full overflow-y-auto">
      <div className="max-w-6xl mx-auto px-6 py-5 space-y-4">

        {/* Header */}
        <div className="flex items-start justify-between">
          <div>
            <div className="text-[9px] font-semibold uppercase tracking-[0.18em] text-muted-foreground/60 mb-1">
              MST · Matrix Scaling
            </div>
            <h1 className="text-xl font-bold text-foreground tracking-tight">Crossmap Results</h1>
            <p className="text-xs text-muted-foreground mt-0.5">
              {currentWorkspace.name} · variable stacks vs {BENCHMARK_VERTICALS.length} benchmark verticals
            </p>
          </div>
          <button
            onClick={() => navigate("/app/mst/concept-map")}
            className="text-[11px] text-muted-foreground hover:text-foreground border border-border/60 px-3 py-1.5 rounded-lg hover:bg-white/5 transition-all flex items-center gap-1.5"
          >
            <Network className="w-3 h-3" /> Concept Map
          </button>
        </div>

        {/* Summary strip */}
        <div className="grid grid-cols-4 gap-3">
          {[
            { label: "Pattern Matches", value: PATTERN_MATCHES.length, sub: "stack × vertical", color: "text-foreground" },
            { label: "Avg Transferability", value: avgTransfer, sub: "across matches", color: transferText(avgTransfer) },
            { label: "Validated", value: validatedCount, sub: "confirmed matches", color: "text-emerald-400" },
            { label: "Winning Stacks", value: VALIDATED_STACKS.length, sub: "cross-account", color: "text-[hsl(var(--metrix-gold))]" },
          ].map(m => (
            <div key={m.label} className="bg-card border border-border/60 rounded-xl px-4 py-3">
              <div className={cn("text-xl font-bold leading-none", m.color)}>{m.value}</div>
              <div className="text-[10px] font-medium text-foreground mt-1.5">{m.label}</div>
              <div className="text-[10px] text-muted-foreground mt-0.5">{m.sub}</div>
            </div>
          ))}
        </div>

        {/* Tabs */}
        <div className="flex items-center gap-1 border-b border-border/50">
          {tabs.map(t => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={cn(
                "flex items-center gap-1.5 px-4 py-2.5 text-xs font-medium border-b-2 transition-all -mb-px",
                tab === t.id ? "border-primary text-foreground" : "border-transparent text-muted-foreground hover:text-foreground"
              )}
            >
              {t.label}
              <span className={cn(
                "text-[10px] px-1.5 py-0.5 rounded-full font-semibold",
                tab === t.id ? "bg-primary/15 text-primary" : "bg-muted text-muted-foreground"
              )}>
                {t.count}
              </span>
            </button>
          ))}
        </div>

        {/* ── Pattern Matches ─────────────────────────────────────────── */}
        {tab === "matches" && (
          <div className="space-y-3">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-[10px] text-muted-foreground font-medium">Status:</span>
              {(["all", "validated", "promising", "divergent"] as const).map(s => (
                <button
                  key={s}
                  onClick={() => setStatusFilter(s)}
                  className={cn(
                    "px-3 py-1.5 rounded-full text-[11px] font-medium border transition-all capitalize",
                    statusFilter === s
                      ? "bg-primary/15 border-primary/40 text-primary"
                      : "bg-transparent border-border/50 text-muted-foreground hover:border-border hover:text-foreground"
                  )}
                >
                  {s === "all" ? "All" : s}
                </button>
              ))}
            </div>

            {/* Column header */}
            <div className="hidden md:flex items-center gap-3 px-4 text-[9px] font-semibold uppercase tracking-[0.12em] text-muted-foreground/50">
              <span className="w-9 shrink-0">Cell</span>
              <span className="flex-1">Variable Stack</span>
              <span className="w-40 shrink-0">Vertical</span>
              <span className="w-28 shrink-0">Transfer</span>
              <span className="w-[76px] shrink-0 text-center">Status</span>
              <span className="w-4 shrink-0" />
            </div>

            <div className="space-y-2">
              {matches.map(m => <MatchCard key={m.id} m={m} />)}
            </div>
          </div>
        )}

        {/* ── Validated Stacks ────────────────────────────────────────── */}
        {tab === "stacks" && (
          <div className="space-y-2">
            {VALIDATED_STACKS.map(s => (
              <div key={s.id} className="bg-card border border-border/60 rounded-xl px-4 py-3">
                <div className="flex items-start gap-3">
                  <div className={cn(
                    "flex items-center justify-center w-8 h-8 rounded-lg border shrink-0 font-mono text-xs font-bold",
                    s.rank === 1
                      ? "border-[hsl(var(--metrix-gold)/0.45)] bg-[hsl(var(--metrix-gold)/0.1)] text-[hsl(var(--metrix-gold))]"
                      : "border-border/50 bg-muted/30 text-muted-foreground"
                  )}>
                    {s.rank === 1 ? <Trophy className="w-3.5 h-3.5" /> : `#${s.rank}`}
                  </div>
                  <div className="flex-1 min-w-0 space-y-2">
                    <div className="flex items-center gap-1 flex-wrap">
                      {s.codes.map((c, i) => <VarChip key={i} code={c} />)}
                    </div>
                    <div className="flex items-center gap-4 text-[10px] text-muted-foreground flex-wrap">
                      <span className="flex items-center gap-1 text-emerald-400">
                        <CheckCircle2 className="w-2.5 h-2.5" /> {s.verticals_confirmed} vertical{s.verticals_confirmed !== 1 ? "s" : ""} confirmed
                      </span>
                      <span className="text-muted-foreground/30">·</span>
                      <span>CPR <span className="font-mono text-foreground">{money(s.cpr_usd)}</span></span>
                      <span className="text-muted-foreground/30">·</span>
                      <span>Reg-rate lift <span className="font-mono text-emerald-400">+{s.lift_pct}%</span></span>
                      <span className="text-muted-foreground/30">·</span>
                      <span><span className="font-mono text-foreground">{s.registrations}</span> regs · {money(s.spend_usd)}</span>
                    </div>
                    <p className="text-[11px] text-muted-foreground leading-relaxed">{s.evidence}</p>
                  </div>
                  <div className="shrink-0 text-right space-y-1.5 w-28">
                    <TransferBar value={s.transferability} />
                    <span className="text-[9px] px-1.5 py-0.5 rounded border border-primary/20 bg-primary/10 text-primary font-medium leading-none inline-block">
                      {s.status}
                    </span>
                  </div>
                </div>
              </div>
            ))}
            <div className="flex items-start gap-3 px-4 py-3 rounded-xl bg-[hsl(var(--metrix-gold)/0.06)] border border-[hsl(var(--metrix-gold)/0.2)]">
              <Sparkles className="w-3.5 h-3.5 text-[hsl(var(--metrix-gold))] shrink-0 mt-0.5" />
              <p className="text-[11px] text-muted-foreground leading-relaxed">
                Rank 1–3 are cleared for scale. Rank 4–5 require isolation budget before promotion — watch the iOS CAPI gap on Android-led stacks.
              </p>
            </div>
          </div>
        )}

        {/* ── Benchmark Verticals ─────────────────────────────────────── */}
        {tab === "verticals" && (
          <div className="grid grid-cols-2 gap-3">
            {BENCHMARK_VERTICALS.map(v => (
              <div key={v.id} className="bg-card border border-border/60 rounded-xl px-4 py-3 space-y-2">
                <div className="flex items-center gap-2">
                  {v.internal ? <Building2 className="w-3.5 h-3.5 text-primary" /> : <Globe className="w-3.5 h-3.5 text-[hsl(var(--metrix-cyan))]" />}
                  <span className="text-xs font-semibold text-foreground">{v.name}</span>
                  <span className={cn(
                    "ml-auto text-[9px] px-1.5 py-0.5 rounded border font-medium leading-none",
                    v.internal ? "border-primary/20 bg-primary/10 text-primary" : "border-[hsl(var(--metrix-cyan)/0.25)] bg-[hsl(var(--metrix-cyan)/0.08)] text-[hsl(var(--metrix-cyan))]"
                  )}>
                    {v.internal ? "Internal" : "External"}
                  </span>
                </div>
                <div className="text-[10px] text-muted-foreground">{v.account_label} · sample {money(v.sample_spend_usd)}</div>
                <div className="grid grid-cols-3 gap-2 pt-1">
                  <div>
                    <div className="text-[9px] uppercase tracking-wide text-muted-foreground/60">CPR band</div>
                    <div className="text-[11px] font-mono font-semibold text-foreground mt-0.5">{money(v.cpr_band_min)}–{money(v.cpr_band_max)}</div>
                  </div>
                  <div>
                    <div className="text-[9px] uppercase tracking-wide text-muted-foreground/60">CPI band</div>
                    <div className="text-[11px] font-mono font-semibold text-foreground mt-0.5">{money(v.cpi_band_min)}–{money(v.cpi_band_max)}</div>
                  </div>
                  <div>
                    <div className="text-[9px] uppercase tracking-wide text-muted-foreground/60">Reg-rate</div>
                    <div className="text-[11px] font-mono font-semibold text-foreground mt-0.5">{v.reg_rate_band[0]}–{v.reg_rate_band[1]}%</div>
                  </div>
                </div>
                <p className="text-[10px] text-muted-foreground leading-relaxed border-t border-border/30 pt-2">{v.notes}</p>
              </div>
            ))}
          </div>
        )}

        {/* Downstream link */}
        <div className="flex items-center gap-2 pt-1">
          <button
            onClick={() => navigate("/app/briefs")}
            className="text-[11px] text-white bg-primary hover:bg-primary/90 px-3 py-1.5 rounded-lg font-medium transition-all flex items-center gap-1.5 ml-auto"
          >
            Brief validated stacks <ArrowRight className="w-3 h-3" />
          </button>
        </div>

      </div>
    </div>
  );
}
