// ═══════════════════════════════════════════════════════════════════════
// METRIX IAP — Analysis execution hub (/app/analysis)
// Primary entry: recent/active runs, status KPI strip, New IAP Run CTA.
// ═══════════════════════════════════════════════════════════════════════

import { Link } from "wouter";
import { Zap, ArrowUpRight, PlusCircle, Clock } from "lucide-react";
import { cn } from "@/lib/utils";
import { useCurrentWorkspace } from "@/contexts/WorkspaceContext";
import { ANALYSIS_RUNS } from "@/lib/mock-data";
import type { AnalysisRunStatus } from "@/lib/types";

const STATUS_BAR: Record<AnalysisRunStatus, string> = {
  Pending: "bg-border",
  Running: "bg-primary",
  Completed: "bg-emerald-500",
  Failed: "bg-destructive",
  Archived: "bg-muted-foreground/20",
};
const STATUS_PILL: Record<AnalysisRunStatus, string> = {
  Pending: "bg-muted text-muted-foreground border-border/40",
  Running: "bg-primary/10 text-primary border-primary/20",
  Completed: "bg-emerald-500/10 text-emerald-400 border-emerald-500/20",
  Failed: "bg-destructive/15 text-destructive border-destructive/20",
  Archived: "bg-muted text-muted-foreground/60 border-border/30",
};

export function AnalysisHub() {
  const ws = useCurrentWorkspace();

  const runs = ANALYSIS_RUNS
    .filter(r => r.workspace_id === ws.id)
    .sort((a, b) => b.created_at.localeCompare(a.created_at));

  const completed = runs.filter(r => r.status === "Completed").length;
  const running   = runs.filter(r => r.status === "Running").length;
  const pending   = runs.filter(r => r.status === "Pending").length;
  const openDecs  = runs.flatMap(r => r.decision_feed).filter(d => d.status === "Open").length;

  return (
    <div className="flex-1 p-5 space-y-4 max-w-5xl">
      <div className="flex items-end justify-between gap-4">
        <div>
          <div className="text-[9px] font-semibold uppercase tracking-[0.18em] text-muted-foreground/60 mb-1">
            Analysis · IAP Runs
          </div>
          <h1 className="text-lg font-bold text-foreground tracking-tight">Analysis</h1>
          <p className="text-xs text-muted-foreground mt-0.5">
            {ws.name} · {runs.length} run{runs.length !== 1 ? "s" : ""} total
          </p>
        </div>
        <Link
          href="/app/analysis/new-run"
          className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-primary text-primary-foreground text-xs font-semibold hover:opacity-90 transition-opacity"
        >
          <PlusCircle className="w-3.5 h-3.5" /> New IAP Run
        </Link>
      </div>

      {/* KPI strip */}
      <div className="grid grid-cols-4 gap-2.5">
        {[
          { label: "Total runs",         value: runs.length,  color: "text-foreground" },
          { label: "Completed",          value: completed,    color: "text-[hsl(var(--metrix-success))]" },
          { label: "Active / pending",   value: running + pending, color: "text-primary" },
          { label: "Open decisions",     value: openDecs,     color: "text-[hsl(var(--metrix-gold))]" },
        ].map(kpi => (
          <div key={kpi.label} className="bg-card/60 border border-border/60 rounded-xl px-4 py-3">
            <div className="text-[9px] font-semibold uppercase tracking-[0.18em] text-muted-foreground/70 mb-1">{kpi.label}</div>
            <div className={cn("text-2xl font-bold tabular-nums", kpi.color)}>{kpi.value}</div>
          </div>
        ))}
      </div>

      {/* Runs list */}
      {runs.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-20 space-y-3">
          <Zap className="w-8 h-8 text-muted-foreground/40" />
          <p className="text-sm text-muted-foreground">No runs yet — start your first IAP analysis.</p>
          <Link
            href="/app/analysis/new-run"
            className="px-3.5 py-2 rounded-lg bg-primary text-primary-foreground text-xs font-semibold hover:opacity-90 transition-opacity"
          >
            New IAP Run
          </Link>
        </div>
      ) : (
        <div className="bg-card/60 border border-border/60 rounded-xl overflow-hidden">
          <div className="px-4 py-2.5 flex items-center justify-between border-b border-border/40">
            <div className="text-[9px] font-semibold uppercase tracking-[0.18em] text-muted-foreground/70">Recent runs</div>
            <Link href="/app/analysis/library" className="text-[11px] text-primary hover:text-primary/80 transition-colors flex items-center gap-1">
              Full library <ArrowUpRight className="w-3 h-3" />
            </Link>
          </div>
          <div className="divide-y divide-border/30">
            {runs.slice(0, 8).map(run => (
              <Link
                key={run.id}
                href={`/app/analysis/library/${run.id}`}
                className="flex items-center gap-3 px-4 py-3 hover:bg-white/[0.02] transition-colors group"
              >
                <div className={cn("w-1 h-8 rounded-full shrink-0", STATUS_BAR[run.status])} />
                <div className="flex-1 min-w-0 space-y-0.5">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-semibold text-foreground font-mono">{run.id.toUpperCase()}</span>
                    <span className={cn(
                      "text-[10px] px-1.5 py-0.5 rounded border font-semibold leading-none shrink-0",
                      STATUS_PILL[run.status]
                    )}>
                      {run.status}
                    </span>
                  </div>
                  <div className="text-[11px] text-muted-foreground truncate">
                    {run.objective} · {run.depth}
                  </div>
                </div>
                <div className="flex items-center gap-2 shrink-0 text-[10px] text-muted-foreground">
                  <Clock className="w-3 h-3" />
                  {run.created_at.slice(0, 10)}
                </div>
                <ArrowUpRight className="w-3.5 h-3.5 text-muted-foreground/40 group-hover:text-primary transition-colors" />
              </Link>
            ))}
          </div>
        </div>
      )}

      {/* Quick links */}
      <div className="grid grid-cols-3 gap-2.5">
        {[
          { label: "Analysis Overview", desc: "KPI summary + trend read", href: "/app/analysis/overview" },
          { label: "Benchmarks",        desc: "Category benchmark memory", href: "/app/analysis/benchmarks" },
          { label: "Audience",          desc: "Segment + placement read",  href: "/app/analysis/audience" },
        ].map(l => (
          <Link
            key={l.href}
            href={l.href}
            className="bg-card/60 border border-border/60 rounded-xl px-4 py-3 hover:border-primary/30 hover:bg-card transition-colors group"
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-foreground">{l.label}</span>
              <ArrowUpRight className="w-3.5 h-3.5 text-muted-foreground/50 group-hover:text-primary transition-colors" />
            </div>
            <p className="text-[11px] text-muted-foreground mt-0.5">{l.desc}</p>
          </Link>
        ))}
      </div>
    </div>
  );
}
