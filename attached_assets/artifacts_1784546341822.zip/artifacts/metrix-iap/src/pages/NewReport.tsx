import { useState } from "react";
import { useLocation } from "wouter";
import { cn } from "@/lib/utils";
import {
  FileText, LayoutGrid, RefreshCw, Users, Check,
  Calendar, Building2, Zap, ArrowRight, ListChecks, Eye,
} from "lucide-react";
import { useWorkspace } from "@/contexts/WorkspaceContext";
import { WORKSPACES, AD_ACCOUNTS } from "@/lib/mock-data";

// ─── Templates ────────────────────────────────────────────────────────

type TemplateId = "executive" | "deepdive" | "loop" | "monthly";

interface ReportTemplate {
  id: TemplateId;
  label: string;
  desc: string;
  icon: React.ComponentType<{ className?: string }>;
  accent: string;
  audience: string;
  default_sections: string[];
}

const ALL_SECTIONS = [
  "Executive Summary",
  "Account Totals",
  "Results by Event",
  "Creative Learnings",
  "Concept Performance",
  "IAP Loop Recap",
  "Budget Decisions",
  "Signal Quality",
  "Next Sprint",
  "Appendix",
];

const TEMPLATES: ReportTemplate[] = [
  {
    id: "executive",
    label: "Executive Summary",
    desc: "One-page read for stakeholders. Diagnosis, key metrics, next action.",
    icon: FileText,
    accent: "text-[hsl(var(--metrix-gold))]",
    audience: "Leadership",
    default_sections: ["Executive Summary", "Account Totals", "Results by Event", "Next Sprint"],
  },
  {
    id: "deepdive",
    label: "Creative Deep-Dive",
    desc: "Concept-by-concept read with variable performance and fatigue.",
    icon: LayoutGrid,
    accent: "text-primary",
    audience: "Creative team",
    default_sections: ["Creative Learnings", "Concept Performance", "Signal Quality", "Next Sprint", "Appendix"],
  },
  {
    id: "loop",
    label: "IAP Loop Recap",
    desc: "Full data → analysis → strategy → briefs → report cycle recap.",
    icon: RefreshCw,
    accent: "text-[hsl(var(--metrix-cyan))]",
    audience: "Strategist",
    default_sections: ["Executive Summary", "IAP Loop Recap", "Creative Learnings", "Budget Decisions", "Next Sprint"],
  },
  {
    id: "monthly",
    label: "Client Monthly",
    desc: "Client-ready monthly performance recap. Terse, visual, on-brand.",
    icon: Users,
    accent: "text-emerald-400",
    audience: "Client",
    default_sections: ["Executive Summary", "Account Totals", "Results by Event", "Creative Learnings", "Budget Decisions"],
  },
];

// ─── Date range presets ───────────────────────────────────────────────

const DATE_PRESETS = [
  { id: "7d", label: "Last 7 days" },
  { id: "30d", label: "Last 30 days" },
  { id: "cycle", label: "This IAP cycle" },
  { id: "mtd", label: "Month to date" },
  { id: "custom", label: "Custom" },
];

// ─── Section label ────────────────────────────────────────────────────

function SectionLabel({ children }: { children: React.ReactNode }) {
  return (
    <span className="text-[9px] font-semibold uppercase tracking-[0.18em] text-muted-foreground/70">
      {children}
    </span>
  );
}

// ─── NewReport ────────────────────────────────────────────────────────

export function NewReport() {
  const { currentWorkspace } = useWorkspace();
  const [, navigate] = useLocation();

  const [workspaceId, setWorkspaceId] = useState(currentWorkspace.id);
  const wsAccounts = AD_ACCOUNTS.filter(a => a.workspace_id === workspaceId);
  const [accountId, setAccountId] = useState(wsAccounts[0]?.id ?? "");
  const [datePreset, setDatePreset] = useState("cycle");
  const [customStart, setCustomStart] = useState("2026-05-02");
  const [customEnd, setCustomEnd] = useState("2026-07-07");
  const [templateId, setTemplateId] = useState<TemplateId>("executive");
  const [sections, setSections] = useState<string[]>(
    TEMPLATES.find(t => t.id === "executive")!.default_sections
  );
  const [clientReady, setClientReady] = useState(true);

  const selectedWs = WORKSPACES.find(w => w.id === workspaceId);
  const selectedAccount = wsAccounts.find(a => a.id === accountId) ?? wsAccounts[0];
  const template = TEMPLATES.find(t => t.id === templateId)!;

  function selectWorkspace(id: string) {
    setWorkspaceId(id);
    const next = AD_ACCOUNTS.filter(a => a.workspace_id === id);
    setAccountId(next[0]?.id ?? "");
  }

  function selectTemplate(id: TemplateId) {
    setTemplateId(id);
    setSections(TEMPLATES.find(t => t.id === id)!.default_sections);
  }

  function toggleSection(s: string) {
    setSections(prev => prev.includes(s) ? prev.filter(x => x !== s) : [...prev, s]);
  }

  const dateLabel =
    datePreset === "custom"
      ? `${customStart} → ${customEnd}`
      : DATE_PRESETS.find(d => d.id === datePreset)?.label ?? "";

  // Preview outline follows the checklist order defined by ALL_SECTIONS
  const outline = ALL_SECTIONS.filter(s => sections.includes(s));

  return (
    <div className="h-full overflow-y-auto">
      <div className="max-w-6xl mx-auto px-6 py-5 space-y-4">

        {/* Header */}
        <div className="flex items-start justify-between">
          <div>
            <div className="text-[9px] font-semibold uppercase tracking-[0.18em] text-muted-foreground/60 mb-1">
              Report Builder
            </div>
            <h1 className="text-xl font-bold text-foreground tracking-tight">New Report</h1>
            <p className="text-xs text-muted-foreground mt-0.5">
              Assemble a report from analyzed IAP data · {template.label}
            </p>
          </div>
          <button
            onClick={() => navigate("/app/reports")}
            className="text-[11px] text-muted-foreground hover:text-foreground border border-border/60 px-3 py-1.5 rounded-lg hover:bg-white/5 transition-all"
          >
            Cancel
          </button>
        </div>

        {/* Body — two columns: builder + live preview */}
        <div className="grid grid-cols-[1fr_340px] gap-4 items-start">

          {/* ── Builder column ─────────────────────────────────────────── */}
          <div className="space-y-4">

            {/* Source */}
            <div className="space-y-2">
              <SectionLabel>Source</SectionLabel>
              <div className="grid grid-cols-2 gap-3">
                {/* Workspace */}
                <div className="bg-card border border-border/60 rounded-xl px-4 py-3 space-y-2">
                  <div className="flex items-center gap-1.5 text-[10px] font-semibold text-muted-foreground">
                    <Building2 className="w-3 h-3" /> Workspace
                  </div>
                  <select
                    value={workspaceId}
                    onChange={e => selectWorkspace(e.target.value)}
                    className="w-full bg-muted/40 border border-border/60 rounded-lg px-2.5 py-1.5 text-xs text-foreground focus:outline-none focus:border-primary/50"
                  >
                    {WORKSPACES.map(w => (
                      <option key={w.id} value={w.id}>{w.name}</option>
                    ))}
                  </select>
                </div>
                {/* Account */}
                <div className="bg-card border border-border/60 rounded-xl px-4 py-3 space-y-2">
                  <div className="flex items-center gap-1.5 text-[10px] font-semibold text-muted-foreground">
                    <Zap className="w-3 h-3" /> Ad Account
                  </div>
                  <select
                    value={accountId}
                    onChange={e => setAccountId(e.target.value)}
                    disabled={wsAccounts.length === 0}
                    className="w-full bg-muted/40 border border-border/60 rounded-lg px-2.5 py-1.5 text-xs text-foreground focus:outline-none focus:border-primary/50 disabled:opacity-40"
                  >
                    {wsAccounts.length === 0 ? (
                      <option>No connected accounts</option>
                    ) : (
                      wsAccounts.map(a => (
                        <option key={a.id} value={a.id}>{a.account_name}</option>
                      ))
                    )}
                  </select>
                </div>
              </div>
            </div>

            {/* Date range */}
            <div className="space-y-2">
              <SectionLabel>Date Range</SectionLabel>
              <div className="flex items-center gap-2 flex-wrap">
                {DATE_PRESETS.map(d => (
                  <button
                    key={d.id}
                    onClick={() => setDatePreset(d.id)}
                    className={cn(
                      "flex items-center gap-1.5 px-3 py-1.5 rounded-full text-[11px] font-medium border transition-all",
                      datePreset === d.id
                        ? "bg-primary/15 border-primary/40 text-primary"
                        : "bg-transparent border-border/50 text-muted-foreground hover:border-border hover:text-foreground"
                    )}
                  >
                    <Calendar className="w-3 h-3" /> {d.label}
                  </button>
                ))}
              </div>
              {datePreset === "custom" && (
                <div className="flex items-center gap-2 pt-1">
                  <input
                    type="date"
                    value={customStart}
                    onChange={e => setCustomStart(e.target.value)}
                    className="bg-muted/40 border border-border/60 rounded-lg px-2.5 py-1.5 text-xs text-foreground focus:outline-none focus:border-primary/50"
                  />
                  <ArrowRight className="w-3 h-3 text-muted-foreground" />
                  <input
                    type="date"
                    value={customEnd}
                    onChange={e => setCustomEnd(e.target.value)}
                    className="bg-muted/40 border border-border/60 rounded-lg px-2.5 py-1.5 text-xs text-foreground focus:outline-none focus:border-primary/50"
                  />
                </div>
              )}
            </div>

            {/* Template cards */}
            <div className="space-y-2">
              <SectionLabel>Template</SectionLabel>
              <div className="grid grid-cols-2 gap-3">
                {TEMPLATES.map(t => {
                  const Icon = t.icon;
                  const active = templateId === t.id;
                  return (
                    <button
                      key={t.id}
                      onClick={() => selectTemplate(t.id)}
                      className={cn(
                        "text-left rounded-xl border px-4 py-3.5 transition-all space-y-2",
                        active
                          ? "border-primary/50 bg-primary/5 shadow-[0_0_14px_hsl(var(--metrix-gold)/0.06)]"
                          : "border-border/60 bg-card hover:border-border"
                      )}
                    >
                      <div className="flex items-center justify-between">
                        <Icon className={cn("w-4 h-4", t.accent)} />
                        {active && (
                          <span className="w-4 h-4 rounded-full bg-primary flex items-center justify-center">
                            <Check className="w-2.5 h-2.5 text-white" />
                          </span>
                        )}
                      </div>
                      <div>
                        <div className="text-xs font-semibold text-foreground">{t.label}</div>
                        <p className="text-[10px] text-muted-foreground leading-relaxed mt-0.5">{t.desc}</p>
                      </div>
                      <div className="flex items-center gap-2 text-[9px] text-muted-foreground/70">
                        <span className="border border-border/40 rounded px-1.5 py-0.5">{t.audience}</span>
                        <span>{t.default_sections.length} sections</span>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Section toggles */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <SectionLabel>Sections</SectionLabel>
                <span className="text-[10px] text-muted-foreground">{sections.length} of {ALL_SECTIONS.length} included</span>
              </div>
              <div className="bg-card border border-border/60 rounded-xl px-4 py-3 grid grid-cols-2 gap-x-4 gap-y-1">
                {ALL_SECTIONS.map(s => {
                  const on = sections.includes(s);
                  return (
                    <button
                      key={s}
                      onClick={() => toggleSection(s)}
                      className="flex items-center gap-2.5 py-1.5 text-left group"
                    >
                      <span className={cn(
                        "w-4 h-4 rounded border flex items-center justify-center shrink-0 transition-colors",
                        on ? "bg-primary border-primary" : "border-border/60 group-hover:border-border"
                      )}>
                        {on && <Check className="w-2.5 h-2.5 text-white" />}
                      </span>
                      <span className={cn(
                        "text-[11px] transition-colors",
                        on ? "text-foreground" : "text-muted-foreground group-hover:text-foreground"
                      )}>
                        {s}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* ── Live preview column ────────────────────────────────────── */}
          <div className="sticky top-5 space-y-3">
            <div className="bg-card border border-border/60 rounded-xl overflow-hidden">
              <div className="flex items-center gap-1.5 px-4 py-2.5 border-b border-border/40 bg-muted/10">
                <Eye className="w-3 h-3 text-muted-foreground" />
                <SectionLabel>Outline Preview</SectionLabel>
              </div>

              <div className="px-4 py-3.5 space-y-3">
                {/* Cover block */}
                <div className="space-y-1">
                  <div className="text-[9px] font-semibold uppercase tracking-[0.16em] text-muted-foreground/60">
                    {template.label}
                  </div>
                  <div className="text-sm font-bold text-foreground leading-snug">
                    {selectedWs?.name ?? "—"} — {template.label}
                  </div>
                  <div className="flex items-center gap-1.5 text-[10px] text-muted-foreground">
                    <Calendar className="w-2.5 h-2.5" /> {dateLabel}
                  </div>
                  {selectedAccount && (
                    <div className="text-[10px] text-muted-foreground font-mono">{selectedAccount.account_name}</div>
                  )}
                </div>

                <div className="border-t border-border/30 pt-3">
                  <div className="flex items-center gap-1.5 mb-2">
                    <ListChecks className="w-3 h-3 text-muted-foreground" />
                    <SectionLabel>Contents</SectionLabel>
                  </div>
                  {outline.length === 0 ? (
                    <p className="text-[11px] text-muted-foreground/60 italic">No sections selected.</p>
                  ) : (
                    <ol className="space-y-1.5">
                      {outline.map((s, i) => (
                        <li key={s} className="flex items-center gap-2 text-[11px] text-foreground">
                          <span className="w-4 text-[10px] font-mono text-muted-foreground/60 text-right">{i + 1}</span>
                          <span className="w-1 h-1 rounded-full bg-primary/60 shrink-0" />
                          {s}
                        </li>
                      ))}
                    </ol>
                  )}
                </div>

                <div className="border-t border-border/30 pt-3 flex items-center justify-between">
                  <span className="text-[10px] text-muted-foreground">Client-ready</span>
                  <button
                    onClick={() => setClientReady(v => !v)}
                    className={cn(
                      "relative w-9 h-5 rounded-full transition-colors",
                      clientReady ? "bg-emerald-500/80" : "bg-border/60"
                    )}
                  >
                    <span className={cn(
                      "absolute top-0.5 w-4 h-4 rounded-full bg-white transition-all",
                      clientReady ? "left-4" : "left-0.5"
                    )} />
                  </button>
                </div>
              </div>
            </div>

            {/* Generate CTA */}
            <button
              onClick={() => navigate("/app/reports")}
              disabled={outline.length === 0}
              className="w-full flex items-center justify-center gap-2 bg-primary hover:bg-primary/90 text-white text-xs font-semibold px-4 py-2.5 rounded-xl transition-all disabled:opacity-40 disabled:cursor-not-allowed"
            >
              <Zap className="w-3.5 h-3.5" />
              Generate report
            </button>
            <p className="text-[10px] text-muted-foreground/60 text-center leading-relaxed">
              {outline.length} sections · {dateLabel} · {clientReady ? "client-ready" : "internal draft"}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
