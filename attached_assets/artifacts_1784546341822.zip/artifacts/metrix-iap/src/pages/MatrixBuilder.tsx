import { Fragment, useMemo, useState } from "react";
import { useLocation } from "wouter";
import { cn } from "@/lib/utils";
import {
  Grid3x3, Trophy, Flame, CircleDashed, Radio, Clock,
  ArrowRight, RotateCcw, FileText,
} from "lucide-react";
import { useWorkspace } from "@/contexts/WorkspaceContext";
import { CREATIVE_VARIABLES, CREATIVE_CONCEPTS, ADS } from "@/lib/mock-data";

// ─── Cell state model ─────────────────────────────────────────────────

type CellState = "empty" | "planned" | "live" | "winner" | "loser";

const CYCLE: CellState[] = ["empty", "planned", "live", "winner", "loser"];

const STATE_STYLE: Record<CellState, string> = {
  empty: "border-dashed border-border/40 bg-transparent hover:border-border/70 text-muted-foreground/30",
  planned: "border-primary/40 bg-primary/10 text-primary",
  live: "border-[hsl(var(--metrix-gold)/0.45)] bg-[hsl(var(--metrix-gold)/0.1)] text-[hsl(var(--metrix-gold))]",
  winner: "border-emerald-500/45 bg-emerald-500/12 text-emerald-400",
  loser: "border-red-500/40 bg-red-500/10 text-red-400",
};

const STATE_META: Record<Exclude<CellState, "empty">, { label: string; icon: React.ComponentType<{ className?: string }>; color: string; dot: string }> = {
  planned: { label: "Planned", icon: Clock, color: "text-primary", dot: "bg-primary" },
  live: { label: "Live", icon: Radio, color: "text-[hsl(var(--metrix-gold))]", dot: "bg-[hsl(var(--metrix-gold))]" },
  winner: { label: "Winner", icon: Trophy, color: "text-emerald-400", dot: "bg-emerald-500" },
  loser: { label: "Loser", icon: Flame, color: "text-red-400", dot: "bg-red-500" },
};

function labelOf(code: string): string {
  const i = code.indexOf("_");
  return i === -1 ? code : code.slice(i + 1);
}

const STATE_PRIORITY: Record<CellState, number> = { empty: 0, planned: 1, loser: 2, live: 3, winner: 4 };

// ─── MatrixBuilder ────────────────────────────────────────────────────

export function MatrixBuilder() {
  const { currentWorkspace } = useWorkspace();
  const [, navigate] = useLocation();
  const wsId = currentWorkspace.id;

  const [axis, setAxis] = useState<"FW" | "TN">("FW");

  // Rows — hook variables
  const hkScoped = CREATIVE_VARIABLES.filter(v => v.family === "HK" && v.workspace_id === wsId);
  const hooks = (hkScoped.length >= 4 ? hkScoped : CREATIVE_VARIABLES.filter(v => v.family === "HK"))
    .slice()
    .sort((a, b) => b.performance_index - a.performance_index)
    .slice(0, 8);

  // Columns — frameworks (from library) or tones (derived from concepts + ads)
  const frameworks = CREATIVE_VARIABLES.filter(v => v.family === "FW")
    .slice()
    .sort((a, b) => b.performance_index - a.performance_index);

  const toneCodes = useMemo(() => {
    const set = new Set<string>();
    CREATIVE_CONCEPTS.forEach(c => c.tone_variable && set.add(c.tone_variable));
    ADS.forEach(a => a.variable_codes.forEach(code => code.startsWith("TN_") && set.add(code)));
    return Array.from(set).sort();
  }, []);

  const columns = axis === "FW"
    ? frameworks.map(f => ({ code: f.code, label: labelOf(f.code) }))
    : toneCodes.map(code => ({ code, label: labelOf(code) }));

  // Seed cell states from concepts + ads for the current workspace
  const seed = useMemo(() => {
    const m = new Map<string, CellState>();
    const setBest = (key: string, s: CellState) => {
      const cur = m.get(key) ?? "empty";
      if (STATE_PRIORITY[s] > STATE_PRIORITY[cur]) m.set(key, s);
    };
    const stateFromTier = (t: number): CellState =>
      t === 1 ? "winner" : t === 4 ? "loser" : t === 2 ? "live" : "planned";

    const scopedConcepts = CREATIVE_CONCEPTS.filter(c => c.workspace_id === wsId);
    const conceptPool = scopedConcepts.length > 0 ? scopedConcepts : CREATIVE_CONCEPTS;
    conceptPool.forEach(c => {
      const hk = c.hook_variable;
      const col = axis === "FW" ? c.framework_variable : c.tone_variable;
      if (hk && col) setBest(`${hk}|${col}`, stateFromTier(c.tier));
    });

    const scopedAds = ADS.filter(a => a.workspace_id === wsId);
    const adPool = scopedAds.length > 0 ? scopedAds : ADS;
    adPool.forEach(a => {
      const hk = a.variable_codes.find(c => c.startsWith("HK_"));
      const col = a.variable_codes.find(c => c.startsWith(axis === "FW" ? "FW_" : "TN_"));
      if (hk && col) setBest(`${hk}|${col}`, stateFromTier(a.tier));
    });
    return m;
  }, [wsId, axis]);

  // Local editable overrides on top of the seed
  const [overrides, setOverrides] = useState<Record<string, CellState>>({});

  const getState = (key: string): CellState => overrides[key] ?? seed.get(key) ?? "empty";

  const cycle = (key: string) => {
    const cur = getState(key);
    const next = CYCLE[(CYCLE.indexOf(cur) + 1) % CYCLE.length];
    setOverrides(o => ({ ...o, [key]: next }));
  };

  const resetMatrix = () => setOverrides({});

  // Counts
  const counts = { planned: 0, live: 0, winner: 0, loser: 0, empty: 0 };
  hooks.forEach(h => columns.forEach(col => {
    counts[getState(`${h.code}|${col.code}`)]++;
  }));
  const totalCells = hooks.length * columns.length;
  const active = totalCells - counts.empty;

  return (
    <div className="h-full overflow-y-auto">
      <div className="max-w-6xl mx-auto px-6 py-5 space-y-4">

        {/* Header */}
        <div className="flex items-start justify-between">
          <div>
            <div className="text-[9px] font-semibold uppercase tracking-[0.18em] text-muted-foreground/60 mb-1">
              MST · Matrix Scaling
            </div>
            <h1 className="text-xl font-bold text-foreground tracking-tight">Matrix Builder</h1>
            <p className="text-xs text-muted-foreground mt-0.5">
              {currentWorkspace.name} · hooks × {axis === "FW" ? "frameworks" : "tones"} · click cells to cycle state
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={resetMatrix}
              className="text-[11px] text-muted-foreground hover:text-foreground border border-border/60 px-3 py-1.5 rounded-lg hover:bg-white/5 transition-all flex items-center gap-1.5"
            >
              <RotateCcw className="w-3 h-3" /> Reset
            </button>
            <button
              onClick={() => navigate("/app/briefs")}
              className={cn(
                "text-[11px] px-3 py-1.5 rounded-lg font-medium transition-all flex items-center gap-1.5",
                counts.planned > 0
                  ? "text-white bg-primary hover:bg-primary/90"
                  : "text-muted-foreground border border-border/60 hover:text-foreground hover:bg-white/5"
              )}
            >
              <FileText className="w-3 h-3" />
              Generate {counts.planned} brief{counts.planned !== 1 ? "s" : ""} from planned
              <ArrowRight className="w-3 h-3" />
            </button>
          </div>
        </div>

        {/* Summary strip */}
        <div className="grid grid-cols-6 gap-3">
          {[
            { label: "Active Cells", value: active, sub: `of ${totalCells}`, color: "text-foreground", dot: "" },
            { label: "Planned", value: counts.planned, sub: "queued", color: "text-primary", dot: "bg-primary" },
            { label: "Live", value: counts.live, sub: "in market", color: "text-[hsl(var(--metrix-gold))]", dot: "bg-[hsl(var(--metrix-gold))]" },
            { label: "Winners", value: counts.winner, sub: "P1 cells", color: "text-emerald-400", dot: "bg-emerald-500" },
            { label: "Losers", value: counts.loser, sub: "retired", color: "text-red-400", dot: "bg-red-500" },
            { label: "Coverage", value: `${Math.round((active / totalCells) * 100)}%`, sub: "matrix fill", color: "text-foreground", dot: "" },
          ].map(m => (
            <div key={m.label} className="bg-card border border-border/60 rounded-xl px-3 py-2.5">
              <div className={cn("text-lg font-bold leading-none flex items-center gap-1.5", m.color)}>
                {m.dot && <span className={cn("w-1.5 h-1.5 rounded-full", m.dot)} />}
                {m.value}
              </div>
              <div className="text-[10px] font-medium text-foreground mt-1.5">{m.label}</div>
              <div className="text-[10px] text-muted-foreground mt-0.5">{m.sub}</div>
            </div>
          ))}
        </div>

        {/* Axis toggle + legend */}
        <div className="flex items-center justify-between gap-3 flex-wrap">
          <div className="flex items-center gap-2">
            <span className="text-[10px] text-muted-foreground font-medium">Columns:</span>
            {([["FW", "Frameworks"], ["TN", "Tones"]] as const).map(([id, label]) => (
              <button
                key={id}
                onClick={() => setAxis(id)}
                className={cn(
                  "px-3 py-1 rounded-full text-[11px] font-medium border transition-all",
                  axis === id
                    ? "bg-primary/15 border-primary/40 text-primary"
                    : "bg-transparent border-border/50 text-muted-foreground hover:border-border hover:text-foreground"
                )}
              >
                {label}
              </button>
            ))}
          </div>
          <div className="flex items-center gap-3">
            {(Object.keys(STATE_META) as Array<Exclude<CellState, "empty">>).map(s => {
              const meta = STATE_META[s];
              return (
                <span key={s} className="flex items-center gap-1 text-[10px] text-muted-foreground">
                  <span className={cn("w-2 h-2 rounded-sm", meta.dot)} />
                  {meta.label}
                </span>
              );
            })}
            <span className="flex items-center gap-1 text-[10px] text-muted-foreground/60">
              <CircleDashed className="w-2.5 h-2.5" /> Empty
            </span>
          </div>
        </div>

        {/* Matrix grid */}
        <div className="bg-card border border-border/60 rounded-xl p-3 overflow-x-auto">
          <div
            className="grid gap-1.5 min-w-[720px]"
            style={{ gridTemplateColumns: `140px repeat(${columns.length}, minmax(0, 1fr))` }}
          >
            {/* Corner + column headers */}
            <div className="flex items-end pb-1">
              <span className="text-[9px] font-semibold uppercase tracking-[0.14em] text-muted-foreground/60 flex items-center gap-1">
                <Grid3x3 className="w-2.5 h-2.5" /> HK ⇣ / {axis} ⇢
              </span>
            </div>
            {columns.map(col => (
              <div key={col.code} className="px-1 pb-1 flex flex-col items-center justify-end text-center">
                <span className="text-[9px] font-mono text-muted-foreground/50">{axis}</span>
                <span className="text-[10px] font-semibold text-foreground leading-tight">{col.label}</span>
              </div>
            ))}

            {/* Rows */}
            {hooks.map(h => (
              <Fragment key={h.code}>
                <div className="flex items-center gap-1.5 pr-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-primary shrink-0" />
                  <div className="min-w-0">
                    <div className="text-[10px] font-semibold text-foreground truncate">{labelOf(h.code)}</div>
                    <div className="text-[9px] font-mono text-muted-foreground/50">idx {h.performance_index}</div>
                  </div>
                </div>
                {columns.map(col => {
                  const key = `${h.code}|${col.code}`;
                  const state = getState(key);
                  const meta = state !== "empty" ? STATE_META[state] : null;
                  const Icon = meta?.icon;
                  return (
                    <button
                      key={key}
                      onClick={() => cycle(key)}
                      title={`${labelOf(h.code)} × ${col.label} — ${state}`}
                      className={cn(
                        "h-11 rounded-lg border flex items-center justify-center transition-all",
                        STATE_STYLE[state]
                      )}
                    >
                      {Icon && <Icon className="w-3.5 h-3.5" />}
                    </button>
                  );
                })}
              </Fragment>
            ))}
          </div>
        </div>

        <p className="text-[10px] text-muted-foreground/70 px-1">
          Seeded from {currentWorkspace.name} concepts + deployed ads. Click any cell to cycle
          empty → planned → live → winner → loser. Planned cells feed the brief generator.
        </p>

      </div>
    </div>
  );
}
