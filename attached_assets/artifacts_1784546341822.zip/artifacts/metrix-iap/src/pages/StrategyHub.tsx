// ═══════════════════════════════════════════════════════════════════════
// METRIX IAP — Strategy execution hub (/app/strategy)
// Past strategy sessions, current control read, links to strategy tools.
// ═══════════════════════════════════════════════════════════════════════

import { Link } from "wouter";
import { Compass, ArrowUpRight, PlusCircle, Users, Map, FlaskConical } from "lucide-react";
import { cn } from "@/lib/utils";
import { useCurrentWorkspace } from "@/contexts/WorkspaceContext";
import { ANALYSIS_RUNS, ICP_PROFILES } from "@/lib/mock-data";

// Mock strategy sessions derived from completed runs
const SESSION_OUTCOMES = [
  "Repositioned to mid-funnel retention angle",
  "Identified dominant hook: Aspirational Value",
  "Confirmed seasonal creative rotation",
  "Validated ICP expansion into secondary segment",
  "Eliminated underperforming framework family",
];

export function StrategyHub() {
  const ws = useCurrentWorkspace();

  const runs = ANALYSIS_RUNS
    .filter(r => r.workspace_id === ws.id && r.status === "Completed")
    .sort((a, b) => b.created_at.localeCompare(a.created_at));
  const latest = runs[0];
  const icps = ICP_PROFILES.filter(p => p.workspace_id === ws.id);

  // Derive mock strategy sessions from completed runs
  const sessions = runs.slice(0, 5).map((r, i) => ({
    id: `strat-${r.id}`,
    date: r.created_at.slice(0, 10),
    source: r.id.toUpperCase(),
    outcome: SESSION_OUTCOMES[i % SESSION_OUTCOMES.length],
    depth: r.depth,
  }));

  return (
    <div className="flex-1 p-5 space-y-4 max-w-5xl">
      <div className="flex items-end justify-between gap-4">
        <div>
          <div className="text-[9px] font-semibold uppercase tracking-[0.18em] text-muted-foreground/60 mb-1">
            Strategy · Runs
          </div>
          <h1 className="text-lg font-bold text-foreground tracking-tight">Strategy</h1>
          <p className="text-xs text-muted-foreground mt-0.5">
            {ws.name} · {sessions.length} strategy session{sessions.length !== 1 ? "s" : ""} · {icps.length} ICP profile{icps.length !== 1 ? "s" : ""}
          </p>
        </div>
        <Link
          href="/app/analysis/new-run"
          className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg bg-primary text-primary-foreground text-xs font-semibold hover:opacity-90 transition-opacity"
        >
          <PlusCircle className="w-3.5 h-3.5" /> New Strategy Run
        </Link>
      </div>

      {/* KPI strip */}
      <div className="grid grid-cols-3 gap-2.5">
        {[
          { label: "Strategy sessions", value: sessions.length, icon: FlaskConical, color: "text-primary" },
          { label: "ICP profiles",      value: icps.length,     icon: Users,       color: "text-[hsl(var(--metrix-cyan))]" },
          { label: "Completed runs",    value: runs.length,     icon: Compass,     color: "text-[hsl(var(--metrix-success))]" },
        ].map(kpi => (
          <div key={kpi.label} className="bg-card/60 border border-border/60 rounded-xl px-4 py-3">
            <div className="flex items-center gap-1.5 mb-1">
              <kpi.icon className={cn("w-3 h-3", kpi.color)} />
              <div className="text-[9px] font-semibold uppercase tracking-[0.18em] text-muted-foreground/70">{kpi.label}</div>
            </div>
            <div className={cn("text-2xl font-bold tabular-nums", kpi.color)}>{kpi.value}</div>
          </div>
        ))}
      </div>

      {/* Current control */}
      {latest ? (
        <div className="bg-card/60 border border-primary/25 rounded-xl px-4 py-3.5">
          <div className="text-[9px] font-semibold uppercase tracking-[0.18em] text-primary mb-1.5">Current control</div>
          <p className="text-sm text-foreground leading-relaxed">{latest.priority_read}</p>
          <div className="flex items-center gap-3 mt-2.5 pt-2.5 border-t border-border/40">
            <span className="text-[10px] font-mono text-muted-foreground/60 uppercase">source · {latest.id}</span>
            <Link href={`/app/analysis/library/${latest.id}`} className="text-[11px] text-primary hover:text-primary/80 transition-colors ml-auto">
              Evidence
            </Link>
          </div>
        </div>
      ) : (
        <div className="flex items-start gap-2.5 bg-card/60 border border-border/60 rounded-xl px-4 py-3.5">
          <Compass className="w-4 h-4 text-muted-foreground/50 shrink-0 mt-0.5" />
          <p className="text-xs text-muted-foreground">
            No completed run yet — the control read appears after the first IAP analysis.{" "}
            <Link href="/app/analysis/new-run" className="text-primary hover:text-primary/80 transition-colors">Start one</Link>.
          </p>
        </div>
      )}

      {/* Strategy sessions */}
      {sessions.length > 0 && (
        <div className="bg-card/60 border border-border/60 rounded-xl overflow-hidden">
          <div className="px-4 py-2.5 border-b border-border/40">
            <div className="text-[9px] font-semibold uppercase tracking-[0.18em] text-muted-foreground/70">Past strategy sessions</div>
          </div>
          <div className="divide-y divide-border/30">
            {sessions.map(s => (
              <div key={s.id} className="flex items-center gap-3 px-4 py-3">
                <div className="w-1 h-8 rounded-full bg-primary/40 shrink-0" />
                <div className="flex-1 min-w-0 space-y-0.5">
                  <div className="text-xs font-semibold text-foreground font-mono">{s.source}</div>
                  <p className="text-[11px] text-muted-foreground truncate">{s.outcome}</p>
                </div>
                <div className="text-[10px] text-muted-foreground/60 shrink-0">{s.date}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tool jump-offs */}
      <div className="grid grid-cols-3 gap-2.5">
        {[
          { label: "Strategy Overview", desc: "ICP grid + pipeline metrics", href: "/app/strategy/overview", icon: Compass },
          { label: "Avatar / ICP",      desc: `${icps.length} profile${icps.length !== 1 ? "s" : ""} on this account`, href: "/app/strategy/avatars", icon: Users },
          { label: "Strategy Map",      desc: "Positioning + funnel structure", href: "/app/strategy/map", icon: Map },
        ].map(l => (
          <Link
            key={l.href}
            href={l.href}
            className="bg-card/60 border border-border/60 rounded-xl px-4 py-3 hover:border-primary/30 hover:bg-card transition-colors group"
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-foreground">{l.label}</span>
              <ArrowUpRight className="w-3.5 h-3.5 text-muted-foreground/50 group-hover:text-primary transition-colors" />
            </div>
            <p className="text-[11px] text-muted-foreground mt-0.5">{l.desc}</p>
          </Link>
        ))}
      </div>
    </div>
  );
}
