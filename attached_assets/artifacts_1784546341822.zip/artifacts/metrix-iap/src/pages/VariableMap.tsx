// ═══════════════════════════════════════════════════════════════════════
// METRIX IAP — MST › Variable Map (/app/mst/variable-map)
// 2D variable lineage grid: hooks × formats × audiences with mock data.
// Replaces the legacy Concept Map entry point.
// ═══════════════════════════════════════════════════════════════════════

import { Fragment, useMemo, useState } from "react";
import { Link } from "wouter";
import { cn } from "@/lib/utils";
import {
  GitBranch, Trophy, CircleDashed, Radio, Clock,
  ChevronRight, ArrowRight,
} from "lucide-react";
import { useWorkspace } from "@/contexts/WorkspaceContext";
import { CREATIVE_VARIABLES, CREATIVE_CONCEPTS, ADS } from "@/lib/mock-data";

type CellState = "empty" | "planned" | "live" | "winner" | "loser";

const CYCLE: CellState[] = ["empty", "planned", "live", "winner", "loser"];

const STATE_STYLE: Record<CellState, string> = {
  empty:   "border-dashed border-border/40 bg-transparent hover:border-border/70 text-muted-foreground/30",
  planned: "border-primary/40 bg-primary/10 text-primary",
  live:    "border-[hsl(var(--metrix-gold)/0.45)] bg-[hsl(var(--metrix-gold)/0.1)] text-[hsl(var(--metrix-gold))]",
  winner:  "border-emerald-500/45 bg-emerald-500/12 text-emerald-400",
  loser:   "border-red-500/40 bg-red-500/10 text-red-400",
};

const STATE_DOT: Record<CellState, string> = {
  empty:   "bg-border/50",
  planned: "bg-primary",
  live:    "bg-[hsl(var(--metrix-gold))]",
  winner:  "bg-emerald-500",
  loser:   "bg-red-500",
};

const STATE_LABEL: Record<Exclude<CellState, "empty">, string> = {
  planned: "Planned",
  live:    "Live",
  winner:  "Winner",
  loser:   "Loser",
};

const STATE_PRIORITY: Record<CellState, number> = { empty: 0, planned: 1, loser: 2, live: 3, winner: 4 };

function labelOf(code: string): string {
  const i = code.indexOf("_");
  return i === -1 ? code : code.slice(i + 1);
}

const FAMILY_COLORS: Record<string, string> = {
  HK:  "text-primary bg-primary/10 border-primary/20",
  FW:  "text-purple-400 bg-purple-500/10 border-purple-500/20",
  TN:  "text-blue-400 bg-blue-500/10 border-blue-500/20",
  CN:  "text-emerald-400 bg-emerald-500/10 border-emerald-500/20",
  CTA: "text-yellow-400 bg-yellow-400/10 border-yellow-400/20",
};

function VarChip({ code }: { code: string }) {
  const fam = code.split("_")[0];
  return (
    <span className={cn(
      "text-[10px] px-1.5 py-0.5 rounded border font-medium leading-none whitespace-nowrap",
      FAMILY_COLORS[fam] ?? "text-muted-foreground bg-muted border-border/40"
    )}>
      <span className="font-mono opacity-60">{fam}</span> {labelOf(code)}
    </span>
  );
}

export function VariableMap() {
  const { currentWorkspace } = useWorkspace();
  const wsId = currentWorkspace.id;

  const [axis, setAxis] = useState<"FW" | "TN">("FW");

  const hkScoped = CREATIVE_VARIABLES.filter(v => v.family === "HK" && v.workspace_id === wsId);
  const hooks = (hkScoped.length >= 4 ? hkScoped : CREATIVE_VARIABLES.filter(v => v.family === "HK"))
    .slice()
    .sort((a, b) => b.performance_index - a.performance_index)
    .slice(0, 8);

  const frameworks = CREATIVE_VARIABLES.filter(v => v.family === "FW")
    .sort((a, b) => b.performance_index - a.performance_index);

  const toneCodes = useMemo(() => {
    const set = new Set<string>();
    CREATIVE_CONCEPTS.forEach(c => c.tone_variable && set.add(c.tone_variable));
    ADS.forEach(a => a.variable_codes.forEach(code => code.startsWith("TN_") && set.add(code)));
    return Array.from(set).sort();
  }, []);

  const columns = axis === "FW"
    ? frameworks.map(f => ({ code: f.code, label: labelOf(f.code) }))
    : toneCodes.map(code => ({ code, label: labelOf(code) }));

  const seed = useMemo(() => {
    const m = new Map<string, CellState>();
    const setBest = (key: string, s: CellState) => {
      const cur = m.get(key) ?? "empty";
      if (STATE_PRIORITY[s] > STATE_PRIORITY[cur]) m.set(key, s);
    };
    const stateFromTier = (t: number): CellState =>
      t === 1 ? "winner" : t === 4 ? "loser" : t === 2 ? "live" : "planned";

    const scopedConcepts = CREATIVE_CONCEPTS.filter(c => c.workspace_id === wsId);
    const conceptPool = scopedConcepts.length > 0 ? scopedConcepts : CREATIVE_CONCEPTS;
    conceptPool.forEach(c => {
      const hk = c.hook_variable;
      const col = axis === "FW" ? c.framework_variable : c.tone_variable;
      if (hk && col) setBest(`${hk}|${col}`, stateFromTier(c.tier));
    });

    const scopedAds = ADS.filter(a => a.workspace_id === wsId);
    const adPool = scopedAds.length > 0 ? scopedAds : ADS;
    adPool.forEach(a => {
      const hk = a.variable_codes.find(c => c.startsWith("HK_"));
      const col = a.variable_codes.find(c => c.startsWith(axis === "FW" ? "FW_" : "TN_"));
      if (hk && col) setBest(`${hk}|${col}`, stateFromTier(a.tier));
    });
    return m;
  }, [wsId, axis]);

  const [overrides, setOverrides] = useState<Record<string, CellState>>({});
  const getState = (key: string): CellState => overrides[key] ?? seed.get(key) ?? "empty";
  const cycle = (key: string) => {
    const cur = getState(key);
    const next = CYCLE[(CYCLE.indexOf(cur) + 1) % CYCLE.length];
    setOverrides(o => ({ ...o, [key]: next }));
  };

  const counts = { planned: 0, live: 0, winner: 0, loser: 0, empty: 0 };
  hooks.forEach(h => columns.forEach(col => { counts[getState(`${h.code}|${col.code}`)]++; }));
  const totalCells = hooks.length * columns.length;
  const active = totalCells - counts.empty;
  const winnerPaths = counts.winner;

  // Top winning lineages
  const topWinners = hooks.flatMap(h =>
    columns
      .filter(col => getState(`${h.code}|${col.code}`) === "winner")
      .map(col => ({ hook: h.code, col: col.code }))
  ).slice(0, 3);

  return (
    <div className="h-full overflow-y-auto">
      <div className="max-w-6xl mx-auto px-6 py-5 space-y-4">

        {/* Header */}
        <div className="flex items-start justify-between">
          <div>
            <div className="text-[9px] font-semibold uppercase tracking-[0.18em] text-muted-foreground/60 mb-1">
              MST · Variable Map
            </div>
            <h1 className="text-xl font-bold text-foreground tracking-tight">Variable Map</h1>
            <p className="text-xs text-muted-foreground mt-0.5">
              {currentWorkspace.name} · hooks × {axis === "FW" ? "frameworks" : "tones"} · click cells to cycle state
            </p>
          </div>
          <Link
            href="/app/mst/crossmap"
            className="text-[11px] text-white bg-primary hover:bg-primary/90 px-3 py-1.5 rounded-lg font-medium transition-all flex items-center gap-1.5"
          >
            <ArrowRight className="w-3 h-3" /> View Crossmap
          </Link>
        </div>

        {/* Summary strip */}
        <div className="grid grid-cols-5 gap-3">
          {[
            { label: "Active Cells",   value: active,       color: "text-foreground" },
            { label: "Planned",        value: counts.planned, color: "text-primary" },
            { label: "Live",           value: counts.live,   color: "text-[hsl(var(--metrix-gold))]" },
            { label: "Winners",        value: winnerPaths,  color: "text-emerald-400" },
            { label: "Coverage",       value: `${totalCells > 0 ? Math.round((active / totalCells) * 100) : 0}%`, color: "text-foreground" },
          ].map(m => (
            <div key={m.label} className="bg-card border border-border/60 rounded-xl px-4 py-3">
              <div className={cn("text-xl font-bold leading-none", m.color)}>{m.value}</div>
              <div className="text-[10px] font-medium text-foreground mt-1.5">{m.label}</div>
            </div>
          ))}
        </div>

        {/* Axis + legend */}
        <div className="flex items-center justify-between gap-3 flex-wrap">
          <div className="flex items-center gap-2">
            <span className="text-[10px] text-muted-foreground font-medium">Columns:</span>
            {(["FW", "TN"] as const).map(id => (
              <button
                key={id}
                onClick={() => setAxis(id)}
                className={cn(
                  "px-3 py-1 rounded-full text-[11px] font-medium border transition-all",
                  axis === id
                    ? "bg-primary/15 border-primary/40 text-primary"
                    : "bg-transparent border-border/50 text-muted-foreground hover:border-border hover:text-foreground"
                )}
              >
                {id === "FW" ? "Frameworks" : "Tones"}
              </button>
            ))}
          </div>
          <div className="flex items-center gap-2.5">
            {(["planned", "live", "winner", "loser"] as const).map(s => (
              <span key={s} className="flex items-center gap-1 text-[10px] text-muted-foreground">
                <span className={cn("w-2 h-2 rounded-sm", STATE_DOT[s])} /> {STATE_LABEL[s]}
              </span>
            ))}
            <span className="flex items-center gap-1 text-[10px] text-muted-foreground/60">
              <CircleDashed className="w-2.5 h-2.5" /> Empty
            </span>
          </div>
        </div>

        {/* Grid */}
        <div className="bg-card border border-border/60 rounded-xl p-3 overflow-x-auto">
          <div
            className="grid gap-1.5 min-w-[720px]"
            style={{ gridTemplateColumns: `140px repeat(${columns.length}, minmax(0, 1fr))` }}
          >
            <div className="flex items-end pb-1">
              <span className="text-[9px] font-semibold uppercase tracking-[0.14em] text-muted-foreground/60 flex items-center gap-1">
                <GitBranch className="w-2.5 h-2.5" /> HK ⇣ / {axis} ⇢
              </span>
            </div>
            {columns.map(col => (
              <div key={col.code} className="px-1 pb-1 flex flex-col items-center justify-end text-center">
                <span className="text-[9px] font-mono text-muted-foreground/50">{axis}</span>
                <span className="text-[10px] font-semibold text-foreground leading-tight">{col.label}</span>
              </div>
            ))}

            {hooks.map(h => (
              <Fragment key={h.code}>
                <div className="flex items-center gap-1.5 pr-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-primary shrink-0" />
                  <div className="min-w-0">
                    <div className="text-[10px] font-semibold text-foreground truncate">{labelOf(h.code)}</div>
                    <div className="text-[9px] font-mono text-muted-foreground/50">idx {h.performance_index}</div>
                  </div>
                </div>
                {columns.map(col => {
                  const key = `${h.code}|${col.code}`;
                  const state = getState(key);
                  const Icon = state === "winner" ? Trophy
                    : state === "live" ? Radio
                    : state === "planned" ? Clock
                    : null;
                  return (
                    <button
                      key={key}
                      onClick={() => cycle(key)}
                      title={`${labelOf(h.code)} × ${col.label} — ${state}`}
                      className={cn(
                        "h-11 rounded-lg border flex items-center justify-center transition-all",
                        STATE_STYLE[state]
                      )}
                    >
                      {Icon && <Icon className="w-3.5 h-3.5" />}
                    </button>
                  );
                })}
              </Fragment>
            ))}
          </div>
        </div>

        {/* Winning lineage callout */}
        {topWinners.length > 0 && (
          <div className="bg-card/60 border border-border/60 rounded-xl px-4 py-3.5">
            <div className="flex items-center gap-1.5 text-[9px] font-semibold uppercase tracking-[0.18em] text-muted-foreground/70 mb-2">
              <Trophy className="w-3 h-3 text-emerald-400" /> Top winning lineages
            </div>
            <div className="space-y-1.5">
              {topWinners.map(({ hook, col }) => (
                <div key={`${hook}|${col}`} className="flex items-center gap-2 text-[11px]">
                  <VarChip code={hook} />
                  <ChevronRight className="w-3 h-3 text-muted-foreground/40" />
                  <VarChip code={col} />
                  <span className="text-emerald-400 font-semibold ml-1">P1 Winner</span>
                </div>
              ))}
            </div>
          </div>
        )}

        <p className="text-[10px] text-muted-foreground/70 px-1">
          Seeded from {currentWorkspace.name} concepts + deployed ads. Click any cell to cycle empty → planned → live → winner → loser.
        </p>
      </div>
    </div>
  );
}
