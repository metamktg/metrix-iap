import { useState } from "react";
import { useLocation } from "wouter";
import { cn } from "@/lib/utils";
import {
  FlaskConical, ChevronDown, ArrowUp, ArrowDown,
  Clock, Activity, CheckCircle2, XCircle, User, Layers,
} from "lucide-react";
import { useWorkspace } from "@/contexts/WorkspaceContext";
import type { ConfidenceLabel, VariableCodeFamily } from "@/lib/types";
import {
  HYPOTHESIS_STATUSES, getHypotheses,
  type Hypothesis, type HypothesisStatus,
} from "@/lib/mock/hypotheses";

// ─── Chip helpers ──────────────────────────────────────────────────────

function ConfidenceChip({ c }: { c: ConfidenceLabel }) {
  const map: Record<ConfidenceLabel, string> = {
    high: "bg-emerald-500/10 border-emerald-500/20 text-emerald-400",
    medium: "bg-yellow-400/10 border-yellow-400/20 text-yellow-400",
    validation_required: "bg-orange-400/10 border-orange-400/20 text-orange-400",
    insufficient: "bg-muted/50 border-border/40 text-muted-foreground",
  };
  const labels: Record<ConfidenceLabel, string> = {
    high: "High", medium: "Med", validation_required: "Validate", insufficient: "Insuff.",
  };
  return (
    <span className={cn("text-[9px] px-1.5 py-0.5 rounded border font-semibold leading-none", map[c])}>
      {labels[c]}
    </span>
  );
}

const STATUS_STYLES: Record<HypothesisStatus, string> = {
  Queued: "text-muted-foreground bg-muted/50 border-border/40",
  Testing: "text-primary bg-primary/10 border-primary/20",
  Validated: "text-emerald-400 bg-emerald-500/10 border-emerald-500/20",
  Rejected: "text-red-400 bg-red-500/10 border-red-500/20",
};

const STATUS_ICONS: Record<HypothesisStatus, React.ComponentType<{ className?: string }>> = {
  Queued: Clock,
  Testing: Activity,
  Validated: CheckCircle2,
  Rejected: XCircle,
};

function StatusChip({ s }: { s: HypothesisStatus }) {
  const Icon = STATUS_ICONS[s];
  return (
    <span className={cn("inline-flex items-center gap-1 text-[9px] px-1.5 py-0.5 rounded border font-semibold leading-none", STATUS_STYLES[s])}>
      <Icon className="w-2.5 h-2.5" />
      {s}
    </span>
  );
}

const FAMILY_COLORS: Record<VariableCodeFamily, string> = {
  HK: "text-primary bg-primary/10 border-primary/20",
  FW: "text-purple-400 bg-purple-500/10 border-purple-500/20",
  TN: "text-blue-400 bg-blue-500/10 border-blue-500/20",
  CN: "text-emerald-400 bg-emerald-500/10 border-emerald-500/20",
  CTA: "text-yellow-400 bg-yellow-400/10 border-yellow-400/20",
};

const FAMILY_LABELS: Record<VariableCodeFamily, string> = {
  HK: "Hook", FW: "Framework", TN: "Tone", CN: "Concept", CTA: "CTA",
};

function PriorityBar({ score }: { score: number }) {
  const color = score >= 80 ? "bg-emerald-500" : score >= 65 ? "bg-primary" : score >= 50 ? "bg-yellow-400" : "bg-red-400";
  const text = score >= 80 ? "text-emerald-400" : score >= 65 ? "text-foreground" : score >= 50 ? "text-yellow-400" : "text-red-400";
  return (
    <div className="flex items-center gap-2">
      <div className="w-10 bg-border/30 rounded-full h-1 overflow-hidden">
        <div className={cn("h-full rounded-full", color)} style={{ width: `${score}%` }} />
      </div>
      <span className={cn("text-[11px] font-mono font-bold w-6 text-right", text)}>{score}</span>
    </div>
  );
}

// ─── Row ───────────────────────────────────────────────────────────────

function HypothesisRow({ h, last }: { h: Hypothesis; last: boolean }) {
  const [open, setOpen] = useState(false);
  const [, navigate] = useLocation();
  const ImpactArrow = h.impact_direction === "up" ? ArrowUp : ArrowDown;
  const impactGood = h.impact_direction === "up"
    ? h.impact_metric !== "CPI" && h.impact_metric !== "CPR"
    : h.impact_metric === "CPI" || h.impact_metric === "CPR";

  return (
    <div className={cn("border-t border-border/20", last && !open && "rounded-b-xl overflow-hidden")}>
      <button
        onClick={() => setOpen((o) => !o)}
        className="w-full flex items-center gap-3 px-4 py-2.5 text-left hover:bg-white/[0.03] transition-colors"
      >
        {/* Priority */}
        <div className="w-[72px] shrink-0"><PriorityBar score={h.priority_score} /></div>

        {/* Code */}
        <span className="text-[10px] font-mono font-bold text-muted-foreground/70 w-9 shrink-0">{h.code}</span>

        {/* Statement */}
        <p className="flex-1 min-w-0 text-[11px] text-foreground truncate">{h.statement}</p>

        {/* Family */}
        <span className={cn("text-[9px] px-1.5 py-0.5 rounded border font-semibold leading-none shrink-0 w-9 text-center", FAMILY_COLORS[h.variable_family])}>
          {h.variable_family}
        </span>

        {/* Expected impact */}
        <span className={cn("flex items-center gap-0.5 text-[10px] font-mono font-semibold shrink-0 w-[92px] justify-end", impactGood ? "text-emerald-400" : "text-muted-foreground")}>
          <ImpactArrow className="w-2.5 h-2.5" />
          {h.expected_impact}
        </span>

        {/* Confidence */}
        <div className="shrink-0 w-14 flex justify-center"><ConfidenceChip c={h.confidence} /></div>

        {/* Status */}
        <div className="shrink-0 w-[92px] flex justify-end"><StatusChip s={h.status} /></div>

        <ChevronDown className={cn("w-3.5 h-3.5 text-muted-foreground shrink-0 transition-transform", open && "rotate-180")} />
      </button>

      {open && (
        <div className="px-4 pb-4 pt-1 bg-muted/[0.03] space-y-3">
          <div className="grid grid-cols-4 gap-3 pt-2">
            <div>
              <div className="text-[9px] font-semibold uppercase tracking-[0.14em] text-muted-foreground/70 flex items-center gap-1">
                <Layers className="w-2.5 h-2.5" /> Concept
              </div>
              <div className="text-[11px] font-mono text-foreground mt-1">{h.linked_concept}</div>
            </div>
            <div>
              <div className="text-[9px] font-semibold uppercase tracking-[0.14em] text-muted-foreground/70">Variable Family</div>
              <div className="text-[11px] text-foreground mt-1">{FAMILY_LABELS[h.variable_family]}</div>
            </div>
            <div>
              <div className="text-[9px] font-semibold uppercase tracking-[0.14em] text-muted-foreground/70">Target Avatar</div>
              <div className="text-[11px] text-foreground mt-1">{h.avatar}</div>
            </div>
            <div>
              <div className="text-[9px] font-semibold uppercase tracking-[0.14em] text-muted-foreground/70 flex items-center gap-1">
                <User className="w-2.5 h-2.5" /> Owner
              </div>
              <div className="text-[11px] text-foreground mt-1">{h.owner}</div>
            </div>
          </div>
          <div>
            <div className="text-[9px] font-semibold uppercase tracking-[0.14em] text-muted-foreground/70 mb-1">
              Impact on {h.impact_metric}
            </div>
            <p className="text-[11px] text-muted-foreground leading-relaxed border-l-2 border-primary/30 pl-3">{h.evidence}</p>
          </div>
          <button
            onClick={() => navigate("/app/creative-library")}
            className="text-[10px] text-primary hover:text-primary/80 transition-colors"
          >
            View {h.linked_concept} in Creative Library →
          </button>
        </div>
      )}
    </div>
  );
}

// ─── HypothesisQueue ───────────────────────────────────────────────────

export function HypothesisQueue() {
  const { currentWorkspace } = useWorkspace();
  const [statusFilter, setStatusFilter] = useState<"All" | HypothesisStatus>("All");

  const all = getHypotheses(currentWorkspace.id);
  const filtered = statusFilter === "All" ? all : all.filter((h) => h.status === statusFilter);
  const sorted = [...filtered].sort((a, b) => b.priority_score - a.priority_score);

  const counts: Record<HypothesisStatus, number> = {
    Queued: all.filter((h) => h.status === "Queued").length,
    Testing: all.filter((h) => h.status === "Testing").length,
    Validated: all.filter((h) => h.status === "Validated").length,
    Rejected: all.filter((h) => h.status === "Rejected").length,
  };

  const STATUS_TABS: ("All" | HypothesisStatus)[] = ["All", ...HYPOTHESIS_STATUSES];

  return (
    <div className="h-full overflow-y-auto">
      <div className="max-w-6xl mx-auto px-6 py-5 space-y-4">

        {/* Header */}
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-primary/10 border border-primary/20 flex items-center justify-center">
            <FlaskConical className="w-4 h-4 text-primary" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-foreground tracking-tight">Hypothesis Queue</h1>
            <p className="text-xs text-muted-foreground mt-0.5">
              {currentWorkspace.name} — {all.length} prioritized test hypothes{all.length !== 1 ? "es" : "is"}
            </p>
          </div>
        </div>

        {/* Summary strip */}
        <div className="grid grid-cols-4 gap-3">
          {HYPOTHESIS_STATUSES.map((s) => {
            const Icon = STATUS_ICONS[s];
            const color = s === "Validated" ? "text-emerald-400" : s === "Testing" ? "text-primary" : s === "Rejected" ? "text-red-400" : "text-muted-foreground";
            return (
              <button
                key={s}
                onClick={() => setStatusFilter(s)}
                className="bg-card border border-border/60 rounded-xl px-4 py-3 text-left hover:border-border transition-all"
              >
                <div className={cn("flex items-center gap-1.5 text-xl font-bold", color)}>
                  <Icon className="w-3.5 h-3.5" />
                  {counts[s]}
                </div>
                <div className="text-[10px] font-medium text-muted-foreground mt-1">{s}</div>
              </button>
            );
          })}
        </div>

        {/* Status filter tabs */}
        <div className="flex items-center gap-2 flex-wrap">
          <span className="text-[10px] text-muted-foreground font-medium">Status:</span>
          {STATUS_TABS.map((s) => (
            <button
              key={s}
              onClick={() => setStatusFilter(s)}
              className={cn(
                "px-3 py-1.5 rounded-full text-[11px] font-medium border transition-all",
                statusFilter === s
                  ? "bg-primary/15 border-primary/40 text-primary"
                  : "bg-transparent border-border/50 text-muted-foreground hover:border-border hover:text-foreground"
              )}
            >
              {s === "All" ? "All Hypotheses" : s}
            </button>
          ))}
        </div>

        {/* Table */}
        {sorted.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 space-y-3">
            <FlaskConical className="w-8 h-8 text-muted-foreground/40" />
            <p className="text-sm text-muted-foreground">No hypotheses in this queue.</p>
            <p className="text-xs text-muted-foreground/60">Hypotheses are generated from IAP runs and coverage gaps.</p>
          </div>
        ) : (
          <div className="bg-card border border-border/60 rounded-xl overflow-hidden">
            {/* Column headers */}
            <div className="flex items-center gap-3 px-4 py-2 bg-muted/10 border-b border-border/30">
              <span className="text-[9px] font-semibold uppercase tracking-[0.14em] text-muted-foreground/70 w-[72px] shrink-0">Priority</span>
              <span className="text-[9px] font-semibold uppercase tracking-[0.14em] text-muted-foreground/70 w-9 shrink-0">ID</span>
              <span className="text-[9px] font-semibold uppercase tracking-[0.14em] text-muted-foreground/70 flex-1">Hypothesis</span>
              <span className="text-[9px] font-semibold uppercase tracking-[0.14em] text-muted-foreground/70 w-9 shrink-0 text-center">Fam</span>
              <span className="text-[9px] font-semibold uppercase tracking-[0.14em] text-muted-foreground/70 w-[92px] shrink-0 text-right">Impact</span>
              <span className="text-[9px] font-semibold uppercase tracking-[0.14em] text-muted-foreground/70 w-14 shrink-0 text-center">Conf.</span>
              <span className="text-[9px] font-semibold uppercase tracking-[0.14em] text-muted-foreground/70 w-[92px] shrink-0 text-right">Status</span>
              <span className="w-3.5 shrink-0" />
            </div>
            {sorted.map((h, i) => (
              <HypothesisRow key={h.id} h={h} last={i === sorted.length - 1} />
            ))}
          </div>
        )}

      </div>
    </div>
  );
}
