import { useEffect, useRef, useState } from "react";
import { useLocation, useSearch } from "wouter";
import { cn } from "@/lib/utils";
import {
  Zap, ChevronRight, Search, Filter, Clock, Calendar, Target, Building2,
} from "lucide-react";
import { useWorkspace } from "@/contexts/WorkspaceContext";
import { rememberRunsListSearch } from "@/lib/runs-list-state";
import { ANALYSIS_RUNS, WORKSPACES, getAdAccountById, getUserById, getWorkspaceById } from "@/lib/mock-data";
import type { AnalysisRunStatus } from "@/lib/types";

// ─── Status styling ────────────────────────────────────────────────────

const STATUS_STYLES: Record<AnalysisRunStatus, string> = {
  Pending: "bg-muted text-muted-foreground border-border/40",
  Running: "bg-primary/10 text-primary border-primary/20",
  Completed: "bg-emerald-500/10 text-emerald-400 border-emerald-500/20",
  Failed: "bg-destructive/15 text-destructive border-destructive/20",
  Archived: "bg-muted text-muted-foreground/60 border-border/30",
};

const STATUS_BAR: Record<AnalysisRunStatus, string> = {
  Pending: "bg-border",
  Running: "bg-primary",
  Completed: "bg-emerald-500",
  Failed: "bg-destructive",
  Archived: "bg-muted-foreground/20",
};

const STATUSES: ("All" | AnalysisRunStatus)[] = [
  "All", "Pending", "Running", "Completed", "Failed", "Archived",
];

// ─── IAPRunsList ───────────────────────────────────────────────────────

export function IAPRunsList() {
  const [, navigate] = useLocation();
  const searchString = useSearch();
  const { currentWorkspace, switchWorkspace } = useWorkspace();

  const params = new URLSearchParams(searchString);
  const allWorkspaces = params.get("scope") === "all";

  const search = params.get("q") ?? "";
  const rawStatus = params.get("status") ?? "All";
  const statusFilter = STATUSES.includes(rawStatus as "All" | AnalysisRunStatus)
    ? rawStatus
    : "All";
  const workspaceFilter = allWorkspaces
    ? (params.get("workspaces") ?? "")
        .split(",")
        .filter(id => WORKSPACES.some(ws => ws.id === id))
    : [];

  const updateParams = (updates: Record<string, string | null>, currentSearch = searchString) => {
    const next = new URLSearchParams(currentSearch);
    for (const [key, value] of Object.entries(updates)) {
      if (value === null || value === "") next.delete(key);
      else next.set(key, value);
    }
    const qs = next.toString();
    navigate(`/app/analysis/library${qs ? `?${qs}` : ""}`, { replace: true });
  };

  useEffect(() => {
    rememberRunsListSearch(searchString);
  }, [searchString]);

  const [searchInput, setSearchInput] = useState(search);
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const lastSyncedRef = useRef(search);

  useEffect(() => {
    if (search !== lastSyncedRef.current) {
      lastSyncedRef.current = search;
      setSearchInput(search);
    }
  }, [search]);

  useEffect(() => () => {
    if (debounceRef.current) clearTimeout(debounceRef.current);
  }, []);

  const setSearch = (value: string) => {
    setSearchInput(value);
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => {
      lastSyncedRef.current = value;
      updateParams({ q: value }, window.location.search.replace(/^\?/, ""));
    }, 300);
  };

  const flushSearch = () => {
    if (!debounceRef.current) return;
    clearTimeout(debounceRef.current);
    debounceRef.current = null;
    lastSyncedRef.current = searchInput;
    updateParams({ q: searchInput }, window.location.search.replace(/^\?/, ""));
  };

  const setStatusFilter = (value: string) =>
    updateParams({ status: value === "All" ? null : value });
  const setWorkspaceFilter = (ids: string[]) =>
    updateParams({ workspaces: ids.length > 0 ? ids.join(",") : null });

  const setScope = (all: boolean) =>
    updateParams({ scope: all ? "all" : null, workspaces: null });

  const toggleWorkspace = (id: string) => {
    setWorkspaceFilter(
      workspaceFilter.includes(id)
        ? workspaceFilter.filter(w => w !== id)
        : [...workspaceFilter, id]
    );
  };

  const scopedRuns = allWorkspaces
    ? ANALYSIS_RUNS
    : ANALYSIS_RUNS.filter(r => r.workspace_id === currentWorkspace.id);

  const allRuns = allWorkspaces && workspaceFilter.length > 0
    ? scopedRuns.filter(r => workspaceFilter.includes(r.workspace_id))
    : scopedRuns;

  const filtered = allRuns.filter(r => {
    const account = getAdAccountById(r.ad_account_id);
    const workspace = allWorkspaces ? getWorkspaceById(r.workspace_id) : null;
    const haystack = `${r.priority_read} ${r.objective} ${account?.account_name ?? ""} ${workspace?.name ?? ""}`.toLowerCase();
    const matchSearch = !searchInput || haystack.includes(searchInput.toLowerCase());
    const matchStatus = statusFilter === "All" || r.status === statusFilter;
    return matchSearch && matchStatus;
  });

  const sortedRuns = [...filtered].sort(
    (a, b) => b.created_at.localeCompare(a.created_at)
  );

  return (
    <div className="h-full overflow-y-auto">
      <div className="max-w-5xl mx-auto px-6 py-5 space-y-4">

        {/* Header */}
        <div className="flex items-start justify-between">
          <div>
            <h1 className="text-xl font-bold text-foreground tracking-tight">IAP Library</h1>
            <p className="text-xs text-muted-foreground mt-0.5">
              {allWorkspaces ? "All workspaces" : currentWorkspace.name} — {allRuns.length} run{allRuns.length !== 1 ? "s" : ""}
            </p>
          </div>
          <div className="flex items-center gap-2">
            <div className="flex items-center rounded-xl border border-border/60 bg-card p-0.5">
              <button
                onClick={() => setScope(false)}
                className={cn(
                  "px-3 py-1.5 rounded-lg text-[11px] font-medium transition-all",
                  !allWorkspaces
                    ? "bg-primary/10 text-primary"
                    : "text-muted-foreground hover:text-foreground"
                )}
              >
                {currentWorkspace.name}
              </button>
              <button
                onClick={() => setScope(true)}
                className={cn(
                  "flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[11px] font-medium transition-all",
                  allWorkspaces
                    ? "bg-primary/10 text-primary"
                    : "text-muted-foreground hover:text-foreground"
                )}
              >
                <Building2 className="w-3 h-3" />
                All workspaces
              </button>
            </div>
            <button
              onClick={() => navigate("/app/analysis/new-run")}
              className="flex items-center gap-2 px-4 py-2 rounded-xl bg-primary text-white text-xs font-medium hover:bg-primary/90 transition-all"
            >
              <Zap className="w-3.5 h-3.5" />
              New IAP Run
            </button>
          </div>
        </div>

        {/* Filter row */}
        <div className="flex items-center gap-3">
          <div className="relative flex-1 max-w-xs">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
            <input
              type="text"
              placeholder="Search runs…"
              value={searchInput}
              onChange={e => setSearch(e.target.value)}
              onBlur={flushSearch}
              onKeyDown={e => {
                if (e.key === "Enter") flushSearch();
              }}
              className="w-full bg-card border border-border/60 rounded-xl pl-9 pr-4 py-2 text-xs text-foreground placeholder:text-muted-foreground focus:outline-none focus:border-primary/50 focus:ring-1 focus:ring-primary/20 transition-all"
            />
          </div>
          <div className="flex items-center gap-1">
            <Filter className="w-3.5 h-3.5 text-muted-foreground mr-1" />
            {STATUSES.map(s => (
              <button
                key={s}
                onClick={() => setStatusFilter(s)}
                className={cn(
                  "px-3 py-1.5 rounded-lg text-[11px] font-medium border transition-all",
                  statusFilter === s
                    ? "bg-primary/10 border-primary/40 text-primary"
                    : "bg-transparent border-border/40 text-muted-foreground hover:border-border hover:text-foreground"
                )}
              >
                {s}
              </button>
            ))}
          </div>
        </div>

        {/* Workspace filter (all-workspaces scope only) */}
        {allWorkspaces && (
          <div className="flex items-center gap-1 flex-wrap">
            <Building2 className="w-3.5 h-3.5 text-muted-foreground mr-1" />
            <button
              onClick={() => setWorkspaceFilter([])}
              className={cn(
                "px-3 py-1.5 rounded-lg text-[11px] font-medium border transition-all",
                workspaceFilter.length === 0
                  ? "bg-primary/10 border-primary/40 text-primary"
                  : "bg-transparent border-border/40 text-muted-foreground hover:border-border hover:text-foreground"
              )}
            >
              All
            </button>
            {WORKSPACES.map(ws => (
              <button
                key={ws.id}
                onClick={() => toggleWorkspace(ws.id)}
                className={cn(
                  "px-3 py-1.5 rounded-lg text-[11px] font-medium border transition-all",
                  workspaceFilter.includes(ws.id)
                    ? "bg-primary/10 border-primary/40 text-primary"
                    : "bg-transparent border-border/40 text-muted-foreground hover:border-border hover:text-foreground"
                )}
              >
                {ws.name}
              </button>
            ))}
          </div>
        )}

        {/* Run list */}
        {/* Status KPI strip */}
        {allRuns.length > 0 && (
          <div className="grid grid-cols-5 gap-3">
            {STATUSES.slice(1).map(s => {
              const count = allRuns.filter(r => r.status === s).length;
              return (
                <button
                  key={s}
                  onClick={() => setStatusFilter(s)}
                  className={cn(
                    "bg-card border rounded-xl px-3 py-2.5 text-left transition-all",
                    statusFilter === s
                      ? "border-primary/40 bg-primary/5"
                      : "border-border/40 hover:border-border/80"
                  )}
                >
                  <div className={cn("text-lg font-bold leading-none", STATUS_STYLES[s as AnalysisRunStatus].split(" ").find((c: string) => c.startsWith("text-")) ?? "text-foreground")}>{count}</div>
                  <div className="text-[10px] text-muted-foreground mt-1">{s}</div>
                </button>
              );
            })}
          </div>
        )}

        {sortedRuns.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 space-y-3">
            <Zap className="w-8 h-8 text-muted-foreground/40" />
            <p className="text-sm text-muted-foreground">No runs found.</p>
            <button
              onClick={() => navigate("/app/analysis/new-run")}
              className="text-xs text-primary hover:underline"
            >
              Start a new IAP run
            </button>
          </div>
        ) : (
          <div className="space-y-2">
            {sortedRuns.map(run => {
              const account = getAdAccountById(run.ad_account_id);
              const workspace = allWorkspaces ? getWorkspaceById(run.workspace_id) : null;
              const creator = getUserById(run.created_by);
              const findingsCount = run.findings.length;
              const decisionsCount = run.decision_feed.length;
              return (
                <button
                  key={run.id}
                  onClick={() => navigate(`/app/analysis/library/${run.id}`)}
                  className="w-full flex items-center gap-4 px-4 py-3.5 rounded-xl border border-border/60 bg-card hover:border-primary/30 hover:bg-primary/5 transition-all text-left group"
                >
                  {/* Status indicator */}
                  <div className={cn("w-1.5 h-8 rounded-full shrink-0", STATUS_BAR[run.status])} />

                  {/* Title + meta */}
                  <div className="flex-1 min-w-0 space-y-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      {workspace && (
                        <span
                          role="link"
                          tabIndex={0}
                          title={`Go to ${workspace.name} workspace`}
                          onClick={(e) => {
                            e.stopPropagation();
                            switchWorkspace(workspace.id);
                          }}
                          onKeyDown={(e) => {
                            if (e.key === "Enter" || e.key === " ") {
                              e.preventDefault();
                              e.stopPropagation();
                              switchWorkspace(workspace.id);
                            }
                          }}
                          className="flex items-center gap-1 text-[10px] px-1.5 py-0.5 rounded border border-border/60 bg-background/60 text-muted-foreground font-medium leading-none shrink-0 cursor-pointer hover:border-primary/40 hover:text-primary hover:bg-primary/10 transition-colors"
                        >
                          <Building2 className="w-2.5 h-2.5" />
                          {workspace.name}
                        </span>
                      )}
                      <span className="text-xs font-semibold text-foreground group-hover:text-primary transition-colors truncate">
                        {run.priority_read}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 flex-wrap text-[10px] text-muted-foreground">
                      {account && <span>{account.account_name}</span>}
                      {account && <span className="text-muted-foreground/30">·</span>}
                      <span className="flex items-center gap-1">
                        <Target className="w-2.5 h-2.5" /> {run.objective}
                      </span>
                      <span className="text-muted-foreground/30">·</span>
                      <span className="font-mono">{run.depth}</span>
                      <span className="text-muted-foreground/30">·</span>
                      <span className="flex items-center gap-1">
                        <Calendar className="w-2.5 h-2.5" />
                        {run.date_range_start} → {run.date_range_end}
                      </span>
                      <span className="text-muted-foreground/30">·</span>
                      <span className="flex items-center gap-1">
                        <Clock className="w-2.5 h-2.5" /> {run.created_at}
                      </span>
                      {creator && (
                        <>
                          <span className="text-muted-foreground/30">·</span>
                          <span>{creator.name}</span>
                        </>
                      )}
                    </div>
                  </div>

                  {/* Badges */}
                  <div className="flex items-center gap-2 shrink-0">
                    {run.status === "Completed" && (
                      <span className="text-[10px] text-muted-foreground font-mono">
                        {findingsCount} finding{findingsCount !== 1 ? "s" : ""} · {decisionsCount} decision{decisionsCount !== 1 ? "s" : ""}
                      </span>
                    )}
                    {run.status === "Completed" && (
                      <span className="text-[10px] px-2 py-0.5 rounded border font-semibold leading-none text-[hsl(var(--metrix-gold))] bg-[hsl(var(--metrix-gold)/0.12)] border-[hsl(var(--metrix-gold)/0.25)]">
                        {run.confidence_score}% conf
                      </span>
                    )}
                    <span className={cn(
                      "text-[10px] px-2 py-0.5 rounded border font-semibold leading-none",
                      STATUS_STYLES[run.status]
                    )}>
                      {run.status}
                    </span>
                    <ChevronRight className="w-3.5 h-3.5 text-muted-foreground/30 group-hover:text-primary transition-colors" />
                  </div>
                </button>
              );
            })}
          </div>
        )}

      </div>
    </div>
  );
}
