import { useState } from "react";
import { useLocation } from "wouter";
import { cn } from "@/lib/utils";
import {
  LayoutGrid, Smartphone, ArrowRight, TrendingUp, TrendingDown,
  ChevronDown, ChevronUp, Apple, Bot,
} from "lucide-react";
import { useWorkspace } from "@/contexts/WorkspaceContext";
import {
  getPlacementData,
  type PlacementRow, type PlacementFatigue, type PlacementAction,
} from "@/lib/mock/placements";

// ─── Formatters ────────────────────────────────────────────────────────

const money = (n: number) => `$${n.toLocaleString("en-US", { maximumFractionDigits: 0 })}`;
const money2 = (n: number) => `$${n.toFixed(2)}`;
const num = (n: number) => n.toLocaleString("en-US");

function cpm(r: PlacementRow) { return (r.spend / r.impressions) * 1000; }
function ctr(r: PlacementRow) { return (r.clicks / r.impressions) * 100; }
function cpa(r: PlacementRow) { return r.installs > 0 ? r.spend / r.installs : 0; }

// ─── Chips ─────────────────────────────────────────────────────────────

const FATIGUE_STYLES: Record<PlacementFatigue, string> = {
  fresh: "text-emerald-400",
  mild_fatigue: "text-yellow-400",
  fatigued: "text-orange-400",
  burnt: "text-red-400",
};

function ActionChip({ a }: { a: PlacementAction }) {
  const s: Record<PlacementAction, string> = {
    Scale: "text-emerald-400 border-emerald-500/20 bg-emerald-500/10",
    Hold: "text-primary border-primary/20 bg-primary/10",
    Shift: "text-yellow-400 border-yellow-400/20 bg-yellow-400/10",
    Cut: "text-red-400 border-red-500/20 bg-red-500/10",
  };
  return <span className={cn("text-[9px] px-1.5 py-0.5 rounded border font-semibold leading-none", s[a])}>{a}</span>;
}

function ConfChip({ c }: { c: "high" | "medium" | "validation_required" }) {
  const map = {
    high: "bg-emerald-500/10 border-emerald-500/20 text-emerald-400",
    medium: "bg-yellow-400/10 border-yellow-400/20 text-yellow-400",
    validation_required: "bg-orange-400/10 border-orange-400/20 text-orange-400",
  } as const;
  const labels = { high: "High", medium: "Med", validation_required: "Validate" } as const;
  return <span className={cn("text-[9px] px-1.5 py-0.5 rounded border font-semibold leading-none", map[c])}>{labels[c]}</span>;
}

function TrendPill({ v }: { v: number }) {
  if (v === 0) return <span className="text-[10px] font-mono text-muted-foreground">0%</span>;
  const up = v > 0;
  return (
    <span className={cn("inline-flex items-center gap-0.5 text-[10px] font-mono font-semibold", up ? "text-emerald-400" : "text-red-400")}>
      {up ? <TrendingUp className="w-2.5 h-2.5" /> : <TrendingDown className="w-2.5 h-2.5" />}
      {up ? "+" : ""}{v}%
    </span>
  );
}

// ─── Split bar (two segments) ──────────────────────────────────────────

function SplitBar({ left, right, leftColor, rightColor }: { left: number; right: number; leftColor: string; rightColor: string }) {
  return (
    <div className="flex w-full h-1.5 rounded-full overflow-hidden bg-border/30">
      <div className={leftColor} style={{ width: `${left}%` }} />
      <div className={rightColor} style={{ width: `${right}%` }} />
    </div>
  );
}

// ─── Placements ────────────────────────────────────────────────────────

export function Placements() {
  const { currentWorkspace } = useWorkspace();
  const [, navigate] = useLocation();
  const data = getPlacementData(currentWorkspace.id);

  const [expanded, setExpanded] = useState<string | null>(data.rows[0]?.id ?? null);

  const totalSpend = data.rows.reduce((s, r) => s + r.spend, 0);
  const totalInstalls = data.rows.reduce((s, r) => s + r.installs, 0);

  // Spend-weighted aggregate splits
  const aggIos = Math.round(data.rows.reduce((s, r) => s + r.ios_pct * r.spend, 0) / totalSpend);
  const aggAndroid = 100 - aggIos;
  const platformSpend = data.rows.filter((r) => r.fb_pct + r.ig_pct > 0).reduce((s, r) => s + r.spend, 0);
  const aggFb = Math.round(data.rows.reduce((s, r) => s + r.fb_pct * r.spend, 0) / platformSpend);
  const aggIg = 100 - aggFb;

  const bestPlacement = [...data.rows].filter((r) => r.installs > 0).sort((a, b) => cpa(a) - cpa(b))[0];

  return (
    <div className="h-full overflow-y-auto">
      <div className="max-w-6xl mx-auto px-6 py-5 space-y-4">

        {/* Header */}
        <div className="flex items-start justify-between">
          <div className="space-y-0.5">
            <div className="flex items-center gap-2">
              <LayoutGrid className="w-4 h-4 text-primary" />
              <h1 className="text-xl font-bold text-foreground tracking-tight">Placements</h1>
            </div>
            <p className="text-xs text-muted-foreground">{data.account_label} · {data.date_range}</p>
          </div>
          <span className="text-[10px] font-mono text-muted-foreground/60 pt-1">
            {data.rows.length} placements · blended CPA {money2(data.blended_cpa)}
          </span>
        </div>

        {/* KPI row */}
        <div className="grid grid-cols-4 gap-3">
          {[
            { label: "Spend Analyzed", value: money(totalSpend), sub: "across placements", color: "text-primary" },
            { label: "Installs", value: num(totalInstalls), sub: `blended CPA ${money2(totalSpend / totalInstalls)}`, color: "text-foreground" },
            { label: "Best Placement", value: bestPlacement?.name ?? "—", sub: bestPlacement ? `CPA ${money2(cpa(bestPlacement))}` : "", color: "text-emerald-400" },
            { label: "Device Lead", value: aggAndroid >= aggIos ? "Android" : "iOS", sub: `${Math.max(aggAndroid, aggIos)}% of spend`, color: "text-[hsl(var(--metrix-gold))]" },
          ].map((k) => (
            <div key={k.label} className="bg-card border border-border/60 rounded-xl px-4 py-3">
              <div className={cn("text-2xl font-bold leading-none", k.color)}>{k.value}</div>
              <div className="text-[11px] font-medium text-foreground mt-1.5">{k.label}</div>
              <div className="text-[10px] text-muted-foreground mt-0.5">{k.sub}</div>
            </div>
          ))}
        </div>

        {/* Aggregate splits */}
        <div className="grid grid-cols-2 gap-3">
          <div className="bg-card border border-border/60 rounded-xl px-4 py-3 space-y-2">
            <div className="flex items-center gap-1.5">
              <Smartphone className="w-3 h-3 text-[hsl(var(--metrix-cyan))]" />
              <span className="text-[9px] font-semibold uppercase tracking-[0.18em] text-muted-foreground/70">Device Split</span>
            </div>
            <SplitBar left={aggIos} right={aggAndroid} leftColor="bg-[hsl(var(--metrix-cyan))]" rightColor="bg-emerald-500" />
            <div className="flex items-center justify-between text-[10px]">
              <span className="flex items-center gap-1 text-[hsl(var(--metrix-cyan))]"><Apple className="w-2.5 h-2.5" /> iOS {aggIos}%</span>
              <span className="flex items-center gap-1 text-emerald-400"><Bot className="w-2.5 h-2.5" /> Android {aggAndroid}%</span>
            </div>
          </div>
          <div className="bg-card border border-border/60 rounded-xl px-4 py-3 space-y-2">
            <div className="flex items-center gap-1.5">
              <LayoutGrid className="w-3 h-3 text-primary" />
              <span className="text-[9px] font-semibold uppercase tracking-[0.18em] text-muted-foreground/70">Platform Split</span>
            </div>
            <SplitBar left={aggFb} right={aggIg} leftColor="bg-primary" rightColor="bg-[hsl(var(--metrix-gold))]" />
            <div className="flex items-center justify-between text-[10px]">
              <span className="text-primary">Facebook {aggFb}%</span>
              <span className="text-[hsl(var(--metrix-gold))]">Instagram {aggIg}%</span>
            </div>
          </div>
        </div>

        {/* Placement rows */}
        <div className="space-y-2">
          <span className="text-[9px] font-semibold uppercase tracking-[0.18em] text-muted-foreground/70">Placement Performance</span>
          <div className="space-y-2">
            {data.rows.map((r) => {
              const open = expanded === r.id;
              const sharePct = (r.spend / totalSpend) * 100;
              const cpaVal = cpa(r);
              const cpaRatio = cpaVal > 0 ? cpaVal / data.blended_cpa : 0;
              const cpaColor = cpaVal === 0 ? "text-muted-foreground/50" : cpaRatio <= 0.95 ? "text-emerald-400" : cpaRatio <= 1.15 ? "text-foreground" : cpaRatio <= 1.5 ? "text-orange-400" : "text-red-400";
              const offPlatform = r.fb_pct + r.ig_pct === 0;
              return (
                <div key={r.id} className="bg-card border border-border/60 rounded-xl overflow-hidden">
                  <button
                    onClick={() => setExpanded(open ? null : r.id)}
                    className="w-full flex items-center gap-3 px-4 py-3 text-left hover:bg-white/[0.02] transition-colors"
                  >
                    {/* name + share bar */}
                    <div className="w-44 shrink-0">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-semibold text-foreground">{r.name}</span>
                        <span className={cn("w-1 h-1 rounded-full", FATIGUE_STYLES[r.fatigue].replace("text-", "bg-"))} />
                      </div>
                      <div className="flex items-center gap-1.5 mt-1">
                        <div className="w-24 bg-border/30 rounded-full h-1 overflow-hidden">
                          <div className="h-full rounded-full bg-[hsl(var(--metrix-cyan))]" style={{ width: `${sharePct}%` }} />
                        </div>
                        <span className="text-[9px] font-mono text-muted-foreground">{sharePct.toFixed(0)}%</span>
                      </div>
                    </div>
                    {/* metrics */}
                    <div className="flex-1 grid grid-cols-5 gap-2 text-right">
                      <div>
                        <div className="text-[11px] font-mono text-foreground">{money(r.spend)}</div>
                        <div className="text-[9px] text-muted-foreground">Spend</div>
                      </div>
                      <div>
                        <div className="text-[11px] font-mono text-muted-foreground">{money2(cpm(r))}</div>
                        <div className="text-[9px] text-muted-foreground">CPM</div>
                      </div>
                      <div>
                        <div className="text-[11px] font-mono text-muted-foreground">{ctr(r).toFixed(2)}%</div>
                        <div className="text-[9px] text-muted-foreground">CTR</div>
                      </div>
                      <div>
                        <div className="text-[11px] font-mono text-foreground">{num(r.installs)}</div>
                        <div className="text-[9px] text-muted-foreground">Installs</div>
                      </div>
                      <div>
                        <div className={cn("text-[11px] font-mono font-semibold", cpaColor)}>{cpaVal > 0 ? money2(cpaVal) : "—"}</div>
                        <div className="text-[9px] text-muted-foreground">CPA</div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 shrink-0 w-16 justify-end">
                      <TrendPill v={r.trend_pct} />
                    </div>
                    {open ? <ChevronUp className="w-3.5 h-3.5 text-muted-foreground shrink-0" /> : <ChevronDown className="w-3.5 h-3.5 text-muted-foreground shrink-0" />}
                  </button>

                  {open && (
                    <div className="px-4 pb-4 pt-1 border-t border-border/20 grid grid-cols-2 gap-5 bg-muted/[0.03]">
                      <div className="space-y-1.5 pt-3">
                        <div className="flex items-center gap-1.5 text-[9px] font-semibold uppercase tracking-wide text-muted-foreground/70">
                          <Smartphone className="w-2.5 h-2.5" /> Device Split
                        </div>
                        <SplitBar left={r.ios_pct} right={r.android_pct} leftColor="bg-[hsl(var(--metrix-cyan))]" rightColor="bg-emerald-500" />
                        <div className="flex items-center justify-between text-[10px]">
                          <span className="text-[hsl(var(--metrix-cyan))]">iOS {r.ios_pct}%</span>
                          <span className="text-emerald-400">Android {r.android_pct}%</span>
                        </div>
                      </div>
                      <div className="space-y-1.5 pt-3">
                        <div className="flex items-center gap-1.5 text-[9px] font-semibold uppercase tracking-wide text-muted-foreground/70">
                          <LayoutGrid className="w-2.5 h-2.5" /> Platform Split
                        </div>
                        {offPlatform ? (
                          <div className="text-[10px] text-muted-foreground pt-1">Off-platform inventory — {r.surface}</div>
                        ) : (
                          <>
                            <SplitBar left={r.fb_pct} right={r.ig_pct} leftColor="bg-primary" rightColor="bg-[hsl(var(--metrix-gold))]" />
                            <div className="flex items-center justify-between text-[10px]">
                              <span className="text-primary">Facebook {r.fb_pct}%</span>
                              <span className="text-[hsl(var(--metrix-gold))]">Instagram {r.ig_pct}%</span>
                            </div>
                          </>
                        )}
                      </div>
                      <div className="col-span-2 flex items-center gap-3 text-[10px] text-muted-foreground pt-1 border-t border-border/20">
                        <span className="capitalize">Fatigue: <span className={FATIGUE_STYLES[r.fatigue]}>{r.fatigue.replace("_", " ")}</span></span>
                        <span className="text-muted-foreground/30">·</span>
                        <span>{r.surface}</span>
                        <span className="text-muted-foreground/30">·</span>
                        <span>{num(r.clicks)} clicks</span>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Recommendations */}
        <div className="space-y-2">
          <span className="text-[9px] font-semibold uppercase tracking-[0.18em] text-muted-foreground/70">Placement Recommendations</span>
          <div className="space-y-2">
            {data.recommendations.map((r) => (
              <div key={r.id} className="flex items-center gap-3 bg-card border border-border/60 rounded-xl px-4 py-2.5">
                <ActionChip a={r.action} />
                <span className="text-[11px] font-semibold text-foreground w-32 shrink-0">{r.placement}</span>
                <span className="text-[11px] text-muted-foreground flex-1">{r.rationale}</span>
                <ConfChip c={r.confidence} />
              </div>
            ))}
          </div>
          <button
            onClick={() => navigate("/app/iap/new")}
            className="text-[11px] text-primary hover:text-primary/80 transition-colors flex items-center gap-1 pt-1"
          >
            Apply to next IAP run <ArrowRight className="w-3 h-3" />
          </button>
        </div>

      </div>
    </div>
  );
}
