// ═══════════════════════════════════════════════════════════════════════
// METRIX IAP — MST › History (/app/mst/history)
// Past MST sessions: date, account, matrix name, status.
// ═══════════════════════════════════════════════════════════════════════

import { Link } from "wouter";
import { Layers, ArrowUpRight, Calendar } from "lucide-react";
import { cn } from "@/lib/utils";
import { useWorkspace } from "@/contexts/WorkspaceContext";
import { MST_MATRICES, WORKSPACES } from "@/lib/mock-data";

type SessionStatus = "Complete" | "Active" | "Archived";

const STATUS_PILL: Record<SessionStatus, string> = {
  Active:   "bg-primary/10 text-primary border-primary/20",
  Complete: "bg-emerald-500/10 text-emerald-400 border-emerald-500/20",
  Archived: "bg-muted text-muted-foreground/60 border-border/30",
};

function deriveStatus(idx: number): SessionStatus {
  if (idx === 0) return "Active";
  if (idx < 3) return "Complete";
  return "Archived";
}

export function MSTHistory() {
  const { currentWorkspace } = useWorkspace();

  const matrices = MST_MATRICES.slice(0, 8).map((m, i) => {
    const ws = WORKSPACES.find(w => w.id === m.workspace_id);
    return {
      ...m,
      wsName: ws?.name ?? currentWorkspace.name,
      status: deriveStatus(i),
    };
  });

  const completeCount = matrices.filter(m => m.status === "Complete").length;
  const activeCount   = matrices.filter(m => m.status === "Active").length;

  return (
    <div className="flex-1 p-5 space-y-4 max-w-5xl">
      <div className="flex items-end justify-between gap-4">
        <div>
          <div className="text-[9px] font-semibold uppercase tracking-[0.18em] text-muted-foreground/60 mb-1">
            MST · Sessions
          </div>
          <h1 className="text-lg font-bold text-foreground tracking-tight">MST History</h1>
          <p className="text-xs text-muted-foreground mt-0.5">
            {matrices.length} session{matrices.length !== 1 ? "s" : ""} · {completeCount} complete · {activeCount} active
          </p>
        </div>
        <Link
          href="/app/mst/variable-map"
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-primary text-primary-foreground text-xs font-semibold hover:opacity-90 transition-opacity"
        >
          New Session
        </Link>
      </div>

      {/* KPI strip */}
      <div className="grid grid-cols-3 gap-2.5">
        {[
          { label: "Total sessions", value: matrices.length,  color: "text-foreground" },
          { label: "Complete",       value: completeCount,    color: "text-[hsl(var(--metrix-success))]" },
          { label: "Active",         value: activeCount,      color: "text-primary" },
        ].map(kpi => (
          <div key={kpi.label} className="bg-card/60 border border-border/60 rounded-xl px-4 py-3">
            <div className="text-[9px] font-semibold uppercase tracking-[0.18em] text-muted-foreground/70 mb-1">{kpi.label}</div>
            <div className={cn("text-2xl font-bold tabular-nums", kpi.color)}>{kpi.value}</div>
          </div>
        ))}
      </div>

      {/* Sessions list */}
      {matrices.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-20 space-y-3">
          <Layers className="w-8 h-8 text-muted-foreground/40" />
          <p className="text-sm text-muted-foreground">No MST sessions yet.</p>
        </div>
      ) : (
        <div className="bg-card/60 border border-border/60 rounded-xl overflow-hidden">
          <div className="px-4 py-2.5 border-b border-border/40">
            <div className="text-[9px] font-semibold uppercase tracking-[0.18em] text-muted-foreground/70">All sessions</div>
          </div>
          <div className="divide-y divide-border/30">
            {matrices.map((m, i) => (
              <div key={m.id} className="flex items-center gap-3 px-4 py-3 group">
                <div className={cn(
                  "w-1 h-8 rounded-full shrink-0",
                  m.status === "Active" ? "bg-primary" : m.status === "Complete" ? "bg-emerald-500" : "bg-border"
                )} />
                <div className="flex-1 min-w-0 space-y-0.5">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-semibold text-foreground truncate">{m.name}</span>
                    <span className={cn(
                      "shrink-0 text-[10px] px-1.5 py-0.5 rounded border font-semibold leading-none",
                      STATUS_PILL[m.status as SessionStatus]
                    )}>
                      {m.status}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 text-[11px] text-muted-foreground">
                    <span>{m.wsName}</span>
                    <span className="text-muted-foreground/30">·</span>
                    <span>{m.cells.length} cells tested</span>
                    <span className="text-muted-foreground/30">·</span>
                    <span>{m.cells.filter(c => c.result === "universal_winner" || c.result === "avatar_specific").length} winner{m.cells.filter(c => c.result === "universal_winner" || c.result === "avatar_specific").length !== 1 ? "s" : ""}</span>
                  </div>
                </div>
                <div className="flex items-center gap-1.5 text-[10px] text-muted-foreground/60 shrink-0">
                  <Calendar className="w-3 h-3" />
                  {m.created_at.slice(0, 10)}
                </div>
                {i === 0 && (
                  <Link href="/app/mst/crossmap" className="text-[11px] text-primary hover:text-primary/80 transition-colors flex items-center gap-1 shrink-0">
                    Results <ArrowUpRight className="w-3 h-3" />
                  </Link>
                )}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
