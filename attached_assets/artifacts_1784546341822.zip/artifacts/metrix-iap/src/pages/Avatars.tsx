import { useState, useMemo } from "react";
import { Link } from "wouter";
import { cn } from "@/lib/utils";
import {
  Users, Frown, Heart, Layers, Sparkles,
  ArrowRight, ChevronDown, ChevronsDownUp, ChevronsUpDown,
} from "lucide-react";
import { useWorkspace } from "@/contexts/WorkspaceContext";
import type { ConfidenceLabel } from "@/lib/types";
import { getAvatars, type Avatar, type AvatarStatus } from "@/lib/mock/avatars";
import { useAccount } from "@/contexts/AccountContext";

// ─── Chip helpers ──────────────────────────────────────────────────────

function ConfidenceChip({ c }: { c: ConfidenceLabel }) {
  const map: Record<ConfidenceLabel, string> = {
    high: "bg-emerald-500/10 border-emerald-500/20 text-emerald-400",
    medium: "bg-yellow-400/10 border-yellow-400/20 text-yellow-400",
    validation_required: "bg-orange-400/10 border-orange-400/20 text-orange-400",
    insufficient: "bg-muted/50 border-border/40 text-muted-foreground",
  };
  const labels: Record<ConfidenceLabel, string> = {
    high: "High", medium: "Med", validation_required: "Validate", insufficient: "Insuff.",
  };
  return (
    <span className={cn("text-[9px] px-1.5 py-0.5 rounded border font-semibold leading-none", map[c])}>
      {labels[c]}
    </span>
  );
}

const STATUS_STYLES: Record<AvatarStatus, string> = {
  Primary:      "text-emerald-400 bg-emerald-500/10 border-emerald-500/20",
  Secondary:    "text-primary bg-primary/10 border-primary/20",
  Emerging:     "text-yellow-400 bg-yellow-400/10 border-yellow-400/20",
  Deprioritized:"text-muted-foreground bg-muted/50 border-border/40",
};

function StatusChip({ s }: { s: AvatarStatus }) {
  return (
    <span className={cn("text-[9px] px-1.5 py-0.5 rounded border font-semibold leading-none shrink-0", STATUS_STYLES[s])}>
      {s}
    </span>
  );
}

const money2 = (n: number) => n.toLocaleString("en-US", { style: "currency", currency: "USD", minimumFractionDigits: 2, maximumFractionDigits: 2 });
const pct = (n: number) => `${(n * 100).toFixed(1)}%`;

// ─── Efficiency bar ────────────────────────────────────────────────────

function EfficiencyBar({ cpi, avgCpi }: { cpi: number; avgCpi: number }) {
  // Higher is more efficient (lower CPA vs average).
  const ratio = avgCpi / Math.max(cpi, 0.01);
  const pctFill = Math.min(100, Math.max(5, Math.round(ratio * 60)));
  const isGood = ratio >= 1;

  return (
    <div className="space-y-0.5">
      <div className="flex items-center justify-between text-[9px]">
        <span className="text-muted-foreground/60">CPI vs avg</span>
        <span className={cn("font-mono font-semibold", isGood ? "text-emerald-400" : "text-orange-400")}>
          {ratio >= 1 ? `${Math.round((ratio - 1) * 100)}% below avg` : `${Math.round((1 - ratio) * 100)}% above avg`}
        </span>
      </div>
      <div className="w-full bg-border/30 rounded-full h-1 overflow-hidden">
        <div className={cn("h-full rounded-full transition-all", isGood ? "bg-emerald-500" : "bg-orange-400")}
          style={{ width: `${pctFill}%` }} />
      </div>
    </div>
  );
}

// ─── Segment Card ──────────────────────────────────────────────────────

function SegmentCard({
  avatar, avgCpi, expanded, onToggle, withAccount,
}: {
  avatar: Avatar;
  avgCpi: number;
  expanded: boolean;
  onToggle: () => void;
  withAccount: (path: string) => string;
}) {
  const s = avatar.stats;
  const isPrimary = avatar.status === "Primary";

  return (
    <div className={cn(
      "rounded-xl border overflow-hidden transition-all duration-200",
      isPrimary
        ? "border-emerald-500/30 shadow-[0_0_16px_hsl(142deg_70%_45%/0.10)]"
        : "border-border/60",
      "bg-card"
    )}>
      {/* Collapsed header — always visible */}
      <button onClick={onToggle} className="w-full text-left hover:bg-white/[0.02] transition-colors">
        <div className="px-4 py-3.5 space-y-3">
          {/* Name + chips row */}
          <div className="flex items-start gap-3">
            <div className={cn(
              "w-9 h-9 rounded-lg flex items-center justify-center shrink-0 text-[11px] font-bold font-mono",
              isPrimary ? "bg-emerald-500/10 border border-emerald-500/20 text-emerald-400"
                : "bg-primary/10 border border-primary/20 text-primary"
            )}>
              {avatar.name.split(" ").slice(0, 2).map(w => w[0]).join("")}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-xs font-bold text-foreground">{avatar.name}</span>
                <StatusChip s={avatar.status} />
                <ConfidenceChip c={avatar.confidence} />
              </div>
              <p className="text-[10px] text-muted-foreground mt-0.5 truncate">{avatar.tagline}</p>
            </div>
            <ChevronDown className={cn("w-3.5 h-3.5 text-muted-foreground shrink-0 mt-0.5 transition-transform", expanded && "rotate-180")} />
          </div>

          {/* Efficiency bar */}
          <EfficiencyBar cpi={s.cpi_usd} avgCpi={avgCpi} />

          {/* Top-line stats */}
          <div className="grid grid-cols-4 gap-2">
            {[
              { label: "CPI",      value: money2(s.cpi_usd) },
              { label: "Reg CPA",  value: money2(s.cpr_usd) },
              { label: "Placement", value: avatar.primary_platform.split("·")[1]?.trim().split("·")[0]?.trim() ?? "—" },
              { label: "Spend",    value: pct(s.share_of_spend) },
            ].map(m => (
              <div key={m.label} className="rounded-lg border border-border/40 bg-muted/20 px-2 py-1.5">
                <div className="text-[8px] font-semibold uppercase tracking-[0.12em] text-muted-foreground/60">{m.label}</div>
                <div className="text-[11px] font-mono font-semibold text-foreground mt-0.5 truncate">{m.value}</div>
              </div>
            ))}
          </div>
        </div>
      </button>

      {/* Expanded detail — fades in */}
      {expanded && (
        <div className="border-t border-border/30 px-4 pb-4 pt-3 space-y-4 bg-muted/[0.03]">
          {/* Demographic profile */}
          <div>
            <div className="text-[9px] font-semibold uppercase tracking-[0.14em] text-muted-foreground/60 mb-1.5">Profile</div>
            <div className="flex flex-wrap gap-2 text-[10px] text-muted-foreground">
              <span className="border border-border/40 rounded px-1.5 py-0.5">{avatar.age_range}</span>
              <span className="border border-border/40 rounded px-1.5 py-0.5">{avatar.demographics}</span>
              <span className="border border-border/40 rounded px-1.5 py-0.5">{avatar.primary_platform}</span>
            </div>
          </div>

          {/* Pain points + motivators */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <div className="flex items-center gap-1 text-[9px] font-semibold uppercase tracking-[0.14em] text-red-400/80">
                <Frown className="w-2.5 h-2.5" /> Pain Points
              </div>
              {avatar.pains.slice(0, 3).map(p => (
                <p key={p} className="text-[10px] text-muted-foreground leading-snug border-l-2 border-red-500/30 pl-2">{p}</p>
              ))}
            </div>
            <div className="space-y-1.5">
              <div className="flex items-center gap-1 text-[9px] font-semibold uppercase tracking-[0.14em] text-emerald-400/80">
                <Heart className="w-2.5 h-2.5" /> Motivators
              </div>
              {avatar.desires.slice(0, 3).map(d => (
                <p key={d} className="text-[10px] text-muted-foreground leading-snug border-l-2 border-emerald-500/30 pl-2">{d}</p>
              ))}
            </div>
          </div>

          {/* Matched hooks */}
          {avatar.matched_hooks.length > 0 && (
            <div>
              <div className="text-[9px] font-semibold uppercase tracking-[0.14em] text-muted-foreground/60 mb-1.5 flex items-center gap-1">
                <Layers className="w-2.5 h-2.5" /> Matched Hooks
              </div>
              <div className="flex flex-wrap gap-1">
                {avatar.matched_hooks.map(h => (
                  <span key={h} className="text-[9px] font-mono px-1.5 py-0.5 rounded border border-primary/20 bg-primary/10 text-primary">{h}</span>
                ))}
              </div>
            </div>
          )}

          {/* Strategic recommendation */}
          <div className="flex items-start gap-2 border-t border-border/20 pt-3">
            <Sparkles className="w-3 h-3 text-[hsl(var(--metrix-gold))] shrink-0 mt-0.5" />
            <div className="flex-1">
              <div className="text-[9px] font-semibold uppercase tracking-[0.12em] text-muted-foreground/60 mb-1">Strategic Recommendation</div>
              <p className="text-[10px] text-muted-foreground leading-relaxed">{avatar.strategic_note}</p>
            </div>
          </div>

          {/* CTAs */}
          <div className="flex items-center gap-4 pt-1">
            <Link href={withAccount("/app/briefs/builder")}
              className="flex items-center gap-1 text-[10px] text-primary hover:text-primary/80 transition-colors">
              See briefs for this segment <ArrowRight className="w-3 h-3" />
            </Link>
            <Link href={withAccount("/app/strategy/map")}
              className="flex items-center gap-1 text-[10px] text-muted-foreground hover:text-foreground transition-colors">
              Open Strategy Map <ArrowRight className="w-3 h-3" />
            </Link>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Avatars (Avatar Map) ──────────────────────────────────────────────

export function Avatars() {
  const { currentWorkspace } = useWorkspace();
  const { withAccount } = useAccount();
  const [statusFilter, setStatusFilter] = useState<"All" | AvatarStatus>("All");
  const [expandedIds, setExpandedIds] = useState<Set<string>>(new Set());

  const allAvatars = getAvatars(currentWorkspace.id);
  const filtered = statusFilter === "All" ? allAvatars : allAvatars.filter(a => a.status === statusFilter);

  // Primary first, then by spend share descending
  const sorted = [...filtered].sort((a, b) => {
    if (a.status === "Primary" && b.status !== "Primary") return -1;
    if (b.status === "Primary" && a.status !== "Primary") return 1;
    return b.stats.share_of_spend - a.stats.share_of_spend;
  });

  const avgCpi = useMemo(() => {
    if (allAvatars.length === 0) return 1;
    return allAvatars.reduce((sum, a) => sum + a.stats.cpi_usd, 0) / allAvatars.length;
  }, [allAvatars]);

  const allExpanded = sorted.length > 0 && sorted.every(a => expandedIds.has(a.id));

  function toggleExpandAll() {
    if (allExpanded) {
      setExpandedIds(new Set());
    } else {
      setExpandedIds(new Set(sorted.map(a => a.id)));
    }
  }

  function toggleCard(id: string) {
    setExpandedIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }

  const STATUS_TABS: ("All" | AvatarStatus)[] = ["All", "Primary", "Secondary", "Emerging", "Deprioritized"];

  const totals = allAvatars.reduce(
    (acc, a) => { acc.spend += a.stats.spend_usd; acc.installs += a.stats.installs; acc.registrations += a.stats.registrations; return acc; },
    { spend: 0, installs: 0, registrations: 0 }
  );

  return (
    <div className="h-full overflow-y-auto">
      <div className="max-w-6xl mx-auto px-6 py-5 space-y-4">

        {/* Header */}
        <div className="flex items-end justify-between gap-4">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-primary/10 border border-primary/20 flex items-center justify-center">
              <Users className="w-4 h-4 text-primary" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-foreground tracking-tight">Avatar Map</h1>
              <p className="text-xs text-muted-foreground mt-0.5">
                {currentWorkspace.name} · {allAvatars.length} segment{allAvatars.length !== 1 ? "s" : ""} mapped
              </p>
            </div>
          </div>
          <button
            onClick={toggleExpandAll}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-border/60 text-[11px] text-muted-foreground hover:text-foreground hover:border-border transition-all"
          >
            {allExpanded ? (
              <><ChevronsDownUp className="w-3.5 h-3.5" /> Collapse all</>
            ) : (
              <><ChevronsUpDown className="w-3.5 h-3.5" /> Expand all</>
            )}
          </button>
        </div>

        {/* Summary strip */}
        <div className="grid grid-cols-4 gap-3">
          {[
            { label: "Segments",      value: allAvatars.length.toString() },
            { label: "Total Spend",   value: totals.spend.toLocaleString("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 }) },
            { label: "Installs",      value: totals.installs.toLocaleString() },
            { label: "Registrations", value: totals.registrations.toLocaleString() },
          ].map(m => (
            <div key={m.label} className="bg-card border border-border/60 rounded-xl px-4 py-3">
              <div className="text-xl font-bold leading-none text-foreground">{m.value}</div>
              <div className="text-[10px] font-medium text-muted-foreground mt-1.5">{m.label}</div>
            </div>
          ))}
        </div>

        {/* Status filter */}
        <div className="flex items-center gap-2 flex-wrap">
          <span className="text-[10px] text-muted-foreground font-medium">Status:</span>
          {STATUS_TABS.map(s => (
            <button
              key={s}
              onClick={() => setStatusFilter(s)}
              className={cn(
                "px-3 py-1.5 rounded-full text-[11px] font-medium border transition-all",
                statusFilter === s
                  ? "bg-primary/15 border-primary/40 text-primary"
                  : "bg-transparent border-border/50 text-muted-foreground hover:border-border hover:text-foreground"
              )}
            >
              {s === "All" ? `All (${allAvatars.length})` : `${s} (${allAvatars.filter(a => a.status === s).length})`}
            </button>
          ))}
        </div>

        {/* Segment grid */}
        {sorted.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 space-y-3">
            <Users className="w-8 h-8 text-muted-foreground/40" />
            <p className="text-sm text-muted-foreground">No avatars for this filter.</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-3 items-start">
            {sorted.map(avatar => (
              <SegmentCard
                key={avatar.id}
                avatar={avatar}
                avgCpi={avgCpi}
                expanded={expandedIds.has(avatar.id)}
                onToggle={() => toggleCard(avatar.id)}
                withAccount={withAccount}
              />
            ))}
          </div>
        )}

      </div>
    </div>
  );
}
