import { useState, useRef, useEffect } from "react";
import { cn } from "@/lib/utils";
import {
  Sparkles, Send, Bot, User, Zap, CheckCircle2, Loader2,
  Clock, AlertCircle, Workflow, ArrowUpRight,
} from "lucide-react";
import { useWorkspace } from "@/contexts/WorkspaceContext";
import {
  AGENT_THREAD, SUGGESTED_PROMPTS, AGENT_ACTIONS, cannedAgentReply,
  type AgentMessage, type AgentAction, type AgentActionStatus,
} from "@/lib/mock/agent-exports";

// ─── Helpers ──────────────────────────────────────────────────────────

function nowTime() {
  return new Date().toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" });
}

const ACTION_STATUS: Record<AgentActionStatus, { style: string; icon: React.ComponentType<{ className?: string }> }> = {
  Done: { style: "text-emerald-400", icon: CheckCircle2 },
  Running: { style: "text-primary", icon: Loader2 },
  Queued: { style: "text-yellow-400", icon: Clock },
  Failed: { style: "text-red-400", icon: AlertCircle },
};

function SectionLabel({ children }: { children: React.ReactNode }) {
  return (
    <span className="text-[9px] font-semibold uppercase tracking-[0.18em] text-muted-foreground/70">
      {children}
    </span>
  );
}

// ─── Message bubble ───────────────────────────────────────────────────

function MessageBubble({ msg }: { msg: AgentMessage }) {
  const isUser = msg.role === "user";
  return (
    <div className={cn("flex gap-2.5", isUser ? "flex-row-reverse" : "flex-row")}>
      <div className={cn(
        "w-7 h-7 rounded-lg border flex items-center justify-center shrink-0 mt-0.5",
        isUser
          ? "border-border/60 bg-muted/30 text-muted-foreground"
          : "border-[hsl(var(--metrix-gold)/0.3)] bg-[hsl(var(--metrix-gold)/0.08)] text-[hsl(var(--metrix-gold))]"
      )}>
        {isUser ? <User className="w-3.5 h-3.5" /> : <Bot className="w-3.5 h-3.5" />}
      </div>
      <div className={cn("max-w-[80%] space-y-1.5", isUser && "items-end flex flex-col")}>
        <div className={cn(
          "rounded-xl px-3.5 py-2.5 text-[11px] leading-relaxed",
          isUser
            ? "bg-primary/10 border border-primary/20 text-foreground"
            : "bg-card border border-border/60 text-muted-foreground"
        )}>
          {msg.text}
        </div>
        <div className={cn("flex items-center gap-1.5 flex-wrap", isUser && "justify-end")}>
          {msg.citations?.map(c => (
            <span key={c} className="text-[9px] font-mono px-1.5 py-0.5 rounded border border-border/40 bg-muted/30 text-muted-foreground">
              {c}
            </span>
          ))}
          <span className="text-[9px] text-muted-foreground/50">{msg.time}</span>
        </div>
      </div>
    </div>
  );
}

// ─── Action rail item ─────────────────────────────────────────────────

function ActionItem({ action }: { action: AgentAction }) {
  const { style, icon: Icon } = ACTION_STATUS[action.status];
  return (
    <div className="flex items-start gap-2.5 px-3 py-2.5 border-t border-border/20 first:border-t-0">
      <Icon className={cn("w-3.5 h-3.5 shrink-0 mt-0.5", style, action.status === "Running" && "animate-spin")} />
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-1.5">
          {action.kind === "automation" && <Workflow className="w-2.5 h-2.5 text-muted-foreground/60 shrink-0" />}
          <span className="text-[11px] font-medium text-foreground leading-snug">{action.title}</span>
        </div>
        <p className="text-[10px] text-muted-foreground mt-0.5 leading-relaxed">{action.detail}</p>
      </div>
      <span className="text-[9px] text-muted-foreground/50 shrink-0 whitespace-nowrap">{action.time}</span>
    </div>
  );
}

// ─── AgentConsole ─────────────────────────────────────────────────────

export function AgentConsole() {
  const { currentWorkspace } = useWorkspace();
  const [messages, setMessages] = useState<AgentMessage[]>(AGENT_THREAD);
  const [input, setInput] = useState("");
  const [thinking, setThinking] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const counter = useRef(0);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, thinking]);

  function send(text: string) {
    const trimmed = text.trim();
    if (!trimmed) return;
    counter.current += 1;
    const userMsg: AgentMessage = {
      id: `local_u_${counter.current}`,
      role: "user",
      text: trimmed,
      time: nowTime(),
    };
    setMessages(prev => [...prev, userMsg]);
    setInput("");
    setThinking(true);

    setTimeout(() => {
      counter.current += 1;
      const agentMsg: AgentMessage = {
        id: `local_a_${counter.current}`,
        role: "agent",
        text: cannedAgentReply(trimmed),
        time: nowTime(),
        citations: ["run_0001", "aa_bookster_meta"],
      };
      setMessages(prev => [...prev, agentMsg]);
      setThinking(false);
    }, 650);
  }

  const runningCount = AGENT_ACTIONS.filter(a => a.status === "Running").length;

  return (
    <div className="h-full overflow-hidden">
      <div className="max-w-6xl mx-auto h-full px-6 py-5 flex flex-col">

        {/* Header */}
        <div className="flex items-start justify-between shrink-0 mb-4">
          <div>
            <div className="text-[9px] font-semibold uppercase tracking-[0.18em] text-muted-foreground/60 mb-1">
              IAP Agent
            </div>
            <h1 className="text-xl font-bold text-foreground tracking-tight flex items-center gap-2">
              Agent Console
              <span className="flex items-center gap-1 text-[10px] font-semibold text-emerald-400">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" /> Online
              </span>
            </h1>
            <p className="text-xs text-muted-foreground mt-0.5">
              {currentWorkspace.name} · {runningCount} automation{runningCount !== 1 ? "s" : ""} running
            </p>
          </div>
        </div>

        {/* Body — chat + right rail */}
        <div className="grid grid-cols-[1fr_300px] gap-4 flex-1 min-h-0">

          {/* ── Chat column ────────────────────────────────────────────── */}
          <div className="flex flex-col min-h-0 bg-card/40 border border-border/60 rounded-xl overflow-hidden">

            {/* Thread */}
            <div ref={scrollRef} className="flex-1 overflow-y-auto px-4 py-4 space-y-4">
              {messages.map(m => <MessageBubble key={m.id} msg={m} />)}
              {thinking && (
                <div className="flex gap-2.5">
                  <div className="w-7 h-7 rounded-lg border border-[hsl(var(--metrix-gold)/0.3)] bg-[hsl(var(--metrix-gold)/0.08)] text-[hsl(var(--metrix-gold))] flex items-center justify-center shrink-0">
                    <Bot className="w-3.5 h-3.5" />
                  </div>
                  <div className="bg-card border border-border/60 rounded-xl px-3.5 py-2.5 flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-muted-foreground/50 animate-pulse" />
                    <span className="w-1.5 h-1.5 rounded-full bg-muted-foreground/50 animate-pulse [animation-delay:150ms]" />
                    <span className="w-1.5 h-1.5 rounded-full bg-muted-foreground/50 animate-pulse [animation-delay:300ms]" />
                  </div>
                </div>
              )}
            </div>

            {/* Suggested prompts */}
            <div className="px-4 py-2.5 border-t border-border/40 shrink-0">
              <div className="flex items-center gap-1.5 mb-2">
                <Sparkles className="w-3 h-3 text-[hsl(var(--metrix-gold))]" />
                <SectionLabel>Suggested</SectionLabel>
              </div>
              <div className="flex items-center gap-1.5 flex-wrap">
                {SUGGESTED_PROMPTS.map(p => (
                  <button
                    key={p}
                    onClick={() => send(p)}
                    className="text-[10px] px-2.5 py-1 rounded-full border border-border/50 bg-transparent text-muted-foreground hover:border-primary/40 hover:text-primary hover:bg-primary/5 transition-all"
                  >
                    {p}
                  </button>
                ))}
              </div>
            </div>

            {/* Input */}
            <div className="px-4 py-3 border-t border-border/40 shrink-0">
              <div className="flex items-center gap-2">
                <input
                  value={input}
                  onChange={e => setInput(e.target.value)}
                  onKeyDown={e => { if (e.key === "Enter") send(input); }}
                  placeholder="Ask the IAP agent about Bookster performance…"
                  className="flex-1 bg-muted/40 border border-border/60 rounded-lg px-3 py-2 text-[11px] text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:border-primary/50"
                />
                <button
                  onClick={() => send(input)}
                  disabled={!input.trim()}
                  className="w-9 h-9 shrink-0 rounded-lg bg-primary hover:bg-primary/90 text-white flex items-center justify-center transition-all disabled:opacity-40 disabled:cursor-not-allowed"
                >
                  <Send className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>

          {/* ── Right rail: recent actions / automations ───────────────── */}
          <div className="flex flex-col min-h-0 space-y-3">
            <div className="bg-card border border-border/60 rounded-xl overflow-hidden flex flex-col min-h-0">
              <div className="flex items-center justify-between px-3.5 py-2.5 border-b border-border/40 bg-muted/10 shrink-0">
                <div className="flex items-center gap-1.5">
                  <Zap className="w-3 h-3 text-[hsl(var(--metrix-gold))]" />
                  <SectionLabel>Agent Activity</SectionLabel>
                </div>
                <span className="text-[9px] text-muted-foreground/60">{AGENT_ACTIONS.length}</span>
              </div>
              <div className="overflow-y-auto">
                {AGENT_ACTIONS.map(a => <ActionItem key={a.id} action={a} />)}
              </div>
            </div>

            {/* Automations summary */}
            <div className="bg-card border border-border/60 rounded-xl px-4 py-3 shrink-0 space-y-2.5">
              <SectionLabel>Automations</SectionLabel>
              <div className="grid grid-cols-2 gap-2">
                {(["Running", "Queued", "Done", "Failed"] as AgentActionStatus[]).map(s => {
                  const count = AGENT_ACTIONS.filter(a => a.status === s).length;
                  const { style, icon: Icon } = ACTION_STATUS[s];
                  return (
                    <div key={s} className="flex items-center gap-2 rounded-lg border border-border/40 px-2.5 py-2">
                      <Icon className={cn("w-3 h-3", style)} />
                      <div>
                        <div className="text-sm font-bold text-foreground leading-none">{count}</div>
                        <div className="text-[9px] text-muted-foreground mt-0.5">{s}</div>
                      </div>
                    </div>
                  );
                })}
              </div>
              <button
                onClick={() => send("Show me all open automations")}
                className="w-full flex items-center justify-center gap-1.5 text-[10px] text-muted-foreground hover:text-foreground border border-border/50 rounded-lg py-1.5 transition-colors"
              >
                Review all <ArrowUpRight className="w-2.5 h-2.5" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
