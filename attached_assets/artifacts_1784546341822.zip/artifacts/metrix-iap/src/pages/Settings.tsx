import { cn } from "@/lib/utils";
import {
  Building2, Database, Cpu,
} from "lucide-react";
import { useWorkspace } from "@/contexts/WorkspaceContext";
import {
  ORG, WORKSPACES, USERS, AD_ACCOUNTS,
  PROMPT_VERSIONS,
} from "@/lib/mock-data";
import { SettingsTabs } from "./settings/SettingsTabs";

// ─── Section wrapper ───────────────────────────────────────────────────

function Section({
  icon,
  title,
  subtitle,
  children,
}: {
  icon: React.ReactNode;
  title: string;
  subtitle?: string;
  children: React.ReactNode;
}) {
  return (
    <div className="bg-card border border-border/60 rounded-xl overflow-hidden">
      <div className="flex items-center gap-3 px-5 py-3.5 border-b border-border/50 bg-muted/10">
        <span className="text-muted-foreground">{icon}</span>
        <div>
          <div className="text-xs font-semibold text-foreground">{title}</div>
          {subtitle && <div className="text-[10px] text-muted-foreground">{subtitle}</div>}
        </div>
      </div>
      {children}
    </div>
  );
}

// ─── Read-only field ───────────────────────────────────────────────────

function Field({ label, value }: { label: string; value: string | number }) {
  return (
    <div className="flex items-center gap-4 py-2.5 border-b border-border/30 last:border-none px-5">
      <div className="w-36 shrink-0 text-[10px] font-medium text-muted-foreground uppercase tracking-wide">{label}</div>
      <div className="text-[11px] text-foreground">{value}</div>
    </div>
  );
}

// ─── Settings ─────────────────────────────────────────────────────────

export function Settings() {
  const { currentWorkspace } = useWorkspace();

  const ws = currentWorkspace ?? WORKSPACES[0];
  const accounts = AD_ACCOUNTS.filter(a => a.workspace_id === ws.id);

  return (
    <div className="h-full overflow-y-auto">
      <div className="max-w-4xl mx-auto px-6 py-5 space-y-4">

        {/* Header */}
        <div>
          <h1 className="text-xl font-bold text-foreground tracking-tight">Settings</h1>
          <p className="text-xs text-muted-foreground mt-0.5">
            {ws.name}
          </p>
        </div>

        <SettingsTabs />

        {/* Organisation */}
        <Section icon={<Building2 className="w-3.5 h-3.5" />} title="Organisation" subtitle="Top-level org configuration">
          <Field label="Name" value={ORG.name} />
          <Field label="Slug" value={ORG.slug} />
          <Field label="ID" value={ORG.id} />
          <Field label="Created" value={ORG.created_at} />
          <Field label="Workspaces" value={WORKSPACES.length} />
          <Field label="Ad Accounts" value={AD_ACCOUNTS.length} />
          <Field label="Team Members" value={USERS.length} />
        </Section>

        {/* Workspace */}
        <Section icon={<Database className="w-3.5 h-3.5" />} title="Workspace" subtitle={`${ws.name} settings`}>
          <Field label="Name" value={ws.name} />
          <Field label="Type" value={ws.type} />
          <Field label="Slug" value={ws.slug} />
          <Field label="Health" value={ws.health_status} />
          <Field label="ID" value={ws.id} />
          <Field label="Created" value={ws.created_at} />
          <Field label="Updated" value={ws.updated_at} />
          {ws.client_name && <Field label="Client" value={ws.client_name} />}
          {ws.description && <Field label="Description" value={ws.description} />}
        </Section>

        {/* Ad Accounts */}
        <Section icon={<Database className="w-3.5 h-3.5" />} title="Ad Accounts" subtitle={`${accounts.length} account${accounts.length !== 1 ? "s" : ""} connected`}>
          <div className="divide-y divide-border/30">
            {accounts.map(aa => (
              <div key={aa.id} className="flex items-center gap-4 px-5 py-3">
                <div className="flex-1 min-w-0 space-y-0.5">
                  <div className="text-[11px] font-medium text-foreground">{aa.account_name}</div>
                  <div className="flex items-center gap-2 text-[10px] text-muted-foreground">
                    <span>{aa.platform}</span>
                    <span className="text-muted-foreground/30">·</span>
                    <span>{aa.account_id_external}</span>
                    <span className="text-muted-foreground/30">·</span>
                    <span>${(aa.spend_analyzed_usd / 1000).toFixed(1)}K spend analyzed</span>
                  </div>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <div className="text-[10px] text-muted-foreground">Quality</div>
                  <div className="flex items-center gap-1.5">
                    <div className="w-16 bg-border/30 rounded-full h-1.5">
                      <div
                        className={cn(
                          "h-full rounded-full",
                          aa.data_quality_score >= 70 ? "bg-emerald-500" : aa.data_quality_score >= 50 ? "bg-yellow-400" : "bg-red-400"
                        )}
                        style={{ width: `${aa.data_quality_score}%` }}
                      />
                    </div>
                    <span className={cn(
                      "text-[10px] font-mono font-semibold",
                      aa.data_quality_score >= 70 ? "text-emerald-400" : aa.data_quality_score >= 50 ? "text-yellow-400" : "text-red-400"
                    )}>
                      {aa.data_quality_score}
                    </span>
                  </div>
                  <span className={cn(
                    "text-[9px] px-1.5 py-0.5 rounded border font-semibold leading-none",
                    aa.status === "Connected" ? "text-emerald-400 border-emerald-500/20 bg-emerald-500/10"
                    : "text-muted-foreground border-border/40"
                  )}>
                    {aa.status}
                  </span>
                </div>
              </div>
            ))}
            {accounts.length === 0 && (
              <div className="px-5 py-4 text-[11px] text-muted-foreground">No ad accounts connected.</div>
            )}
          </div>
        </Section>

        {/* Prompt Versions */}
        <Section icon={<Cpu className="w-3.5 h-3.5" />} title="Prompt Versions" subtitle="Active IAP analysis prompts">
          <div className="divide-y divide-border/30">
            {PROMPT_VERSIONS.map(pv => (
              <div key={pv.id} className="flex items-center gap-4 px-5 py-3">
                <div className="flex-1 min-w-0 space-y-0.5">
                  <div className="text-[11px] font-medium text-foreground">{pv.name}</div>
                  <div className="text-[10px] text-muted-foreground">{pv.description}</div>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <span className="text-[10px] font-mono text-muted-foreground border border-border/40 px-1.5 py-0.5 rounded">
                    {pv.phase}
                  </span>
                  <span className="text-[10px] font-mono font-semibold text-primary">{pv.version}</span>
                </div>
              </div>
            ))}
          </div>
        </Section>

      </div>
    </div>
  );
}
