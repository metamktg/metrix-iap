import { useState } from "react";
import { useParams } from "wouter";
import { Link } from "wouter";
import { cn } from "@/lib/utils";
import {
  Zap, ChevronLeft, ChevronDown, ChevronRight,
  CheckCircle2, AlertCircle, Clock, Target,
  Activity, FileText, ArrowRight, User, Layers,
  BarChart3, Palette, MapPin, Users, Radio,
  ExternalLink,
} from "lucide-react";
import { ANALYSIS_RUNS, WORKSPACES, CREATIVE_CONCEPTS } from "@/lib/mock-data";
import { getAvatars } from "@/lib/mock/avatars";
import type {
  Finding, DecisionFeedItem, Recommendation,
  ConfidenceLabel, PerformanceTier, CreativeConcept,
} from "@/lib/types";
import type { Avatar } from "@/lib/mock/avatars";
import { useAccount } from "@/contexts/AccountContext";

// ─── Types ─────────────────────────────────────────────────────────────

type TabId = "overview" | "signal" | "variables" | "avatars" | "placements" | "creatives";

type VariableGroup = "Creative" | "Budget" | "Audience" | "Funnel";

// ─── Helpers ──────────────────────────────────────────────────────────

function confidenceChip(c: ConfidenceLabel) {
  const map: Record<ConfidenceLabel, string> = {
    high: "bg-emerald-500/10 border-emerald-500/20 text-emerald-400",
    medium: "bg-yellow-400/10 border-yellow-400/20 text-yellow-400",
    validation_required: "bg-orange-400/10 border-orange-400/20 text-orange-400",
    insufficient: "bg-muted border-border/40 text-muted-foreground",
  };
  const labels: Record<ConfidenceLabel, string> = {
    high: "High", medium: "Medium", validation_required: "Validate", insufficient: "Insufficient",
  };
  return (
    <span className={cn("text-[9px] px-1.5 py-0.5 rounded border font-semibold leading-none shrink-0", map[c])}>
      {labels[c]}
    </span>
  );
}

function tierPill(t?: PerformanceTier) {
  if (!t) return null;
  const color = t === 1 ? "text-emerald-400 border-emerald-500/20 bg-emerald-500/10"
    : t === 2 ? "text-yellow-400 border-yellow-400/20 bg-yellow-400/10"
    : t === 3 ? "text-orange-400 border-orange-400/20 bg-orange-400/10"
    : "text-red-400 border-red-500/20 bg-red-500/10";
  return (
    <span className={cn("text-[9px] px-1.5 py-0.5 rounded border font-semibold leading-none shrink-0", color)}>
      T{t}
    </span>
  );
}

function decisionTypeColor(d: string) {
  const m: Record<string, string> = {
    Scale: "text-emerald-400 bg-emerald-500/10 border-emerald-500/20",
    Hold: "text-yellow-400 bg-yellow-400/10 border-yellow-400/20",
    Isolate: "text-orange-400 bg-orange-400/10 border-orange-400/20",
    Kill: "text-red-400 bg-red-500/10 border-red-500/20",
    Rebuild: "text-blue-400 bg-blue-500/10 border-blue-500/20",
    Retest: "text-purple-400 bg-purple-500/10 border-purple-500/20",
    "Brief Next Sprint": "text-primary bg-primary/10 border-primary/20",
  };
  return m[d] ?? "text-muted-foreground bg-muted border-border/40";
}

function getVariableGroup(item: DecisionFeedItem): VariableGroup {
  if (["Rebuild", "Retest", "Brief Next Sprint"].includes(item.decision_type)) return "Creative";
  if (["Scale", "Kill"].includes(item.decision_type)) return "Budget";
  if (["Isolate", "Hold"].includes(item.decision_type)) return "Audience";
  return "Funnel";
}

const VARIABLE_GROUP_COLORS: Record<VariableGroup, string> = {
  Creative: "text-purple-400 bg-purple-500/10 border-purple-500/20",
  Budget:   "text-emerald-400 bg-emerald-500/10 border-emerald-500/20",
  Audience: "text-primary bg-primary/10 border-primary/20",
  Funnel:   "text-orange-400 bg-orange-400/10 border-orange-400/20",
};

// ─── Shared Components ─────────────────────────────────────────────────

function QualityBar({ label, value }: { label: string; value: number }) {
  const color = value >= 80 ? "bg-emerald-500" : value >= 60 ? "bg-yellow-400" : value >= 40 ? "bg-orange-400" : "bg-red-400";
  const textColor = value >= 80 ? "text-emerald-400" : value >= 60 ? "text-yellow-400" : value >= 40 ? "text-orange-400" : "text-red-400";
  return (
    <div className="space-y-1">
      <div className="flex items-center justify-between text-[10px]">
        <span className="text-muted-foreground">{label}</span>
        <span className={cn("font-mono font-semibold", textColor)}>{value}</span>
      </div>
      <div className="w-full bg-border/30 rounded-full h-1.5 overflow-hidden">
        <div className={cn("h-full rounded-full transition-all", color)} style={{ width: `${value}%` }} />
      </div>
    </div>
  );
}

function FindingCard({ finding }: { finding: Finding }) {
  const [open, setOpen] = useState(finding.is_priority_read);
  return (
    <div className={cn(
      "rounded-xl border transition-all overflow-hidden",
      finding.is_open ? "border-orange-400/30 bg-orange-400/5" : "border-border/60 bg-card"
    )}>
      <button className="w-full flex items-start gap-3 p-4 text-left" onClick={() => setOpen(o => !o)}>
        <div className={cn("w-2 h-2 rounded-full mt-1.5 shrink-0", finding.is_open ? "bg-orange-400" : "bg-emerald-500")} />
        <div className="flex-1 min-w-0 space-y-1.5">
          <div className="flex items-center gap-2 flex-wrap">
            <span className={cn("text-xs font-semibold leading-snug", finding.is_open ? "text-orange-300" : "text-foreground")}>
              {finding.title}
            </span>
            {finding.is_priority_read && (
              <span className="text-[9px] px-1.5 py-0.5 rounded bg-primary/10 border border-primary/20 text-primary font-semibold leading-none">Priority Read</span>
            )}
            {finding.is_open && (
              <span className="text-[9px] px-1.5 py-0.5 rounded bg-orange-400/10 border border-orange-400/20 text-orange-400 font-semibold leading-none">Open</span>
            )}
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-[10px] text-muted-foreground border border-border/40 px-1.5 py-0.5 rounded">{finding.dimension}</span>
            {confidenceChip(finding.confidence)}
            {tierPill(finding.tier)}
          </div>
        </div>
        <ChevronDown className={cn("w-3.5 h-3.5 text-muted-foreground shrink-0 transition-transform mt-0.5", open && "rotate-180")} />
      </button>
      {open && (
        <div className="px-4 pb-4 pt-0 border-t border-border/30 space-y-3">
          <p className="text-[11px] text-muted-foreground leading-relaxed pt-3">{finding.body}</p>
          {finding.tags.length > 0 && (
            <div className="flex flex-wrap gap-1">
              {finding.tags.map(tag => (
                <span key={tag} className="text-[9px] px-1.5 py-0.5 rounded bg-muted text-muted-foreground border border-border/30 font-mono">#{tag}</span>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// ─── Tab: Overview ─────────────────────────────────────────────────────

function OverviewTab({ run, withAccount }: {
  run: NonNullable<ReturnType<typeof ANALYSIS_RUNS.find>>;
  withAccount: (path: string) => string;
}) {
  const openFindings = run.findings.filter(f => f.is_open);
  const sq = run.signal_quality;

  const CTA_CARDS = [
    {
      icon: Target,
      label: "View in Strategy",
      desc: "See how this run's findings feed into your strategic map and avatar hypotheses.",
      href: withAccount("/app/strategy/overview"),
      color: "text-primary border-primary/20 bg-primary/5",
    },
    {
      icon: Palette,
      label: "See Briefs",
      desc: "Review creative briefs generated from this analysis or start a new brief.",
      href: withAccount("/app/briefs/builder"),
      color: "text-purple-400 border-purple-500/20 bg-purple-500/5",
    },
    {
      icon: Zap,
      label: "Re-analyze",
      desc: "Run a fresh IAP analysis with updated data or a different analytical depth.",
      href: withAccount("/app/analysis/new-run"),
      color: "text-yellow-400 border-yellow-400/20 bg-yellow-400/5",
    },
  ];

  return (
    <div className="space-y-4">
      {/* Priority Read */}
      <div className="bg-card border border-primary/20 rounded-xl p-5 space-y-2">
        <div className="flex items-center gap-2">
          <Zap className="w-3.5 h-3.5 text-primary" />
          <span className="text-xs font-semibold text-foreground uppercase tracking-wide">Priority Read</span>
        </div>
        <p className="text-xs text-muted-foreground leading-relaxed">{run.priority_read}</p>
      </div>

      {/* Two-column: diagnosis + signal score */}
      <div className="grid grid-cols-2 gap-5">
        <div className="bg-card border border-border/60 rounded-xl p-4 space-y-4">
          <div className="flex items-center gap-2">
            <Target className="w-3.5 h-3.5 text-muted-foreground" />
            <span className="text-xs font-semibold text-foreground">Executive Diagnosis</span>
          </div>
          <p className="text-[11px] text-muted-foreground leading-relaxed">{run.executive_diagnosis}</p>
          <div className="border-t border-border/40 pt-3 space-y-3">
            <div>
              <div className="text-[10px] text-red-400/80 font-medium mb-0.5 flex items-center gap-1">
                <AlertCircle className="w-3 h-3" /> Primary Constraint
              </div>
              <p className="text-[11px] text-muted-foreground leading-relaxed">{run.primary_constraint}</p>
            </div>
            <div>
              <div className="text-[10px] text-emerald-400/80 font-medium mb-0.5 flex items-center gap-1">
                <ChevronRight className="w-3 h-3" /> Primary Opportunity
              </div>
              <p className="text-[11px] text-muted-foreground leading-relaxed">{run.primary_opportunity}</p>
            </div>
            <div>
              <div className="text-[10px] text-primary/80 font-medium mb-0.5 flex items-center gap-1">
                <Zap className="w-3 h-3" /> Recommended Next Action
              </div>
              <p className="text-[11px] text-muted-foreground leading-relaxed">{run.recommended_next_action}</p>
            </div>
            {run.risk_if_ignored && (
              <div>
                <div className="text-[10px] text-orange-400/80 font-medium mb-0.5 flex items-center gap-1">
                  <AlertCircle className="w-3 h-3" /> Risk If Ignored
                </div>
                <p className="text-[11px] text-muted-foreground leading-relaxed">{run.risk_if_ignored}</p>
              </div>
            )}
          </div>
        </div>

        <div className="bg-card border border-border/60 rounded-xl p-4 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Activity className="w-3.5 h-3.5 text-muted-foreground" />
              <span className="text-xs font-semibold text-foreground">Signal Quality</span>
            </div>
            <div className="flex items-baseline gap-1">
              <span className={cn("text-2xl font-bold",
                sq.overall >= 80 ? "text-emerald-400" : sq.overall >= 60 ? "text-yellow-400" : "text-orange-400"
              )}>{sq.overall}</span>
              <span className="text-xs text-muted-foreground">/100</span>
            </div>
          </div>
          <div className="space-y-2.5">
            {[
              ["Tracking Confidence", sq.tracking_confidence],
              ["Conversion Volume", sq.conversion_volume_confidence],
              ["Spend Sufficiency", sq.spend_sufficiency],
              ["Creative Diversity", sq.creative_diversity],
              ["Learning Stability", sq.learning_stability],
            ].map(([label, value]) => (
              <QualityBar key={label as string} label={label as string} value={value as number} />
            ))}
          </div>
          <Link href={withAccount("/app/analysis/overview")}
            className="flex items-center gap-1 text-[11px] text-primary hover:text-primary/80 transition-colors">
            Full signal read <ExternalLink className="w-3 h-3" />
          </Link>
        </div>
      </div>

      {/* Open findings — risk callout */}
      {openFindings.length > 0 && (
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-3.5 h-3.5 text-orange-400" />
            <span className="text-xs font-semibold text-foreground">Open Findings ({openFindings.length})</span>
          </div>
          <div className="space-y-2">
            {openFindings.slice(0, 3).map(f => <FindingCard key={f.id} finding={f} />)}
          </div>
        </div>
      )}

      {/* 3 CTA cards */}
      <div className="grid grid-cols-3 gap-3 pt-1">
        {CTA_CARDS.map(cta => {
          const Icon = cta.icon;
          return (
            <Link key={cta.label} href={cta.href}
              className={cn(
                "flex flex-col gap-3 rounded-xl border p-4 transition-all hover:brightness-110",
                cta.color
              )}>
              <Icon className="w-4 h-4" />
              <div>
                <div className="text-xs font-semibold text-foreground mb-1">{cta.label}</div>
                <p className="text-[10px] text-muted-foreground leading-snug">{cta.desc}</p>
              </div>
              <div className="flex items-center gap-1 text-[11px] font-medium mt-auto">
                Go <ArrowRight className="w-3 h-3" />
              </div>
            </Link>
          );
        })}
      </div>

      {/* All findings */}
      {run.findings.length > 0 && (
        <div className="space-y-2">
          <div className="text-[10px] text-muted-foreground uppercase tracking-wide font-medium">
            All Findings ({run.findings.length})
          </div>
          <div className="space-y-2">
            {run.findings.map(f => <FindingCard key={f.id} finding={f} />)}
          </div>
        </div>
      )}

      {/* Recommendations */}
      {run.recommendations.length > 0 && (
        <div className="space-y-2">
          <div className="text-[10px] text-muted-foreground uppercase tracking-wide font-medium">
            Recommendations ({run.recommendations.length})
          </div>
          <div className="space-y-2">
            {run.recommendations.map(rec => {
              const priorityColor: Record<string, string> = {
                Critical: "text-red-400 border-red-500/20 bg-red-500/10",
                High: "text-orange-400 border-orange-400/20 bg-orange-400/10",
                Medium: "text-yellow-400 border-yellow-400/20 bg-yellow-400/10",
                Low: "text-muted-foreground border-border/40 bg-muted",
              };
              const statusColor: Record<string, string> = {
                Open: "text-orange-400",
                "In Progress": "text-primary",
                Completed: "text-emerald-400",
                Dismissed: "text-muted-foreground",
              };
              return (
                <div key={rec.id} className="flex items-start gap-3 px-4 py-3 rounded-xl border border-border/60 bg-card">
                  <span className={cn("text-[9px] px-1.5 py-0.5 rounded border font-bold leading-none shrink-0 mt-0.5", priorityColor[rec.priority])}>
                    {rec.priority}
                  </span>
                  <div className="flex-1 min-w-0 space-y-1">
                    <div className="flex items-start justify-between gap-2">
                      <span className="text-xs font-medium text-foreground leading-snug">{rec.title}</span>
                      <span className={cn("text-[10px] shrink-0", statusColor[rec.status])}>{rec.status}</span>
                    </div>
                    <p className="text-[11px] text-muted-foreground leading-relaxed">{rec.action}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Tab: Signal ───────────────────────────────────────────────────────

const SQ_DIMENSIONS = [
  { key: "tracking_confidence" as const,           label: "Tracking Confidence",  hint: "Pixel / CAPI reliability" },
  { key: "conversion_volume_confidence" as const,  label: "Conversion Volume",    hint: "Enough events per decision window" },
  { key: "spend_sufficiency" as const,             label: "Spend Sufficiency",    hint: "Budget cleared learning thresholds" },
  { key: "creative_diversity" as const,            label: "Creative Diversity",   hint: "Distinct concepts in rotation" },
  { key: "learning_stability" as const,            label: "Learning Stability",   hint: "Delivery not resetting mid-flight" },
  { key: "funnel_consistency" as const,            label: "Funnel Consistency",   hint: "Event chain fires in order" },
  { key: "segment_clarity" as const,               label: "Segment Clarity",      hint: "Audiences separable in the data" },
  { key: "data_cleanliness" as const,              label: "Data Cleanliness",     hint: "Naming + UTM hygiene" },
  { key: "date_range_reliability" as const,        label: "Date Range Reliability", hint: "Window free of structural breaks" },
  { key: "breakdown_usefulness" as const,          label: "Breakdown Usefulness", hint: "Placement / geo splits usable" },
];

function mockPlacementSplits(base: number) {
  const feed   = Math.min(99, Math.max(20, Math.round(base * 1.07)));
  const story  = Math.min(99, Math.max(20, Math.round(base * 0.88)));
  const reel   = Math.min(99, Math.max(20, Math.round(base * 0.94)));
  return [
    { label: "Feed",  value: feed },
    { label: "Story", value: story },
    { label: "Reel",  value: reel },
  ];
}

function mockDeviceSplits(base: number) {
  const mobile  = Math.min(99, Math.max(20, Math.round(base * 1.05)));
  const desktop = Math.min(99, Math.max(20, Math.round(base * 0.80)));
  return [
    { label: "Mobile",  value: mobile },
    { label: "Desktop", value: desktop },
  ];
}

function DimensionRow({ dim, value, withAccount }: {
  dim: typeof SQ_DIMENSIONS[0];
  value: number;
  withAccount: (path: string) => string;
}) {
  const [open, setOpen] = useState(false);
  const placement = mockPlacementSplits(value);
  const device    = mockDeviceSplits(value);
  const textColor = value >= 80 ? "text-emerald-400" : value >= 60 ? "text-yellow-400" : value >= 40 ? "text-orange-400" : "text-red-400";

  return (
    <div className="border border-border/40 rounded-xl overflow-hidden">
      <button
        onClick={() => setOpen(o => !o)}
        className="w-full px-4 py-3 hover:bg-white/[0.02] transition-colors"
      >
        <div className="flex items-center gap-3">
          <div className="flex-1 space-y-1">
            <div className="flex items-center justify-between">
              <span className="text-xs font-medium text-foreground text-left">{dim.label}</span>
              <span className={cn("text-xs font-mono font-semibold", textColor)}>{value}</span>
            </div>
            <div className="w-full bg-border/30 rounded-full h-1.5 overflow-hidden">
              <div className={cn("h-full rounded-full",
                value >= 80 ? "bg-emerald-500" : value >= 60 ? "bg-yellow-400" : value >= 40 ? "bg-orange-400" : "bg-red-400"
              )} style={{ width: `${value}%` }} />
            </div>
            <span className="text-[10px] text-muted-foreground/60 text-left block">{dim.hint}</span>
          </div>
          <ChevronDown className={cn("w-3.5 h-3.5 text-muted-foreground shrink-0 transition-transform", open && "rotate-180")} />
        </div>
      </button>
      {open && (
        <div className="border-t border-border/30 px-4 py-3 space-y-3 bg-muted/[0.04]">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <div className="text-[9px] font-semibold uppercase tracking-[0.14em] text-muted-foreground/60">By Placement</div>
              {placement.map(p => (
                <div key={p.label} className="flex items-center gap-2">
                  <span className="text-[10px] text-muted-foreground w-12 shrink-0">{p.label}</span>
                  <div className="flex-1 bg-border/30 rounded-full h-1 overflow-hidden">
                    <div className="h-full rounded-full bg-primary/60" style={{ width: `${p.value}%` }} />
                  </div>
                  <span className={cn("text-[10px] font-mono w-5 text-right shrink-0",
                    p.value >= 80 ? "text-emerald-400" : p.value >= 60 ? "text-yellow-400" : "text-muted-foreground"
                  )}>{p.value}</span>
                </div>
              ))}
            </div>
            <div className="space-y-2">
              <div className="text-[9px] font-semibold uppercase tracking-[0.14em] text-muted-foreground/60">By Device</div>
              {device.map(d => (
                <div key={d.label} className="flex items-center gap-2">
                  <span className="text-[10px] text-muted-foreground w-12 shrink-0">{d.label}</span>
                  <div className="flex-1 bg-border/30 rounded-full h-1 overflow-hidden">
                    <div className="h-full rounded-full bg-purple-500/60" style={{ width: `${d.value}%` }} />
                  </div>
                  <span className={cn("text-[10px] font-mono w-5 text-right shrink-0",
                    d.value >= 80 ? "text-emerald-400" : d.value >= 60 ? "text-yellow-400" : "text-muted-foreground"
                  )}>{d.value}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function SignalTab({ run, withAccount }: {
  run: NonNullable<ReturnType<typeof ANALYSIS_RUNS.find>>;
  withAccount: (path: string) => string;
}) {
  const sq = run.signal_quality;
  const weakest = [...SQ_DIMENSIONS].sort((a, b) => sq[a.key] - sq[b.key])[0];

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <div className="text-[9px] font-semibold uppercase tracking-[0.16em] text-muted-foreground/60 mb-0.5">Signal Quality</div>
          <div className="flex items-baseline gap-1">
            <span className={cn("text-3xl font-bold",
              sq.overall >= 80 ? "text-emerald-400" : sq.overall >= 60 ? "text-yellow-400" : "text-orange-400"
            )}>{sq.overall}</span>
            <span className="text-sm text-muted-foreground">/100</span>
          </div>
        </div>
        <div className="flex items-start gap-2 bg-card border border-yellow-400/25 rounded-xl px-3 py-2 max-w-xs">
          <AlertCircle className="w-3.5 h-3.5 text-yellow-400 shrink-0 mt-0.5" />
          <div>
            <div className="text-[10px] font-semibold text-foreground">Weakest: {weakest.label} ({sq[weakest.key]}/100)</div>
            <p className="text-[9px] text-muted-foreground mt-0.5 leading-snug">{weakest.hint}</p>
          </div>
        </div>
      </div>

      {/* Dimension rows */}
      <div className="space-y-2">
        {SQ_DIMENSIONS.map(dim => (
          <DimensionRow key={dim.key} dim={dim} value={sq[dim.key]} withAccount={withAccount} />
        ))}
      </div>

      {/* CTA */}
      <div className="bg-card border border-border/60 rounded-xl px-4 py-3 flex items-center justify-between gap-4">
        <div>
          <div className="text-xs font-semibold text-foreground">Fix weakest dimension</div>
          <p className="text-[11px] text-muted-foreground mt-0.5">{weakest.hint} — improving this raises confidence across the whole IAP loop.</p>
        </div>
        <Link href={withAccount("/app/listen/imports")}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-primary/10 border border-primary/25 text-[11px] text-primary hover:bg-primary/20 transition-colors shrink-0">
          Review imports <ArrowRight className="w-3 h-3" />
        </Link>
      </div>
    </div>
  );
}

// ─── Tab: Variables ────────────────────────────────────────────────────

function VariableGroupSection({
  group, items, withAccount,
}: {
  group: VariableGroup;
  items: DecisionFeedItem[];
  withAccount: (path: string) => string;
}) {
  const [open, setOpen] = useState(true);
  const [expandedItem, setExpandedItem] = useState<string | null>(null);

  return (
    <div className="border border-border/50 rounded-xl overflow-hidden">
      <button
        onClick={() => setOpen(o => !o)}
        className="w-full flex items-center gap-3 px-4 py-3 hover:bg-white/[0.02] transition-colors"
      >
        <span className={cn("text-[10px] px-2 py-0.5 rounded border font-semibold leading-none", VARIABLE_GROUP_COLORS[group])}>
          {group}
        </span>
        <span className="flex-1 text-xs font-semibold text-foreground text-left">{group} Decisions</span>
        <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-muted text-muted-foreground font-semibold">{items.length}</span>
        <ChevronDown className={cn("w-3.5 h-3.5 text-muted-foreground shrink-0 transition-transform", open && "rotate-180")} />
      </button>
      {open && (
        <div className="border-t border-border/30 divide-y divide-border/20">
          {items.map(item => {
            const isExpanded = expandedItem === item.id;
            const hasDemographicNote = (item.tier === 1 || item.tier === 2);
            return (
              <div key={item.id}>
                <button
                  onClick={() => setExpandedItem(isExpanded ? null : item.id)}
                  className="w-full flex items-center gap-3 px-4 py-3 text-left hover:bg-white/[0.02] transition-colors"
                >
                  <span className={cn("text-[10px] px-2 py-1 rounded border font-bold leading-none shrink-0", decisionTypeColor(item.decision_type))}>
                    {item.decision_type}
                  </span>
                  <div className="flex items-center gap-1.5 shrink-0">
                    {tierPill(item.tier)}
                    {confidenceChip(item.confidence_label)}
                  </div>
                  <span className="text-[11px] text-muted-foreground flex-1 truncate">{item.evidence}</span>
                  <ChevronDown className={cn("w-3.5 h-3.5 text-muted-foreground shrink-0 transition-transform", isExpanded && "rotate-180")} />
                </button>
                {isExpanded && (
                  <div className="px-4 pb-3 space-y-2.5 bg-muted/[0.03]">
                    {hasDemographicNote && (
                      <div className="flex items-center gap-2 text-[10px] text-muted-foreground border border-border/40 rounded-lg px-2.5 py-1.5 bg-card w-fit">
                        <User className="w-3 h-3 text-primary/60" />
                        <span>Strong on Mobile · Weak on Desktop</span>
                      </div>
                    )}
                    <p className="text-[11px] text-muted-foreground leading-relaxed">{item.why_it_matters}</p>
                    <div>
                      <div className="text-[10px] text-muted-foreground font-medium mb-0.5">Action</div>
                      <p className="text-[11px] text-foreground leading-relaxed">{item.action}</p>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="text-[10px] text-muted-foreground">
                        <span className="font-mono">{item.supporting_metric}</span>
                      </div>
                      <Link href={withAccount("/app/briefs/builder")}
                        className="flex items-center gap-1 text-[11px] text-primary hover:text-primary/80 transition-colors">
                        Brief this <ArrowRight className="w-3 h-3" />
                      </Link>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

function VariablesTab({ run, withAccount }: {
  run: NonNullable<ReturnType<typeof ANALYSIS_RUNS.find>>;
  withAccount: (path: string) => string;
}) {
  const groups: Record<VariableGroup, DecisionFeedItem[]> = {
    Creative: [], Budget: [], Audience: [], Funnel: [],
  };
  for (const item of run.decision_feed) {
    groups[getVariableGroup(item)].push(item);
  }
  const groupOrder: VariableGroup[] = ["Creative", "Budget", "Audience", "Funnel"];

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <div className="text-[10px] text-muted-foreground">
          {run.decision_feed.length} decisions grouped by variable type
        </div>
        <Link href={withAccount("/app/briefs/builder")}
          className="flex items-center gap-1 text-[11px] text-primary hover:text-primary/80 transition-colors">
          Brief all open <ArrowRight className="w-3 h-3" />
        </Link>
      </div>
      {groupOrder
        .filter(g => groups[g].length > 0)
        .map(g => (
          <VariableGroupSection key={g} group={g} items={groups[g]} withAccount={withAccount} />
        ))}
      {run.decision_feed.length === 0 && (
        <p className="text-xs text-muted-foreground text-center py-8">No decision feed items for this run.</p>
      )}
    </div>
  );
}

// ─── Tab: Avatars ──────────────────────────────────────────────────────

function AvatarMiniCard({ avatar, withAccount }: { avatar: Avatar; withAccount: (p: string) => string }) {
  const [open, setOpen] = useState(false);
  return (
    <div className={cn(
      "bg-card border rounded-xl overflow-hidden transition-all",
      avatar.status === "Primary" ? "border-emerald-500/30 shadow-[0_0_12px_hsl(142deg_70%_45%/0.08)]" : "border-border/60"
    )}>
      <button onClick={() => setOpen(o => !o)} className="w-full text-left px-3 py-3 hover:bg-white/[0.02] transition-colors">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-primary/10 border border-primary/20 flex items-center justify-center shrink-0">
            <span className="text-[10px] font-bold text-primary">
              {avatar.name.split(" ").slice(0, 2).map(w => w[0]).join("")}
            </span>
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-1.5 flex-wrap">
              <span className="text-[11px] font-semibold text-foreground truncate">{avatar.name}</span>
              <span className={cn("text-[9px] px-1.5 py-0.5 rounded border font-semibold leading-none shrink-0",
                avatar.status === "Primary" ? "text-emerald-400 border-emerald-500/20 bg-emerald-500/10"
                  : avatar.status === "Secondary" ? "text-primary border-primary/20 bg-primary/10"
                  : avatar.status === "Emerging" ? "text-yellow-400 border-yellow-400/20 bg-yellow-400/10"
                  : "text-muted-foreground border-border/40 bg-muted"
              )}>{avatar.status}</span>
            </div>
            <div className="flex items-center gap-3 mt-0.5 text-[10px] text-muted-foreground">
              <span>CPI ${avatar.stats.cpi_usd.toFixed(2)}</span>
              <span>{(avatar.stats.share_of_spend * 100).toFixed(0)}% spend</span>
              <span className="truncate">{avatar.primary_platform.split("·")[1]?.trim() ?? avatar.primary_platform}</span>
            </div>
          </div>
          <ChevronDown className={cn("w-3.5 h-3.5 text-muted-foreground shrink-0 transition-transform", open && "rotate-180")} />
        </div>
      </button>
      {open && (
        <div className="border-t border-border/30 px-3 pb-3 pt-2.5 space-y-2.5 bg-muted/[0.03]">
          <div>
            <div className="text-[9px] font-semibold uppercase tracking-[0.14em] text-red-400/70 mb-1">Pain Points</div>
            <div className="space-y-0.5">
              {avatar.pains.slice(0, 2).map(p => (
                <p key={p} className="text-[10px] text-muted-foreground leading-snug border-l-2 border-red-500/30 pl-2">{p}</p>
              ))}
            </div>
          </div>
          <div>
            <div className="text-[9px] font-semibold uppercase tracking-[0.14em] text-primary/70 mb-1">Strategic Note</div>
            <p className="text-[10px] text-muted-foreground leading-snug">{avatar.strategic_note}</p>
          </div>
          <div className="flex items-center gap-3 pt-1">
            <Link href={withAccount("/app/briefs/builder")}
              className="flex items-center gap-1 text-[10px] text-primary hover:text-primary/80 transition-colors">
              Brief this segment <ArrowRight className="w-2.5 h-2.5" />
            </Link>
          </div>
        </div>
      )}
    </div>
  );
}

function AvatarsTab({ workspaceId, withAccount }: { workspaceId: string; withAccount: (p: string) => string }) {
  const avatars = getAvatars(workspaceId);
  const sorted = [...avatars].sort((a, b) => b.stats.share_of_spend - a.stats.share_of_spend);

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <div className="text-[10px] text-muted-foreground">{avatars.length} segments for this workspace</div>
        <Link href={withAccount("/app/strategy/avatars")}
          className="flex items-center gap-1 text-[11px] text-primary hover:text-primary/80 transition-colors">
          View Avatar Map <ExternalLink className="w-3 h-3" />
        </Link>
      </div>
      {sorted.length === 0 ? (
        <p className="text-xs text-muted-foreground text-center py-8">No ICP segments defined for this workspace.</p>
      ) : (
        <div className="grid grid-cols-2 gap-2.5">
          {sorted.map(a => <AvatarMiniCard key={a.id} avatar={a} withAccount={withAccount} />)}
        </div>
      )}
    </div>
  );
}

// ─── Tab: Placements ───────────────────────────────────────────────────

const PLACEMENT_ROWS = [
  { name: "Feed",             spend_pct: 42, cpa: 18.20, tier: 1 as PerformanceTier, trend: "Best performer — scale budget here",              insight: "Feed placements drive 78% of registrations with consistent 2.1× conversion lift. Prioritize Android mobile creative formats." },
  { name: "Story",            spend_pct: 28, cpa: 22.40, tier: 2 as PerformanceTier, trend: "Good engagement; optimize creative format",         insight: "Converting well at mid-funnel but hook score is declining. Shorten to 8s and test UGC-style formats to improve view-through." },
  { name: "Reel",             spend_pct: 18, cpa: 31.50, tier: 3 as PerformanceTier, trend: "High CPM; test shorter hooks before scaling",       insight: "Reel spend is inefficient at current scale. Pause top-spend ads and test native 15s format before re-allocating budget." },
  { name: "Audience Network", spend_pct: 12, cpa: 45.80, tier: 4 as PerformanceTier, trend: "Lowest quality — reallocate budget to Feed",        insight: "3× higher CPA than Feed with consistently low install quality. Reallocate this budget to Feed immediately." },
];

function PlacementsTab({ withAccount }: { withAccount: (p: string) => string }) {
  const [expandedRow, setExpandedRow] = useState<string | null>(null);

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <div className="text-[10px] text-muted-foreground">Placement breakdown — mock splits from latest import</div>
        <Link href={withAccount("/app/analysis/placements")}
          className="flex items-center gap-1 text-[11px] text-primary hover:text-primary/80 transition-colors">
          Open Placements <ExternalLink className="w-3 h-3" />
        </Link>
      </div>
      <div className="border border-border/50 rounded-xl overflow-hidden divide-y divide-border/30">
        {/* Header */}
        <div className="grid grid-cols-[1fr_80px_80px_80px_100px] gap-2 px-4 py-2 bg-muted/20">
          {["Placement", "Spend %", "CPA", "Tier", "Trend"].map(h => (
            <div key={h} className="text-[9px] font-semibold uppercase tracking-[0.14em] text-muted-foreground/60">{h}</div>
          ))}
        </div>
        {PLACEMENT_ROWS.map(row => {
          const isOpen = expandedRow === row.name;
          const tierColor = row.tier === 1 ? "text-emerald-400 border-emerald-500/20 bg-emerald-500/10"
            : row.tier === 2 ? "text-yellow-400 border-yellow-400/20 bg-yellow-400/10"
            : row.tier === 3 ? "text-orange-400 border-orange-400/20 bg-orange-400/10"
            : "text-red-400 border-red-500/20 bg-red-500/10";
          return (
            <div key={row.name}>
              <button
                onClick={() => setExpandedRow(isOpen ? null : row.name)}
                className="w-full grid grid-cols-[1fr_80px_80px_80px_100px] gap-2 px-4 py-3 items-center text-left hover:bg-white/[0.02] transition-colors"
              >
                <div className="flex items-center gap-2">
                  <MapPin className="w-3 h-3 text-muted-foreground/40 shrink-0" />
                  <span className="text-xs font-medium text-foreground">{row.name}</span>
                </div>
                <span className="text-xs font-mono text-foreground">{row.spend_pct}%</span>
                <span className="text-xs font-mono text-foreground">${row.cpa.toFixed(2)}</span>
                <span className={cn("text-[9px] px-1.5 py-0.5 rounded border font-semibold leading-none w-fit", tierColor)}>T{row.tier}</span>
                <div className="flex items-center justify-between">
                  <span className="text-[10px] text-muted-foreground truncate pr-1">{row.trend.split(" — ")[0]}</span>
                  <ChevronDown className={cn("w-3 h-3 text-muted-foreground shrink-0 transition-transform", isOpen && "rotate-180")} />
                </div>
              </button>
              {isOpen && (
                <div className="px-4 pb-3 bg-muted/[0.03] border-t border-border/20">
                  <p className="text-[11px] text-muted-foreground leading-relaxed pt-2">{row.insight}</p>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ─── Tab: Creatives ────────────────────────────────────────────────────

function CreativeRow({ concept, withAccount }: { concept: CreativeConcept; withAccount: (p: string) => string }) {
  const [open, setOpen] = useState(false);
  const actionColor: Record<string, string> = {
    Keep: "text-emerald-400 border-emerald-500/20 bg-emerald-500/10",
    Extend: "text-primary border-primary/20 bg-primary/10",
    Validate: "text-yellow-400 border-yellow-400/20 bg-yellow-400/10",
    Retire: "text-red-400 border-red-500/20 bg-red-500/10",
  };

  return (
    <div className="border-b border-border/30 last:border-0">
      <button
        onClick={() => setOpen(o => !o)}
        className="w-full flex items-center gap-3 px-4 py-3 text-left hover:bg-white/[0.02] transition-colors"
      >
        {/* Thumbnail placeholder */}
        <div className="w-9 h-9 rounded-lg bg-muted/50 border border-border/40 flex items-center justify-center shrink-0">
          <Palette className="w-3.5 h-3.5 text-muted-foreground/40" />
        </div>
        <div className="flex-1 min-w-0 space-y-1">
          <div className="flex items-center gap-2">
            <span className="text-[11px] font-semibold text-foreground truncate">{concept.name}</span>
            {tierPill(concept.tier)}
          </div>
          <div className="flex items-center gap-1 flex-wrap">
            {[concept.hook_variable, concept.framework_variable, concept.tone_variable].filter(Boolean).map(tag => (
              <span key={tag} className="text-[9px] font-mono px-1.5 py-0.5 rounded border border-border/40 bg-muted/30 text-muted-foreground">{tag}</span>
            ))}
          </div>
        </div>
        <span className={cn("text-[9px] px-1.5 py-0.5 rounded border font-semibold leading-none shrink-0", actionColor[concept.recommended_action] ?? "text-muted-foreground border-border/40 bg-muted")}>
          {concept.recommended_action}
        </span>
        <ChevronDown className={cn("w-3.5 h-3.5 text-muted-foreground shrink-0 transition-transform", open && "rotate-180")} />
      </button>
      {open && (
        <div className="px-4 pb-3 space-y-2.5 bg-muted/[0.03]">
          <p className="text-[11px] text-muted-foreground leading-relaxed">{concept.iap_read}</p>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <div className="text-[9px] font-semibold uppercase tracking-[0.12em] text-muted-foreground/60 mb-0.5">Stage</div>
              <span className="text-[10px] text-foreground">{concept.stage}</span>
            </div>
            <div>
              <div className="text-[9px] font-semibold uppercase tracking-[0.12em] text-muted-foreground/60 mb-0.5">Fatigue</div>
              <span className="text-[10px] text-foreground capitalize">{concept.fatigue_state.replace("_", " ")}</span>
            </div>
          </div>
          {concept.winning_segments.length > 0 && (
            <div>
              <div className="text-[9px] font-semibold uppercase tracking-[0.12em] text-muted-foreground/60 mb-1">Winning Segments</div>
              <div className="flex flex-wrap gap-1">
                {concept.winning_segments.map(s => (
                  <span key={s} className="text-[9px] px-1.5 py-0.5 rounded bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 font-mono">{s}</span>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function CreativesTab({ workspaceId, withAccount }: { workspaceId: string; withAccount: (p: string) => string }) {
  const concepts = CREATIVE_CONCEPTS.filter(c => c.workspace_id === workspaceId);
  const sorted = [...concepts].sort((a, b) => a.tier - b.tier);

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <div className="text-[10px] text-muted-foreground">{concepts.length} concepts for this workspace</div>
        <Link href={withAccount("/app/creative-library")}
          className="flex items-center gap-1 text-[11px] text-primary hover:text-primary/80 transition-colors">
          See in Creative Library <ExternalLink className="w-3 h-3" />
        </Link>
      </div>
      {sorted.length === 0 ? (
        <p className="text-xs text-muted-foreground text-center py-8">No creative concepts for this workspace.</p>
      ) : (
        <div className="border border-border/50 rounded-xl overflow-hidden divide-y divide-border/0">
          {sorted.map(c => <CreativeRow key={c.id} concept={c} withAccount={withAccount} />)}
        </div>
      )}
    </div>
  );
}

// ─── RunDetail ────────────────────────────────────────────────────────

const STATUS_BADGE: Record<string, string> = {
  Completed: "bg-emerald-500/10 text-emerald-400 border-emerald-500/20",
  Running:   "bg-primary/10 text-primary border-primary/20",
  Failed:    "bg-destructive/10 text-destructive border-destructive/20",
  Pending:   "bg-muted text-muted-foreground border-border/40",
  Archived:  "bg-muted text-muted-foreground border-border/40",
};

const TABS: { id: TabId; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
  { id: "overview",   label: "Overview",   icon: Target },
  { id: "signal",     label: "Signal",     icon: Radio },
  { id: "variables",  label: "Variables",  icon: BarChart3 },
  { id: "avatars",    label: "Avatars",    icon: Users },
  { id: "placements", label: "Placements", icon: MapPin },
  { id: "creatives",  label: "Creatives",  icon: Palette },
];

export function RunDetail() {
  const { runId } = useParams<{ runId: string }>();
  const [activeTab, setActiveTab] = useState<TabId>("overview");
  const { withAccount } = useAccount();

  const run = ANALYSIS_RUNS.find(r => r.id === runId);
  const workspace = run ? WORKSPACES.find(w => w.id === run.workspace_id) : null;

  if (!run) {
    return (
      <div className="flex-1 flex items-center justify-center">
        <div className="text-center space-y-3">
          <h2 className="text-lg font-bold text-foreground">Run not found</h2>
          <p className="text-xs text-muted-foreground">Run ID: {runId}</p>
          <Link href={withAccount("/app/analysis/library")} className="text-xs text-primary hover:underline">
            Back to IAP Library
          </Link>
        </div>
      </div>
    );
  }

  const sq = run.signal_quality;
  const openFindings = run.findings.filter(f => f.is_open);

  return (
    <div className="h-full overflow-y-auto">
      <div className="max-w-5xl mx-auto px-6 py-5 space-y-4">

        {/* Back link */}
        <Link
          href={withAccount("/app/analysis/library")}
          className="inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground transition-colors"
        >
          <ChevronLeft className="w-3.5 h-3.5" /> Back to IAP Library
        </Link>

        {/* Run header */}
        <div className="space-y-2">
          <div className="flex items-start gap-3">
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 flex-wrap mb-1">
                <h1 className="text-xl font-bold text-foreground tracking-tight">
                  {run.depth} — {run.objective}
                </h1>
                <span className={cn("text-[10px] px-2 py-0.5 rounded border font-semibold leading-none",
                  STATUS_BADGE[run.status] ?? "bg-muted text-muted-foreground border-border/40"
                )}>{run.status}</span>
              </div>
              <div className="flex items-center gap-3 text-[11px] text-muted-foreground flex-wrap">
                {workspace && (
                  <span className="flex items-center gap-1">{workspace.name}</span>
                )}
                <span className="flex items-center gap-1">
                  <Clock className="w-3 h-3" />
                  {run.date_range_start} – {run.date_range_end}
                </span>
                <span className="font-mono text-muted-foreground/60">{run.id}</span>
              </div>
            </div>
          </div>

          {/* KPI row — always visible */}
          <div className="grid grid-cols-5 gap-3">
            {[
              { label: "Signal Quality",    value: `${sq.overall}/100`,             sub: sq.overall >= 80 ? "Strong" : sq.overall >= 60 ? "Moderate" : "Weak",      color: sq.overall >= 80 ? "text-emerald-400" : sq.overall >= 60 ? "text-yellow-400" : "text-orange-400" },
              { label: "Confidence",        value: `${run.confidence_score}/100`,   sub: run.confidence_score >= 80 ? "High" : "Medium",                             color: "text-foreground" },
              { label: "Findings",          value: run.findings.length,             sub: `${openFindings.length} open`,                                              color: openFindings.length > 0 ? "text-orange-400" : "text-foreground" },
              { label: "Recommendations",   value: run.recommendations.length,      sub: `${run.recommendations.filter(r => r.status === "Open").length} open`,      color: "text-foreground" },
              { label: "Decisions",         value: run.decision_feed.length,        sub: `${run.decision_feed.filter(d => d.status === "Open").length} open`,        color: "text-foreground" },
            ].map(k => (
              <div key={k.label} className="bg-card border border-border/60 rounded-xl px-3 py-2.5">
                <div className={cn("text-xl font-bold leading-none", k.color)}>{k.value}</div>
                <div className="text-[10px] font-medium text-foreground mt-1">{k.label}</div>
                <div className="text-[10px] text-muted-foreground mt-0.5">{k.sub}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Tab bar */}
        <div className="flex items-center gap-0.5 border-b border-border/50">
          {TABS.map(tab => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={cn(
                  "flex items-center gap-1.5 px-3.5 py-2.5 text-xs font-medium border-b-2 transition-all -mb-px",
                  activeTab === tab.id
                    ? "border-primary text-foreground"
                    : "border-transparent text-muted-foreground hover:text-foreground"
                )}
              >
                <Icon className="w-3 h-3 shrink-0" />
                {tab.label}
              </button>
            );
          })}
        </div>

        {/* Tab content */}
        <div className="pb-8">
          {activeTab === "overview"   && <OverviewTab   run={run} withAccount={withAccount} />}
          {activeTab === "signal"     && <SignalTab     run={run} withAccount={withAccount} />}
          {activeTab === "variables"  && <VariablesTab  run={run} withAccount={withAccount} />}
          {activeTab === "avatars"    && <AvatarsTab    workspaceId={run.workspace_id} withAccount={withAccount} />}
          {activeTab === "placements" && <PlacementsTab withAccount={withAccount} />}
          {activeTab === "creatives"  && <CreativesTab  workspaceId={run.workspace_id} withAccount={withAccount} />}
        </div>

      </div>
    </div>
  );
}
