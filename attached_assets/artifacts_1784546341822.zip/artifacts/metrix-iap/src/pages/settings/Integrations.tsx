import { useState } from "react";
import { cn } from "@/lib/utils";
import { Plug, CheckCircle2, RefreshCw, Plus } from "lucide-react";
import { SettingsShell } from "./SettingsTabs";

interface Integration {
  id: string;
  name: string;
  desc: string;
  status: "Connected" | "Available" | "Syncing";
  meta?: string;
}

const INITIAL: Integration[] = [
  { id: "meta", name: "Meta Ads API", desc: "Live campaign, ad set, and ad-level sync for all connected accounts.", status: "Connected", meta: "Last sync 12 min ago · 2 accounts" },
  { id: "sheets", name: "Google Sheets", desc: "Push IAP run outputs and report tables to shared sheets.", status: "Connected", meta: "3 linked sheets" },
  { id: "slack", name: "Slack", desc: "Alerts, run completions, and recommendation digests in your channels.", status: "Connected", meta: "#bookster-ads · #metrix-alerts" },
  { id: "ga4", name: "Google Analytics 4", desc: "Blend site conversion data into event results and CPA checks.", status: "Available" },
  { id: "shopify", name: "Shopify", desc: "Revenue-truth matching for ecommerce clients.", status: "Available" },
  { id: "notion", name: "Notion", desc: "Publish briefs and strategy docs to client workspaces.", status: "Available" },
];

export function IntegrationsSettings() {
  const [items, setItems] = useState(INITIAL);

  function connect(id: string) {
    setItems((prev) => prev.map((i) =>
      i.id === id ? { ...i, status: "Connected" as const, meta: "Connected just now" } : i
    ));
  }

  return (
    <SettingsShell title="Connected data sources and destinations">
      <div className="grid grid-cols-2 gap-3">
        {items.map((i) => (
          <div key={i.id} className="bg-card border border-border/60 rounded-xl px-4 py-3.5 space-y-2">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-primary/10 border border-primary/20 flex items-center justify-center shrink-0">
                <Plug className="w-3.5 h-3.5 text-primary" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-xs font-semibold text-foreground">{i.name}</div>
                {i.meta && <div className="text-[10px] text-muted-foreground">{i.meta}</div>}
              </div>
              {i.status === "Connected" ? (
                <span className="flex items-center gap-1 text-[9px] px-1.5 py-0.5 rounded border font-semibold leading-none text-emerald-400 border-emerald-500/20 bg-emerald-500/10">
                  <CheckCircle2 className="w-2.5 h-2.5" /> Connected
                </span>
              ) : (
                <button
                  onClick={() => connect(i.id)}
                  className="flex items-center gap-1 text-[10px] font-medium text-primary border border-primary/25 rounded px-2 py-1 hover:bg-primary/10 transition-colors"
                >
                  <Plus className="w-2.5 h-2.5" /> Connect
                </button>
              )}
            </div>
            <p className="text-[11px] text-muted-foreground leading-relaxed">{i.desc}</p>
            {i.status === "Connected" && (
              <button className="flex items-center gap-1 text-[10px] text-muted-foreground hover:text-foreground transition-colors">
                <RefreshCw className="w-2.5 h-2.5" /> Sync now
              </button>
            )}
          </div>
        ))}
      </div>
    </SettingsShell>
  );
}
