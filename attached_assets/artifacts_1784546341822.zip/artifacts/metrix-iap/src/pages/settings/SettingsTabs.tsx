import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";

const TABS = [
  { label: "Account", href: "/app/settings", exact: true },
  { label: "Integrations", href: "/app/settings/integrations" },
  { label: "Team & Access", href: "/app/settings/team" },
  { label: "Notifications", href: "/app/settings/notifications" },
  { label: "Billing", href: "/app/settings/billing" },
];

export function SettingsTabs() {
  const [location] = useLocation();
  return (
    <div className="flex items-center gap-1 border-b border-border/50 -mb-px">
      {TABS.map((tab) => {
        const active = tab.exact ? location === tab.href : location.startsWith(tab.href);
        return (
          <Link
            key={tab.href}
            href={tab.href}
            className={cn(
              "px-3 py-2 text-[11px] font-medium border-b-2 transition-colors",
              active
                ? "text-primary border-primary"
                : "text-muted-foreground border-transparent hover:text-foreground"
            )}
          >
            {tab.label}
          </Link>
        );
      })}
    </div>
  );
}

export function SettingsShell({ title, children }: { title?: string; children: React.ReactNode }) {
  return (
    <div className="h-full overflow-y-auto">
      <div className="max-w-4xl mx-auto px-6 py-5 space-y-4">
        <div>
          <h1 className="text-xl font-bold text-foreground tracking-tight">Settings</h1>
          {title && <p className="text-xs text-muted-foreground mt-0.5">{title}</p>}
        </div>
        <SettingsTabs />
        {children}
      </div>
    </div>
  );
}
