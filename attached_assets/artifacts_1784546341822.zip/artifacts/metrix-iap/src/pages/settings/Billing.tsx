import { cn } from "@/lib/utils";
import { CreditCard, Download, Zap } from "lucide-react";
import { SettingsShell } from "./SettingsTabs";

const USAGE = [
  { label: "IAP Runs", used: 14, limit: 30 },
  { label: "Creative Scans", used: 128, limit: 500 },
  { label: "Connected Ad Accounts", used: 2, limit: 10 },
  { label: "Team Seats", used: 6, limit: 12 },
];

const INVOICES = [
  { id: "INV-2026-007", date: "Jul 1, 2026", amount: "$499.00", status: "Paid" },
  { id: "INV-2026-006", date: "Jun 1, 2026", amount: "$499.00", status: "Paid" },
  { id: "INV-2026-005", date: "May 1, 2026", amount: "$499.00", status: "Paid" },
  { id: "INV-2026-004", date: "Apr 1, 2026", amount: "$349.00", status: "Paid" },
];

export function Billing() {
  return (
    <SettingsShell title="Plan, usage, and invoices">
      {/* Plan */}
      <div className="bg-card border border-border/60 rounded-xl px-5 py-4 flex items-center gap-4">
        <div className="w-9 h-9 rounded-lg bg-[hsl(var(--metrix-gold)/0.12)] border border-[hsl(var(--metrix-gold)/0.25)] flex items-center justify-center shrink-0">
          <Zap className="w-4 h-4 text-[hsl(var(--metrix-gold))]" />
        </div>
        <div className="flex-1">
          <div className="text-sm font-bold text-foreground">Metrix Pro</div>
          <div className="text-[11px] text-muted-foreground">$499/mo · renews Aug 1, 2026 · Visa ending 4412</div>
        </div>
        <button className="text-[11px] font-medium text-muted-foreground hover:text-foreground border border-border/50 rounded-lg px-3 py-1.5 transition-colors">
          Manage plan
        </button>
      </div>

      {/* Usage */}
      <div className="grid grid-cols-2 gap-3">
        {USAGE.map((u) => {
          const pct = Math.round((u.used / u.limit) * 100);
          return (
            <div key={u.label} className="bg-card border border-border/60 rounded-xl px-4 py-3.5 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">{u.label}</span>
                <span className="text-[10px] font-mono text-foreground">{u.used} / {u.limit}</span>
              </div>
              <div className="w-full bg-border/30 rounded-full h-1.5">
                <div
                  className={cn("h-full rounded-full", pct >= 85 ? "bg-orange-400" : "bg-primary")}
                  style={{ width: `${pct}%` }}
                />
              </div>
            </div>
          );
        })}
      </div>

      {/* Invoices */}
      <div className="bg-card border border-border/60 rounded-xl overflow-hidden">
        <div className="flex items-center gap-2 px-5 py-3 border-b border-border/50 bg-muted/10">
          <CreditCard className="w-3.5 h-3.5 text-muted-foreground" />
          <span className="text-xs font-semibold text-foreground">Invoices</span>
        </div>
        <div className="divide-y divide-border/30">
          {INVOICES.map((inv) => (
            <div key={inv.id} className="flex items-center gap-4 px-5 py-3">
              <span className="text-[11px] font-mono text-foreground w-32">{inv.id}</span>
              <span className="text-[11px] text-muted-foreground flex-1">{inv.date}</span>
              <span className="text-[11px] font-medium text-foreground">{inv.amount}</span>
              <span className="text-[9px] px-1.5 py-0.5 rounded border font-semibold leading-none text-emerald-400 border-emerald-500/20 bg-emerald-500/10">
                {inv.status}
              </span>
              <button className="text-muted-foreground hover:text-foreground transition-colors">
                <Download className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>
      </div>
    </SettingsShell>
  );
}
