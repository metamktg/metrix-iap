import { useState } from "react";
import { cn } from "@/lib/utils";
import { UserPlus, ShieldCheck } from "lucide-react";
import { USERS, WORKSPACE_MEMBERS, WORKSPACES } from "@/lib/mock-data";
import { SettingsShell } from "./SettingsTabs";

const ROLE_COLORS: Record<string, string> = {
  "Master Admin": "text-primary border-primary/20 bg-primary/10",
  "Workspace Admin": "text-purple-400 border-purple-500/20 bg-purple-500/10",
  Strategist: "text-emerald-400 border-emerald-500/20 bg-emerald-500/10",
  "Media Buyer": "text-blue-400 border-blue-500/20 bg-blue-500/10",
  "Creative Strategist": "text-yellow-400 border-yellow-400/20 bg-yellow-400/10",
  "Client Viewer": "text-muted-foreground border-border/40 bg-muted/20",
  "Read Only": "text-muted-foreground border-border/40 bg-muted/10",
};

function RoleBadge({ role }: { role: string }) {
  return (
    <span className={cn(
      "text-[9px] px-1.5 py-0.5 rounded border font-semibold leading-none",
      ROLE_COLORS[role] ?? "text-muted-foreground border-border/40"
    )}>
      {role}
    </span>
  );
}

export function TeamAccess() {
  const [inviteEmail, setInviteEmail] = useState("");
  const [invited, setInvited] = useState<string[]>([]);

  function invite() {
    const email = inviteEmail.trim();
    if (!email) return;
    setInvited((prev) => [...prev, email]);
    setInviteEmail("");
  }

  return (
    <SettingsShell title="Everyone sees the same platform — roles control data scope, never features">
      {/* Invite */}
      <div className="bg-card border border-border/60 rounded-xl px-4 py-3.5 flex items-center gap-3">
        <UserPlus className="w-4 h-4 text-primary shrink-0" />
        <input
          value={inviteEmail}
          onChange={(e) => setInviteEmail(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && invite()}
          placeholder="teammate@agency.com"
          className="flex-1 bg-transparent border border-border/50 rounded-lg px-3 py-1.5 text-xs text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:border-primary/50"
        />
        <button
          onClick={invite}
          className="text-[11px] font-medium text-white bg-primary hover:bg-primary/90 px-3 py-1.5 rounded-lg transition-colors"
        >
          Send invite
        </button>
      </div>

      {invited.length > 0 && (
        <div className="space-y-1.5">
          {invited.map((email) => (
            <div key={email} className="flex items-center gap-3 px-4 py-2.5 rounded-xl border border-border/40 bg-card/60 text-[11px]">
              <span className="text-foreground flex-1">{email}</span>
              <span className="text-[9px] px-1.5 py-0.5 rounded border font-semibold leading-none text-yellow-400 border-yellow-400/20 bg-yellow-400/10">
                Invite sent
              </span>
            </div>
          ))}
        </div>
      )}

      {/* Members */}
      <div className="bg-card border border-border/60 rounded-xl overflow-hidden">
        <div className="flex items-center gap-2 px-5 py-3 border-b border-border/50 bg-muted/10">
          <ShieldCheck className="w-3.5 h-3.5 text-muted-foreground" />
          <span className="text-xs font-semibold text-foreground">Team Members</span>
          <span className="text-[10px] text-muted-foreground">{USERS.length} people</span>
        </div>
        <div className="divide-y divide-border/30">
          {USERS.map((user) => {
            const memberships = WORKSPACE_MEMBERS.filter((m) => m.user_id === user.id);
            return (
              <div key={user.id} className="flex items-center gap-4 px-5 py-3">
                <div className="w-7 h-7 rounded-lg bg-primary/15 border border-primary/20 flex items-center justify-center text-[10px] font-bold text-primary shrink-0">
                  {user.avatar_initials}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-[11px] font-medium text-foreground">{user.name}</div>
                  <div className="text-[10px] text-muted-foreground">{user.email}</div>
                </div>
                <div className="flex items-center gap-1.5 flex-wrap justify-end">
                  {memberships.map((m) => {
                    const ws = WORKSPACES.find((w) => w.id === m.workspace_id);
                    return (
                      <div key={m.id} className="flex items-center gap-1">
                        <span className="text-[9px] text-muted-foreground">{ws?.name}</span>
                        <RoleBadge role={m.role} />
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </SettingsShell>
  );
}
