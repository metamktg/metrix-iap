import { useState } from "react";
import { cn } from "@/lib/utils";
import { Bell, Mail, MessageSquare, Monitor } from "lucide-react";
import { SettingsShell } from "./SettingsTabs";

interface Pref {
  id: string;
  label: string;
  desc: string;
  email: boolean;
  slack: boolean;
  inApp: boolean;
}

const INITIAL: Pref[] = [
  { id: "run_done", label: "IAP run completed", desc: "When an analysis run finishes and recommendations are ready.", email: true, slack: true, inApp: true },
  { id: "alerts", label: "Change alerts", desc: "Spend spikes, CPA drift, delivery drops on watched accounts.", email: true, slack: true, inApp: true },
  { id: "fatigue", label: "Creative fatigue warnings", desc: "When a live concept crosses the fatigue threshold.", email: false, slack: true, inApp: true },
  { id: "briefs", label: "Brief status changes", desc: "Briefs approved, produced, or launched.", email: false, slack: false, inApp: true },
  { id: "imports", label: "Import processing", desc: "Uploads validated, mapped, or failed.", email: true, slack: false, inApp: true },
  { id: "digest", label: "Weekly digest", desc: "Monday summary of loop progress across all workspaces.", email: true, slack: false, inApp: false },
];

type Channel = "email" | "slack" | "inApp";

const CHANNELS: { key: Channel; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
  { key: "email", label: "Email", icon: Mail },
  { key: "slack", label: "Slack", icon: MessageSquare },
  { key: "inApp", label: "In-app", icon: Monitor },
];

function Toggle({ on, onClick }: { on: boolean; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "w-8 h-[18px] rounded-full border transition-colors relative",
        on ? "bg-primary/80 border-primary" : "bg-muted/40 border-border/60"
      )}
    >
      <span className={cn(
        "absolute top-[2px] w-3 h-3 rounded-full bg-white transition-all",
        on ? "left-[16px]" : "left-[2px] opacity-60"
      )} />
    </button>
  );
}

export function NotificationSettings() {
  const [prefs, setPrefs] = useState(INITIAL);

  function toggle(id: string, channel: Channel) {
    setPrefs((prev) => prev.map((p) => (p.id === id ? { ...p, [channel]: !p[channel] } : p)));
  }

  return (
    <SettingsShell title="Delivery preferences per event type">
      <div className="bg-card border border-border/60 rounded-xl overflow-hidden">
        <div className="grid grid-cols-[1fr_repeat(3,64px)] items-center gap-2 px-5 py-2.5 border-b border-border/50 bg-muted/10">
          <div className="flex items-center gap-2">
            <Bell className="w-3.5 h-3.5 text-muted-foreground" />
            <span className="text-xs font-semibold text-foreground">Event</span>
          </div>
          {CHANNELS.map((c) => (
            <div key={c.key} className="flex items-center justify-center gap-1 text-[9px] font-semibold uppercase tracking-wide text-muted-foreground">
              <c.icon className="w-2.5 h-2.5" /> {c.label}
            </div>
          ))}
        </div>
        <div className="divide-y divide-border/30">
          {prefs.map((p) => (
            <div key={p.id} className="grid grid-cols-[1fr_repeat(3,64px)] items-center gap-2 px-5 py-3">
              <div className="min-w-0">
                <div className="text-[11px] font-medium text-foreground">{p.label}</div>
                <div className="text-[10px] text-muted-foreground">{p.desc}</div>
              </div>
              {CHANNELS.map((c) => (
                <div key={c.key} className="flex justify-center">
                  <Toggle on={p[c.key]} onClick={() => toggle(p.id, c.key)} />
                </div>
              ))}
            </div>
          ))}
        </div>
      </div>
    </SettingsShell>
  );
}
