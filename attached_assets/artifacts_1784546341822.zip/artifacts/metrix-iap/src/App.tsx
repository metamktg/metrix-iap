import { Switch, Route, Redirect, Router as WouterRouter, Link, useParams } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AccountProvider } from "@/contexts/AccountContext";
import { RequireAccount } from "@/components/RequireAccount";
import { AppShell } from "@/components/layout/AppShell";
import { ACCOUNTS } from "@/lib/mock-data";
import { AgencyOverview } from "@/pages/AgencyOverview";
import { AccountOverview } from "@/pages/AccountOverview";
import { ImportCenter } from "@/pages/ImportCenter";
import { ChangeWatch } from "@/pages/ChangeWatch";
import { Signal } from "@/pages/Signal";
import { Recommendations } from "@/pages/Recommendations";
import { AnalysisHub } from "@/pages/AnalysisHub";
import { AnalysisOverview } from "@/pages/AnalysisOverview";
import { IAPRunsList } from "@/pages/IAPRunsList";
import { RunDetail } from "@/pages/RunDetail";
import { IAPRunBuilder } from "@/pages/IAPRunBuilder";
import { BenchmarkMemoryPage } from "@/pages/BenchmarkMemory";
import { Audience } from "@/pages/Audience";
import { Placements } from "@/pages/Placements";
import { BudgetInsight } from "@/pages/BudgetInsight";
import { StrategyHub } from "@/pages/StrategyHub";
import { StrategyOverview } from "@/pages/StrategyOverview";
import { StrategyMap } from "@/pages/StrategyMap";
import { Avatars } from "@/pages/Avatars";
import { HypothesisQueue } from "@/pages/HypothesisQueue";
import { CreativeHub } from "@/pages/CreativeHub";
import { CreativeLibrary } from "@/pages/CreativeLibrary";
import { BriefEngine } from "@/pages/BriefEngine";
import { BriefDetail } from "@/pages/BriefDetail";
import { Produce } from "@/pages/Produce";
import { ReportsHub } from "@/pages/ReportsHub";
import { ReportsOverview } from "@/pages/ReportsOverview";
import { NewReport } from "@/pages/NewReport";
import { Reports } from "@/pages/Reports";
import { Exports } from "@/pages/Exports";
import { ReportSettings } from "@/pages/ReportSettings";
import { MSTHub } from "@/pages/MSTHub";
import { VariableMap } from "@/pages/VariableMap";
import { MatrixBuilder } from "@/pages/MatrixBuilder";
import { CreativeScan } from "@/pages/CreativeScan";
import { CrossmapResults } from "@/pages/CrossmapResults";
import { MSTHistory } from "@/pages/MSTHistory";
import { AgentConsole } from "@/pages/AgentConsole";
import { Settings } from "@/pages/Settings";
import { IntegrationsSettings } from "@/pages/settings/Integrations";
import { TeamAccess } from "@/pages/settings/TeamAccess";
import { NotificationSettings } from "@/pages/settings/NotificationSettings";
import { Billing } from "@/pages/settings/Billing";

function NotFound() {
  return (
    <div className="flex-1 flex items-center justify-center py-24">
      <div className="text-center space-y-2">
        <h2 className="text-lg font-bold text-foreground">Page not found</h2>
        <Link href="/" className="text-xs text-primary hover:text-primary/80 transition-colors">
          Back to overview
        </Link>
      </div>
    </div>
  );
}

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: Infinity,
      retry: false,
    },
  },
});

// Account-scoped pages require ?account=<slug> — gate them.
function gated(Component: React.ComponentType) {
  return function GatedPage() {
    return (
      <RequireAccount>
        <Component />
      </RequireAccount>
    );
  };
}

// Legacy /app/workspaces/:id/* deep links → account-scoped equivalent.
function LegacyWorkspaceRedirect() {
  const params = useParams<{ workspaceId: string }>();
  const account = ACCOUNTS.find(a => a.id === params.workspaceId);
  return <Redirect to={account ? `/app/account?account=${account.slug}` : "/"} replace />;
}

function Router() {
  return (
    <Switch>
      {/* Agency level */}
      <Route path="/" component={AgencyOverview} />

      {/* Account overview */}
      <Route path="/app/account" component={gated(AccountOverview)} />

      {/* Listen */}
      <Route path="/app/listen/imports" component={gated(ImportCenter)} />
      <Route path="/app/listen/alerts" component={gated(ChangeWatch)} />
      <Route path="/app/listen/signal" component={gated(Signal)} />
      <Route path="/app/listen/recommendations" component={gated(Recommendations)} />

      {/* Analysis — hub + children */}
      <Route path="/app/analysis" component={gated(AnalysisHub)} />
      <Route path="/app/analysis/overview" component={gated(AnalysisOverview)} />
      <Route path="/app/analysis/library/:runId" component={gated(RunDetail)} />
      <Route path="/app/analysis/library" component={gated(IAPRunsList)} />
      <Route path="/app/analysis/new-run" component={gated(IAPRunBuilder)} />
      <Route path="/app/analysis/benchmarks" component={gated(BenchmarkMemoryPage)} />
      <Route path="/app/analysis/audience" component={gated(Audience)} />
      <Route path="/app/analysis/placements" component={gated(Placements)} />
      <Route path="/app/analysis/budget" component={gated(BudgetInsight)} />

      {/* Strategy — hub + children */}
      <Route path="/app/strategy" component={gated(StrategyHub)} />
      <Route path="/app/strategy/overview" component={gated(StrategyOverview)} />
      <Route path="/app/strategy/map" component={gated(StrategyMap)} />
      <Route path="/app/strategy/avatars" component={gated(Avatars)} />
      <Route path="/app/strategy/hypotheses" component={gated(HypothesisQueue)} />

      {/* Creative — hub + children */}
      <Route path="/app/creative" component={gated(CreativeHub)} />
      <Route path="/app/creative/produce" component={gated(Produce)} />
      <Route path="/app/creative-library" component={gated(CreativeLibrary)} />
      <Route path="/app/briefs/builder" component={gated(BriefEngine)} />
      <Route path="/app/briefs/history" component={gated(BriefEngine)} />
      <Route path="/app/briefs/:briefId" component={gated(BriefDetail)} />

      {/* Reports — hub + children */}
      <Route path="/app/reports" component={gated(ReportsHub)} />
      <Route path="/app/reports/overview" component={gated(ReportsOverview)} />
      <Route path="/app/reports/new" component={gated(NewReport)} />
      <Route path="/app/reports/history" component={gated(Reports)} />
      <Route path="/app/reports/exports" component={gated(Exports)} />
      <Route path="/app/reports/settings" component={gated(ReportSettings)} />

      {/* MST — hub + children */}
      <Route path="/app/mst" component={gated(MSTHub)} />
      <Route path="/app/mst/variable-map" component={gated(VariableMap)} />
      <Route path="/app/mst/matrix" component={gated(MatrixBuilder)} />
      <Route path="/app/mst/creative-scan" component={gated(CreativeScan)} />
      <Route path="/app/mst/crossmap" component={gated(CrossmapResults)} />
      <Route path="/app/mst/results"  component={gated(CrossmapResults)} />
      <Route path="/app/mst/history"  component={gated(MSTHistory)} />

      {/* Agent */}
      <Route path="/app/agent" component={gated(AgentConsole)} />

      {/* Settings */}
      <Route path="/app/settings/account" component={gated(Settings)} />
      <Route path="/app/settings/integrations" component={IntegrationsSettings} />
      <Route path="/app/settings/team" component={TeamAccess} />
      <Route path="/app/settings/notifications" component={NotificationSettings} />
      <Route path="/app/settings/billing" component={Billing} />

      {/* Legacy route redirects (old prototype paths) */}
      <Route path="/app/iap/new"><Redirect to="/app/analysis/new-run" replace /></Route>
      <Route path="/app/iap/runs/:runId">
        {params => <Redirect to={`/app/analysis/library/${params.runId}`} replace />}
      </Route>
      <Route path="/app/iap/runs"><Redirect to="/app/analysis/library" replace /></Route>
      <Route path="/app/imports"><Redirect to="/app/listen/imports" replace /></Route>
      <Route path="/app/change-watch"><Redirect to="/app/listen/alerts" replace /></Route>
      <Route path="/app/benchmarks"><Redirect to="/app/analysis/benchmarks" replace /></Route>
      <Route path="/app/audience"><Redirect to="/app/analysis/audience" replace /></Route>
      <Route path="/app/placements"><Redirect to="/app/analysis/placements" replace /></Route>
      <Route path="/app/budget"><Redirect to="/app/analysis/budget" replace /></Route>
      <Route path="/app/strategy-map"><Redirect to="/app/strategy/map" replace /></Route>
      <Route path="/app/avatars"><Redirect to="/app/strategy/avatars" replace /></Route>
      <Route path="/app/hypotheses"><Redirect to="/app/strategy/hypotheses" replace /></Route>
      <Route path="/app/briefs"><Redirect to="/app/briefs/builder" replace /></Route>
      <Route path="/app/exports"><Redirect to="/app/reports/exports" replace /></Route>
      <Route path="/app/mst/scan"><Redirect to="/app/mst/creative-scan" replace /></Route>
      <Route path="/app/mst/concept-map"><Redirect to="/app/mst/variable-map" replace /></Route>
      <Route path="/app/settings"><Redirect to="/app/settings/account" replace /></Route>
      <Route path="/app/workspaces/:workspaceId/*?" component={LegacyWorkspaceRedirect} />

      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <AccountProvider>
            <AppShell>
              <Router />
            </AppShell>
          </AccountProvider>
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
