import { describe, it, expect, beforeEach } from "vitest";
import { render, screen, waitFor, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import App from "../App";

// Regression guard: sidebar and breadcrumb navigation must go through the
// browser history (wouter Link/navigate), so back/forward buttons keep working.
// The ?account= scope param must ride along with sidebar navigation.

function topbar(): HTMLElement {
  const header = document.querySelector("header");
  if (!header) throw new Error("Topbar header not found");
  return header as HTMLElement;
}

function sidebar(): HTMLElement {
  const aside = document.querySelector("aside");
  if (!aside) throw new Error("Sidebar not found");
  return aside as HTMLElement;
}

async function expectPath(path: string) {
  await waitFor(() => {
    expect(window.location.pathname).toBe(path);
  });
}

async function expectBreadcrumb(label: string) {
  await waitFor(() => {
    expect(within(topbar()).getByText(label)).toBeInTheDocument();
  });
}

describe("browser back/forward with app navigation", () => {
  beforeEach(() => {
    window.history.replaceState(null, "", "/");
  });

  it("keeps back/forward working across sidebar and breadcrumb navigation", async () => {
    const user = userEvent.setup();
    render(<App />);

    // Root: Agency overview
    await expectBreadcrumb("Metrix Manager");
    expect(window.location.pathname).toBe("/");

    // Sidebar → Analysis (expand chevron) → Benchmarks
    await user.click(within(sidebar()).getByRole("button", { name: /expand analysis/i }));
    await user.click(within(sidebar()).getByRole("link", { name: /benchmarks/i }));
    await expectPath("/app/analysis/benchmarks");
    await expectBreadcrumb("Benchmarks");

    // Sidebar → Creative (expand chevron) → Briefs
    await user.click(within(sidebar()).getByRole("button", { name: /expand creative/i }));
    await user.click(within(sidebar()).getByRole("link", { name: /^briefs$/i }));
    await expectPath("/app/briefs/builder");
    await expectBreadcrumb("Briefs");

    // Back → Benchmarks
    window.history.back();
    await expectPath("/app/analysis/benchmarks");
    await expectBreadcrumb("Benchmarks");

    // Back → Agency overview
    window.history.back();
    await expectPath("/");
    await expectBreadcrumb("Metrix Manager");

    // Forward → Benchmarks
    window.history.forward();
    await expectPath("/app/analysis/benchmarks");
    await expectBreadcrumb("Benchmarks");

    // Breadcrumb "Metrix Manager" link → root
    await user.click(within(topbar()).getByRole("link", { name: /metrix manager/i }));
    await expectPath("/");
    await expectBreadcrumb("Metrix Manager");

    // Back → Benchmarks again (breadcrumb click must have pushed history)
    window.history.back();
    await expectPath("/app/analysis/benchmarks");
    await expectBreadcrumb("Benchmarks");
  });

  it("sidebar and breadcrumb navigation render as real links (history-based)", async () => {
    render(<App />);
    await expectBreadcrumb("Metrix Manager");

    const user = userEvent.setup();
    await user.click(within(sidebar()).getByRole("button", { name: /expand analysis/i }));

    const benchmarks = within(sidebar()).getByRole("link", { name: /benchmarks/i });
    expect(benchmarks).toHaveAttribute("href", "/app/analysis/benchmarks");

    await user.click(benchmarks);
    await expectPath("/app/analysis/benchmarks");

    const crumbLink = within(topbar()).getByRole("link", { name: /metrix manager/i });
    expect(crumbLink).toHaveAttribute("href", "/");
  });

  it("carries the ?account= scope through sidebar navigation", async () => {
    window.history.replaceState(null, "", "/app/account?account=bookster");
    const user = userEvent.setup();
    render(<App />);

    await expectBreadcrumb("Bookster");

    // Sidebar hrefs carry the account param
    await user.click(within(sidebar()).getByRole("button", { name: /expand analysis/i }));
    const benchmarks = within(sidebar()).getByRole("link", { name: /benchmarks/i });
    expect(benchmarks).toHaveAttribute("href", "/app/analysis/benchmarks?account=bookster");

    await user.click(benchmarks);
    await expectPath("/app/analysis/benchmarks");
    expect(window.location.search).toContain("account=bookster");
    await expectBreadcrumb("Benchmarks");

    // The account picker is NOT shown — the page renders in scope
    expect(screen.queryByText(/no ad account selected/i)).not.toBeInTheDocument();
  });
});
