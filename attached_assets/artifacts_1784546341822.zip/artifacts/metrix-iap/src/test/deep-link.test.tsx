import { describe, it, expect, afterEach } from "vitest";
import { render, screen, waitFor, within, cleanup } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import App from "../App";

// Regression guard: opening a deep link directly (fresh mount, no prior
// navigation) must render the correct page, and a hard refresh (remount at
// the same URL) must re-render the same page — never a blank page or the
// "Page Not Found" stub. Account-scoped routes carry ?account=<slug>.

function topbar(): HTMLElement {
  const header = document.querySelector("header");
  if (!header) throw new Error("Topbar header not found");
  return header as HTMLElement;
}

async function expectBreadcrumb(label: string) {
  await waitFor(() => {
    expect(within(topbar()).getByText(label)).toBeInTheDocument();
  });
}

async function expectPageRendered(breadcrumb: string) {
  await expectBreadcrumb(breadcrumb);
  expect(screen.queryByText(/page not found/i)).not.toBeInTheDocument();
}

// Simulates a direct open of a deep link: set the URL first, then mount the
// app from scratch, exactly like a browser loading index.html at that path.
function openDirectly(url: string) {
  window.history.replaceState(null, "", url);
  return render(<App />);
}

function currentUrl(): string {
  return window.location.pathname + window.location.search;
}

const DEEP_LINKS: { url: string; breadcrumb: string }[] = [
  { url: "/app/analysis/benchmarks?account=bookster", breadcrumb: "Benchmarks" },
  { url: "/app/analysis/library?account=bookster", breadcrumb: "IAP Library" },
  { url: "/app/analysis/library/run_0001?account=bookster", breadcrumb: "Run Detail" },
  { url: "/app/account?account=bookster", breadcrumb: "Overview" },
  { url: "/app/briefs/builder?account=bookster", breadcrumb: "Briefs" },
  { url: "/app/settings/account?account=bookster", breadcrumb: "Settings" },
  { url: "/app/listen/signal?account=bookster", breadcrumb: "Signal" },
  { url: "/app/strategy/overview?account=skov", breadcrumb: "Strategy" },
];

describe("deep links open directly and survive hard refresh", () => {
  afterEach(cleanup);

  for (const { url, breadcrumb } of DEEP_LINKS) {
    it(`renders ${url} on direct open and after refresh`, async () => {
      // Direct open (fresh context — no prior in-app navigation)
      const first = openDirectly(url);
      await expectPageRendered(breadcrumb);
      expect(currentUrl()).toBe(url);

      // Hard refresh: tear down and remount at the same URL
      first.unmount();
      openDirectly(url);
      await expectPageRendered(breadcrumb);
      expect(currentUrl()).toBe(url);
    });
  }

  it("redirects legacy routes to the new structure", async () => {
    openDirectly("/app/iap/runs/run_0001?account=bookster");
    await expectPageRendered("Run Detail");
    await waitFor(() => {
      expect(window.location.pathname).toBe("/app/analysis/library/run_0001");
    });
  });

  it("redirects legacy workspace routes to the account overview", async () => {
    openDirectly("/app/workspaces/ws_bookster");
    await expectPageRendered("Overview");
    await waitFor(() => {
      expect(window.location.pathname).toBe("/app/account");
      expect(window.location.search).toContain("account=bookster");
    });
  });

  it("renders the page body (not onboarding) for non-Bookster configured accounts", async () => {
    openDirectly("/app/strategy/overview?account=skov-pet");
    await expectPageRendered("Strategy");
    // The actual page body must render — not an onboarding/setup screen
    await waitFor(() => {
      expect(screen.getByText("Strategy Overview")).toBeInTheDocument();
    });
    expect(screen.queryByText(/no ad account selected/i)).not.toBeInTheDocument();
  });

  it("gates account-scoped pages behind the account picker when no account is set", async () => {
    const user = userEvent.setup();
    openDirectly("/app/analysis/benchmarks");
    await waitFor(() => {
      expect(screen.getByText(/no ad account selected/i)).toBeInTheDocument();
    });

    // Picking an account renders the page in that scope
    await user.click(screen.getByTestId("button-select-account-bookster"));
    await expectPageRendered("Benchmarks");
    expect(window.location.search).toContain("account=bookster");
  });

  it("shows the Page Not Found stub for an unknown route", async () => {
    openDirectly("/app/nonexistent-route");
    await waitFor(() => {
      expect(screen.getByText(/page not found/i)).toBeInTheDocument();
    });
  });
});
