// ═══════════════════════════════════════════════════════════════════════
// METRIX IAP — Account Switcher
// Mirrors live: ONE agency ("Metrix Manager") + flat AD ACCOUNTS list.
// Selecting an account sets ?account=<slug>; the agency item clears it.
// ═══════════════════════════════════════════════════════════════════════

import { useState } from "react";
import { useLocation } from "wouter";
import { ChevronsUpDown, Check, Building2, Briefcase, Plus } from "lucide-react";
import { cn } from "@/lib/utils";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useAccount } from "@/contexts/AccountContext";
import type { Workspace } from "@/lib/types";

export function AccountSwitcher() {
  const { accounts, currentAccount, navigateToAccount } = useAccount();
  const [location, navigate] = useLocation();
  const [open, setOpen] = useState(false);

  function handleSelect(account: Workspace) {
    setOpen(false);
    if (location === "/" || location === "/app") {
      navigate(`/app/account?account=${account.slug}`);
    } else {
      navigateToAccount(account.slug);
    }
  }

  const triggerName = currentAccount ? currentAccount.name : "Metrix Manager";
  const triggerSub = currentAccount
    ? currentAccount.configured === false
      ? "Setup Required"
      : `${currentAccount.platform_label ?? "Meta Ads"} · Connected`
    : "Manager · Agency Overview";
  const TriggerIcon = currentAccount ? Briefcase : Building2;

  return (
    <DropdownMenu open={open} onOpenChange={setOpen}>
      <DropdownMenuTrigger asChild>
        <button
          className={cn(
            "w-full flex items-center gap-2.5 px-3 py-2 rounded-md",
            "hover:bg-white/5 transition-colors text-left group",
            "border border-transparent hover:border-border/40"
          )}
          data-testid="button-account-switcher"
        >
          <div className="shrink-0 w-7 h-7 rounded-md bg-primary/15 border border-primary/20 flex items-center justify-center">
            <TriggerIcon className="w-3.5 h-3.5 text-primary" />
          </div>
          <div className="flex-1 min-w-0">
            <span className="block text-sm font-medium text-foreground truncate leading-tight">
              {triggerName}
            </span>
            <span className={cn(
              "block text-[10px] truncate leading-tight mt-0.5",
              currentAccount?.configured === false ? "text-yellow-400" : "text-muted-foreground"
            )}>
              {triggerSub}
            </span>
          </div>
          <ChevronsUpDown className="shrink-0 w-3.5 h-3.5 text-muted-foreground group-hover:text-foreground transition-colors" />
        </button>
      </DropdownMenuTrigger>

      <DropdownMenuContent
        align="start"
        sideOffset={4}
        className="w-64 bg-card border-border/60 shadow-xl p-1"
      >
        {/* Agency overview */}
        <DropdownMenuItem
          className="flex items-center gap-2 px-2 py-1.5 cursor-pointer"
          onClick={() => { setOpen(false); navigate("/"); }}
          data-testid="menu-item-agency-overview"
        >
          <div className="w-6 h-6 rounded bg-primary/15 border border-primary/20 flex items-center justify-center shrink-0">
            <Building2 className="w-3 h-3 text-primary" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-xs font-medium text-foreground">Metrix Manager</div>
            <div className="text-[10px] text-muted-foreground">Agency Overview</div>
          </div>
          {!currentAccount && <Check className="w-3 h-3 text-primary shrink-0" />}
        </DropdownMenuItem>

        <DropdownMenuSeparator className="my-1 bg-border/40" />

        <DropdownMenuLabel className="px-2 py-1 text-[10px] font-semibold uppercase tracking-widest text-muted-foreground">
          Ad Accounts
        </DropdownMenuLabel>

        {accounts.map(account => {
          const isActive = currentAccount?.id === account.id;
          const unconfigured = account.configured === false;
          return (
            <DropdownMenuItem
              key={account.id}
              className={cn(
                "flex items-center gap-2 px-2 py-1.5 cursor-pointer rounded",
                isActive && "bg-primary/10"
              )}
              onClick={() => handleSelect(account)}
              data-testid={`menu-item-account-${account.slug}`}
            >
              <div className={cn(
                "w-6 h-6 rounded border flex items-center justify-center shrink-0",
                isActive ? "bg-primary/20 border-primary/30" : "bg-white/5 border-border/40"
              )}>
                <Briefcase className={cn("w-3 h-3", isActive ? "text-primary" : "text-muted-foreground")} />
              </div>
              <div className="flex-1 min-w-0">
                <div className={cn("text-xs font-medium truncate", isActive ? "text-primary" : "text-foreground")}>
                  {account.name}
                </div>
                <div className={cn("text-[10px] truncate", unconfigured ? "text-yellow-400" : "text-muted-foreground")}>
                  {unconfigured ? "Unconfigured · Setup" : "Configured"}
                </div>
              </div>
              {isActive && <Check className="w-3 h-3 text-primary shrink-0" />}
            </DropdownMenuItem>
          );
        })}

        <DropdownMenuSeparator className="my-1 bg-border/40" />

        <DropdownMenuItem
          className="flex items-center gap-2 px-2 py-1.5 cursor-pointer"
          onClick={() => { setOpen(false); navigate("/app/settings/integrations"); }}
          data-testid="menu-item-add-account"
        >
          <div className="w-6 h-6 rounded border border-dashed border-border/60 flex items-center justify-center shrink-0">
            <Plus className="w-3 h-3 text-muted-foreground" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-xs font-medium text-foreground">Add Ad Account</div>
            <div className="text-[10px] text-muted-foreground">Connect Meta or add a manual import</div>
          </div>
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
