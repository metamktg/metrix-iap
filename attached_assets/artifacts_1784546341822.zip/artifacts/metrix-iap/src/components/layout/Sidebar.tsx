import { useState } from "react";
import { Link, useLocation, useSearch } from "wouter";
import { cn } from "@/lib/utils";
import {
  LayoutGrid, Radio, BarChart3, Compass, Palette,
  ClipboardList, Layers, Bot, Settings2, ChevronDown,
} from "lucide-react";
import { AccountSwitcher } from "./AccountSwitcher";
import { useAccount } from "@/contexts/AccountContext";

// ─── Nav types ─────────────────────────────────────────────────────────

interface NavChild {
  label: string;
  href: string;
  badge?: string | number;
  badgeVariant?: "blue" | "gold" | "danger" | "muted";
  exact?: boolean;
}

interface NavSection {
  id: string;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  href?: string;        // whole-section top-level link (no children)
  parentHref?: string;  // hub page for accordion sections
  children?: NavChild[];
}

// ─── Nav map ───────────────────────────────────────────────────────────

function buildSections(openRecs: number, hasAccount: boolean): NavSection[] {
  return [
    {
      id: "overview",
      label: "Overview",
      icon: LayoutGrid,
      href: hasAccount ? "/app/account" : "/",
    },
    {
      id: "listen",
      label: "Listen",
      icon: Radio,
      children: [
        { label: "Imports",         href: "/app/listen/imports" },
        { label: "Alerts",          href: "/app/listen/alerts" },
        { label: "Signal",          href: "/app/listen/signal" },
        {
          label: "Recommendations",
          href: "/app/listen/recommendations",
          badge: openRecs > 0 ? openRecs : undefined,
          badgeVariant: "gold",
        },
      ],
    },
    {
      id: "analysis",
      label: "Analysis",
      icon: BarChart3,
      parentHref: "/app/analysis",
      children: [
        { label: "Overview",    href: "/app/analysis/overview",   exact: true },
        { label: "IAP Library", href: "/app/analysis/library",    exact: true },
        { label: "Audience",    href: "/app/analysis/audience" },
        { label: "Placements",  href: "/app/analysis/placements" },
        { label: "Benchmarks",  href: "/app/analysis/benchmarks" },
        { label: "Budgets",     href: "/app/analysis/budget" },
      ],
    },
    {
      id: "strategy",
      label: "Strategy",
      icon: Compass,
      parentHref: "/app/strategy",
      children: [
        { label: "Overview",         href: "/app/strategy/overview",    exact: true },
        { label: "Avatar / ICP",     href: "/app/strategy/avatars" },
        { label: "Strategy Map",     href: "/app/strategy/map" },
        { label: "Hypothesis Queue", href: "/app/strategy/hypotheses" },
      ],
    },
    {
      id: "creative",
      label: "Creative",
      icon: Palette,
      parentHref: "/app/creative",
      children: [
        { label: "Library", href: "/app/creative-library" },
        { label: "Briefs",  href: "/app/briefs/builder" },
        { label: "History", href: "/app/briefs/history" },
        { label: "Produce", href: "/app/creative/produce" },
      ],
    },
    {
      id: "reports",
      label: "Reports",
      icon: ClipboardList,
      parentHref: "/app/reports",
      children: [
        { label: "Overview", href: "/app/reports/overview",  exact: true },
        { label: "Builder",  href: "/app/reports/new" },
        { label: "History",  href: "/app/reports/history" },
        { label: "Settings", href: "/app/reports/settings" },
      ],
    },
    {
      id: "mst",
      label: "MST",
      icon: Layers,
      parentHref: "/app/mst",
      children: [
        { label: "Crossmap",      href: "/app/mst/crossmap" },
        { label: "Variable Map",  href: "/app/mst/variable-map" },
        { label: "Creative Scan", href: "/app/mst/creative-scan" },
        { label: "Results",       href: "/app/mst/results" },
        { label: "History",       href: "/app/mst/history" },
      ],
    },
    {
      id: "agent",
      label: "Agent",
      icon: Bot,
      href: "/app/agent",
    },
    {
      id: "settings",
      label: "Settings",
      icon: Settings2,
      children: [
        { label: "Account",       href: "/app/settings/account" },
        { label: "Integrations",  href: "/app/settings/integrations" },
        { label: "Team & Access", href: "/app/settings/team" },
        { label: "Notifications", href: "/app/settings/notifications" },
        { label: "Billing",       href: "/app/settings/billing" },
      ],
    },
  ];
}

// ─── Active check ──────────────────────────────────────────────────────

function isActive(href: string, location: string, search: string, exact?: boolean): boolean {
  const [path, queryStr = ""] = href.split("?");
  const hrefParams = new URLSearchParams(queryStr);
  hrefParams.delete("account");
  const locParams = new URLSearchParams(search);
  locParams.delete("account");
  const hrefQ = hrefParams.toString();
  const locQ  = locParams.toString();

  if (hrefQ) return location === path && locQ === hrefQ;
  if (exact) return location === path && !locQ;
  if (path === "/") return location === "/" || location === "/app";
  return location === path || location.startsWith(path + "/");
}

// ─── Badge ─────────────────────────────────────────────────────────────

const BADGE_STYLES: Record<string, string> = {
  blue:   "bg-primary/15 text-primary border-primary/20",
  gold:   "text-[hsl(var(--metrix-gold))] bg-[hsl(var(--metrix-gold)/0.12)] border-[hsl(var(--metrix-gold)/0.25)]",
  danger: "bg-destructive/15 text-destructive border-destructive/20",
  muted:  "bg-muted text-muted-foreground border-border/40",
};

function NavBadge({ value, variant = "blue" }: { value: string | number; variant?: string }) {
  return (
    <span className={cn(
      "ml-auto text-[10px] font-semibold px-1.5 py-0.5 rounded border leading-none shrink-0",
      BADGE_STYLES[variant] ?? BADGE_STYLES.blue
    )}>
      {value}
    </span>
  );
}

// ─── Sidebar ───────────────────────────────────────────────────────────

export function Sidebar() {
  const [location] = useLocation();
  const rawSearch  = useSearch();
  const search     = rawSearch.startsWith("?") ? rawSearch.slice(1) : rawSearch;
  const { currentAccount, withAccount } = useAccount();

  const openRecs = currentAccount
    ? currentAccount.ad_accounts.reduce((sum, a) => sum + a.open_recommendations, 0)
    : 0;
  const sections = buildSections(openRecs, currentAccount != null);

  const [toggled, setToggled] = useState<Record<string, boolean>>({});

  function sectionContainsActive(section: NavSection): boolean {
    return (section.children ?? []).some(c => isActive(c.href, location, search, c.exact));
  }

  function isOpen(section: NavSection): boolean {
    if (toggled[section.id] !== undefined) return toggled[section.id];
    if (sectionContainsActive(section)) return true;
    // Auto-open when exactly on the hub page
    if (section.parentHref && location === section.parentHref) return true;
    return false;
  }

  function toggle(section: NavSection) {
    setToggled(t => ({ ...t, [section.id]: !isOpen(section) }));
  }

  function openSection(section: NavSection) {
    setToggled(t => ({ ...t, [section.id]: true }));
  }

  return (
    <aside
      className="flex flex-col w-[220px] shrink-0 h-full border-r border-border/60 overflow-hidden"
      style={{ background: "hsl(222 61% 5%)" }}
    >
      {/* Logo */}
      <div className="px-4 py-3.5 border-b border-border/40">
        <div className="flex items-center gap-2">
          <img
            src={`${import.meta.env.BASE_URL}metrix-logo.png`}
            alt="Metrix"
            className="w-6 h-6 object-contain shrink-0"
          />
          <span className="text-sm font-bold tracking-tight text-foreground">METRIX</span>
          <span className="text-[10px] font-mono text-muted-foreground border border-border/60 px-1 py-0.5 rounded leading-none">
            IAP
          </span>
        </div>
        <p className="text-[10px] text-muted-foreground/70 mt-1.5 leading-tight">
          Not more data. Better decisions.
        </p>
      </div>

      {/* Account switcher */}
      <div className="px-2 py-2 border-b border-border/40">
        <div className="px-2 pt-1 pb-1.5 text-[9px] font-semibold uppercase tracking-[0.18em] text-muted-foreground/60">
          Workspace
        </div>
        <AccountSwitcher />
      </div>

      {/* Nav */}
      <nav className="flex-1 overflow-y-auto px-2.5 py-3 space-y-1">
        {sections.map(section => {
          const Icon = section.icon;

          // ── Top-level link (Overview, Agent) ──
          if (section.href) {
            const active = isActive(section.href, location, search);
            return (
              <Link
                key={section.id}
                href={section.href === "/" ? "/" : withAccount(section.href)}
                className={cn(
                  "flex items-center gap-2.5 px-3 py-2 rounded-lg text-[11px] font-bold uppercase tracking-[0.14em] transition-all",
                  active
                    ? "text-white bg-gradient-to-r from-primary/90 to-primary/60 shadow-[0_0_16px_hsl(var(--primary)/0.35)] border border-[hsl(var(--metrix-cyan)/0.35)]"
                    : "text-muted-foreground hover:text-foreground hover:bg-white/5 border border-transparent"
                )}
              >
                <Icon className="w-3.5 h-3.5 shrink-0" />
                <span className="truncate">{section.label}</span>
              </Link>
            );
          }

          const open           = isOpen(section);
          const containsActive = sectionContainsActive(section);
          const parentActive   = !!section.parentHref && isActive(section.parentHref, location, search);

          return (
            <div key={section.id}>
              {/* ── Parent row ── */}
              {section.parentHref ? (
                // Split: label navigates to hub, chevron toggles accordion
                <div className={cn(
                  "flex items-center rounded-lg text-[11px] font-bold uppercase tracking-[0.14em] transition-colors",
                  containsActive || parentActive ? "text-foreground" : "text-muted-foreground"
                )}>
                  <Link
                    href={withAccount(section.parentHref)}
                    onClick={() => openSection(section)}
                    className={cn(
                      "flex items-center gap-2.5 flex-1 min-w-0 px-3 py-2 rounded-l-lg hover:text-foreground hover:bg-white/5 transition-colors",
                      containsActive || parentActive ? "text-foreground" : "text-muted-foreground"
                    )}
                  >
                    <Icon className={cn("w-3.5 h-3.5 shrink-0", (containsActive || parentActive) && "text-primary")} />
                    <span className="truncate">{section.label}</span>
                  </Link>
                  <button
                    onClick={() => toggle(section)}
                    aria-label={`Expand ${section.label}`}
                    className={cn(
                      "px-2 py-2 rounded-r-lg hover:text-foreground hover:bg-white/5 transition-colors shrink-0",
                      containsActive || parentActive ? "text-muted-foreground/70" : "text-muted-foreground/50"
                    )}
                  >
                    <ChevronDown className={cn(
                      "w-3 h-3 transition-transform",
                      open ? "rotate-0" : "-rotate-90"
                    )} />
                  </button>
                </div>
              ) : (
                // Button-only accordion (Listen, Settings)
                <button
                  onClick={() => toggle(section)}
                  className={cn(
                    "w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-[11px] font-bold uppercase tracking-[0.14em] transition-colors",
                    containsActive ? "text-foreground" : "text-muted-foreground hover:text-foreground hover:bg-white/5"
                  )}
                >
                  <Icon className={cn("w-3.5 h-3.5 shrink-0", containsActive && "text-primary")} />
                  <span className="flex-1 text-left truncate">{section.label}</span>
                  <ChevronDown className={cn(
                    "w-3 h-3 shrink-0 text-muted-foreground/50 transition-transform",
                    open ? "rotate-0" : "-rotate-90"
                  )} />
                </button>
              )}

              {/* ── Children ── */}
              {open && (
                <div className="mt-0.5 mb-1 ml-[17px] pl-3 border-l border-border/40 space-y-px">
                  {section.children!.map(child => {
                    const active = isActive(child.href, location, search, child.exact);
                    return (
                      <Link
                        key={child.label}
                        href={withAccount(child.href)}
                        className={cn(
                          "flex items-center gap-2 px-2 py-[5px] rounded text-xs transition-colors",
                          active
                            ? "text-primary font-medium bg-primary/10 border border-primary/25"
                            : "text-muted-foreground hover:text-foreground hover:bg-white/5 border border-transparent"
                        )}
                      >
                        <span className="flex-1 truncate">{child.label}</span>
                        {child.badge !== undefined && (
                          <NavBadge value={child.badge} variant={child.badgeVariant} />
                        )}
                      </Link>
                    );
                  })}
                </div>
              )}
            </div>
          );
        })}
      </nav>

      {/* Footer */}
      <div className="px-4 py-2 border-t border-border/40">
        <div className="text-[10px] text-muted-foreground/50 font-mono">
          METRIX IAP v2.0-rc · demo data
        </div>
      </div>
    </aside>
  );
}
