import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import {
  ChevronRight, Bell, AlertCircle, CheckCircle2,
} from "lucide-react";
import { useAccount } from "@/contexts/AccountContext";

// ─── Page crumb map ────────────────────────────────────────────────────

function pageCrumbs(location: string): { label: string; href?: string }[] {
  if (location === "/app/account") return [{ label: "Overview" }];

  // Listen
  if (location.startsWith("/app/listen/imports"))         return [{ label: "Imports" }];
  if (location.startsWith("/app/listen/alerts"))          return [{ label: "Alerts" }];
  if (location.startsWith("/app/listen/signal"))          return [{ label: "Signal" }];
  if (location.startsWith("/app/listen/recommendations")) return [{ label: "Recommendations" }];

  // Analysis — specific first
  if (location.startsWith("/app/analysis/library/"))
    return [{ label: "IAP Library", href: "/app/analysis/library" }, { label: "Run Detail" }];
  if (location.startsWith("/app/analysis/library"))   return [{ label: "IAP Library" }];
  if (location.startsWith("/app/analysis/new-run"))
    return [{ label: "IAP Library", href: "/app/analysis/library" }, { label: "New Run" }];
  if (location.startsWith("/app/analysis/overview"))  return [{ label: "Analysis" }];
  if (location.startsWith("/app/analysis/benchmarks")) return [{ label: "Benchmarks" }];
  if (location.startsWith("/app/analysis/audience"))  return [{ label: "Audience" }];
  if (location.startsWith("/app/analysis/placements")) return [{ label: "Placements" }];
  if (location.startsWith("/app/analysis/budget"))    return [{ label: "Budgets" }];
  if (location === "/app/analysis")                   return [{ label: "Analysis" }];

  // Strategy
  if (location.startsWith("/app/strategy/overview"))   return [{ label: "Strategy" }];
  if (location.startsWith("/app/strategy/map"))        return [{ label: "Strategy Map" }];
  if (location.startsWith("/app/strategy/avatars"))    return [{ label: "Avatars / ICP" }];
  if (location.startsWith("/app/strategy/hypotheses")) return [{ label: "Hypothesis Queue" }];
  if (location === "/app/strategy")                    return [{ label: "Strategy" }];

  // Creative
  if (location.startsWith("/app/creative-library"))    return [{ label: "Creative Library" }];
  if (location.startsWith("/app/creative/produce"))    return [{ label: "Produce" }];
  if (location === "/app/creative")                    return [{ label: "Creative" }];
  if (location.startsWith("/app/briefs/builder"))      return [{ label: "Briefs" }];
  if (location.startsWith("/app/briefs/history"))      return [{ label: "Brief History" }];
  if (location.startsWith("/app/briefs/"))
    return [{ label: "Briefs", href: "/app/briefs/builder" }, { label: "Brief Detail" }];

  // Reports
  if (location.startsWith("/app/reports/overview"))    return [{ label: "Reports Overview" }];
  if (location.startsWith("/app/reports/new"))         return [{ label: "Builder" }];
  if (location.startsWith("/app/reports/history"))     return [{ label: "History" }];
  if (location.startsWith("/app/reports/exports"))     return [{ label: "Exports" }];
  if (location.startsWith("/app/reports/settings"))    return [{ label: "Settings" }];
  if (location === "/app/reports")                     return [{ label: "Reports" }];

  // MST
  if (location.startsWith("/app/mst/variable-map"))   return [{ label: "Variable Map" }];
  if (location.startsWith("/app/mst/matrix"))         return [{ label: "Matrix Builder" }];
  if (location.startsWith("/app/mst/creative-scan"))  return [{ label: "Creative Scan" }];
  if (location.startsWith("/app/mst/results"))        return [{ label: "Results" }];
  if (location.startsWith("/app/mst/crossmap"))       return [{ label: "Crossmap" }];
  if (location.startsWith("/app/mst/history"))        return [{ label: "MST History" }];
  if (location === "/app/mst")                        return [{ label: "MST" }];

  if (location.startsWith("/app/agent"))    return [{ label: "Agent" }];
  if (location.startsWith("/app/settings")) return [{ label: "Settings" }];
  return [];
}

// ─── Health status badge ───────────────────────────────────────────────

const HEALTH_CONFIG = {
  Healthy:       { icon: CheckCircle2, cls: "text-[hsl(var(--metrix-success))]", label: "Healthy" },
  Watch:         { icon: AlertCircle,  cls: "text-yellow-400",    label: "Watch" },
  "Needs Action":{ icon: AlertCircle,  cls: "text-orange-400",    label: "Needs Action" },
  Critical:      { icon: AlertCircle,  cls: "text-destructive",   label: "Critical" },
} as const;

// ─── Topbar ────────────────────────────────────────────────────────────

export function Topbar() {
  const [location] = useLocation();
  const { currentAccount, currentUser, withAccount } = useAccount();

  const crumbs: { label: string; href?: string }[] = [];
  if (location === "/" || location === "/app") {
    crumbs.push({ label: "Metrix Manager" });
  } else {
    crumbs.push({ label: "Metrix Manager", href: "/" });
    if (currentAccount) {
      crumbs.push({ label: currentAccount.name, href: withAccount("/app/account") });
    }
    crumbs.push(
      ...pageCrumbs(location).map(c => (c.href ? { ...c, href: withAccount(c.href) } : c))
    );
  }

  const showSetupRequired = currentAccount?.configured === false;
  const hc = currentAccount && !showSetupRequired
    ? HEALTH_CONFIG[currentAccount.health_status]
    : null;

  return (
    <header className="h-12 flex items-center gap-3 px-4 border-b border-border/60 bg-background/95 backdrop-blur-sm shrink-0">
      {/* Breadcrumbs */}
      <div className="flex items-center gap-1.5 flex-1 min-w-0">
        {crumbs.map((crumb, i) => (
          <span key={i} className="flex items-center gap-1.5">
            {i > 0 && <ChevronRight className="w-3 h-3 text-muted-foreground/40 shrink-0" />}
            {crumb.href ? (
              <Link
                href={crumb.href}
                className="text-xs text-muted-foreground hover:text-foreground transition-colors truncate"
              >
                {crumb.label}
              </Link>
            ) : (
              <span className="text-xs font-medium text-foreground truncate">{crumb.label}</span>
            )}
          </span>
        ))}
      </div>

      {/* Account health */}
      {hc && (
        <div className={cn("flex items-center gap-1 text-xs font-medium", hc.cls)}>
          <hc.icon className="w-3.5 h-3.5" />
          <span>{hc.label}</span>
        </div>
      )}

      {/* Setup required */}
      {showSetupRequired && (
        <div className="flex items-center gap-1.5 text-xs text-muted-foreground border border-border/60 rounded px-2 py-1">
          <div className="w-1.5 h-1.5 rounded-full bg-yellow-400/70" />
          <span>Setup required</span>
        </div>
      )}

      <div className="w-px h-4 bg-border/60" />

      {/* Actions */}
      <div className="flex items-center gap-1">
        <button className="w-7 h-7 rounded flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-white/5 transition-colors relative">
          <Bell className="w-3.5 h-3.5" />
          {currentAccount?.id === "ws_bookster" && (
            <span className="absolute top-1 right-1 w-1.5 h-1.5 rounded-full bg-destructive" />
          )}
        </button>
        <button className="w-7 h-7 rounded flex items-center justify-center bg-primary/15 border border-primary/20 text-primary hover:bg-primary/20 transition-colors">
          <span className="text-[10px] font-bold leading-none">
            {currentUser.name.split(" ").map(n => n[0]).join("").slice(0, 2).toUpperCase()}
          </span>
        </button>
      </div>
    </header>
  );
}
