// ═══════════════════════════════════════════════════════════════════════
// METRIX IAP — RequireAccount gate
// Wraps account-scoped pages. When no ?account=<slug> is present (or it
// doesn't resolve), shows an account picker instead of the page. When the
// account exists but isn't configured, shows a setup prompt (mirrors live
// "Unconfigured · Setup").
// ═══════════════════════════════════════════════════════════════════════

import React from "react";
import { Link } from "wouter";
import { useAccount } from "../contexts/AccountContext";

export function RequireAccount({ children }: { children: React.ReactNode }) {
  const { currentAccount, accounts, navigateToAccount, withAccount } = useAccount();

  if (!currentAccount) {
    return (
      <div className="flex flex-col items-center justify-center py-24 px-6 text-center">
        <div className="w-12 h-12 rounded-xl bg-card border border-border/60 flex items-center justify-center mb-4">
          <svg className="w-6 h-6 text-muted-foreground" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 21h19.5m-18-18v18m10.5-18v18m6-13.5V21M6.75 6.75h.75m-.75 3h.75m-.75 3h.75m3-6h.75m-.75 3h.75m-.75 3h.75" />
          </svg>
        </div>
        <h2 className="text-lg font-semibold text-foreground mb-1">No ad account selected</h2>
        <p className="text-sm text-muted-foreground mb-6 max-w-sm">
          Pick an ad account to view this page. The account selection carries across the whole IAP loop.
        </p>
        <div className="flex flex-col gap-2 w-full max-w-xs">
          {accounts.map(account => (
            <button
              key={account.id}
              onClick={() => navigateToAccount(account.slug)}
              className="flex items-center justify-between px-4 py-2.5 rounded-lg border border-border/60 bg-card/60 hover:bg-card transition-colors text-left"
              data-testid={`button-select-account-${account.slug}`}
            >
              <span className="text-sm font-medium text-foreground">{account.name}</span>
              <span className="text-xs text-muted-foreground">
                {account.configured === false ? "Unconfigured" : account.platform_label ?? "Meta Ads"}
              </span>
            </button>
          ))}
        </div>
      </div>
    );
  }

  if (currentAccount.configured === false) {
    return (
      <div className="flex flex-col items-center justify-center py-24 px-6 text-center">
        <div className="w-12 h-12 rounded-xl bg-card border border-border/60 flex items-center justify-center mb-4">
          <svg className="w-6 h-6 text-amber-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M11.42 15.17L17.25 21A2.652 2.652 0 0021 17.25l-5.877-5.877M11.42 15.17l2.496-3.03c.317-.384.74-.626 1.208-.766M11.42 15.17l-4.655 5.653a2.548 2.548 0 11-3.586-3.586l6.837-5.63m5.108-.233c.55-.164 1.163-.188 1.743-.14a4.5 4.5 0 004.486-6.336l-3.276 3.277a3.004 3.004 0 01-2.25-2.25l3.276-3.276a4.5 4.5 0 00-6.336 4.486c.091 1.076-.071 2.264-.904 2.95l-.102.085" />
          </svg>
        </div>
        <h2 className="text-lg font-semibold text-foreground mb-1">{currentAccount.name} isn't set up yet</h2>
        <p className="text-sm text-muted-foreground mb-6 max-w-sm">
          This ad account is connected but setup hasn't been completed. Finish the data connection to run analysis.
        </p>
        <Link
          href={withAccount("/app/settings/account")}
          className="px-4 py-2 rounded-lg bg-primary text-primary-foreground text-sm font-medium hover:opacity-90 transition-opacity"
          data-testid="link-finish-setup"
        >
          Finish setup
        </Link>
      </div>
    );
  }

  return <>{children}</>;
}
