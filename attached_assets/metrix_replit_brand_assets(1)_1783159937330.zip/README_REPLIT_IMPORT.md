# Metrix IAP Brand Assets for Replit

Attach this package to the Replit build and place the files under the same paths shown here.

## Main files to use

- `/public/brand/metrix-mark-512.png` — primary app logo mark
- `/public/brand/metrix-mark-original-transparent.png` — transparent high-resolution logo mark
- `/public/brand/metrix-mark-dark-tile-512.png` — app icon / square dark tile
- `/public/brand/metrix-logo-lockup-reference.jpg` — horizontal lockup reference
- `/public/brand/metrix-iap-hero-reference.png` — cinematic brand reference
- `/public/brand/metrix-og-image-1200x630.jpg` — social / OpenGraph image
- `/public/brand/favicon.ico` — favicon
- `/public/brand/metrix-brand-tokens.css` — CSS variables
- `/public/brand/metrix-brand.json` — brand metadata and UI direction
- `/components/metrix/MetrixLogo.tsx` — optional Next.js logo component

## Brand direction

Metrix IAP should feel like a dark, premium SaaS command center for paid media decision-making.

Core positioning:

> Not more data. Better decisions.

Product language to use inside the UI:

- Decision Layer
- Creative Intelligence
- Priority Read
- Signal Quality
- Decision Feed
- Creative DNA
- Sprint Matrix
- Brief Engine
- Benchmark Memory
- Change Watch

## Visual rules

- Use deep navy / near-black backgrounds.
- Use electric blue and cyan for active states, intelligence, navigation, and primary actions.
- Use amber/gold only for priority states, warnings, or strategic action emphasis.
- Use red only for true risk or critical issues.
- Keep the interface dense, sharp, analytical, and premium.
- Avoid childish gradients, generic dashboard cards, or fluffy SaaS illustrations.
- Show the decision before the chart. Data should validate the decision, not force users to interpret everything from scratch.

## Suggested favicon setup for Next.js App Router

Place these in `/app` or reference them in metadata:

```ts
export const metadata = {
  title: "Metrix IAP",
  description: "Creative intelligence and performance decision platform.",
  icons: {
    icon: "/brand/favicon.ico",
    apple: "/brand/metrix-mark-180.png",
  },
  openGraph: {
    title: "Metrix IAP",
    description: "Not more data. Better decisions.",
    images: ["/brand/metrix-og-image-1200x630.jpg"],
  },
};
```

## Suggested Tailwind/CSS usage

Import `/public/brand/metrix-brand-tokens.css` or copy the variables into your global CSS.

Use:

- `--metrix-bg` for main app background
- `--metrix-surface` for cards
- `--metrix-border` for subtle borders
- `--metrix-blue-bright` for active states
- `--metrix-amber` for priority states

## Notes

These are raster logo assets derived from the supplied Metrix logo files. If a true vector logo becomes available later, replace the PNG mark files while keeping the same filenames so the app does not need to be refactored.
