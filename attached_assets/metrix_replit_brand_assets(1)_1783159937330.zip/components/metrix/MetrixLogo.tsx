import Image from "next/image";
import Link from "next/link";

interface MetrixLogoProps {
  href?: string;
  showWordmark?: boolean;
  size?: "sm" | "md" | "lg";
  className?: string;
}

const sizeMap = {
  sm: { mark: 28, text: "text-lg" },
  md: { mark: 36, text: "text-xl" },
  lg: { mark: 48, text: "text-2xl" },
};

export function MetrixLogo({
  href = "/app",
  showWordmark = true,
  size = "md",
  className = "",
}: MetrixLogoProps) {
  const s = sizeMap[size];

  const content = (
    <div className={`flex items-center gap-3 ${className}`}>
      <Image
        src="/brand/metrix-mark-512.png"
        alt="Metrix IAP"
        width={s.mark}
        height={s.mark}
        priority
        className="h-auto w-auto drop-shadow-[0_0_18px_rgba(56,189,248,0.28)]"
      />
      {showWordmark && (
        <div className={`font-semibold tracking-[0.18em] text-slate-100 ${s.text}`}>
          METRIX <span className="text-slate-400">IAP</span>
        </div>
      )}
    </div>
  );

  return href ? <Link href={href}>{content}</Link> : content;
}
