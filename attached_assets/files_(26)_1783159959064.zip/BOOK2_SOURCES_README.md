# BOOK2 IAP Outputs — Source Package for Replit Build

**Sprint:** BOOK2 · **Client:** Bookster · **Period:** Jun 4–30, 2026
**Generated from:** `IAP-DEMO-SIGNAL-BOOK2-JUNE.csv` (ad×day×gender×age×copy) + `IAP-Device-SIGNAL-BOOK2-JUNE.xlsx` (ad×day×placement×device×platform)

No prior BOOK2-stage JSON/HTML artifacts existed in the project — these were built fresh from the two raw manual uploads via `metrix-data-bundle-prep` → `metrix-analysis-core` → `metrix-report-summary`.

## Files in this package

| File | IAP Phase | Purpose for Replit |
|---|---|---|
| `normalized_data_bundle_BOOK2.json` | IAP_DATA_BUNDLE_PREP output | Clean, structured performance data — campaign totals, copy variants, demographics, placements, devices, concept rollups, quality flags. This is the primary machine-readable source of truth. |
| `campaign_intelligence_BOOK2.json` | IAP_ANALYSIS_CORE output | Interpreted findings — executive summary, performance tiers, optimization priorities, failure patterns, winning creative formula, confidence labels per insight. |
| `BOOK2_IAP_Report_Summary.html` | IAP_REPORT_SUMMARY output (internal_dash mode) | Standalone visual dashboard (Metrix brand tokens: violet base `#17122B`, accent `#7C5CFF`, gold `#F5B62E`, lime `#8CCC40`) — use as a visual/UX reference for the webapp prototype, or embed directly. |

## Key findings to carry into the prototype

1. **C2B_STC_QF_BOOK2_T2** is the dominant creative across all three campaign iterations — reconfirms the previously established golden formula (`FW_PAS + HP_Overwhelm + TN_Empathetic`).
2. **Copy-line isolation matters within the same ad container.** The narrative/specific-detail line ("You paid for that book...") produced 50 of 109 results at $19.02 CPR; the generic price-stat line ("Books cost $18+...") produced 5 results at $170.52 CPR on similar spend.
3. **Two event-tracking gaps, same pattern.** V1 (trial) and V3 (checkout) both show near-zero results in the demo-signal export that partially recover in the placement-signal export. This matches the already-documented V1 SDK/pixel issue — treat as a tracking gate, not a creative verdict, until Jan confirms.
4. **Audience Network remains a confirmed dead placement** — $174.78 spend, 0 results.
5. **Facebook Reels shows a CPR/CTR efficiency edge over Feed** ($7.15 vs $9.24 CPR on the placement-file basis), consistent with the prior-sprint Reels > Feed finding.
6. **Female 45–54 remains the strongest core demographic** at meaningful spend ($5.87 CPR); Female 65+ again shows the click/registration divergence pattern (highest CTR, weaker CPR).
7. **No revenue/purchase event is present in either export.** ROAS is not calculable for BOOK2 — the funnel truncates at registration/checkout. Do not represent ROAS in the prototype as a live figure; represent it as "pending" or omit until purchase data is available.

## Data quality notes for the build

- Spend and results differ slightly between the two source exports (variance: $147.19 spend, and V1/V3 results are 0 in one export vs 3/28 in the other). The JSON bundle carries both raw source values plus a `reconciled` field — the prototype should surface the reconciled figures by default but keep source-level transparency available (e.g., a tooltip or drill-down), matching Metrix's confidence-labeling standard.
- Every insight in `campaign_intelligence_BOOK2.json` carries a `confidence` label (`high` / `medium` / `validation_required` / `insufficient`). If the prototype renders any of these findings as UI copy, preserve the confidence label — do not present `validation_required` or `insufficient` findings as settled.
