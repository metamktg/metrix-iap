# METRIX IAP — Official Repository

Metrix Intelligent Ads Protocol (IAP): an 11-prompt creative-intelligence engine for Meta Ads, with a Supabase backend. This repo is the canonical home for the platform's schema, seeds, and prompt documentation (Blueprint v2.0 §11.5).

## What this repo is right now

**A cleaned Stage 0 repo shell: full folder hierarchy per Blueprint §14, real migrations/seeds/prompt docs, and placeholder stubs everywhere runtime code goes.** It is GitHub-organized, not yet build-ready. `apps/*` and `packages/*` are empty skeletons (`.gitkeep` only) — no application, API, worker, or engine code has been written yet. Do not read "GitHub-ready" as "ready to run."

## Repo map (Blueprint v2.0 §14, in full)

```
supabase/
  migrations/   Runnable schema DDL, filename order (22 tables incl. global_variable_registry)
  seed/         Seed data: cohort_definitions (4 cohorts), global_variable_registry (51 codes)
  policies/     RLS policies — PENDING, hard blocker before any app connects to real data
  functions/    Edge Functions — PENDING stubs
  tests/        Migration/RLS/constraint tests — PENDING
docs/
  architecture/ Master Blueprint v2.0 — present, exported from live Drive source
  data-model/   Cohort Architecture, Listen Layer 125-metric contract, migrations README,
                reference/ (non-runnable combined SQL — do not paste into supabase/migrations/)
  iap/          PENDING — MST_CREATIVE_SCAN, MST_METHOD_REFERENCE, registry-as-doc (scope TBD)
  prompts/      The 7 cohort-aware v2.0 IAP prompt documents — present
  product/      PENDING — product loop documentation (Blueprint §4)
  security/     PENDING — service-role tenancy documentation (Blueprint §12)
  resources/    PENDING — archive manifest, non-canonical reference material
apps/           web / api / worker — empty skeletons, no code yet
packages/       iap-engine / metrix-core / schemas / db / connectors / ui — empty skeletons
tests/          integration / e2e / security — empty skeletons
```

## Hard constraints baked into the schema (do not relax)
- BSIL is suggestion-only; `bsil_suggestions.budget_scope_object` is check-constrained to campaign/ad_set.
- `alert_rules.metric <> 'roas'` (no ROAS alerts in v1; ROAS stays a reporting metric).
- `learning_registry` writes require an `approval_events` row with `approved_for = 'learning_registry'`.
- Manual creative intake requires >= 5 assets.
- Creative identity: naming-convention (`concept_code`) is primary; `ad_id` is the fallback join key. No `creative_id` field exists.
- Cohorts are first-class, per-run snapshotted, never blended. `lead_gen` and `service` are distinct cohorts sharing `required_metric_block: service_18` (decision, July 6 2026).

## Scope notes
- The 7 prompts in `docs/prompts/` are the cohort-aware v2.0 repairs. The remaining IAP prompts (MST_CREATIVE_SCAN, MST_METHOD_REFERENCE, VARIABLES_REGISTRY-as-doc, system context) are pending a scope/inclusion decision and are not yet in this repo.
- Session/handoff working documents are intentionally excluded from this repo.
- `docs/architecture/METRIX_IAP_MASTER_BLUEPRINT_v2.0.md`'s own Section 15 Gap Register still shows two items as "Open" that this repo's current state has closed (funnel registry, 5/11 doc repairs) — that's a pending correction on the live Drive source, reproduced as-is rather than silently edited here.

## What's still required before this is an engineering-ready monorepo
Root tooling (`package.json`, workspace config, CI, linting) is intentionally not included — that's the next stage, once `packages/schemas` and `packages/iap-engine` have real content to build against, not before.
