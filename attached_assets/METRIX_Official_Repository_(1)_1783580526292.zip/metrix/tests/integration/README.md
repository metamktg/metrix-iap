Integration tests — pending.
