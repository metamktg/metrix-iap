# Install and Use

## Claude.ai upload

Each Skill must be uploaded as its own ZIP.

1. Open `dist/individual-zips/`.
2. Upload the ZIPs one at a time.
3. Confirm code execution is enabled.
4. Enable the Skills.
5. Test activation with these prompts:

```text
Run IAP Data Bundle Prep on these Meta Ads exports.
```

```text
Use Metrix Analysis Core on this normalized_data_bundle.json.
```

```text
Generate a client-facing IAP report from this campaign_intelligence.json.
```

```text
Validate these 16 MST assets against the matrix plan.
```

## Claude Code / Agent SDK

Copy the Skill folders into your project:

```bash
mkdir -p .claude/skills
cp -R skills/metrix-* .claude/skills/
```

Restart Claude Code or the agent runtime.

## Recommended activation order

1. metrix-iap-routing
2. metrix-output-qa
3. metrix-data-bundle-prep
4. metrix-analysis-core
5. metrix-report-summary
6. metrix-strategy-map
7. metrix-brief-builder
8. metrix-client-library
9. metrix-mst-creative-scan
10. metrix-mst-test-engine
11. metrix-optimization-loop

## Use with care

These Skills do not connect to Meta Ads, write to ad accounts, store client data, or replace the Metrix backend. They package the reasoning, workflow, and validation layer. Any live ad action still requires backend guardrails, dry-run validation, and human approval.
