\
#!/usr/bin/env python3
"""
Package each Skill folder as an individual Claude.ai-compatible ZIP.

Run from repository root:
  python scripts/package_skills.py
"""

from pathlib import Path
import zipfile
import shutil

ROOT = Path(__file__).resolve().parents[1]
SKILLS = ROOT / "skills"
DIST = ROOT / "dist" / "individual-zips"

def zip_folder(folder: Path, out: Path):
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        for p in folder.rglob("*"):
            if p.is_file():
                z.write(p, p.relative_to(folder.parent))

def main():
    if DIST.exists():
        shutil.rmtree(DIST)
    DIST.mkdir(parents=True)
    for folder in sorted(SKILLS.iterdir()):
        if folder.is_dir():
            zip_folder(folder, DIST / f"{folder.name}.zip")
    print(f"Packaged {len(list(DIST.glob('*.zip')))} skills into {DIST}")

if __name__ == "__main__":
    main()
