\
#!/usr/bin/env python3
"""
Validate a 4x4 MST matrix map.

Input JSON example:
{
  "cells": {
    "C1A": ["CN_ICP_A", "FW_PAS", "TN_Emotional", "ST_TOFU"],
    "C1B": ["CN_ICP_A", "FW_BAB", "TN_Rational", "ST_MOFU"]
  },
  "columns": {
    "C1": ["CN_ICP_A"]
  },
  "rows": {
    "A": "ST_TOFU",
    "B": "ST_MOFU"
  },
  "diagonals": {
    "main": "FW_PAS",
    "counter": "PR_Testimonial"
  }
}
"""

from pathlib import Path
import json
import sys
from collections import Counter

POSITIONS = [f"C{c}{r}" for c in range(1,5) for r in "ABCD"]
MAIN = ["C1A", "C2B", "C3C", "C4D"]
COUNTER = ["C4A", "C3B", "C2C", "C1D"]

def main():
    if len(sys.argv) != 2:
        print("Usage: mst_matrix_validator.py matrix.json")
        return 2
    data = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
    cells = {k: set(v) for k, v in data.get("cells", {}).items()}
    issues = []
    missing = [p for p in POSITIONS if p not in cells]
    if missing:
        issues.append({"type": "missing_cells", "cells": missing})
    # Column constants
    for col, required in data.get("columns", {}).items():
        for row in "ABCD":
            pos = f"{col}{row}"
            for var in required:
                if pos in cells and var not in cells[pos]:
                    issues.append({"type": "column_constant_missing", "cell": pos, "variable": var})
    # Row shared variables
    for row, var in data.get("rows", {}).items():
        row_positions = [f"C{c}{row}" for c in range(1,5)]
        for pos in row_positions:
            if pos in cells and var not in cells[pos]:
                issues.append({"type": "row_variable_missing", "cell": pos, "variable": var})
        common = None
        existing = [cells[p] for p in row_positions if p in cells]
        if existing:
            common = set.intersection(*existing)
            # Column constants may appear as common in malformed local plans; warn on >1 angle-common variables if using strict mode.
            if var not in common:
                issues.append({"type": "row_common_variable_not_found", "row": row, "expected": var})
    # Diagonals
    diag = data.get("diagonals", {})
    for label, positions in [("main", MAIN), ("counter", COUNTER)]:
        expected = diag.get(label)
        if expected:
            for pos in positions:
                if pos in cells and expected not in cells[pos]:
                    issues.append({"type": "diagonal_variable_missing", "diagonal": label, "cell": pos, "variable": expected})
    # Distribution
    counts = Counter()
    for vars_ in cells.values():
        counts.update(vars_)
    under = [v for v, n in counts.items() if n == 1 and not v.startswith("CN_ICP")]
    print(json.dumps({
        "status": "fail" if issues else "pass",
        "issues": issues,
        "distribution_warnings": [{"variable": v, "appearances": 1} for v in under],
        "variable_counts": dict(counts)
    }, indent=2))
    return 1 if issues else 0

if __name__ == "__main__":
    raise SystemExit(main())
