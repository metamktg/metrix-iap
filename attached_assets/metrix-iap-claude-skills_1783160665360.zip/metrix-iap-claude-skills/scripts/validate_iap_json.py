\
#!/usr/bin/env python3
"""
Lightweight IAP JSON validator.

Usage:
  python scripts/validate_iap_json.py normalized_data_bundle.json normalized_data_bundle
  python scripts/validate_iap_json.py campaign_intelligence.json campaign_intelligence
  python scripts/validate_iap_json.py strategic_map.json strategic_map

This is intentionally lightweight. Product backends should replace this with full JSON Schema validation.
"""

from pathlib import Path
import json
import sys

REQUIRED = {
    "normalized_data_bundle": ["metadata", "copy_performance", "demographic_performance", "placement_performance"],
    "campaign_intelligence": ["report_metadata", "executive_summary", "performance_tables", "winning_creative_formula", "actionable_recommendations"],
    "strategic_map": ["icp_profiles", "message_pillars", "variable_combinations", "testing_hypotheses", "scaling_playbook"],
    "creative_briefs": ["briefs"],
    "mst_scan_results": ["scan_results"],
    "mst_performance_analysis": ["creative_performance", "variable_verdicts", "combination_synergies", "next_sprint_blueprint"],
    "optimization_updates": ["updated_variable_weights", "icp_priority_scores", "golden_formulas", "avoid_combinations", "budget_allocation_model"]
}

def main():
    if len(sys.argv) != 3:
        print("Usage: validate_iap_json.py <file.json> <schema_name>")
        print("Schema names:", ", ".join(REQUIRED.keys()))
        return 2
    path = Path(sys.argv[1])
    schema = sys.argv[2]
    if schema not in REQUIRED:
        print(json.dumps({"status": "fail", "error": f"Unknown schema {schema}"}))
        return 2
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception as e:
        print(json.dumps({"status": "fail", "error": f"Invalid JSON: {e}"}))
        return 1
    missing = [k for k in REQUIRED[schema] if k not in data]
    print(json.dumps({
        "status": "fail" if missing else "pass",
        "schema": schema,
        "missing": missing,
        "required": REQUIRED[schema]
    }, indent=2))
    return 1 if missing else 0

if __name__ == "__main__":
    raise SystemExit(main())
