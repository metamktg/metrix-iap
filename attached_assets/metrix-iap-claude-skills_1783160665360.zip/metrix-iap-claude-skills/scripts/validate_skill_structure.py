\
#!/usr/bin/env python3
"""
Validate Metrix IAP Skill folder structure.

Checks:
- each skill folder has SKILL.md
- YAML frontmatter has name and description
- name matches folder
- name uses lowercase letters, numbers, hyphens
- name length <= 64
- reserved words not in name
- description non-empty and <= 1024 chars
- SKILL.md <= 500 lines
"""

from pathlib import Path
import re
import sys
import json

ROOT = Path(__file__).resolve().parents[1]
SKILLS = ROOT / "skills"
NAME_RE = re.compile(r"^[a-z0-9-]{1,64}$")
RESERVED = {"anthropic", "claude"}

def parse_frontmatter(text: str):
    if not text.startswith("---\n"):
        return {}
    end = text.find("\n---", 4)
    if end == -1:
        return {}
    block = text[4:end].strip().splitlines()
    out = {}
    for line in block:
        if ":" in line:
            k, v = line.split(":", 1)
            out[k.strip()] = v.strip().strip('"').strip("'")
    return out

def main():
    errors = []
    results = []
    if not SKILLS.exists():
        errors.append("Missing skills directory")
    else:
        for folder in sorted([p for p in SKILLS.iterdir() if p.is_dir()]):
            skill_md = folder / "SKILL.md"
            record = {"folder": folder.name, "status": "pass", "issues": []}
            if not skill_md.exists():
                record["issues"].append("Missing SKILL.md")
            else:
                text = skill_md.read_text(encoding="utf-8")
                fm = parse_frontmatter(text)
                name = fm.get("name", "")
                desc = fm.get("description", "")
                if name != folder.name:
                    record["issues"].append(f"name '{name}' does not match folder '{folder.name}'")
                if not NAME_RE.match(name):
                    record["issues"].append("name must use lowercase letters, numbers, hyphens and be <=64 chars")
                if any(word in name for word in RESERVED):
                    record["issues"].append("name contains reserved word")
                if not desc:
                    record["issues"].append("description is empty")
                if len(desc) > 1024:
                    record["issues"].append("description exceeds 1024 chars")
                if len(text.splitlines()) > 500:
                    record["issues"].append("SKILL.md exceeds 500 lines")
                # verify referenced files exist for common markdown links
                for match in re.findall(r"\((references/[^)]+|examples/[^)]+|scripts/[^)]+)\)", text):
                    if not (folder / match).exists():
                        record["issues"].append(f"Referenced file missing: {match}")
            if record["issues"]:
                record["status"] = "fail"
                errors.extend([f"{folder.name}: {i}" for i in record["issues"]])
            results.append(record)
    print(json.dumps({"status": "fail" if errors else "pass", "errors": errors, "results": results}, indent=2))
    return 1 if errors else 0

if __name__ == "__main__":
    raise SystemExit(main())
