---
name: metrix-brief-builder
description: Generate execution-ready Meta Ads creative briefs from IAP strategy. Use when producing static, video, carousel, UGC, AI-UGC, or MST-ready creative briefs with variable stacks, communication focus, specs, and QA rules.
---

# metrix-brief-builder

## Purpose

Generate execution-ready creative briefs from `strategic_map.json`.

## Required inputs

- Strategic map JSON
- Campaign objective
- Asset type
- Voice style
- Client brand guidelines
- Local client library if available
- Mode: `matrix` or `general`

## Process

1. Confirm mode, asset type, and voice.
2. Select ICP, pillar, and variable stack.
3. Define Communication Focus.
4. Define creative specs.
5. Define copy architecture.
6. Define visual direction.
7. Define production checklist.
8. Define QA and success criteria.
9. Output `creative_briefs.json` and human-readable briefs.

## Matrix mode rules

- Isolated variable must be explicit.
- Control reference must be explicit.
- Locked variables must be explicit.
- Naming convention must be included and must use this MST format exactly: `{MatrixPosition}_{ConceptCodes}_{AngleCodes}_{UniqueID}`.
  - `MatrixPosition` = the assigned matrix cell, such as `C1A` or `C2D`.
  - `ConceptCodes` = global or local concept identifiers, such as `CN_ICP_BusyParents` or `CN_Design_UGC`.
  - `AngleCodes` = the tested stack codes, such as `FW_`, `TN_`, `ST_`, `AW_`, `HP_`, `PR_`, `HK_`, and/or `CTA_`.
  - `UniqueID` = a stable three-digit suffix, such as `001`.
  - Example: `C1A_CN_ICP_BusyParents_CN_Design_UGC_FW_PAS_TN_Emotional_HK_Problem_ST_TOFU_001`.
- Success criteria must include minimum read window and KPI threshold.

## General mode rules

- Scale proven patterns.
- Allow more creative freedom.
- Preserve evidence and rationale.
- Include production-ready instructions.

## References

- Read `references/brief-framework.md`.
- Read `references/io-schema.json`.

## Version history

- v1.0.1 (2026-05-08): Added explicit MST naming convention requirement for matrix-mode briefs.
- v1.0.0 (2026-05-08): Initial Metrix IAP Skill package.
