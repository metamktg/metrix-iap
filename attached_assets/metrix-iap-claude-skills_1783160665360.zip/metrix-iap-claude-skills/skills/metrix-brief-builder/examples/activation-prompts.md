# Activation Prompts for metrix-brief-builder

```text
Use metrix-brief-builder for this Metrix IAP task.
```

```text
Run the appropriate Metrix IAP workflow and apply final QA before output.
```

```text
Check this output against IAP standards and tell me what fails before I send it.
```
