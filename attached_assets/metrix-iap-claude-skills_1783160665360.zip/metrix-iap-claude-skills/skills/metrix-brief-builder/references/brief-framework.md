# Brief Framework

## Brief metadata

- brief_id
- mode
- voice
- asset_type
- strategic_source
- priority
- confidence

## Strategic foundation

- data insight
- target ICP
- message pillar
- concept code
- angle stack
- performance benchmark

## Testing framework

- matrix_position
- matrix_naming_convention
- hypothesis
- isolated variable
- control reference
- success criteria
- learning objective

## Creative specifications

- format
- dimensions
- duration
- placement
- safe zones
- production requirements

## Copy architecture

- hook
- problem/agitation or value setup
- product/solution
- proof
- CTA

## Visual direction

- composition
- style guide
- color palette
- typography
- imagery
- avoid list
