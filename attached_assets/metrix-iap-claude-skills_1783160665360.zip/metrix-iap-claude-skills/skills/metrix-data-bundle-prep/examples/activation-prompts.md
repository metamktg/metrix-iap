# Activation Prompts for metrix-data-bundle-prep

```text
Use metrix-data-bundle-prep for this Metrix IAP task.
```

```text
Run the appropriate Metrix IAP workflow and apply final QA before output.
```

```text
Check this output against IAP standards and tell me what fails before I send it.
```
