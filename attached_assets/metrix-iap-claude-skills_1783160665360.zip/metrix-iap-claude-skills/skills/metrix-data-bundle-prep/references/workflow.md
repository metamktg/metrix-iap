# Data Bundle Prep Workflow

## Normalization logic

- Standardize metric labels to: spend, impressions, clicks_all, link_clicks, purchases, revenue, cpm, cpc_all, cpc_link, ctr_all, ctr_link, cpa, roas, cvr, frequency.
- Preserve source column names in `source_metadata`.
- Convert currency strings to numeric values.
- Parse dates into ISO format.
- Merge duplicate copy variants using spend-weighted averages.
- Assign quality flags instead of deleting questionable rows.

## Funnel calculations

```text
click_to_atc_rate = add_to_cart / link_clicks
atc_to_checkout_rate = initiate_checkout / add_to_cart
checkout_to_purchase_rate = purchases / initiate_checkout
overall_cvr = purchases / link_clicks
```

## Confidence

- high: large conversion volume or high spend with consistent pattern
- medium: enough data for directional read
- validation_required: promising but underpowered
- insufficient: do not use for action

## Anomaly examples

- CTR greater than 10% or below 0.1%
- conversions without clicks
- frequency above 5 with zero conversions
- placements with engagement but zero conversion
- CPA 10x account average
