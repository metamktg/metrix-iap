---
name: metrix-data-bundle-prep
description: Normalize Meta Ads exports into an IAP-ready JSON bundle. Use when working with raw Meta Ads pivot exports, copy performance, demographic breakdowns, placement data, campaign exports, or data quality checks.
---

# metrix-data-bundle-prep

## Purpose

Normalize raw Meta Ads exports into `normalized_data_bundle.json`.

## Required inputs

- Copy/ad-level performance export
- Demographic breakdown export
- Placement breakdown export
- Ad names and copy text
- Date range
- Attribution window
- Known tracking issues
- Optional creative mapping / concept matrix

## Process

1. Confirm date range, attribution window, currency, and objective.
2. Standardize metric names.
3. Validate required columns.
4. Consolidate duplicate copy variants.
5. Parse ad naming conventions.
6. Calculate blended metrics and funnel rates.
7. Detect anomalies.
8. Assign confidence labels to each segment.
9. Output `normalized_data_bundle.json`.
10. Run JSON validation if scripts are available.

## Required checks

- No missing spend/impression/click fields without flags.
- No downstream event count exceeds upstream event count without anomaly flag.
- No unsupported conversion conclusion from weak samples.
- Creative/ad IDs remain traceable.
- Low-spend rows are not treated as proven winners.

## Output

Return structured JSON only unless the user asks for a human summary.

## References

- Read `references/workflow.md` for normalization logic.
- Read `references/io-schema.json` for output shape.
- Use root script `scripts/validate_iap_json.py` for lightweight validation.

## Version history

- v1.0.0 (2026-05-08): Initial Metrix IAP Skill package.
