---
name: metrix-output-qa
description: Quality-check Metrix IAP deliverables. Use before finalizing any analysis, report, strategy, brief, MST output, optimization recommendation, JSON payload, or client-facing document to verify schema, evidence, confidence, and IAP standards.
---

# metrix-output-qa

## Purpose

Run final quality control on Metrix IAP deliverables before handoff.

## Use this Skill before sending

- analysis reports
- client-facing reports
- strategy maps
- creative briefs
- MST scan reports
- MST performance outputs
- optimization recommendations
- local client libraries
- platform JSON payloads

## QA process

1. Identify deliverable type.
2. Confirm expected input and output schema.
3. Check evidence support for claims.
4. Check math and metric consistency.
5. Check confidence labels.
6. Check variable-code validity.
7. Check IAP phase alignment.
8. Check Meta Andromeda guardrails.
9. Check client-specific constraints.
10. Check action safety and human-approval needs.
11. Return a QA report with pass/conditional/fail.

## Failure conditions

Fail the output if:

- major claims lack evidence
- schema is unusable
- global variables are changed without authorization
- recommendations violate Meta/Andromeda rules
- live account actions are recommended without guardrails
- weak samples are presented as definitive
- MST isolation is broken but treated as valid

## References

- Read `references/qa-gates.md`.
- Use root script `scripts/validate_iap_json.py` when JSON is available.

## Version history

- v1.0.0 (2026-05-08): Initial Metrix IAP Skill package.
