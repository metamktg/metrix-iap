---
name: metrix-report-summary
description: Render IAP campaign intelligence into stakeholder-ready reports. Use when creating internal dashboards, client-facing performance reports, executive summaries, management exports, or report-builder content from structured IAP JSON.
---

# metrix-report-summary

## Purpose

Render `campaign_intelligence.json` into stakeholder-ready report output.

## Modes

- `internal_dash`: data-dense, technical, for operators
- `client_facing`: clear business narrative, for clients and executives
- `management_export`: expanded decision-support format

## Process

1. Confirm report mode and audience.
2. Use structured analysis output as source of truth.
3. Do not re-run analysis unless user requests it.
4. Populate report sections from JSON paths.
5. Preserve confidence notes and limitations.
6. Translate technical findings into action without losing evidence.
7. Output report markdown plus optional machine-readable report JSON.

## Client-facing rules

- Lead with account truth, not generic summary.
- Use plain business language.
- Keep key findings tied to metrics.
- Include what to scale, what to kill, what to validate.
- Do not bury limitations.
- Avoid AI tells and inflated certainty.

## References

- Read `references/report-templates.md`.
- Read `references/io-schema.json`.

## Version history

- v1.0.0 (2026-05-08): Initial Metrix IAP Skill package.
