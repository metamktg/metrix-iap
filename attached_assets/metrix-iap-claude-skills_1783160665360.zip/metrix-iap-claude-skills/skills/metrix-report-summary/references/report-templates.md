# Report Templates

## Internal dashboard

Sections:

1. Performance snapshot
2. Top wins
3. Failure patterns
4. Copy performance intelligence
5. Demographic performance
6. Placement intelligence
7. Funnel analysis
8. Cross-correlations
9. Winning variable stack
10. Performance tiers
11. Budget reallocation
12. Creative roadmap
13. Confidence notes

## Client-facing report

Sections:

1. Executive summary
2. Performance dashboard
3. Key insights
4. What's working
5. What's not working
6. Strategic recommendations
7. Budget optimization plan
8. Creative direction
9. Next steps
10. Confidence notes
