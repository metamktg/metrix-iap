# Strategy Map Fields

## ICP profile

- profile_id
- profile_name
- demographic_foundation
- psychographic_profile
- behavioral_signals
- funnel_entry_point
- performance_data
- message_resonance
- strategic_recommendation
- confidence_level

## Message pillar

- pillar_id
- pillar_name
- strategic_purpose
- target_icps
- funnel_application
- performance_evidence
- messaging_framework
- execution_specifications
- placement_strategy
- scaling_guidance

## Hypothesis

Use this structure:

```text
We believe that [action/change] will [expected result] because [evidence].
```

Include control, test variants, isolated variable, sample requirement, duration, success criteria, risk, expected impact, and failure plan.

## ICP field note

`behavioral_signals` may include behavioral triggers, purchase triggers, usage context, and funnel-entry cues when those patterns are supported by performance evidence.
