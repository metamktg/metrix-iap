---
name: metrix-strategy-map
description: Convert IAP analysis into strategy. Use when building ICP profiles, message pillars, variable priorities, golden formulas, hypothesis queues, scaling playbooks, or next-sprint strategic direction.
---

# metrix-strategy-map

## Purpose

Convert `campaign_intelligence.json` into strategic map output.

## Required inputs

- Campaign intelligence JSON
- Client offer/product details
- Client goals and constraints
- Optional local client library
- Optional previous strategy map or optimization updates

## Process

1. Build ICP profile registry from validated audience and creative-response patterns.
2. Build message pillar framework.
3. Create variable combination matrix.
4. Prioritize hypotheses.
5. Build scaling playbook.
6. Identify avoid-combinations and weak patterns.
7. Separate scale-now, optimize, validate, and explore.
8. Output `strategic_map.json`.

## Strategy discipline

- Do not invent ICPs from demographics alone.
- ICPs must include performance evidence and confidence.
- ICP registry entries must include: `profile_id`, `profile_name`, `demographic_foundation`, `psychographic_profile`, `behavioral_signals`, `funnel_entry_point`, `performance_data`, `message_resonance`, `strategic_recommendation`, and `confidence_level`.
- Message pillars must be executable by creative teams.
- Test hypotheses must be prioritized by impact, probability, and resource cost.
- Strategy should feed Brief Builder cleanly.

## References

- Read `references/strategy-map-fields.md`.
- Read `references/io-schema.json`.

## Version history

- v1.0.1 (2026-05-08): Added explicit minimum ICP schema requirements for Brief Builder compatibility.
- v1.0.0 (2026-05-08): Initial Metrix IAP Skill package.
