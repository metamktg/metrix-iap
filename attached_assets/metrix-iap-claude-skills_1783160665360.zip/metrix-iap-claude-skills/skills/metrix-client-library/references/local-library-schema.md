# Local Client Library Schema

```json
{
  "client_id": "",
  "client_name": "",
  "library_version": "",
  "source_files": [],
  "global_variables_used": [],
  "local_concepts": [],
  "icp_profiles": [],
  "design_systems": [],
  "cta_strategies": [],
  "message_pillars": [],
  "creative_id_map": [],
  "winning_patterns": [],
  "failed_patterns": [],
  "active_hypotheses": [],
  "evidence_notes": []
}
```
