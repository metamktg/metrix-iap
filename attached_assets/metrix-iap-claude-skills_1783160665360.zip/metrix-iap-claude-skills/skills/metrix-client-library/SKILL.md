---
name: metrix-client-library
description: Create and maintain Metrix IAP local client libraries. Use when mapping client-specific concepts, ICPs, design systems, CTAs, brand voice, creative IDs, and client evidence for Bookster, EDBIO, KOV, or new accounts.
---

# metrix-client-library

## Purpose

Create or update a Local Client Library for Metrix IAP.

## Required inputs

- Client name and account context
- Brand voice / positioning
- Meta Ads naming convention
- Creative assets or mappings
- Existing IAP reports or exports
- Client constraints
- Performance evidence
- Active hypotheses

## Process

1. Identify client-specific ICPs.
2. Create local concept codes.
3. Create design-system codes.
4. Create CTA strategy codes.
5. Map creative IDs to ad names where possible.
6. Register proven winners and failed patterns.
7. Record evidence grade and source.
8. Preserve global variable definitions unchanged.
9. Output `local_client_library.json`.

## Client examples

Use reference files as scaffolds only:

- `references/kov-local-library-notes.md`
- `references/bookster-local-library-notes.md`
- `references/edbio-local-library-notes.md`

## Caution

Never treat historical client examples as current truth unless the active client files are present. Mark inherited knowledge as historical or validation_required.

## Version history

- v1.0.0 (2026-05-08): Initial Metrix IAP Skill package.
