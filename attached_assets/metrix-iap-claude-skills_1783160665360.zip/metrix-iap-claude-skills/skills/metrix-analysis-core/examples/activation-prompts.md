# Activation Prompts for metrix-analysis-core

```text
Use metrix-analysis-core for this Metrix IAP task.
```

```text
Run the appropriate Metrix IAP workflow and apply final QA before output.
```

```text
Check this output against IAP standards and tell me what fails before I send it.
```
