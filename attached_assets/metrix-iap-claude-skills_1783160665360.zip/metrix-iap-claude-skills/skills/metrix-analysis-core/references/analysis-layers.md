# Analysis Layers

All 11 dimensions must run in sequence. Do not skip or merge dimensions.

---

## 1. Buyer Intent Funnel Analysis

Calculate for each copy variant, demographic segment, and placement:

- click_to_atc_rate
- atc_to_checkout_rate
- checkout_to_purchase_rate
- overall_cvr
- buying_intent_score
- funnel_drop_stage

**Buying intent score weighting:**
- Purchases × 10
- Initiate Checkout × 5
- Add to Cart × 2
- Link Clicks × 1

Rank all segments by buying intent score, not CTR. The funnel drop stage is the primary diagnostic for underperformers.

---

## 2. Traffic Quality Correlation Analysis

Map every copy variant to one of:
- `high_ctr_low_cvr` — engagement bait or poor message-product fit
- `low_ctr_high_cvr` — premium message, qualified traffic, do not judge on CTR
- `aligned_performance` — message-market fit confirmed

**Key signal pairs to calculate:**
- CTR (All) vs CTR (Link Clicks): ad relevance vs landing intent
- CPC (All) vs CPC (Link Clicks): traffic quality and targeting precision
- Purchase Rate per Link Click: copy-to-conversion alignment strength

---

## 3. Audience Psychology Indicators

Identify patterns in:
- Frequency tolerance by copy angle (where does ROAS decay begin?)
- CPM variance (broad resonance vs niche appeal signal)
- Multiple checkout attempts (urgency / FOMO response strength)
- Engagement depth correlation (initial interest to final conversion)

These patterns reveal how audiences are responding psychologically, not just behaviorally.

---

## 4. Creative Effectiveness Signals

Extract creative DNA signals for:
- concept (CN_ code performance delta)
- angle / framework (FW_ code performance delta)
- hook (HK_ code engagement and funnel entry)
- format (static vs video vs carousel)
- copy length (short / medium / long by placement)
- tone (TN_ code performance delta)

For each signal: calculate performance delta vs average, consistency score (appears in X of top N performers), and isolation confidence.

---

## 5. Messaging Theme Categorization

Group copy variants by strategic theme and analyze performance per group:

| Theme | Definition |
|---|---|
| Scientific / Educational | Health claims, mechanism explanations, research-backed benefits |
| Problem / Solution | Pain point identification, consequence framing, direct solution |
| Social Proof / Authority | Testimonials, popularity claims, expert endorsements |
| Emotional / Lifestyle | Transformation promises, identity positioning, aspiration |
| Relationship / Social | Partner benefits, social harmony, shared experiences |
| Feature / Product | Technical specs, product detail, functionality focus |

For each theme: copy count, aggregated metrics, top performer, bottom performer, audience fit, placement fit, recommendation (scale / optimize / test / eliminate).

---

## 6. Cross-Dimensional Pattern Recognition

Run correlations across these priority pairs:

1. Copy Theme × Demographics — message-audience resonance
2. Copy × Placement — message-placement optimization
3. Demographics × Placement — audience-placement preferences
4. Creative Format × All Dimensions — format performance variation
5. Call-to-Action × Placement — CTA effectiveness by placement
6. Copy Length × Platform — character count optimization
7. Hook Type × Awareness Level — opening strategy by audience stage
8. Tone × Funnel Stage — emotional vs rational by buyer journey
9. Proof Type × Conversion Stage — social proof / data / expert by funnel position
10. Offer Type × Demographics — if multiple offers are tested

For each correlation: record dimension pair, pattern description, sample size, confidence level, and strategic action.

---

## 7. Concept-Level Variable Extraction

Map performance to IAP global variable codes. For each code that appears in top performers, record:
- variable_code (FW_ / TN_ / ST_ / AW_ / HP_ / PR_ / HK_ / CTA_)
- appears_in_top_performers (count)
- avg_performance_lift (% vs baseline)
- recommended_expansion (specific next tests)

**Reference full code lists from variable-code-standard.md.** Do not invent codes. Do not use deprecated codes (CN_PainFirst → reclassify as HK_Problem + structural CN_).

---

## 8. Performance Tier Classification

Assign every creative to exactly one tier:

| Tier | Criteria | Action |
|---|---|---|
| 1 — Scale Winners | High ROAS + strong buying intent + efficient acquisition | Increase budget immediately |
| 2 — Optimize Candidates | High intent with bottleneck OR solid performance with iteration potential | Specific optimization per ad |
| 3 — Test / Pivot | Mixed signals or needs controlled retest | Controlled validation with isolated change |
| 4 — Eliminate | Poor performance across multiple metrics with clear failure pattern | Kill, document failure patterns |

Do not promote a creative to Tier 1 based on CTR alone.

---

## 9. Failure Pattern Documentation

For every zero-conversion segment with meaningful spend:
- segment type (copy / demographic / placement / combination)
- spend and percent of total
- engagement present (yes / no)
- diagnosis (traffic quality / offer mismatch / audience / technical)
- wasted spend calculation

Generate avoidance rules from documented failures. These feed directly to the strategy map avoid-combinations list.

---

## 10. Statistical Confidence Assessment

For every insight, assign one label:

| Label | Threshold |
|---|---|
| high | >100 conversions OR >$1,000 spend with consistent pattern |
| medium | Directional but below high threshold |
| validation_required | Promising signal, insufficient spend or time |
| insufficient | Cannot support action |

Never collapse validation_required into medium. Never present insufficient data as directional. Every insight must carry its confidence label in the output JSON.

---

## 11. Winning Variable Stack Identification

Synthesize the optimal combination from all prior dimensions:

Fields required:
- copy_theme
- copy_angle
- hook_type
- demographic_segment
- placement
- creative_format
- copy_length
- cta_type
- projected_combined_roas
- confidence_level

This is the primary feed-forward signal to IAP_STRATEGY_MAP. If confidence is below medium, label the stack as hypothesis, not proven.

---

## Insight quality standard

Every insight output must answer:
1. **What** — the pattern or finding
2. **Why** — the underlying reason
3. **So what** — the business impact
4. **Now what** — the specific action

If an insight cannot answer all four, it is not ready for output.

---

## Performance tier thresholds (for optimization loop alignment)

- Critical Scale: +20% lift vs baseline
- Scale: +10–19% lift
- Optimize: 0–9% performance
- Validate: new / unproven (5% allocation max)
- Retire: −20% or worse underperformance
