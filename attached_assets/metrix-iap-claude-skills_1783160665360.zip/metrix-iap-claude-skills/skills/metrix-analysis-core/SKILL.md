---
name: metrix-analysis-core
description: Run the IAP Analysis Core on a normalized data bundle. Use when extracting campaign intelligence, buyer-intent funnel patterns, creative DNA signals, audience insights, placement findings, performance tiers, and strategic recommendations.
---

# metrix-analysis-core

## Purpose

Run IAP Analysis Core on `normalized_data_bundle.json` and produce `campaign_intelligence.json`.

## Required inputs

- `normalized_data_bundle.json`
- Client goals and KPI targets
- Known attribution/tracking issues
- Optional client local library
- Optional Variables Registry reference

## Process

1. Validate normalized data quality before interpretation.
2. Analyze buyer-intent funnel performance.
3. Separate engagement signals from conversion signals.
4. Identify traffic quality patterns.
5. Analyze audience psychology indicators.
6. Extract creative DNA signals.
7. Categorize messaging themes.
8. Run cross-dimensional correlations.
9. Map findings to variable codes.
10. Classify performance tiers.
11. Document failures and avoid-rules.
12. Assign confidence level to each insight.
13. Output `campaign_intelligence.json`.

## Interpretation discipline

- High CTR + low CVR is a diagnostic signal, not proof of creative quality.
- Low CTR + high CVR may indicate qualified but narrow appeal.
- Never collapse attribution/tracking uncertainty into performance certainty.
- Separate facts, interpretations, and hypotheses.
- Prioritize purchase/subscription quality over click volume.

## References

- Read `references/analysis-layers.md`.
- Read `references/io-schema.json`.

## Version history

- v1.0.1 (2026-05-08): Expanded analysis-layers.md with full 11-dimension logic, insight quality standard, and performance tier thresholds.
- v1.0.0 (2026-05-08): Initial Metrix IAP Skill package.
