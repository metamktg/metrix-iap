# MST Validation Rules

Run all checks in order. A critical failure stops the scan — do not proceed to launch recommendations without resolving it or documenting the remapping decision.

---

## Check 1 — Naming convention

Every creative must follow:

```
{MatrixPosition}_{ConceptCodes}_{AngleCodes}_{UniqueID}
```

Example: `C1A_CN_ICP_BusyParents_CN_Design_UGC_FW_PAS_TN_Emotional_HK_Problem_ST_TOFU_001`

**Critical failure triggers:**
- MatrixPosition is missing or does not match a valid cell (C1A–C4D)
- Concept codes not present or do not map to a valid CN_ or local library code
- Angle codes use invalid or deprecated prefixes
- UniqueID is absent or reused across distinct creatives

**Warning triggers:**
- Name is technically parseable but inconsistently formatted vs other cells in the matrix
- Deprecated code present (e.g., CN_PainFirst) — flag for migration, do not auto-fail

---

## Check 2 — Column (concept) consistency

All four creatives within a column share the same avatar/ICP concept constants. The column is the audience isolation axis.

**Critical failure triggers:**
- A creative in column C1 carries a C2 avatar concept code
- Two different ICP concepts appear within the same column
- Column constants change between angle variations (C1A vs C1B have different CN_ICP codes)

**What this breaks:** Avatar-level performance analysis becomes invalid. You cannot attribute column performance to a specific ICP if the column is contaminated.

**Warning triggers:**
- A structural CN_ code varies across the column when it should be shared — document if intentional

---

## Check 3 — Row (angle variable) consistency

All four creatives within a row must share exactly one intended angle variable. All other angle variables should vary across the row.

**Critical failure triggers:**
- The intended shared variable is absent from one or more cells in the row
- Two angle variables are shared across all four row cells — over-constrains the row, breaks isolation
- No angle variable is shared across the row — the row has no isolation logic

**What this breaks:** Row-level signals cannot be attributed to a single variable. The crossmap leaderboard loses validity for that variable.

**Warning triggers:**
- Shared variable is present but value differs slightly in execution (e.g., same FW_ code but different copy structure) — flag for remapping decision

---

## Check 4 — Diagonal isolation

Main diagonal (C1A, C2B, C3C, C4D) and counter diagonal (C1D, C2C, C3B, C4A) each test one intended variable across maximum avatar diversity.

**Critical failure triggers:**
- The diagonal's intended isolation variable does not appear in all four diagonal cells
- A second variable is also constant across all four diagonal cells — breaks single-variable isolation
- Diagonal cells share the same avatar concept — defeats the maximum diversity purpose

**What this breaks:** Diagonal analysis is the highest-confidence isolation signal in the matrix. Contamination here eliminates the ability to make universal winner declarations.

---

## Check 5 — Variable distribution

Important variables must appear in 2–4 cells across different combinations. Single appearances produce weak isolation.

**Critical failure triggers:**
- A variable that is a primary test hypothesis appears only once in the entire matrix

**Warning triggers:**
- A variable appears in 5 or more cells — over-represented, reduces learning diversity
- A variable appears exactly once — flag as insufficient for isolation verdict, mark as `validation_required` in test engine

**Info:**
- Document variable distribution counts as part of scan output for use by MST Test Engine

---

## Check 6 — Copy-to-variable alignment

The copy text of each creative must be consistent with its assigned variable stack.

**Critical failure triggers:**
- FW_ code is PAS but copy has no problem-agitation-solution structure
- TN_ code is TN_Emotional but copy is clinical and rational throughout
- HK_ code is HK_Problem but creative opens with a benefit statement
- HP_ code references a pain point not present in the copy

**Warning triggers:**
- Variable is present but weakly expressed — flag for creative revision before launch
- CTA_ code assigned but CTA in copy is generic / not distinctive — document

**Remapping rule:** If copy cannot be revised before launch and execution genuinely reflects a different variable, remap the stack and document the matrix impact before proceeding.

---

## Check 7 — Concept adherence

Each creative must match its assigned CN_ structural code.

**Critical failure triggers:**
- CN_Testimonial assigned but no real person testimony or quote is present
- CN_ProductDemo assigned but creative is a lifestyle shot with no product interaction
- CN_Comparison assigned but no comparison structure exists in copy or visual

**What this breaks:** Concept-level performance analysis collapses. If a CN_Testimonial cell contains a product demo, the concept signal is wrong and attribution is corrupted.

---

## Severity definitions

| Severity | Definition | Launch action |
|---|---|---|
| critical | Invalidates MST learning for that cell or dimension | Do not launch until resolved or remapped with documentation |
| warning | Should be documented; may proceed with risk noted | Proceed with risk flag in scan output |
| info | Note for future iteration improvement | Proceed; include in scan output |

---

## Remapping decision tree

When execution diverges from the planned stack:

1. Can the creative be revised before launch? → Revise to match planned stack.
2. Can the stack be remapped to match execution without breaking column or row constants? → Remap, document matrix impact, update naming convention.
3. Does remapping break isolation for a column, row, or diagonal? → Remove cell from MST launch. Run with remaining cells. Flag gap in scan output.

Never launch a cell with a known critical failure without one of these three resolutions documented.

---

## Scan output fields

```
mst_scan_results:
  cell: (e.g. C1A)
  status: pass | conditional | fail
  checks:
    naming: pass | warning | critical
    column_consistency: pass | warning | critical
    row_consistency: pass | warning | critical
    diagonal_isolation: pass | warning | critical
    variable_distribution: pass | warning | info
    copy_alignment: pass | warning | critical
    concept_adherence: pass | warning | critical
  issues: [list of specific findings with severity]
  remapping_decision: (if applicable)
  launch_recommendation: proceed | proceed_with_risk | do_not_launch
```
