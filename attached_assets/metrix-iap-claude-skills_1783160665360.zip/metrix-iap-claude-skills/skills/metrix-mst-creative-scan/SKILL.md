---
name: metrix-mst-creative-scan
description: Validate Matrix Sprint Test creative assets before launch. Use when auditing MST assets, checking naming conventions, row/column/diagonal consistency, variable stack alignment, creative execution, or remapping needs.
---

# metrix-mst-creative-scan

## Purpose

Validate MST assets before launch.

## Required inputs

- 16 creative assets or creative specs
- Claimed matrix positions
- Claimed variable stacks
- Matrix specification
- Naming convention
- Copy text
- Visual descriptions or asset thumbnails

## Process

1. Validate naming convention.
2. Validate visual consistency within columns.
3. Validate copy-to-variable alignment.
4. Validate concept variable consistency.
5. Validate row pattern compliance.
6. Validate diagonal pattern compliance.
7. Validate variable distribution.
8. Recommend remapping only when execution truly diverges.
9. Output `mst_scan_results.json`.

## Severity

- critical: invalidates MST learning
- warning: should be documented but may proceed
- info: note for future iteration

## Remapping rule

If creative execution differs from the planned stack, recommend one of:

- revise creative to match planned stack
- remap variable stack and document matrix impact
- remove cell from MST launch if isolation breaks

## References

- Read `references/mst-validation-rules.md`.
- Use root script `scripts/mst_matrix_validator.py` for basic matrix validation.

## Version history

- v1.0.1 (2026-05-08): Expanded mst-validation-rules.md with check-by-check logic, failure definitions, isolation failure examples, and remapping decision tree.
- v1.0.0 (2026-05-08): Initial Metrix IAP Skill package.
