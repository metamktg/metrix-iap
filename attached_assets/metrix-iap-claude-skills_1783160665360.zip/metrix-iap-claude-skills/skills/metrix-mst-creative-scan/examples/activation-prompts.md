# Activation Prompts for metrix-mst-creative-scan

```text
Use metrix-mst-creative-scan for this Metrix IAP task.
```

```text
Run the appropriate Metrix IAP workflow and apply final QA before output.
```

```text
Check this output against IAP standards and tell me what fails before I send it.
```
