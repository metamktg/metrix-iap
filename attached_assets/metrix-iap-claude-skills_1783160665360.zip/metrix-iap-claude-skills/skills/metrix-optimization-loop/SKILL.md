---
name: metrix-optimization-loop
description: Convert IAP or MST results into updated variable weights and next-cycle recommendations. Use when re-weighting variables, classifying scale/optimize/validate/retire actions, building golden formulas, or updating strategy and brief defaults.
---

# metrix-optimization-loop

## Purpose

Update variable weights, strategy defaults, and next-cycle priorities from IAP/MST results.

## Required inputs

- MST performance analysis or campaign intelligence JSON
- Historical performance registry if available
- Current variable weights
- Client constraints
- Current strategy map and brief defaults if available

## Process

1. Validate data thresholds.
2. Calculate variable performance scores.
3. Detect lift versus baseline.
4. Apply rate limits.
5. Update framework, tonality, hook, proof, ICP, and message-pillar priorities.
6. Identify golden formulas and avoid-combinations.
7. Build budget allocation model.
8. Feed updates to Strategy Map and Brief Builder.
9. Output `optimization_updates.json`.

## Rate limits

- Maximum 2.5x weight increase per cycle.
- Maximum 0.5x weight decrease per cycle.
- Do not retire major strategic lanes from one weak sprint alone unless critical failure is clear.
- Human approval required for high-impact changes.

## Budget model

- Critical Scale: 60%
- Scale: 25%
- Optimize: 10%
- Validate: 5%

Use only when data supports it. Otherwise return a conservative allocation.

## References

- Read `references/reweighting-rules.md`.
- Read `references/io-schema.json`.

## Version history

- v1.0.1 (2026-05-08): Expanded reweighting-rules.md with full scoring formula, worked example, lift thresholds, rate limits, data thresholds, trend validation, and feed-forward output spec.
- v1.0.0 (2026-05-08): Initial Metrix IAP Skill package.
