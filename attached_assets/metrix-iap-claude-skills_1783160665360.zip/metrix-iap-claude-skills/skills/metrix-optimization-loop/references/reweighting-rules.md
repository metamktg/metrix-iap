# Reweighting Rules

---

## Performance scoring formula

```
final_score = avg_roas_score × consistency_multiplier × sample_size_factor × recency_weight
```

**Component values:**

| Component | Value |
|---|---|
| avg_roas_score | avg_roas × 100 |
| consistency_multiplier | 1.0 (low) / 1.2 (medium) / 1.3 (high) / 1.5 (very high) |
| sample_size_factor | 0.7 (<2 tests) / 1.0 (2–3 tests) / 1.1 (4–5 tests) / 1.2 (6+ tests) |
| recency_weight | 1.2 (current sprint) / 1.0 (1 sprint ago) / 0.9 (2 sprints ago) / 0.8 (3+ sprints ago) |

**Worked example:**

```
Variable: FW_PAS
Avg ROAS: 4.3 → base score: 430
Consistency: high → multiplier: 1.3
Appearances: 4 tests → sample factor: 1.1
Recency: current sprint → weight: 1.2
Final score: 430 × 1.3 × 1.1 × 1.2 = 742
```

Apply the same formula to all variable types including CTA_.

---

## Lift classification and action triggers

| Class | Threshold | Actions |
|---|---|---|
| Critical Winner | ≥ +20% vs baseline | Upgrade to Tier 1. Increase allocation to 60%+. Flag for immediate scaling. Generate expansion variations. |
| Strong Performer | +10% to +19% | Maintain or increase allocation. Continue testing in new contexts. Monitor for sustained performance. |
| Baseline | −9% to +9% | Maintain current allocation. Continue as control or comparison. |
| Underperformer | −10% to −19% | Reduce allocation by 50%. Test in limited contexts only. Flag for potential retirement. |
| Critical Failure | ≤ −20% | Retire immediately. Add to avoidance list. Document failure patterns. |

Baseline is calculated from the account average for the metric being scored. State the baseline value explicitly in the output.

---

## Rate limits

These limits apply per optimization cycle. Do not exceed them regardless of performance signal strength.

| Limit | Value |
|---|---|
| Maximum weight increase per cycle | 2.5× current weight |
| Maximum weight decrease per cycle | 0.5× current weight (50% reduction) |
| Minimum weight floor | 5% (never zero until formally retired) |
| Maximum single-variable allocation | 60% |

A variable cannot be retired from a single sprint result alone unless it is a critical failure. Require 2 consecutive sprints of underperformance for retirement of a previously proven variable.

**Human approval required for:**
- Any variable moving from active to retired status
- Any reallocation exceeding 30 percentage points in a single cycle
- Any golden formula change that affects >50% of brief-builder defaults

---

## Minimum data thresholds

Do not apply weight changes below these thresholds. Return `validation_required` and hold current weight.

| Threshold | Minimum |
|---|---|
| Spend per variable | $100 |
| Conversions per variable | 10 |
| Appearances in different contexts | 2 |
| Sprint history for isolation | 2 sprints |

---

## Trend validation

Require 2 consecutive sprints of same direction before a major weight change on a previously proven variable. A single outlier sprint does not override accumulated history.

Flag volatile variables — those with performance swings >30% between consecutive sprints — as `volatile: true` in the output. Weight long-term trend over recent spike for volatile variables.

---

## Feed-forward updates

After each reweighting cycle, output updated parameters for:

**IAP_STRATEGY_MAP:**
- icp_profile budget allocation (updated percentages)
- priority ranking (reordered by score)
- winning variables per ICP (updated lists)
- hypothesis queue (new hypotheses from combination analysis)
- retirement flags for underperforming pillars

**IAP_BRIEF_BUILDER:**
- default variable distribution (FW_, TN_, HK_, PR_ percentage allocations)
- concept preferences by ICP
- golden formula list (updated)
- avoid-combination list (updated)

---

## Budget allocation model

Apply only when data supports the full classification. If data is insufficient, return a conservative allocation with a note.

| Allocation | Budget % | Criteria |
|---|---|---|
| Critical Scale | 60% | Variables / ICPs / pillars at +20% lift |
| Scale | 25% | Variables / ICPs / pillars at +10–19% lift |
| Optimize | 10% | Variables / ICPs / pillars at 0–9% |
| Validate | 5% | New or unproven variables / new sprint hypotheses |

---

## Golden formula identification

A golden formula is a variable combination that:
- Appears in at least 2 distinct test contexts
- Produces ≥+20% lift vs baseline in both
- Is not avatar-specific (works across at least 2 ICPs)

Document each golden formula with: formula string, proven ROAS, applicable ICPs, evidence sprints, and confidence level.

---

## Avoid-combination registry

Add a combination to the avoid list when:
- It produces ≤−20% lift in 2 or more test contexts
- It consistently underperforms regardless of avatar or placement

Document each avoid-combination with: combination string, failure contexts, failure rate, and the date added.

---

## Legacy code migration

If historical data contains `CN_PainFirst`:
1. Reclassify the associated creative as the appropriate structural CN_ code (CN_Testimonial, CN_ProductDemo, etc.)
2. Add HK_Problem to the variable stack to indicate pain-first opening
3. Flag for manual review in the data quality notes
4. Do not carry CN_PainFirst forward into any new output

---

## Output fields required per cycle

```
optimization_updates:
  cycle_date:
  data_source: (MST sprint / general campaign / both)
  baseline_used:
  variable_scores: [variable_code, score, lift_class, action]
  weight_changes: [variable_code, old_weight, new_weight, rationale]
  golden_formulas: [added / updated / removed]
  avoid_combinations: [added / updated]
  icp_reallocation: [icp_id, old_allocation, new_allocation]
  pillar_reallocation: [pillar_id, old_priority, new_priority]
  human_approval_required: [list of high-impact changes]
  validation_required_holds: [variables held at current weight with reason]
  performance_forecast:
    expected_roas_improvement:
    expected_cpa_reduction:
    confidence_interval:
```
