# MST Analysis Layers

1. Creative-level performance
2. Column analysis
3. Row analysis
4. Diagonal analysis
5. Variable isolation
6. Combination synergy
7. Crossmap variable performance

## Variable verdicts

- universal_winner
- avatar_specific
- underperformer
- neutral
- insufficient_data
- avoid_combination
- golden_formula

## Next sprint blueprint

Include:

- scale immediately
- iterate
- retest
- retire
- new variables to validate
- budget allocation
- creative development focus
