---
name: metrix-mst-test-engine
description: Analyze Matrix Sprint Test performance. Use when campaign results include MST matrix positions, variable stacks, creative metrics, or when identifying universal winners, avatar-specific winners, variable isolation, and next sprint priorities.
---

# metrix-mst-test-engine

## Purpose

Analyze MST performance after a matrix test.

## Required inputs

- Per-creative performance data
- Confirmed variable stack assignments
- Matrix specification
- Spend, impressions, clicks, conversions, CPA, ROAS, CVR
- Funnel and engagement metrics where available
- Test duration and attribution window

## Process

1. Check test validity and data confidence.
2. Analyze creative-level performance.
3. Analyze columns for avatar/ICP patterns.
4. Analyze rows for cross-avatar variable signals.
5. Analyze diagonals for maximum isolation.
6. Aggregate individual variable performance.
7. Analyze combination synergy.
8. Build crossmap leaderboard.
9. Classify variables as universal winner, avatar-specific, underperformer, neutral, or insufficient.
10. Output `mst_performance_analysis.json`.

## Interpretation rules

- A winning creative is not automatically a winning variable.
- A variable needs repeated appearances in varied contexts to be isolated.
- Do not collapse row, column, and diagonal signals into one conclusion.
- If test duration or spend is insufficient, label as validation_required.

## References

- Read `references/mst-analysis-layers.md`.
- Read `references/io-schema.json`.

## Version history

- v1.0.0 (2026-05-08): Initial Metrix IAP Skill package.
