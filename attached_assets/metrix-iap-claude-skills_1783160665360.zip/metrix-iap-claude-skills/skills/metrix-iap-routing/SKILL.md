---
name: metrix-iap-routing
description: Route Metrix IAP work to the correct specialized skill. Use when a user asks to run, plan, audit, package, or troubleshoot an IAP workflow, including analysis, reporting, strategy, briefs, MST, optimization, or client library work.
---

# metrix-iap-routing

## Purpose

Use this Skill to route Metrix IAP tasks to the correct specialized Skill while preserving the IAP phase order.

## Routing rules

1. If the task is broad, identify the phase first.
2. If raw Meta Ads exports are present, route to `metrix-data-bundle-prep`.
3. If `normalized_data_bundle.json` is present, route to `metrix-analysis-core`.
4. If `campaign_intelligence.json` is present and the user wants a document/report, route to `metrix-report-summary`.
5. If the user wants ICPs, message pillars, next-sprint strategy, or test priorities, route to `metrix-strategy-map`.
6. If the user wants production-ready creative briefs, route to `metrix-brief-builder`.
7. If creative files/scripts are being validated against an MST matrix, route to `metrix-mst-creative-scan`.
8. If post-launch MST performance data is provided, route to `metrix-mst-test-engine`.
9. If the user wants variable weights, budget allocation, scale/optimize/validate/retire decisions, route to `metrix-optimization-loop`.
10. If a client-specific library must be built or updated, route to `metrix-client-library`.
11. Before final delivery, route to `metrix-output-qa`.

## IAP phase order

```text
Raw Data
→ IAP_DATA_BUNDLE_PREP
→ IAP_ANALYSIS_CORE
→ IAP_REPORT_SUMMARY
→ IAP_STRATEGY_MAP
→ IAP_BRIEF_BUILDER
→ [MST opt-in decision]
→ MST_CREATIVE_SCAN
→ MST_TEST_ENGINE
→ IAP_OPTIMIZATION_LOOP
→ Feed forward to Strategy + Briefs
```

## Required behavior

- Do not skip validation.
- Do not infer missing data if the missing data affects confidence.
- Do not recommend live ad-account changes without guardrails.
- State which downstream artifact is expected from each phase.
- Keep global variables separate from local client variables.

## References

Read `references/routing-map.md` for routing triggers and artifact dependencies.

## Version history

- v1.0.0 (2026-05-08): Initial Metrix IAP Skill package.
