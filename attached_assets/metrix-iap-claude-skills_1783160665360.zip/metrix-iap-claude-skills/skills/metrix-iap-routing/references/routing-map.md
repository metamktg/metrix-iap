# Routing Map

| User asks for | Use Skill | Expected input | Expected output |
|---|---|---|---|
| clean exports, normalize data, prepare bundle | metrix-data-bundle-prep | Meta exports | normalized_data_bundle.json |
| analyze performance | metrix-analysis-core | normalized_data_bundle.json | campaign_intelligence.json |
| client report or internal report | metrix-report-summary | campaign_intelligence.json | report markdown/doc JSON |
| strategy, ICPs, message pillars | metrix-strategy-map | campaign_intelligence.json | strategic_map.json |
| creative briefs | metrix-brief-builder | strategic_map.json | creative_briefs.json |
| validate MST assets | metrix-mst-creative-scan | assets + matrix spec | mst_scan_results.json |
| analyze MST results | metrix-mst-test-engine | performance + variable stacks | mst_performance_analysis.json |
| update weights / next cycle | metrix-optimization-loop | MST/IAP results | optimization_updates.json |
| client library | metrix-client-library | client evidence | local_client_library.json |
| QA | metrix-output-qa | any deliverable | qa_report.json |
