# Metrix IAP Claude Skills Directory

Version: 1.0.0  
Prepared for: Meta Marketing Agency / Metrix IAP  
Date: 2026-05-08

This directory packages the Metrix IAP operating system into focused Claude Skills.

## What this is

A modular skill library for the Intelligent Ads Protocol (IAP) and Metrix Sprint Test (MST), built to support:

- Meta Ads data normalization
- IAP core analysis
- stakeholder reports
- strategic mapping
- creative brief generation
- MST creative validation
- MST performance analysis
- optimization-loop reweighting
- local client library management
- final QA and evidence discipline

## Important install note

Claude.ai custom Skills are uploaded as individual Skill ZIPs. This repository ZIP is a full working directory for review, Claude Code/Agent SDK use, and developer handoff.

For Claude.ai:
1. Open `dist/individual-zips/`
2. Upload each individual skill ZIP through Claude settings
3. Enable the uploaded Skills
4. Test with the prompts in each Skill folder

For Claude Code / Agent SDK:
1. Copy each `skills/<skill-name>/` folder into `.claude/skills/`
2. Restart the agent environment
3. Run the examples in each folder

## Directory map

```text
metrix-iap-claude-skills/
├── README.md
├── INSTALL.md
├── QUALITY_REPORT.md
├── manifest.json
├── shared-references/
├── scripts/
├── skills/
└── dist/
```

## Design principle

Do not create one oversized Metrix Skill. Use focused Skills that mirror the IAP architecture. This preserves progressive disclosure, reduces context load, and keeps each workflow testable.


## v1.0.1 patch note

This patched build adds `CTA_` to the global variable standard, documents CN_ConditionSupport/CN_EnvironmentHack dual-function handling, adds the explicit MST naming convention to Brief Builder, and hardens Strategy Map ICP schema requirements.
