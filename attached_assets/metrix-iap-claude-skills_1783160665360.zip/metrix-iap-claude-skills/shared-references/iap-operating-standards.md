# IAP Operating Standards

## Non-negotiables

- Output structured JSON whenever the output will be consumed by another phase or by the Metrix platform.
- Do not produce narrative-only analysis when a schema is expected.
- Always preserve the distinction between facts, evidence-backed interpretations, and hypotheses.
- Do not create or modify global variable codes casually.
- Local client variables augment global variables; they do not replace them.
- Every recommendation must trace back to data, a validated client constraint, or an explicitly marked hypothesis.
- Do not recommend live Meta Ads write actions without guardrails, dry-run validation, and human approval.

## IAP architecture

IAP has three operating layers:

1. IAP-ISS  
   Always active. Handles data normalization, analysis, reporting, strategy, and brief generation.

2. MST  
   Optional client opt-in. Handles matrix design, variable validation, controlled testing, and performance intelligence.

3. Optimization Loop  
   Continuous learning layer. Re-weights variables and feeds learning back into Strategy Map and Brief Builder.

## Data confidence

Use confidence labels carefully:

- high: enough spend/conversions and consistent pattern
- medium: directional but not definitive
- validation_required: promising signal requiring more spend/time
- insufficient: cannot support action

Never hide limitations. If attribution delay, low sample size, tracking issues, MMP issues, or export gaps exist, state them.

## Performance hierarchy

Prefer bottom-funnel evidence over vanity engagement:

1. Purchases / subscriptions / revenue
2. Trial starts / checkouts / initiate checkout
3. Add-to-cart / lead / qualified event
4. Link clicks / landing page views
5. CTR / hook quality
6. Impressions / reach / engagement

Use CTR as a diagnostic, not as proof of purchase intent.

## Meta Andromeda alignment

- Build 4-6 distinct creative concepts, not micro-variations.
- Use broad targeting by default for top-of-funnel unless client constraints prove otherwise.
- Prefer auto placements unless data proves a material placement issue.
- Avoid judging ads before the minimum learning period.
- Do not recommend color/button/font-only creative tests.
- Check frequency, fatigue, Event Match Quality, attribution windows, and tracking quality before making major performance claims.

## Output tone

- Direct, evidence-led, operator-grade.
- Avoid generic AI tells.
- Avoid filler phrases.
- Avoid unsupported certainty.
- Use client-facing simplification only after preserving internal evidence.
