# Metrix Product Context

## Product role

Metrix is an AI-powered creative intelligence and campaign optimization platform for Meta Ads.

The platform has two jobs:

1. Analyze  
   Ingest campaign performance data and convert it into structured intelligence.

2. Act  
   Eventually execute guarded optimization decisions through the Meta Ads API.

## Current product priority

The current priority is not autonomous ad actions first. The build order is:

1. IAP Output → Database → Dashboard
2. Meta Ads API connection for live KPI, funnel, and sparkline data
3. IAP workflow runner
4. Safety guardrails and campaign action execution

## Data-source split

- Meta API feeds live KPI modules, funnel metrics, and sparklines.
- IAP output feeds analysis, creative intelligence, audience intelligence, recommendations, briefs, reports, MST logic, and strategic modules.

## Platform architecture targets

- Frontend: Next.js + TypeScript
- UI: custom CSS + shadcn/ui
- Backend: Node.js + TypeScript
- Database: PostgreSQL / Supabase
- Queue: Redis + BullMQ
- AI: Claude API
- Meta: Meta Marketing API
- Auth: Supabase Auth + Meta OAuth

## Safety

Live action execution requires:

- read-only validation first
- minimum spend thresholds
- cooldowns
- max budget-change caps
- dry-run simulation
- human approval for high-impact actions
- immutable audit logging
