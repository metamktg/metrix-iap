# Metrix IAP QA Checklist

## Before analysis

- Required files are present.
- Date range is known.
- Attribution window is known.
- Campaign objective and optimization event are known.
- Tracking/MMP issues are documented.
- Metric definitions are consistent.
- Raw data has not been silently modified.

## Before report

- Every major claim has supporting data.
- Weak samples are marked as directional.
- Wasted spend calculations reconcile.
- Winners are separated from promising signals.
- Client-facing narrative does not overstate confidence.
- The report does not re-analyze if it should only render structured JSON.

## Before strategy

- Strategy follows the strongest validated patterns.
- Hypotheses are prioritized, not exhaustive.
- Budget guidance respects data confidence and risk.
- ICPs are based on performance, not stereotypes.
- Creative direction accounts for placement and format.

## Before brief

- Variable Stack is valid.
- Communication Focus aligns with stack.
- Brief is executable by a creative team.
- Success criteria and test role are clear.
- Locked variables and rotating variables are explicit.
- If MST mode, one-variable-change discipline is preserved.

## Before MST launch

- Matrix positions are valid.
- Column constants are intact.
- Rows share exactly one intended angle variable.
- Diagonals share exactly one intended isolation variable.
- Variables are distributed enough to learn.
- Naming conventions are compliant.
- Remapping decisions are documented.

## Before optimization

- Minimum data thresholds are met.
- No decision is based on a single volatile result.
- Rate limits are applied.
- Human approval is required for high-impact actions.
- Audit log records recommendation, rationale, confidence, and evidence.
