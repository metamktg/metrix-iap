# Client Local Library Guide

## Purpose

A Local Client Library stores client-specific creative intelligence without modifying global IAP variables.

It should capture:

- ICP profiles
- client-specific concept IDs
- design systems
- CTA strategies
- message pillars
- brand voice rules
- proven winners
- failed patterns
- active hypotheses
- naming conventions
- creative-to-ad mapping
- evidence grade and source

## Standard schema

```json
{
  "client_id": "",
  "client_name": "",
  "library_version": "1.0.0",
  "last_updated": "",
  "source_files": [],
  "local_concepts": [],
  "icp_profiles": [],
  "design_systems": [],
  "cta_strategies": [],
  "message_pillars": [],
  "winning_patterns": [],
  "failed_patterns": [],
  "active_hypotheses": [],
  "creative_id_map": [],
  "evidence_notes": []
}
```

## Client examples

### KOV

Use as a local library example for an ecommerce apparel/streetwear account where restraint, product proof, and brand-specific tone matter.

Known local constraints:

- Short copy wins.
- Product proof matters.
- Overly generic macho fightwear language fails.
- Dark/near-black backgrounds are core brand fit.
- Instagram-native creative should be prioritized.
- Chuck is authority, not promotional prop.

### Bookster

Use as a local library example for app/subscription/MMP workflows.

Known local constraints:

- Attribution/event integrity must be verified before scaling.
- Trial/subscription event quality matters more than install volume alone.
- MMP configuration and postback reliability affect confidence.
- MST creative lanes should connect audience motivation to subscription quality.

### EDBIO

Use as a local library example for skincare/scalp-care and small-budget controlled tests.

Known local constraints:

- Naming hygiene may limit deterministic creative mapping.
- Controlled matrix testing is better than broad creative churn.
- Acne purchase, scalp purchase, and giveaway lead-capture lanes should stay separate unless data proves overlap.
- Japanese sourcing/production claim must be handled accurately.

## Evidence discipline

Never treat client examples as current truth without checking the current client files and exports. Mark inherited examples as historical until refreshed.
