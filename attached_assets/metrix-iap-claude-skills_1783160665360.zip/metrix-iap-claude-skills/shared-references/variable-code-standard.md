# Variable Code Standard

## Global variables

Global variables are the universal IAP creative language. They should remain stable across clients.

| Prefix | Type | Purpose |
|---|---|---|
| CN_ | Concept format | Narrative structure, creative format, concept family |
| FW_ | Framework | Persuasive structure |
| TN_ | Tonality | Communication style |
| ST_ | Funnel stage | Customer journey position |
| AW_ | Awareness level | Customer awareness state |
| HP_ | Pain point | Core pain or motivator |
| PR_ | Proof type | Credibility mechanism |
| HK_ | Hook type | Opening strategy |
| CTA_ | Call-to-action strategy | Desired user action, CTA framing, urgency/commitment level, and conversion ask |

## CTA_ handling

`CTA_` is a global variable type. Use it when the CTA strategy itself is part of the tested or analyzed angle, such as commitment level, urgency, free/trial framing, social action, or direct conversion action.

Examples include:

- `CTA_Action`
- `CTA_Low`
- `CTA_Urgency`
- `CTA_Social`
- `CTA_Free`

Do not confuse global `CTA_` variables with local client `CN_CTA_` variables. Use `CN_CTA_` only when documenting a client-specific CTA pattern inside a Local Client Library.

## Local client variables

Local variables are generated during client setup or MST activation.

Examples:

- CN_ICP_BusyParents
- CN_Design_EditorialStudy
- CN_CTA_StartFree
- CN_ICP_Male55Heritage

Rules:

- Local variables must be documented in the client library.
- Local variables must include definition, evidence source, intended use, and active/archived status.
- Never overwrite a prior local variable definition without version notes.
- New Variable Stack equals new angle. Do not reuse a matrix code for a materially different creative stack.

## CN_ConditionSupport and CN_EnvironmentHack handling

`CN_ConditionSupport` and `CN_EnvironmentHack` can function as audience-application concept codes rather than pure narrative-structure codes.

When these codes appear, classify what the creative is applying the message to, not only the visible narrative format. These codes may coexist with a structural `CN_` code or a local client concept when the creative has both:

- a narrative or design structure, and
- an audience/application context being tested.

Do not force these codes to replace the structural concept when both are materially present. Document the dual function in the variable rationale.

## Variable Stack

A creative stack should generally include:

- 1 CN_ concept or local client concept
- 1 FW_ framework
- 1 TN_ tonality
- 1-2 supporting variables from ST_, AW_, HP_, PR_, HK_, CTA_

Add more only when useful for analysis. Avoid bloated stacks that cannot be validated.

## Communication Focus

Every creative brief must include a plain-language Communication Focus that matches the variable stack.

Example:

```text
Present the mental friction of wanting to learn more but lacking time, then position the app as the low-effort bridge to comprehension.
```

This field is both human-readable creative direction and validation anchor.
