# Bookster Client Notes

Use these as local-library scaffolding only. Refresh against current Bookster files before treating as active truth.

## Strategic context

Bookster is an app/subscription client where Meta Ads performance depends on both creative quality and attribution/event reliability.

## IAP considerations

- Validate MMP/postback configuration before scaling conclusions.
- Do not optimize only for installs if downstream trial/subscription quality is the decision metric.
- Separate early funnel creative signals from paid subscriber quality.
- Map creative angles to app learning value, friction removal, trial intent, and subscription confidence.
- Attribution delay must be stated in any early-signal read.

## Useful Skill routing

- Data exports → metrix-data-bundle-prep
- Tracking caveats → metrix-analysis-core with anomaly/quality flags
- Trial/subscription strategy → metrix-strategy-map
- Creative concepts → metrix-brief-builder
- Controlled matrix testing → metrix-mst-creative-scan and metrix-mst-test-engine
