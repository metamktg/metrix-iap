# Source Map

## Official Claude Skills references

Use these to maintain Skill format and packaging standards.

1. Claude Skills overview  
   Source: official Claude documentation  
   Key rules: Skills are directories containing instructions, scripts, and resources; each Skill has `SKILL.md`; Claude loads metadata, then full instructions, then extra files only when needed.

2. How to create custom Skills  
   Source: official Claude Help Center / Claude docs  
   Key rules: Skills should solve specific repeatable tasks, include clear instructions, define when they should be used, include examples when helpful, and remain focused on one workflow.

3. Agent Skills documentation  
   Source: official Claude docs  
   Key rules: `SKILL.md` requires YAML frontmatter with `name` and `description`; names use lowercase letters, numbers, and hyphens; names must not contain reserved terms; descriptions should explain what the Skill does and when to use it.

## Metrix / IAP source references

Use these as the authoritative Metrix/IAP foundation.

1. IAP SYSTEM: COMPLETE ARCHITECTURE & PROMPT ECOSYSTEM  
   Role: master architecture. Defines IAP-ISS, MST, Optimization Loop, phase sequence, JSON-first design, and continuous feedback loop.

2. IAP SYSTEM: IMPLEMENTATION GUIDE & QUICK-START  
   Role: operating guide. Defines first-client execution, data collection, normalization, analysis, reporting, strategy, briefs, MST activation, optimization loop, cadence, and troubleshooting.

3. SYSTEM CONTEXT: IAP + Meta Andromeda Guardrails  
   Role: foundational guardrails. Defines two-silo architecture, global/local variables, concept code rules, Meta Andromeda principles, data quality rules, output standards, and safety safeguards.

4. VARIABLES_REGISTRY  
   Role: canonical variable registry. Defines global CN_, FW_, TN_, ST_, AW_, HP_, PR_, HK_ variables and strategic roles.

5. MST_METHOD_REFERENCE  
   Role: MST methodology. Defines 4x4 matrix structure, column constants, row shared variable rules, diagonal isolation, variable distribution, and anti-patterns.

6. MST_CREATIVE_SCAN  
   Role: validation engine. Defines naming checks, visual consistency, copy-to-variable alignment, concept consistency, row/diagonal compliance, distribution analysis, and remapping workflow.

7. MST_TEST_ENGINE  
   Role: performance analysis engine. Defines creative-level, column, row, diagonal, variable isolation, combination synergy, and crossmap variable performance analysis.

8. IAP_OPTIMIZATION_LOOP  
   Role: feedback and reweighting. Defines performance scoring, lift detection, re-weighting, ICP/message-pillar updates, budget allocation, feed-forward updates, and rate-limit safeguards.

9. IAP & Metrix: Complete Prompt Architecture & System Workflows  
   Role: earlier master prompt architecture. Defines Raw Data → IAP → AI Agent Training → Metrix Execution → Results Feedback Loop, plus normalization, mapping, gap detection, anomaly checks, reporting, strategy, rules, guardrails, live optimizer, and audit logging.

10. Developer Handoff Document for Metrix  
   Role: current product architecture. Defines Metrix as AI-powered creative intelligence/campaign optimization platform; priority build order; IAP output → database → dashboard; Meta API scope; workflow runner; guardrails; DB tables.

## Client-specific references

Use client references only as local library examples unless current client files are provided.

- KOV / King of Violence: validated conversion-control logic, restrained product-rooted tone, DC02 control dependency, KOV brand voice rules, challenger brief rules.
- Bookster: app subscription/MMP context, attribution-event validation, MST as creative/audience learning mechanism, full-funnel Meta with trial/subscription optimization.
- EDBIO: local library and creative-mapping hygiene, skincare/scalp-care angles, controlled MST for acne/scalp/giveaway lanes.

## Source hierarchy

When sources conflict, use this order:

1. Current user-provided files for the active client
2. Current IAP system files and Variables Registry
3. Current Metrix product docs
4. Current platform/API source documentation
5. Historical client examples
6. Memory/context notes
