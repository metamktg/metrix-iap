# EDBIO Client Notes

Use these as local-library scaffolding only. Refresh against current EDBIO files before treating as active truth.

## Strategic context

EDBIO is a skincare/scalp-care ecommerce account suited for controlled testing due to limited budget and early-stage signal needs.

## Known IAP considerations

- Naming hygiene may limit deterministic asset-to-ad mapping.
- Treat acne purchase, scalp purchase, and giveaway lead-capture lanes separately unless data proves overlap.
- Japanese sourcing/production claims require exact wording and verification.
- Prefer controlled MST structure over creative sprawl.
- Giveaway tests should be isolated; do not let giveaway lead volume contaminate purchase-intent conclusions.

## Useful Skill routing

- Library compilation → metrix-client-library
- Creative deconstruction → metrix-client-library + metrix-brief-builder
- Controlled test design → metrix-strategy-map + metrix-brief-builder
- MST validation → metrix-mst-creative-scan
