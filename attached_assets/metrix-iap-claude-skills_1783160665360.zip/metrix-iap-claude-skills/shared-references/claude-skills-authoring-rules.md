# Claude Skills Authoring Rules

## Skill structure

Each Skill folder must contain:

```text
skill-name/
└── SKILL.md
```

Additional files are optional but recommended:

```text
skill-name/
├── SKILL.md
├── references/
├── examples/
└── scripts/
```

## Metadata

`SKILL.md` must begin with YAML frontmatter.

Required:

```yaml
---
name: skill-name
description: What the Skill does and when to use it.
---
```

Name rules:

- lowercase letters, numbers, and hyphens only
- maximum 64 characters
- no XML tags
- do not use reserved platform/vendor words in the name

Description rules:

- non-empty
- maximum 1024 characters
- explain what the Skill does and when it should be used
- specific trigger phrases beat vague descriptions

## Progressive disclosure

Keep the main `SKILL.md` concise. Move detailed material into reference files.

Use references like:

```markdown
For schema details, read `references/io-schema.json`.
For validation logic, run `scripts/validator.py`.
```

## Packaging

For Claude.ai, zip each Skill folder so the folder is at the ZIP root.

Correct:

```text
metrix-analysis-core.zip
└── metrix-analysis-core/
    └── SKILL.md
```

Incorrect:

```text
metrix-analysis-core.zip
└── SKILL.md
```

## Best practices

- One workflow per Skill.
- Clear instructions.
- Clear activation description.
- Examples when useful.
- Scripts for deterministic validation.
- Version notes.
- No hardcoded secrets.
- No client private data embedded unless the Skill is private and approved.
