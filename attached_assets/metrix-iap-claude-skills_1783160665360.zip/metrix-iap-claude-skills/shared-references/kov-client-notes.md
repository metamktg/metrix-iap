# KOV Client Notes

Use these as local-library scaffolding only. Refresh against current KOV files before treating as active truth.

## Strategic context

KOV / King of Violence is a combat-heritage streetwear ecommerce brand where the winning territory is restrained, product-rooted, masculine, and specific.

## Known creative rules

- Short copy wins.
- Declare; do not sell.
- Product specifics convert.
- Avoid motivational poster language.
- Avoid generic tough-guy fightwear tropes.
- Anti-fashion framing can work.
- Dark / near-black visual systems fit the brand.
- Instagram-native creative should be primary.
- Chuck is authority, not a promotional prop.
- Keep DC02-like validated controls live during challenger testing.

## Known examples of approved territory

- Violence, done right.
- Built for pressure.
- Heavyweight feel. Athletic fit. Built to be worn cold.
- Made from legends. This isn't fashion. It's King of Violence.
- Built by fighters. Worn by people who prefer to not get punched.

## IAP caution

KOV patterns are client-specific. Do not generalize KOV's restrained fight-culture language to unrelated accounts.
